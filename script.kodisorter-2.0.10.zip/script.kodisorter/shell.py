"""Sortovia 2.0's window: a side bar that never goes away (7 places) and one page beside it.

Pages are plain data, a list of widgets (pictures, text, buttons), made by the pure functions below. Window
turns them into Kodi's own controls (1280x720, like screens.py); tools/render_ui.py draws the same widgets to a
PNG to check them against the design. Rounded shapes are pictures made at the exact size they're shown
(tools/make_ui_images.py), so their corners never stretch.

Controller: Left from a page's first column goes to the side bar, Right comes back. Y (Info) opens Search and
X (Context menu) opens Downloads from anywhere; a page can take X for itself (more for this row).
"""
import re

MEDIA = "special://home/addons/script.kodisorter/resources/media/ui/"
W, H = 1280, 720
SIDE_W = 208
X0, X1 = 240, 1248          # the page's left and right edge
CW = X1 - X0                 # 1008

# colours, "AARRGGBB"
BG = "FF0E161E"
SIDE = "FF0A1117"
CARD = "FF141F29"
CARD_FOCUS = "FF1B2A37"
LINE = "FF22303C"
TEAL = "FF2EC4B6"
TEAL_FOCUS = "FF0B6E65"       # a chosen button with the cursor on it: darker green, white text (2.0.6: the light
                              # green it was barely showed)
NAVY = "FF0F1A24"            # text on teal
FG = "FFEEF2F5"
MUTE = "FF93A3AF"
DIM = "FF6B7B87"
TAGS = {"REAL-DEBRID": "FF2EC4B6", "YOUTUBE": "FFF2C14E", "PHONE": "FF8AB4F8", "BIGLYBT": "FFB8C2CC",
        "TORRENT": "FF2EC4B6"}
GOOD = "FF4CD07D"
BAD = "FFE5534B"

FONT = {"title": "font32_title", "h": "font14", "body": "font12", "small": "font10", "big": "font13"}
FONT_SIZES = {"normal": dict(FONT), "large": {"title": "font32_title", "h": "font14", "body": "font13",
                                               "small": "font12", "big": "font14"}}
LEFT, RIGHT, CENTER, MIDDLE = 0, 1, 2, 4


def set_text_size(size):
    """Settings > Look: "normal" or "large" (each text a step bigger)."""
    FONT.clear()
    FONT.update(FONT_SIZES.get(size) or FONT_SIZES["normal"])

NAV = [("home", "Home", "home"), ("search", "Search", "search"), ("downloads", "Downloads", "download"),
       ("transfer", "Transfer / sort", "transfer"), ("music", "Music", "music"), ("library", "Library", "library"),
       ("settings", "Settings", "settings")]
NAV_Y, NAV_H, NAV_STEP = 96, 50, 58

# Y and X on a controller, and the keys Kodi gives them (Info is I on a keyboard, Context menu is C)
ACT_LEFT, ACT_RIGHT, ACT_UP, ACT_DOWN, ACT_SELECT = 1, 2, 3, 4, 7
ACT_PAGE_UP, ACT_PAGE_DOWN = 5, 6
ACT_SCROLL_UP, ACT_SCROLL_DOWN = 111, 112  # what some controller keymaps give the triggers
PAGE_UPS, PAGE_DOWNS = (ACT_PAGE_UP, ACT_SCROLL_UP), (ACT_PAGE_DOWN, ACT_SCROLL_DOWN)
ACT_Y = (11, 18)  # Info (I on a keyboard), and FullScreen: what Kodi's controller keymap gives Y
ACT_X = (117,)
ACT_BACK = (9, 10, 13, 92)
ACT_MOUSE_UP, ACT_MOUSE_DOWN = 104, 105

SHAPES = {}  # file name -> (w, h, radius, fill, line, line width), everything the pages ask for


def shape(w, h, r, fill, line=None, lw=0):
    """The picture of a rounded box at exactly w x h (made by tools/make_ui_images.py)."""
    name = "rr_%dx%d_r%d_%s_%s%d.png" % (w, h, r, fill[2:].lower(), (line or "none")[2:].lower() if line else "none", lw)
    SHAPES[name] = (w, h, r, fill, line, lw)
    return name


ICONS = ("home", "search", "download", "transfer", "music", "library", "settings", "pencil", "list", "check",
         "phone", "image", "wave", "disc", "undo", "folder", "report", "broom", "space", "tv", "globe", "album",
         "comic", "text", "wrench", "sliders", "cloud", "play", "eye", "help", "refresh", "chevron", "logo",
         "box_on", "box_off", "toggle_on", "toggle_off", "hint_a", "hint_b", "hint_x", "hint_y", "hint_ls", "hint_rs", "dot", "ok_circle",
         "link", "pause", "trash", "backup")


def icon(name):
    return "icon_%s.png" % name


# ---------- widgets ----------
def img(key, x, y, w, h, src, color=None):
    return {"t": "img", "key": key, "x": x, "y": y, "w": w, "h": h, "src": src, "color": color}


def text(key, x, y, w, h, s, font="body", color=FG, align=LEFT | MIDDLE):
    return {"t": "text", "key": key, "x": x, "y": y, "w": w, "h": h, "s": s, "font": font, "color": color,
            "align": align}


def button(key, x, y, w, h, off, on, label="", font="body", color=FG, focus_color=None, align=LEFT | MIDDLE,
           pad=0):
    return {"t": "btn", "key": key, "x": x, "y": y, "w": w, "h": h, "off": off, "on": on, "s": label,
            "font": font, "color": color, "focus_color": focus_color or color, "align": align, "pad": pad}


def bar(key, x, y, w, h, frac, color=TEAL, back=LINE):
    """A progress bar: the track and the filled part (never wider than the track)."""
    frac = max(0.0, min(1.0, frac or 0.0))
    fill = max(h, int(round(w * frac))) if frac > 0 else 0
    out = [img(key + ":track", x, y, w, h, shape(w, h, h // 2, back))]
    if fill:  # 2.0.6: the whole bar's picture, shown at the filled width (Kodi stretches it): a picture per width
        out.append(img(key + ":fill", x, y, fill, h, shape(w, h, h // 2, color)))  # was missing for most amounts
    return out


def tag(key, x, y, name):
    """A small outlined label: REAL-DEBRID, YOUTUBE, PHONE, BIGLYBT, TORRENT. Returns (widgets, width)."""
    colour = TAGS.get(name, MUTE)
    w = 18 + 9 * len(name)
    return [img(key + ":box", x, y, w, 20, shape(w, 20, 4, BG, colour, 1)),
            text(key + ":s", x, y, w, 20, "[B]%s[/B]" % name, "small", colour, CENTER | MIDDLE)], w


def short(s, n):
    s = re.sub(r"\s+", " ", s or "").strip()
    return s if len(s) <= n else s[:n - 1].rstrip() + "..."


# ---------- the frame: side bar, background, page title, hints ----------
def side_bar(current, status):
    """status: {"downloads": badge count, "drive": "D:\\", "free": "1.2 TB free", "used": 0..1, "version": "2.0"}"""
    out = [img("bg", 0, 0, W, H, shape(W, H, 0, BG)),
           img("side", 0, 0, SIDE_W, H, shape(SIDE_W, H, 0, SIDE)),
           img("side:edge", SIDE_W - 1, 0, 1, H, shape(1, H, 0, LINE)),
           img("logo", 22, 26, 32, 32, icon("logo")),
           text("brand", 66, 26, 140, 32, "[B]Sortovia[/B]", "h", FG)]
    for n, (key, label, ic) in enumerate(NAV):
        y = NAV_Y + n * NAV_STEP
        on = key == current
        out.append(button("nav:" + key, 12, y, 184, NAV_H,
                          shape(184, NAV_H, 10, "FF1A2734") if on else shape(184, NAV_H, 10, SIDE),
                          shape(184, NAV_H, 10, "FF1A2734", TEAL, 2)))
        if on:
            out.append(img("nav:%s:mark" % key, 12, y + 10, 4, NAV_H - 20, shape(4, NAV_H - 20, 2, TEAL)))
        out.append(img("nav:%s:icon" % key, 30, y + 13, 24, 24, icon(ic), TEAL if on else MUTE))
        out.append(text("nav:%s:s" % key, 68, y, 96 if key == "downloads" else 124, NAV_H, "[B]%s[/B]" % label if on else label, "body",
                        FG if on else "FFC9D3DA"))
        if key == "downloads" and status.get("downloads"):
            out.append(img("nav:badge", 170, y + 14, 24, 22, shape(24, 22, 11, TEAL)))
            out.append(text("nav:badge:s", 170, y + 14, 24, 22, "[B]%d[/B]" % status["downloads"], "small", NAVY,
                            CENTER | MIDDLE))
    out.append(img("foot:line", 22, 612, 164, 1, shape(164, 1, 0, LINE)))
    # 2.0.10: no free space or bar (the Xbox never lets an add-on read a drive's free space)
    out.append(text("foot:drive", 22, 622, 164, 24, "Library on %s" % status.get("drive", ""), "small", FG))
    out.append(text("foot:clock", 22, 648, 164, 24, CLOCK, "small", "FFC9D3DA"))  # 2.0.10: the time, kept by Kodi
    out.append(text("foot:ver", 22, 676, 164, 24, "Version %s" % status.get("version", ""), "small", DIM))
    return out


CLOCK = "$INFO[System.Time]"  # Kodi fills in the time itself and keeps it current


def page_title(title, sub=""):
    out = [text("title", X0, 24, 600, 48, "[B]%s[/B]" % title, "title", FG)]
    if sub:
        x = X0 + 20 + int(len(title) * 21)
        out.append(text("sub", x, 34, X1 - x, 34, sub, "small", MUTE))
    return out


def hints(pairs, x=X0, y=682):
    """[("a", "Open"), ("b", "Back"), ...] along the bottom."""
    out = []
    pairs = list(pairs)
    if ("b", "Back") in pairs:  # 2.0.8: what Left and Right at the edges do, beside Back
        i = pairs.index(("b", "Back")) + 1
        pairs[i:i] = [("ls", "Top row"), ("rs", "Bottom row")]
    for letter, label in pairs:
        out.append(img("hint:%s" % letter, x, y + 2, 22, 22, icon("hint_" + letter)))
        out.append(text("hint:%s:s" % letter, x + 27, y, min(160, W - x - 31), 26, label, "small", MUTE))
        x += 27 + 8 * len(label) + 24
    return out


DEFAULT_HINTS = [("a", "Open"), ("b", "Back"), ("y", "Search"), ("x", "Downloads")]


# ---------- pages ----------
class Page(object):
    """What one page shows. widgets: the list; rows: [[button key]] the D-pad grid (top to bottom, left to right);
    focus: the key to start on; live: seconds between refreshes (0: never); x_own: X is this page's (more for
    a row) instead of Downloads."""

    def __init__(self, name, widgets, rows, focus=None, live=0, x_own=False, scroll=None, place=None):
        self.name, self.widgets, self.rows, self.live, self.x_own = name, widgets, rows, live, x_own
        self.place = place or name  # the side bar place it lights up
        self.focus = focus or (rows[0][0] if rows and rows[0] else "nav:" + name)
        self.jump = {}  # {button key: key that Right goes to} where the grid's own Right would stay put
        self.scroll = scroll or {}  # {"first slot key": ..., "last slot key": ..., "more_up": bool, "more_down": bool}

    def keys(self):
        return [w["key"] for w in self.widgets if w["t"] == "btn"]


def navigation(page):
    """{key: (up, down, left, right)} for every button: the page grid, and the side bar in its own column.
    2.0.8: Left and Right go to the nearest thing that way: Left from a row's first button goes to the side bar
    place level with it, Right from the side bar to the page button level with it. Left in the side bar goes to
    the page's top row, and Right from a row's last button to the bottom row. Up and down in a row of a
    different length go to the nearest column."""
    nav = {}
    side = ["nav:" + k for k, _, _ in NAV]
    rows = [r for r in page.rows if r]
    mid = dict((w["key"], w["y"] + w["h"] / 2.0) for w in page.widgets if w.get("t") == "btn")
    for i, k in enumerate(side):
        mid.setdefault(k, NAV_Y + i * NAV_STEP + NAV_H / 2.0)

    def level(key, choices):
        y = mid.get(key, 0)
        return min(choices, key=lambda o: (abs(mid.get(o, 0) - y), choices.index(o))) if choices else key

    firsts = [r[0] for r in rows]
    top = rows[0][0] if rows else None
    bottom = rows[-1] if rows else []
    for i, k in enumerate(side):
        nav[k] = (side[i - 1], side[(i + 1) % len(side)], top or k, level(k, firsts) if rows else k)

    def col_x(row, n):
        return n / float(max(len(row) - 1, 1))

    for r, row in enumerate(rows):
        for n, k in enumerate(row):
            def nearest(other):
                if not other:
                    return k
                target = col_x(row, n)
                return min(other, key=lambda o: abs(col_x(other, other.index(o)) - target))
            up = nearest(rows[r - 1]) if r > 0 else k
            down = nearest(rows[r + 1]) if r + 1 < len(rows) else k
            sc = page.scroll
            if sc.get("more_down") and k == sc.get("last"):
                down = k  # 2.0.2: the list pages on instead (Kodi moving to the buttons too made the scroll put it back)
            if sc.get("more_up") and k == sc.get("first"):
                up = k
            left = row[n - 1] if n > 0 else level(k, side)
            if n + 1 < len(row):
                right = row[n + 1]
            elif k in page.jump:
                right = page.jump[k]
            elif r + 1 < len(rows):
                right = bottom[0]
            else:
                right = k
            nav[k] = (up, down, left, right)
    return nav


CARD_W, CARD_H, CARD_GAP = 496, 130, 16


def cards_page(name, title, sub, items, status, focus=None, current=None, top=84):
    """Two columns of cards, at most 8: items [(key, icon, title, description, opens_more)]."""
    out = side_bar(current or name, status) + page_title(title, sub)
    rows, row = [], []
    rows_n = (len(items) + 1) // 2
    h = CARD_H if rows_n <= 4 else (H - top - 60 - CARD_GAP * (rows_n - 1)) // rows_n
    for i, (key, ic, head, desc, more) in enumerate(items):
        r, c = divmod(i, 2)
        x, y = X0 + c * (CARD_W + CARD_GAP), top + r * (h + CARD_GAP)
        out.append(button(key, x, y, CARD_W, h, shape(CARD_W, h, 12, CARD, LINE, 1),
                          shape(CARD_W, h, 12, CARD_FOCUS, TEAL, 2)))
        mid = y + h // 2
        out.append(img(key + ":iconbox", x + 22, mid - 30, 60, 60, shape(60, 60, 12, "FF17323A")))
        out.append(img(key + ":icon", x + 36, mid - 16, 32, 32, icon(ic), TEAL))
        out.append(text(key + ":h", x + 104, mid - 30, CARD_W - 150, 32, "[B]%s[/B]" % head, "h", FG))
        out.append(text(key + ":d", x + 104, mid + 2, CARD_W - 150, 28, desc, "small", MUTE))
        if more:
            out.append(img(key + ":more", x + CARD_W - 40, mid - 10, 20, 20, icon("chevron"), MUTE))
        row.append(key)
        if c == 1:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    out += hints(DEFAULT_HINTS)
    return Page(name, out, rows, focus if focus in [k for k, _, _, _, _ in items] else None, place=current or name)


def badge_width(count):
    """A count bubble wide enough for its number: round for 1-2 digits, longer for more."""
    return max(22, 10 + 9 * len(str(count)))


def pill_width(label, per=8.2, pad=36):
    return int(pad + per * len(re_plain(label)))


def re_plain(s):
    return re.sub(r"\[/?[A-Z]+[^\]]*\]", "", s or "")


def chips(items, y=34):
    """Status chips at the top right: [(text, good)] -> widgets, right to left."""
    out, x = [], X1
    for n, (label, good) in enumerate(reversed(items)):
        w = pill_width(label, 8.2, 44)
        x -= w
        out.append(img("chip%d" % n, x, y, w, 26, shape(w, 26, 13, "FF121C25", LINE, 1)))
        out.append(img("chip%d:dot" % n, x + 12, y + 9, 8, 8, icon("dot"), GOOD if good else BAD))
        out.append(text("chip%d:s" % n, x + 26, y, w - 30, 26, label, "small", "FFC9D3DA"))
        x -= 8
    return out


def toggle(key, x, y, on):
    """A switch button 48x24 (the focus ring is the picture's own box)."""
    return [button(key, x - 4, y - 4, 56, 32, shape(56, 32, 16, "00000000"), shape(56, 32, 16, "00000000", TEAL, 2)),
            img(key + ":knob", x, y, 48, 24, icon("toggle_on" if on else "toggle_off"))]


def dl_row(key, x, y, w, h, row, bar_x, bar_w, focus_fill=CARD_FOCUS):
    """One download: name, tag and details under it, the bar, the percent (or state) and speed or a note.
    row: {"name", "tag", "info", "frac" (0..1 or None), "state" (text shown instead of the percent, or ""),
    "state_color", "right"}"""
    out = [button(key, x, y, w, h, shape(w, h, 10, CARD, LINE, 1), shape(w, h, 10, focus_fill, TEAL, 2))]
    out.append(text(key + ":name", x + 18, y + 8, bar_x - x - 40, 28, short(row.get("name"), 60), "body", FG))
    t, tw = tag(key + ":tag", x + 18, y + h - 30, row.get("tag") or "PHONE")
    out += t
    out.append(text(key + ":info", x + 26 + tw, y + h - 33, bar_x - x - tw - 60, 26, row.get("info", ""), "small",
                    MUTE))
    frac = row.get("frac")
    colour = row.get("state_color") or TEAL
    out += bar(key + ":bar", bar_x, y + h // 2 - 3, bar_w, 6, frac or 0, colour if row.get("state") else TEAL)
    state = row.get("state") or ("%d%%" % int(round((frac or 0) * 100)))
    out.append(text(key + ":pct", bar_x + bar_w + 14, y, 80, h, "[B]%s[/B]" % state, "body",
                    row.get("state_color") or FG))
    out.append(text(key + ":right", bar_x + bar_w + 90, y, x + w - (bar_x + bar_w + 90) - 18, h, row.get("right", ""),
                    "small", MUTE, RIGHT | MIDDLE))
    if "ticked" in row:  # 2.0.8: Y ticks it, A then works on every ticked one (hidden, not missing, when unticked)
        out.append(img(key + ":tick", x + w - 30, y + 6, 20, 20, icon("box_on"), None if row["ticked"] else "00FFFFFF"))
    return out


def home_page(status, phone=None, rd="", banner=None, active=0, speed="", rows=(), finished="", new=(), auto=False,
              last="", focus=None):
    """Home: the search box, what's downloading (top 4), what just landed, the auto move switch.
    banner: [(key, text)] shown above the search box only when they apply (resume a sort, moving now)."""
    out = side_bar("home", status) + page_title("Home")
    out += chips(([("Phone connected", True)] if phone else [("Phone not answering", False)] if phone is False else [])
                 + ([(rd, True)] if rd else []))
    grid = []
    y = 84
    for n, (key, label) in enumerate(banner or []):
        out.append(button("banner:" + key, X0, y, CW, 40, shape(CW, 40, 10, "FF15303A", TEAL, 1),
                          shape(CW, 40, 10, "FF1C4450", TEAL, 2), label, "body", FG, pad=18))
        grid.append(["banner:" + key])
        y += 48
    box_w = 848
    out.append(button("home:box", X0, y, box_w, 62, shape(box_w, 62, 12, "FF16222D", LINE, 2),
                      shape(box_w, 62, 12, "FF16222D", TEAL, 2)))
    out.append(img("home:box:icon", X0 + 22, y + 19, 24, 24, icon("search"), TEAL))
    out.append(text("home:box:s", X0 + 64, y, box_w - 90, 62, "Search TV, movies, music, tutorials and comics",
                    "big", MUTE))
    out.append(button("home:go", X0 + box_w + 12, y, CW - box_w - 12, 62, shape(CW - box_w - 12, 62, 12, TEAL),
                      shape(CW - box_w - 12, 62, 12, TEAL_FOCUS), "[B]Search[/B]", "big", NAVY, FG,
                      CENTER | MIDDLE))
    grid.append(["home:box", "home:go"])
    out.append(text("home:boxhint", X0, y + 68, 700, 24,
                    "One search for torrents and YouTube.  A pasted link works here too.", "small", MUTE))
    top = y + 112
    # downloading now
    pw, ph = 624, 664 - top
    out.append(img("dl:panel", X0, top, pw, ph, shape(pw, ph, 14, CARD, LINE, 1)))
    out.append(text("dl:h", X0 + 22, top + 12, 200, 32, "[B]Downloading now[/B]", "h", FG))
    out.append(text("dl:sub", X0 + 232, top + 12, 200, 32, ("%d active  ·  %s" % (active, speed)) if active
                    else "nothing downloading", "small", MUTE))
    out.append(button("dl:all", X0 + pw - 86, top + 14, 70, 28, shape(70, 28, 8, CARD), shape(70, 28, 8, CARD, TEAL, 2),
                      "[B]See all[/B]", "small", TEAL, TEAL, CENTER | MIDDLE))
    grid.append(["dl:all"])
    slot = (ph - 60 - 52) // 4
    for i in range(4):
        ry = top + 52 + i * slot
        if i < len(rows):
            r = rows[i]
            out.append(button("dl:%d" % i, X0 + 10, ry, pw - 20, slot - 4, shape(pw - 20, slot - 4, 8, CARD),
                              shape(pw - 20, slot - 4, 8, CARD_FOCUS, TEAL, 2)))
            out.append(text("dl:%d:name" % i, X0 + 22, ry + 6, pw - 140, 28, short(r.get("name"), 50), "body", FG))
            state = r.get("state") or "%d%%" % int(round((r.get("frac") or 0) * 100))
            out.append(text("dl:%d:pct" % i, X0 + pw - 122, ry + 6, 100, 28, "[B]%s[/B]" % state, "body",
                            r.get("state_color") or (FG if not r.get("state") else MUTE), RIGHT | MIDDLE))
            t, tw = tag("dl:%d:tag" % i, X0 + 22, ry + 40, r.get("tag") or "PHONE")
            out += t
            out.append(text("dl:%d:info" % i, X0 + 30 + tw, ry + 37, 290 - tw, 26, r.get("info", ""), "small", MUTE))
            out += bar("dl:%d:bar" % i, X0 + 320, ry + 47, pw - 342, 6, r.get("frac") or 0)
            grid.append(["dl:%d" % i])
        if i < 3:
            out.append(img("dl:line%d" % i, X0 + 22, ry + slot - 2, pw - 44, 1, shape(pw - 44, 1, 0, LINE)))
    if finished:
        out.append(img("dl:done:icon", X0 + 22, top + ph - 44, 20, 20, icon("ok_circle"), GOOD))
        out.append(text("dl:done", X0 + 52, top + ph - 48, pw - 70, 28, finished, "small", "FFC9D3DA"))
    # new in your library
    rx, rw = X0 + pw + 16, CW - pw - 16
    nh = 324 if top + 324 + 16 + 128 <= 664 else 664 - top - 16 - 128
    out.append(img("new:panel", rx, top, rw, nh, shape(rw, nh, 14, CARD, LINE, 1)))
    out.append(text("new:h", rx + 22, top + 12, rw - 44, 32, "[B]New in your library[/B]", "h", FG))
    step = (nh - 60) // 4
    for i in range(4):
        ny = top + 52 + i * step
        if i < len(new):
            name, sub = new[i]
            out.append(text("new:%d" % i, rx + 22, ny + 4, rw - 44, 26, short(name, 34), "body", FG))
            out.append(text("new:%d:sub" % i, rx + 22, ny + 30, rw - 44, 22, sub, "small", MUTE))
        if i < 3:
            out.append(img("new:line%d" % i, rx + 22, ny + step - 2, rw - 44, 1, shape(rw - 44, 1, 0, LINE)))
    ay = top + nh + 16
    ah = 664 - ay
    out.append(img("auto:panel", rx, ay, rw, ah, shape(rw, ah, 14, CARD, LINE, 1)))
    out.append(text("auto:h", rx + 22, ay + 14, rw - 110, 26, "[B]Move finished downloads[/B]", "body", FG))
    out.append(text("auto:sub", rx + 22, ay + 38, rw - 110, 22, "to the library by themselves", "small", MUTE))
    out += toggle("auto", rx + rw - 70, ay + 24, auto)
    out.append(img("auto:line", rx + 22, ay + ah - 52, rw - 44, 1, shape(rw - 44, 1, 0, LINE)))
    out.append(text("auto:last", rx + 22, ay + ah - 48, 160, 40, "Last transfer / sort", "small", MUTE))
    out.append(text("auto:when", rx + 178, ay + ah - 48, rw - 200, 40, last or "not yet", "small", FG, RIGHT | MIDDLE))
    for g in grid:  # the switch sits right of See all, so Right from See all reaches it
        if g[0] == "dl:all":
            g.append("auto")
            break
    out += hints(DEFAULT_HINTS)
    return Page("home", out, grid, focus or "home:box", live=3)


DL_SLOTS, DL_TOP, DL_H, DL_STEP = 6, 132, 68, 76


def downloads_page(status, active=0, speed="", auto=False, filters=(), shown="all", rows=(), offset=0,
                   buttons=(), focus=None, note="", auto_note="", empty=""):
    """filters: [(key, label, count)]; rows: dl_row dicts (all of them: offset says which are on screen);
    buttons: [(key, label)] along the bottom."""
    out = side_bar("downloads", status) + page_title("Downloads", ("%d active  ·  %s" % (active, speed))
                                                     if active else note)
    out.append(text("clock", X1 - 560, 34, 80, 26, "[B]%s[/B]" % CLOCK, "body", FG, RIGHT | MIDDLE))  # 2.0.10
    out.append(text("auto:s", X1 - 470, 34, 394, 26, auto_note or "Move finished to the library by themselves",
                    "small", MUTE, RIGHT | MIDDLE))  # 2.0.8: when it last moved and when it looks next
    out += toggle("auto", X1 - 52, 35, auto)
    grid = [[], ]
    x = X0
    for key, label, count in filters:
        on = key == shown
        bw = badge_width(count)  # 2.0.6: fits 3 and 4 digits ("1..." was all of 125)
        w = pill_width(label, 9.6, 44) + bw
        out.append(button("f:" + key, x, 78, w, 40, shape(w, 40, 10, TEAL) if on else shape(w, 40, 10, CARD, LINE, 1),
                          shape(w, 40, 10, TEAL_FOCUS) if on else shape(w, 40, 10, CARD_FOCUS, TEAL, 2),
                          "[B]%s[/B]" % label if on else label, "body", NAVY if on else FG, FG, pad=16))
        out.append(img("f:%s:badge" % key, x + w - bw - 12, 87, bw, 22, shape(bw, 22, 11, "FF0F1A24" if on else "FF22303C")))
        out.append(text("f:%s:n" % key, x + w - bw - 12, 87, bw, 22, "[B]%d[/B]" % count, "small", FG, CENTER | MIDDLE))
        grid[0].append("f:" + key)
        x += w + 8
    grid[0].append("auto")
    visible = list(rows)[offset:offset + DL_SLOTS]
    for i in range(DL_SLOTS):
        y = DL_TOP + i * DL_STEP
        if i < len(visible):
            out += dl_row("row:%d" % i, X0, y, CW, DL_H, visible[i], 770, 210)
            grid.append(["row:%d" % i])
    if not rows:
        out.append(text("empty", X0, DL_TOP, CW, 60, empty or "Nothing here.", "body", MUTE, CENTER | MIDDLE))
    if len(rows) > DL_SLOTS:
        out.append(text("more", X1 - 200, 586, 200, 18, "%d-%d of %d" % (offset + 1, offset + len(visible), len(rows)),
                        "small", DIM, RIGHT | MIDDLE))
    gap = 12
    # sized for the longer of a button's two labels, so "Pause all" / "Resume all" doesn't change the pictures
    widths = [pill_width("Resume all" if k == "pause" else "At once: 16" if k == "at_once" else l, 8.6, 48)
              for k, l in buttons]
    extra = (CW - sum(widths) - gap * (len(widths) - 1)) // max(len(widths), 1)
    x, line = X0, []
    for (key, label), w in zip(buttons, widths):
        w += extra
        out.append(button("b:" + key, x, 606, w, 44, shape(w, 44, 10, CARD, LINE, 1),
                          shape(w, 44, 10, CARD_FOCUS, TEAL, 2), label, "body", FG, align=CENTER | MIDDLE))
        line.append("b:" + key)
        x += w + gap
    grid.append(line)
    out += hints([("a", "Options"), ("y", "Tick"), ("x", "Details"), ("b", "Back")])
    scroll = {"first": "row:0", "last": "row:%d" % (len(visible) - 1), "more_up": offset > 0,
              "more_down": offset + DL_SLOTS < len(rows), "page": DL_SLOTS}
    first = "row:0" if visible else (grid[-1][0] if grid[-1] else None)
    page = Page("downloads", out, [g for g in grid if g], focus or first, live=3, x_own=True, scroll=scroll)
    page.jump = dict(("row:%d" % i, line[0]) for i in range(len(visible))) if line else {}  # Right: to the buttons
    return page


SR_SLOTS, SR_TOP, SR_H, SR_STEP = 6, 258, 58, 64
CATS = [("tv", "TV"), ("movies", "Movies"), ("music", "Music"), ("tutorials", "Tutorials"), ("comics", "Comics")]
SOURCES = [("torrents", "Torrents"), ("youtube", "YouTube"), ("both", "Both")]
SORTS = [("best", "Best match"), ("seeders", "Most seeders"), ("newest", "Newest"), ("largest", "Largest"),
         ("views", "Most viewed"), ("name", "Name A-Z")]


def search_page(status, query="", cats=(), source="both", sort="best", results=(), offset=0, summary="",
                more=False, focus=None, busy="", missing=None):
    """results: [{"ticked", "tag" (YOUTUBE / TORRENT), "title", "meta", "note", "note_color"}]. missing (2.0.7):
    [{"q", "meta"}] shows the missing episodes instead, each in a search box with its own Search button."""
    out = side_bar("search", status) + page_title("Search")
    if summary:
        out.append(text("summary", X1 - 500, 34, 500, 26, summary, "small", MUTE, RIGHT | MIDDLE))
    box_w = 848
    out.append(button("box", X0, 78, box_w, 56, shape(box_w, 56, 12, "FF16222D", LINE, 1),
                      shape(box_w, 56, 12, "FF16222D", TEAL, 2)))
    out.append(img("box:icon", X0 + 20, 94, 24, 24, icon("search"), MUTE))
    out.append(text("box:s", X0 + 60, 78, box_w - 80, 56, short(query, 70) or "Type what to look for",
                    "big", FG if query else MUTE))
    out.append(button("go", X0 + box_w + 12, 78, CW - box_w - 12, 56, shape(CW - box_w - 12, 56, 12, TEAL),
                      shape(CW - box_w - 12, 56, 12, TEAL_FOCUS), "[B]Search[/B]", "big", NAVY, FG, CENTER | MIDDLE))
    grid = [["box", "go"], []]
    x = X0
    for key, label in CATS:
        on = key in cats
        out.append(button("cat:" + key, x, 150, 118, 42, shape(118, 42, 10, CARD, TEAL if on else LINE, 1 + on),
                          shape(118, 42, 10, CARD_FOCUS, TEAL, 2)))
        out.append(text("cat:%s:s" % key, x + 44, 150, 70, 42, label, "body", FG))
        out.append(img("cat:%s:box" % key, x + 14, 160, 22, 22, icon("box_on" if on else "box_off")))
        grid[1].append("cat:" + key)
        x += 126
    out.append(img("src:panel", 900, 150, 348, 42, shape(348, 42, 10, CARD, LINE, 1)))
    for n, (key, label) in enumerate(SOURCES):
        on = key == source
        out.append(button("src:" + key, 904 + n * 114, 154, 112, 34,
                          shape(112, 34, 8, TEAL) if on else shape(112, 34, 8, CARD),
                          shape(112, 34, 8, TEAL_FOCUS) if on else shape(112, 34, 8, CARD_FOCUS, TEAL, 2),
                          "[B]%s[/B]" % label if on else label, "body", NAVY if on else FG, FG,
                          CENTER | MIDDLE))
        grid[1].append("src:" + key)
    out.append(text("sort:s", X0, 208, 52, 36, "[B]Sort[/B]", "body", MUTE))
    x, line = X0 + 54, []
    for key, label in SORTS:
        on = key == sort
        w = pill_width(label, 9.4, 34)
        out.append(button("sort:" + key, x, 208, w, 36, shape(w, 36, 18, TEAL) if on else shape(w, 36, 18, CARD, LINE, 1),
                          shape(w, 36, 18, TEAL_FOCUS) if on else shape(w, 36, 18, CARD_FOCUS, TEAL, 2),
                          "[B]%s[/B]" % label if on else label, "body", NAVY if on else FG, FG,
                          CENTER | MIDDLE))
        line.append("sort:" + key)
        x += w + 8
    on = missing is not None
    w = pill_width("Missing episodes", 9.4, 34)
    out.append(button("missing", X1 - w, 208, w, 36, shape(w, 36, 18, TEAL) if on else shape(w, 36, 18, CARD, LINE, 1),
                      shape(w, 36, 18, TEAL_FOCUS) if on else shape(w, 36, 18, CARD_FOCUS, TEAL, 2),
                      "[B]Missing episodes[/B]" if on else "Missing episodes", "body", NAVY if on else FG, FG,
                      CENTER | MIDDLE))
    line.append("missing")
    grid.append(line)
    if on:
        return _missing_rows(out, grid, missing, offset, summary, busy, focus)
    visible = list(results)[offset:offset + SR_SLOTS]
    for i in range(SR_SLOTS):
        y = SR_TOP + i * SR_STEP
        if i >= len(visible):
            continue
        r, key = visible[i], "res:%d" % i
        out.append(button(key, X0, y, CW, SR_H, shape(CW, SR_H, 10, CARD, LINE, 1),
                          shape(CW, SR_H, 10, CARD_FOCUS, TEAL, 2)))
        out.append(img(key + ":box", X0 + 15, y + 18, 22, 22, icon("box_on" if r.get("ticked") else "box_off")))
        t, tw = tag(key + ":tag", X0 + 52, y + 19, r.get("tag") or "TORRENT")
        out += t
        out.append(text(key + ":title", X0 + 142, y + 6, 640, 26, short(r.get("title"), 72), "body", FG))
        out.append(text(key + ":meta", X0 + 142, y + 30, 640, 22, r.get("meta", ""), "small", MUTE))
        out.append(text(key + ":note", X1 - 260, y, 242, SR_H, "[B]%s[/B]" % r["note"] if r.get("note") else "",
                        "small", r.get("note_color") or TEAL, RIGHT | MIDDLE))
        grid.append([key])
    if busy or not results:
        out.append(text("empty", X0, SR_TOP + 40, CW, 60, busy or ("No results. Try fewer words or another category."
                                                                     if summary else "Type what to look for, then Search."),
                        "body", MUTE, CENTER | MIDDLE))
    ticked = sum(1 for r in results if r.get("ticked"))
    line = []
    out.append(button("b:download", X0, 652, 280, 46, shape(280, 46, 10, TEAL), shape(280, 46, 10, TEAL_FOCUS),
                      "[B]Download the %d ticked[/B]" % ticked if ticked else "[B]Download the ticked[/B]", "body",
                      NAVY, FG, CENTER | MIDDLE))
    line.append("b:download")
    out.append(button("b:next", X0 + 292, 652, 150, 46, shape(150, 46, 10, CARD, LINE, 1),
                      shape(150, 46, 10, CARD_FOCUS, TEAL, 2), "Next 100", "body", FG if more else DIM,
                      align=CENTER | MIDDLE))
    line.append("b:next")
    out.append(button("b:paste", X0 + 454, 652, 150, 46, shape(150, 46, 10, CARD, LINE, 1),
                      shape(150, 46, 10, CARD_FOCUS, TEAL, 2), "Paste a link", "body", FG, align=CENTER | MIDDLE))
    line.append("b:paste")
    grid.append(line)
    out += hints([("b", "Back")], x=880, y=662)
    scroll = {"first": "res:0", "last": "res:%d" % (len(visible) - 1), "more_up": offset > 0,
              "more_down": offset + SR_SLOTS < len(results), "page": SR_SLOTS}
    page = Page("search", out, [g for g in grid if g], focus or ("res:0" if visible else "box"), x_own=False,
                scroll=scroll)
    page.jump = dict(("res:%d" % i, "b:download") for i in range(len(visible)))  # Right: to the buttons
    return page


def _missing_rows(out, grid, missing, offset, summary, busy, focus):  # summary: drawn by search_page
    """The search page's lower half while it shows missing episodes: a box with the search words (A changes
    them) and a Search button on each row, paging like the results."""
    visible = list(missing)[offset:offset + SR_SLOTS]
    go_w = 150
    box_w = CW - go_w - 12
    for i, r in enumerate(visible):
        y = SR_TOP + i * SR_STEP
        key = "miss:%d" % i
        out.append(button(key, X0, y, box_w, SR_H, shape(box_w, SR_H, 10, "FF16222D", LINE, 1),
                          shape(box_w, SR_H, 10, "FF16222D", TEAL, 2)))
        out.append(img(key + ":icon", X0 + 16, y + 17, 24, 24, icon("search"), MUTE))
        out.append(text(key + ":q", X0 + 54, y + 4, box_w - 70, 28, short(r.get("q"), 70), "body", FG))
        out.append(text(key + ":meta", X0 + 54, y + 30, box_w - 70, 22, short(r.get("meta"), 90), "small", MUTE))
        out.append(button(key + ":go", X1 - go_w, y, go_w, SR_H, shape(go_w, SR_H, 10, TEAL),
                          shape(go_w, SR_H, 10, TEAL_FOCUS), "[B]Search[/B]", "body", NAVY, FG, CENTER | MIDDLE))
        grid.append([key, key + ":go"])
    if busy or not visible:
        out.append(text("empty", X0, SR_TOP + 40, CW, 60, busy or "No missing episodes in the last scan.", "body",
                        MUTE, CENTER | MIDDLE))
    if len(missing) > SR_SLOTS:
        out.append(text("more", X1 - 200, 652, 200, 46, "%d-%d of %d" % (offset + 1, offset + len(visible),
                                                                      len(missing)), "small", DIM, RIGHT | MIDDLE))
    out += hints([("a", "Search"), ("y", "New search"), ("b", "Back")], x=X0, y=662)
    scroll = {"first": "miss:0", "last": "miss:%d" % (len(visible) - 1), "more_up": offset > 0,
              "more_down": offset + SR_SLOTS < len(missing), "page": SR_SLOTS}
    page = Page("search", out, [g for g in grid if g], focus or ("miss:0" if visible else "missing"), x_own=False,
                scroll=scroll)
    page.jump = dict(("miss:%d:go" % i, "miss:%d:go" % i) for i in range(len(visible)))  # no buttons under them
    return page


# ---------- the window ----------
class Window(object):
    """One Kodi window that shows Page after Page. show(page) puts a page up (replacing what's there, or
    updating it in place when it has the same buttons), wait() returns the next event:
    ("click", key), ("x", key), ("y", key), ("back", key) or ("tick",) when a live page is due to refresh."""

    def __init__(self):
        import xbmcgui
        self.gui = xbmcgui
        shell = self

        class Win(xbmcgui.WindowDialog):
            def onAction(self, action):
                shell._action(action.getId())

            def onControl(self, control):
                shell._click(control.getId())

        self.win = Win()
        self.controls = {}   # key -> control
        self.ids = {}        # control id -> key
        self.events = []
        self.page = None
        self.shown = False
        self.nav = {}  # key -> (up, down, left, right) as last set

    # building
    def _make(self, w):
        g = self.gui
        if w["t"] == "img":
            c = g.ControlImage(w["x"], w["y"], w["w"], w["h"], MEDIA + w["src"], 0, w["color"] or "0xFFFFFFFF")
        elif w["t"] == "text":
            c = g.ControlLabel(w["x"], w["y"], w["w"], w["h"], w["s"], font=FONT[w["font"]], textColor=w["color"],
                               alignment=w["align"])
        else:
            c = g.ControlButton(w["x"], w["y"], w["w"], w["h"], w["s"], focusTexture=MEDIA + w["on"],
                                noFocusTexture=MEDIA + w["off"], textOffsetX=w["pad"], alignment=w["align"],
                                font=FONT[w["font"]], textColor=w["color"], focusedColor=w["focus_color"])
        return c

    def _same_shape(self, page):
        if not self.page or self.page.name != page.name:
            return False
        old = dict((w["key"], w) for w in self.page.widgets)
        if set(old) != set(w["key"] for w in page.widgets):
            return False
        look = ("x", "y", "w", "h", "off", "on", "color", "focus_color", "font", "align", "pad")
        # 2.0.6: a button whose look changed (a filter chosen) is made again: Kodi can't change a button's
        # pictures or colours once it's made, so the old chosen look stayed and the Finished filter vanished
        return all(old[w["key"]]["t"] == w["t"] and (w["t"] != "btn" or
                   tuple(old[w["key"]].get(k) for k in look) == tuple(w.get(k) for k in look)) for w in page.widgets)

    def show(self, page, focus=None):
        if self._same_shape(page):
            self._update(page)
            self._navigate(page)
        else:
            self._build(page)
        self.page = page
        want = focus if focus in self.controls else page.focus  # a saved key that's gone: the page's own start
        if want in self.controls:
            try:
                self.win.setFocus(self.controls[want])
            except Exception:
                pass
        if not self.shown:
            self.win.show()
            self.shown = True

    def _build(self, page):
        if self.controls:
            try:
                self.win.removeControls(list(self.controls.values()))
            except Exception:
                for c in self.controls.values():
                    try:
                        self.win.removeControl(c)
                    except Exception:
                        pass
        self.controls, self.ids = {}, {}
        made = [(w["key"], self._make(w)) for w in page.widgets]
        self.win.addControls([c for _, c in made])
        for key, c in made:
            self.controls[key] = c
            self.ids[c.getId()] = key
        self.nav = {}
        self._navigate(page)

    def _navigate(self, page):
        """Sets where each button's arrows go: on a new page, and when an in-place update changes it (2.0.3: a
        list paged to its end kept "Down stays put" from the page before, so the buttons under it were unreachable)."""
        nav = navigation(page)
        for key, (u, d, l, r) in nav.items():
            c = self.controls.get(key)
            if c is None or self.nav.get(key) == (u, d, l, r):
                continue
            try:
                c.setNavigation(self.controls.get(u, c), self.controls.get(d, c), self.controls.get(l, c),
                                self.controls.get(r, c))
                self.nav[key] = (u, d, l, r)
            except Exception:
                pass

    def _update(self, page):
        old = dict((w["key"], w) for w in self.page.widgets)
        # 2.0.8: Kodi ignores a new colour or font on a label that's already made, and a label kept its old width
        # (a row that was REAL-DEBRID showed a teal "YOUT..."). A label or picture that changed in more than its
        # words or picture is made again, with the rest of its group (a tag's box and text) so the text stays on top.
        same = lambda w, o, ks: all(w.get(k) == o.get(k) for k in ks)
        redo = set()
        for w in page.widgets:
            o = old[w["key"]]
            if w["t"] == "text" and not same(w, o, ("h", "color", "font", "align")) or \
                    w["t"] == "img" and not same(w, o, ("h", "color")):
                redo.add(w["key"].rsplit(":", 1)[0])
        again = [w for w in page.widgets if w["t"] != "btn" and w["key"].rsplit(":", 1)[0] in redo]
        if again:
            gone = [self.controls[w["key"]] for w in again]
            try:
                self.win.removeControls(gone)
            except Exception:
                pass
            for c in gone:
                self.ids.pop(c.getId(), None)
            made = [(w["key"], self._make(w)) for w in again]
            self.win.addControls([c for _, c in made])
            for key, c in made:
                self.controls[key] = c
                self.ids[c.getId()] = key
        remade = set(w["key"] for w in again)
        for w in page.widgets:
            c, o = self.controls[w["key"]], old[w["key"]]
            if w == o or w["key"] in remade:
                continue
            try:
                if w["t"] in ("text", "img"):
                    if w["t"] == "text" and w["s"] != o["s"]:
                        c.setLabel(w["s"])
                    if w["t"] == "img" and w["src"] != o["src"]:
                        c.setImage(MEDIA + w["src"], False)
                    if (w["x"], w["y"]) != (o["x"], o["y"]):
                        c.setPosition(w["x"], w["y"])
                    if w["w"] != o["w"]:
                        c.setWidth(w["w"])
                else:
                    c.setLabel(w["s"])
            except Exception:
                pass

    # events
    def focused(self):
        try:
            return self.ids.get(self.win.getFocusId())
        except Exception:
            return None

    def _action(self, aid):
        key = self.focused()
        p = self.page
        if aid in ACT_BACK:
            self.events.append(("back", key))
        elif aid in ACT_Y:
            self.events.append(("y", key))
        elif aid in ACT_X:
            self.events.append(("x", key))
        elif p and p.scroll and key:
            sc, n = p.scroll, p.scroll.get("page", 6)
            # 2.0.10: any part of the end row (a missing episode's Search button too) pages the list
            row = lambda k: k and (key == k or key.startswith(k + ":"))
            if aid in PAGE_DOWNS + (ACT_MOUSE_DOWN,) or (aid == ACT_DOWN and row(sc.get("last"))):
                if sc.get("more_down"):  # a whole page at a time (one row at a time was too slow)
                    self.events.append(("scroll", key, 1 if aid == ACT_MOUSE_DOWN else n))
                elif aid in PAGE_DOWNS and sc.get("last") in self.controls:
                    self.win.setFocus(self.controls[sc["last"]])
            elif aid in PAGE_UPS + (ACT_MOUSE_UP,) or (aid == ACT_UP and row(sc.get("first"))):
                if sc.get("more_up"):
                    self.events.append(("scroll", key, -1 if aid == ACT_MOUSE_UP else -n))
                elif aid in PAGE_UPS and sc.get("first") in self.controls:
                    self.win.setFocus(self.controls[sc["first"]])

    def _click(self, cid):
        key = self.ids.get(cid)
        if key:
            self.events.append(("click", key))

    def wait(self, seconds=0):
        """The next event; ("tick",) after `seconds` with none (0: wait for one). ("quit",) if Kodi is closing."""
        import xbmc
        monitor = xbmc.Monitor()
        waited = 0.0
        while not self.events:
            if monitor.waitForAbort(0.05):
                return ("quit",)
            waited += 0.05
            if seconds and waited >= seconds:
                return ("tick",)
        return self.events.pop(0)

    def hide(self):
        """Out of the way while a Kodi dialog runs (the page comes back with show())."""
        if self.shown:
            self.win.close()
            self.shown = False
        self.events = []

    def close(self):
        self.hide()
        del self.win
