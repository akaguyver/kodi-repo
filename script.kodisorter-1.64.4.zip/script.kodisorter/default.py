# Sortovia - sorts downloads into Kodi-friendly folders from inside Kodi.
#   TV:     <dest>/TV/Show Name (Year)/Season 01/Show Name (Year) S01E02.mkv
#   Movies: <dest>/Movies/Movie Name (Year)/Movie Name (Year).mkv
#   Comics: <dest>/Comics/<original name>
#   Tutorials: <dest>/Tutorials/<AutoCAD, Revit ...>/<original name>
# Duplicates: keeps the better copy (higher resolution, else bigger file).
# Can check audio tracks and keep only files with audio in your language.
# Nothing is overwritten without your OK; replaced copies go to <dest>/_Replaced
# unless you choose to delete them.
import hashlib
import io
import json
import os
import re
import time
import zipfile
try:
    from urllib.parse import quote
except ImportError:  # very old Kodi
    from urllib import quote
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# File naming rules (shared with the command-line kodi_sort.py and its tests)
import backup
import comics
try:
    import devtools  # not in public builds
except ImportError:
    devtools = None
import drive_letter
import musictags
import screens
import vault
from sortlib import VIDEO, SUBS, AUDIO, MUSIC, plan_music, shared_artist, episode_tag, sub_lang, MIN_VIDEO_BYTES, SPECIAL_GUESS_NOTE, CREDITS_NOTE, plan_name, split_year, safe

try:
    ADDON = "Sortovia " + xbmcaddon.Addon().getAddonInfo("version")
except Exception:
    ADDON = "Sortovia"


SETTINGS_FILE = "settings.json"  # 1.48 only: those choices move back to Kodi's settings page


def setting_on(name, default=True):
    """A switch on the add-on's settings page (resources/settings.xml). A setting Kodi hasn't loaded
    yet takes default, so most behave as they always did, and one that skips a question stays off."""
    try:
        value = xbmcaddon.Addon().getSetting(name)
    except Exception:
        return default
    return value == "true" if value in ("true", "false") else default


def set_setting(name, on):
    xbmcaddon.Addon().setSetting(name, "true" if on else "false")


def bring_settings_back():
    """Put the choices 1.48 kept in its own file onto Kodi's settings page, and one comic choice with them."""
    path = data_file(SETTINGS_FILE)
    saved = load_cache(path) if path and os.path.exists(path) else {}
    for name, on in saved.items():
        set_setting(name, on)
    if path and os.path.exists(path):
        os.remove(path)
    pref = load_cache(data_file(COMICS_PREF))
    if "convert" in pref:
        set_setting("convert_comics", pref.pop("convert"))
        save_cache(data_file(COMICS_PREF), pref)


RES_RE = re.compile(r"(?<![0-9])(2160|1440|1080|720|576|480|360)[pi](?![a-z0-9])", re.I)

ASK, ALWAYS, NEVER = 0, 1, 2

# Background moves: Kodi's home window holds two flags so that opening Sortovia
# again while a move is running offers to stop it instead of starting a second run.
PROP_RUN = "kodisorter.running"   # status text, e.g. "12 of 41" - empty when idle
PROP_STOP = "kodisorter.stop"     # STOP_NOW or STOP_AFTER
STOP_NOW, STOP_AFTER = "1", "after"


def home():
    return xbmcgui.Window(10000)


class Progress(object):
    """Full-screen progress with a Cancel button, or a small bar in the corner
    (background) that leaves Kodi free to use. Background runs are stopped by
    opening Sortovia again. Both stop if Kodi is closing."""

    def __init__(self, background, heading, text):
        self.background = background
        self.monitor = xbmc.Monitor()
        self.dlg = xbmcgui.DialogProgressBG() if background else xbmcgui.DialogProgress()
        self.dlg.create(heading, text)

    def update(self, pct, text):
        if self.background:
            self.dlg.update(pct, message=text.replace("\n", " - "))
        else:
            self.dlg.update(pct, text)

    def canceled(self, mid_file=False):
        """mid_file=True is asked during a copy: only "stop now" interrupts it;
        "stop after this file" is seen between files."""
        if self.monitor.abortRequested():
            return True
        if self.background:
            flag = home().getProperty(PROP_STOP)
            return flag == STOP_NOW or (flag == STOP_AFTER and not mid_file)
        return self.dlg.iscanceled()

    def close(self):
        self.dlg.close()


# ---------- path helpers ----------
def log(msg):
    xbmc.log("[%s] %s" % (ADDON, str(msg).replace("\x00", "")), xbmc.LOGINFO)


def log_block(title, text):
    """Write a whole report into kodi.log between clear markers, so it can be
    shared with Kodi Logfile Uploader instead of photographing the screen."""
    log("===== %s - START =====" % title)
    for line in text.splitlines():
        if line.strip():
            log("  " + line)
    log("===== %s - END =====" % title)


def sep_of(path):
    # Xbox/Windows local paths use "\", Kodi URLs (smb://, special://) use "/"
    return "\\" if ("\\" in path and "://" not in path) else "/"


def ensure_slash(path):
    return path if path.endswith(("/", "\\")) else path + sep_of(path)


def join(base, *parts):
    return ensure_slash(base) + sep_of(base).join(parts)


def _last_sep(path):
    # Xbox paths mix both: win-lib://removable/E:\\TV/Show/x.mkv
    p = path.rstrip("/\\")
    return max(p.rfind("/"), p.rfind("\\"))


def parent_of(path):
    return path[: _last_sep(path) + 1]


def base_of(path):
    return path.rstrip("/\\")[_last_sep(path) + 1:]


def split_name(filename):
    if "." in filename:
        stem, ext = filename.rsplit(".", 1)
        return stem, "." + ext.lower()
    return filename, ""


def in_archive(path):
    return path.split("://", 1)[0].lower() in ("archive", "rar", "zip") if "://" in path else False


def size_of(path):
    """File size in bytes, or -1 if unknown. Kodi's Stat() reports 0 (or the
    packed size) for files inside archives, so those are opened and asked."""
    if in_archive(path):
        try:
            f = xbmcvfs.File(path)
            try:
                n = f.size()
            finally:
                f.close()
            if n > 0:
                return n
        except Exception as e:
            log("size of %s: %s" % (path, e))
        return -1
    try:
        n = xbmcvfs.Stat(path).st_size()
    except Exception:
        n = -1
    if n <= 0 and "://" in path and not path.startswith(("win-lib://", "special://")):
        # Over the network (the phone) a size check that failed or timed out comes back as 0:
        # ask again by opening the file.
        try:
            f = xbmcvfs.File(path)
            try:
                m = f.size()
            finally:
                f.close()
            if m > 0:
                return m
        except Exception:
            pass
    return n


KODI_FOLDERS = ("TV", "Movies", "Comics", "Tutorials", "Music")
# The folder each kind goes into, under the library root. Set per run by
# resolve_dest: picking E:\\Movies (or "Films", "TV Shows" ...) uses that folder,
# and the other kinds go to their folders next to it.
FOLDER_NAMES = {"TV": "TV", "Movies": "Movies", "Comics": "Comics", "Tutorials": "Tutorials", "Music": "Music"}
FOLDER_SYNONYMS = {
    "TV": ("tv", "tv shows", "tvshows", "tv series", "shows", "series", "television"),
    "Movies": ("movies", "movie", "films", "film"),
    "Comics": ("comics", "comic", "manga", "graphic novels"),
    "Tutorials": ("tutorials", "tutorial", "courses"),
    "Music": ("music", "songs", "my music"),
}


# Folders the person already has for a kind (Help > My library folders), anywhere,
# e.g. {"TV": "win-lib://removable/D:\\My Shows/"}. Set per run from onboarding.json.
# Kinds without one use <library root>/<FOLDER_NAMES[kind]> as before.
KIND_DIRS = {}
ONBOARD_KIND = {"TV": "TV", "MOVIE": "Movies", "COMIC": "Comics", "TUTORIAL": "Tutorials", "MUSIC": "Music"}


def kind_root(kind, dest):
    """The folder a kind goes into: the person's own folder, or <dest>/TV etc."""
    return KIND_DIRS.get(kind) or join(dest, FOLDER_NAMES.get(kind, kind))


def rel_of(target, dest):
    """A target as library parts, ["TV", "Show", "Season 01", "x.mkv"], also when TV
    is the person's own folder somewhere else (then "TV" stands for that folder)."""
    for kind, folder in KIND_DIRS.items():
        top = ensure_slash(folder)
        if _norm(target).startswith(_norm(top) + "/"):
            return [FOLDER_NAMES.get(kind, kind)] + [p for p in re.split(r"[\\/]", target[len(top):]) if p]
    if target.startswith(ensure_slash(dest)):
        return [p for p in re.split(r"[\\/]", target[len(ensure_slash(dest)):]) if p]
    return [base_of(target)]


def from_rel(parts, dest):
    """Inverse of rel_of."""
    for kind, name in FOLDER_NAMES.items():
        if parts and parts[0] == name and kind in KIND_DIRS:
            return join(KIND_DIRS[kind], *parts[1:])
    return join(dest, *parts)


# ---------- reuse the library's own show / season / movie folders ----------
# "Sams Sandwiches S15E01" goes into an existing "Sam's Sandwiches" folder, and into its
# "Season 1" folder if that's how the library names seasons, instead of making
# near-duplicate folders next to them. Each folder is listed once per run.
DIR_CACHE = {}


def _subdirs(path):
    key = _norm(path)
    if key not in DIR_CACHE:
        try:
            DIR_CACHE[key] = xbmcvfs.listdir(ensure_slash(path))[0] if xbmcvfs.exists(ensure_slash(path)) else []
        except Exception:
            DIR_CACHE[key] = []
    return DIR_CACHE[key]


def _title_key(name):
    """('sams sandwiches', None) for "Sam's Sandwiches"; ('office us', '2005') for "The Office (US) (2005)"."""
    m = re.match(r"^(.*?)\s*\((\d{4})\)\s*$", name)
    title, year = (m.group(1), m.group(2)) if m else (name, None)
    k = title.lower().replace("&", " and ")
    k = re.sub(r"['\u2019`.]", "", k)
    k = re.sub(r"[^a-z0-9]+", " ", k).strip()
    return re.sub(r"^the ", "", k), year


def match_folder(root, wanted, need_year=False):
    """An existing folder in root that is the same show/movie as `wanted`, or None.
    Years must agree when both have one (Doctor Who (2005) is not Doctor Who (1963));
    movies (need_year) only match the same year."""
    dirs = _subdirs(root)
    if wanted in dirs:
        return wanted
    key, year = _title_key(wanted)
    if not key:
        return None
    same = [d for d in dirs if _title_key(d)[0] == key]
    exact = [d for d in same if _title_key(d)[1] == year]
    if len(exact) == 1:
        return exact[0]
    if need_year or exact:
        return None
    loose = [d for d in same if not year or not _title_key(d)[1]]
    return loose[0] if len(loose) == 1 else None


def match_season(show_path, number):
    for d in _subdirs(show_path):
        m = re.match(r"^(?:season|series|staffel|saison|s)[ ._\-]*0*(\d+)$", d.strip(), re.I)
        if (m and int(m.group(1)) == number) or (number == 0 and d.strip().lower() == "specials"):
            return d
    return None


def use_library_names(parts, dest):
    """Swap new show/season/movie folder names for the library's existing ones."""
    kind = {FOLDER_NAMES["TV"]: "TV", FOLDER_NAMES["Movies"]: "Movies"}.get(parts[0])
    if not kind or len(parts) < 3:
        return parts
    parts = list(parts)
    root = kind_root(kind, dest)
    have = match_folder(root, parts[1], need_year=(kind == "Movies"))
    if have and have != parts[1]:
        if parts[-1].lower().startswith(parts[1].lower()):
            parts[-1] = have + parts[-1][len(parts[1]):]  # file named like its folder, so duplicates are spotted
        parts[1] = have
    if kind == "TV" and len(parts) >= 4:
        m = re.match(r"^Season (\d+)$", parts[2])
        season = m and match_season(join(root, parts[1]), int(m.group(1)))
        if season:
            parts[2] = season
    return tuple(parts)


def resolve_dest(dest):
    """(library root, {kind: folder name}) for the destination the user picked.
    E:\\Movies -> (E:\\, Movies=Movies, TV=TV or an existing 'TV Shows', ...).
    E:\\ -> (E:\\, existing folders or the defaults)."""
    names = {}
    base = base_of(dest).strip()
    for kind, words in FOLDER_SYNONYMS.items():
        if base.lower() in words:
            names[kind] = base
            root = parent_of(dest)
            break
    else:
        root = dest
    try:
        existing = xbmcvfs.listdir(ensure_slash(root))[0]
    except Exception:
        existing = []
    low = dict((d.lower(), d) for d in existing)
    for kind, words in FOLDER_SYNONYMS.items():
        if kind in names:
            continue
        names[kind] = low.get(kind.lower()) or next((low[w] for w in words if w in low), kind)
    return root, names


def friendly(path):
    """How a path reads to a person: win-lib://removable/E:\\Movies/ -> E:\\Movies"""
    p = re.sub(r"^win-lib://[^/]*/", "", path or "")
    p = p.replace("/", "\\")
    p = re.sub(r"\\{2,}", r"\\", p).rstrip("\\")
    if re.match(r"^[A-Za-z]:$", p):
        p += "\\"
    return masked(p) if "://" in path and not path.startswith("win-lib://") else p


def _norm(path):
    return re.sub(r"[\\/]+", "/", path).rstrip("/").lower()


def sorted_folders(dest):
    """The destination's TV/Movies/Comics folders: skipped when the source is
    the same drive/folder (or contains it), so sorted files aren't re-sorted."""
    return set(_norm(join(dest, f)) for f in FOLDER_NAMES.values()) | set(_norm(d) for d in KIND_DIRS.values())


def already_sorted(path, target):
    """The file is already in its Kodi folder under its Kodi name (a title
    after the episode number is allowed: "Show S00E01 - Title.mkv")."""
    if _norm(parent_of(path)) != _norm(parent_of(target)):
        return False
    stem = split_name(base_of(target))[0].lower()
    return base_of(path).lower().startswith(stem)


def walk(folder, skip=(), tree=None):
    """Files under folder. tree (optional dict) records each folder seen as
    folder -> [has files or skipped content, [subfolders walked]]."""
    folder = ensure_slash(folder)
    dirs, files = xbmcvfs.listdir(folder)
    node = None
    if tree is not None:
        node = tree[folder] = [bool(files), []]
    for f in files:
        yield folder + f, f
    for d in dirs:
        if d.startswith(".") or d.lower() in ("_replaced", "_unpacked", LOG_DIR.lower()) or NO_LANG_RE.match(d) or \
                (skip and _norm(folder + d) in skip):
            if node is not None:
                node[0] = True  # holds a folder we don't look into: never "empty"
            continue
        if node is not None:
            node[1].append(ensure_slash(folder + d))
        for item in walk(folder + d, skip, tree):
            yield item


def empty_folders(tree, src, keep_top=False):
    """Folders with no files anywhere below them, deepest first. Never the
    source itself; with keep_top, not its top-level folders either."""
    root = ensure_slash(src)
    out, memo = [], {}

    def empty(f):
        if f not in memo:
            node = tree.get(f)
            memo[f] = node is not None and not node[0] and all([empty(d) for d in node[1]])
        return memo[f]
    for f in tree:
        if f == root or not empty(f):
            continue
        if keep_top and _norm(parent_of(f)) == _norm(root):
            continue
        out.append(f)
    return sorted(out, key=lambda f: -_norm(f).count("/"))


# ---------- archives (.rar / .zip / .7z) ----------
# Kodi opens archives through its own file system: zip:// is built in, rar and
# 7z need the "Archive support" add-on (vfs.libarchive). Videos inside are
# copied out; the archive is then parked in an _Unpacked folder next to it.
ARCHIVES = (".rar", ".zip", ".7z")
LATER_VOLUME_RE = re.compile(r"\.part0*(?:[2-9]|\d{2,})\.rar$", re.I)
ARCHIVE_HELP = ("Some archives could not be opened. In Kodi go to Add-ons > Install from "
                "repository > Kodi Add-on repository > VFS add-ons > Archive support, "
                "install it, then run Sortovia again.")


def _walk_archive(base):
    dirs, files = xbmcvfs.listdir(base)
    for f in files:
        yield base + f, f
    for d in dirs:
        for item in _walk_archive(base + d + "/"):
            yield item


def open_archive(path):
    """List of (url, name) for files inside the archive, or None if Kodi can't open it."""
    enc = quote(path, safe="")
    bases = ["archive://%s/" % enc]
    low = path.lower()
    if low.endswith((".rar", ".cbr")):
        bases.append("rar://%s/" % enc)
    if low.endswith((".zip", ".cbz")):
        bases.append("zip://%s/" % enc)
    for base in bases:
        try:
            items = list(_walk_archive(base))
        except Exception as e:
            log("can't open %s as %s: %s" % (path, base.split(":")[0], e))
            continue
        if items:
            return items
    return None


def archive_volumes(path):
    """The archive plus its other volumes (name.part2.rar, name.r00 ...)."""
    folder, name = parent_of(path), base_of(path)
    if not name.lower().endswith(".rar"):
        return [path]
    stem = re.sub(r"(?:\.part\d+)?\.rar$", "", name, flags=re.I)
    vol = re.compile(re.escape(stem) + r"(?:\.part\d+\.rar|\.rar|\.r\d{2})$", re.I)
    _, files = xbmcvfs.listdir(folder)
    return [folder + f for f in files if vol.match(f)] or [path]


def park_archive(path):
    """Move a fully unpacked archive (all volumes) into _Unpacked beside it.
    Rename only: on the Xbox that fails, and copying gigabytes of archive
    just to tidy up isn't worth it, so the archive is then left where it is."""
    results = []
    for vol in archive_volumes(path):
        target = join(parent_of(vol), "_Unpacked", base_of(vol))
        xbmcvfs.mkdirs(parent_of(target))
        mark_nomedia(target)
        results.append(bool(xbmcvfs.rename(vol, target)))
    return all(results)


# ---------- specials with no number ----------
def renumber_special(target, name, state):
    """Give an unnumbered OVA the next free S00Exx in its show's Season 00.
    The same OVA always gets the same number, so a second copy is treated as a
    duplicate instead of being added again: matched by its file name (numbers
    given out are remembered in specials.json) or by its title, e.g. an
    existing "Show S00E02 - The Long Road Home.mkv"."""
    folder = parent_of(target)
    key = folder.lower() + "|" + name.lower()
    base = base_of(target)
    title = re.search(r"S00E\d+( - .+)\.[^.]+$", base, re.I)
    if folder not in state["used"]:
        used, titles = set(), {}
        if xbmcvfs.exists(folder):
            for f in xbmcvfs.listdir(folder)[1]:
                m = re.search(r"S00E(\d+)( - .+)?\.[^.]+$", f, re.I)
                if m:
                    used.add(int(m.group(1)))
                    if m.group(2):
                        titles[m.group(2).lower()] = int(m.group(1))
        state["used"][folder], state["titles"][folder] = used, titles
    if key not in state["by_name"]:
        n = state["titles"][folder].get(title.group(1).lower()) if title else None
        if n is None:
            n = 1
            while n in state["used"][folder]:
                n += 1
        state["used"][folder].add(n)
        if title:
            state["titles"][folder][title.group(1).lower()] = n
        state["by_name"][key] = n
    n = state["by_name"][key]
    return folder + re.sub(r"S00E\d+", "S00E%02d" % n, base, count=1, flags=re.I)


# ---------- audio language detection (reads file headers, no playback) ----------
# Only an explicit English mention counts. "Dual audio"/"multi" could be French + Japanese.
import lang as langmod
# The person's language (Help > Your language): the audio looked for, subtitles kept and
# movie titles from TMDb. The "eng"/"English" names inside the code mean "your language".
PREF = [langmod.Language("en")]


def set_language(setting=None):
    """Load the chosen language (or Kodi's own menu language)."""
    if setting is None:
        setting = load_cache(data_file("onboarding.json")).get("language", "en")
    try:
        kodi = xbmc.getLanguage(xbmc.ISO_639_1)
    except Exception:
        kodi = "en"
    PREF[0] = langmod.resolve(setting, kodi)
    return PREF[0]


def LN():
    """The language's name for messages: "English", "Spanish" ..."""
    return PREF[0].name


def _read_vint(f, keep_marker=False):
    b = f.readBytes(1)
    if not b:
        return None, 0
    first = b[0]
    length, mask = 1, 0x80
    while length <= 8 and not (first & mask):
        length += 1
        mask >>= 1
    if length > 8:
        return None, 0
    value = first if keep_marker else first & (mask - 1)
    rest = f.readBytes(length - 1) if length > 1 else b""
    if len(rest) != length - 1:
        return None, 0
    unknown = (not keep_marker) and value == (mask - 1) and all(x == 0xFF for x in rest)
    for x in rest:
        value = (value << 8) | x
    return (-1 if unknown else value), length


def _mkv_langs(f, file_size):
    """Return list of audio track languages from a Matroska/WebM file."""
    langs = []

    def walk_children(start, end, depth):
        pos = start
        while pos < end:
            f.seek(pos, 0)
            eid, l1 = _read_vint(f, keep_marker=True)
            size, l2 = _read_vint(f)
            if eid is None or size is None:
                return False
            data = pos + l1 + l2
            stop = end if size < 0 else min(end, data + size)
            if eid == 0x18538067:            # Segment
                return walk_children(data, stop, depth + 1)
            if eid == 0x1654AE6B:            # Tracks
                walk_children(data, stop, depth + 1)
                return True
            if eid == 0xAE:                  # TrackEntry
                ttype, lang, ietf, name = None, None, None, ""
                q = data
                while q < stop:
                    f.seek(q, 0)
                    cid, c1 = _read_vint(f, keep_marker=True)
                    csz, c2 = _read_vint(f)
                    if cid is None or csz is None or csz < 0:
                        break
                    if csz <= 256:
                        raw = bytes(f.readBytes(csz))
                        if cid == 0x83:
                            ttype = int.from_bytes(raw, "big") if raw else None
                        elif cid == 0x22B59C:
                            lang = raw.split(b"\0")[0].decode("ascii", "ignore").lower()
                        elif cid == 0x22B59D:
                            ietf = raw.split(b"\0")[0].decode("ascii", "ignore").lower()
                        elif cid == 0x536E:
                            name = raw.decode("utf-8", "ignore").lower()
                    q += c1 + c2 + csz
                if ttype == 2:
                    if ietf:
                        langs.append(ietf.split("-")[0])
                    elif lang:
                        langs.append(lang)
                    elif "english" in name:
                        langs.append("eng")
                    elif PREF[0].code != "en" and PREF[0].hint_re.search(name):
                        langs.append(PREF[0].code)  # track named "Castellano", "Deutsch" ...
                    elif PREF[0].code == "en":
                        langs.append("eng")  # Matroska default language is English
                    else:
                        langs.append("und")  # untagged: don't call it "not your language"
            elif eid == 0x1F43B675:          # Cluster: tracks should have come before this
                return False
            if size < 0:
                return False
            pos = data + size
        return False

    walk_children(0, file_size, 0)
    return langs


def _mp4_langs(f, file_size):
    """Return list of audio track languages from an MP4/M4V/MOV file."""
    langs = []

    def boxes(start, end):
        pos = start
        while pos + 8 <= end:
            f.seek(pos, 0)
            hdr = bytes(f.readBytes(8))
            if len(hdr) < 8:
                return
            size = int.from_bytes(hdr[:4], "big")
            btype = hdr[4:8]
            head = 8
            if size == 1:
                size = int.from_bytes(bytes(f.readBytes(8)), "big")
                head = 16
            elif size == 0:
                size = end - pos
            if size < head:
                return
            yield btype, pos + head, pos + size
            pos += size

    def read_at(off, n):
        f.seek(off, 0)
        return bytes(f.readBytes(n))

    for btype, s, e in boxes(0, file_size):
        if btype != b"moov":
            continue
        for t, ts, te in boxes(s, e):
            if t != b"trak":
                continue
            for m, ms, me in boxes(ts, te):
                if m != b"mdia":
                    continue
                handler, lang, elng = None, None, None
                for c, cs, ce in boxes(ms, me):
                    if c == b"hdlr":
                        handler = read_at(cs + 8, 4)
                    elif c == b"mdhd":
                        ver = read_at(cs, 1)
                        off = cs + (32 if ver and ver[0] == 1 else 20)
                        raw = read_at(off, 2)
                        if len(raw) == 2:
                            v = int.from_bytes(raw, "big")
                            lang = "".join(chr(((v >> sh) & 0x1F) + 0x60) for sh in (10, 5, 0))
                    elif c == b"elng":
                        elng = read_at(cs + 4, ce - cs - 4).split(b"\0")[0].decode("ascii", "ignore").lower()
                if handler == b"soun":
                    langs.append((elng.split("-")[0] if elng else lang) or "und")
        break
    return langs


def audio_languages(path):
    """List of audio languages, or None if the file type can't be read."""
    ext = split_name(path)[1]
    try:
        f = xbmcvfs.File(path)
        try:
            size = f.size()
            if ext in (".mkv", ".webm", ".mka"):
                return _mkv_langs(f, size)
            if ext in (".mp4", ".m4v", ".mov"):
                return _mp4_langs(f, size)
        finally:
            f.close()
    except Exception as e:
        log("audio check failed for %s: %s" % (path, e))
    return None


def english_status(path, name):
    """True = has audio in your language, False = audio found but none in it, None = unknown."""
    langs = audio_languages(path)
    if langs:
        if any(PREF[0].matches(l) for l in langs):
            return True, langs
        if all(l not in ("und", "") for l in langs):
            return False, langs
    if PREF[0].hint_re.search(name):
        return True, langs or ["filename says %s" % LN()]
    return None, langs or []


def lang_note(eng, langs):
    if eng is True:
        return "%s audio" % LN()
    if eng is False:
        return "no %s audio: " % LN() + ", ".join(langs)
    return "audio language unknown"


# ---------- quality ----------
def resolution(name):
    m = RES_RE.search(name)
    if m:
        return int(m.group(1))
    if re.search(r"(?<![a-z0-9])(4k|uhd)(?![a-z0-9])", name, re.I):
        return 2160
    return 0  # unknown (e.g. a file already renamed for Kodi)


def describe(res, size):
    r = ("%dp" % res) if res else "res unknown"
    gb = size / 1024.0 ** 3 if size and size > 0 else 0
    return "%s, %.2f GB" % (r, gb)


ENG_RANK = {True: 2, None: 1, False: 0}


def is_better(new_res, new_size, old_res, old_size, new_eng=None, old_eng=None):
    """Audio in your language wins first, then higher resolution (when both known), then bigger file."""
    if ENG_RANK[new_eng] != ENG_RANK[old_eng]:
        return ENG_RANK[new_eng] > ENG_RANK[old_eng]
    if new_res and old_res and new_res != old_res:
        return new_res > old_res
    return new_size > old_size


# ---------- naming ----------
def shown_path(path, src):
    """A source path as a person reads it: %20 -> space, password hidden."""
    p = masked(path.replace(src, ""))
    if re.search(r"%[0-9a-fA-F]{2}", p):
        try:
            from urllib.parse import unquote
        except ImportError:
            from urllib import unquote
        p = unquote(p)
    return p


# ---------- music ----------
COVER_RE = re.compile(r"(?i)^(?:cover|folder|front|album|albumart)\.(?:jpe?g|png)$")
IMAGE_EXTS = (".jpg", ".jpeg", ".png")


def cover_name(filename, images):
    """The name a picture gets beside its album. Kodi shows cover.jpg (or folder.jpg ...) as the album's art, so
    when an album has none by those names, its main picture becomes cover.<ext>: the one whose name says cover or
    front, else the first. Every other picture keeps its name."""
    if COVER_RE.match(filename) or any(COVER_RE.match(n) for n in images):
        return filename
    ranked = sorted(images, key=lambda n: (not re.search(r"(?i)cover|front|folder", n), n.lower()))
    if ranked and ranked[0] == filename:
        return "cover" + split_name(filename)[1].lower().replace(".jpeg", ".jpg")
    return filename
MUSIC_SEEN = {}  # folder -> what its music files say, for one run


def read_music_tags(path):
    f = xbmcvfs.File(path)
    try:
        def read_at(offset, count):
            f.seek(offset, 0)
            return bytes(f.readBytes(count))
        return musictags.read_tags(read_at, f.size())
    except Exception as e:
        log("music tags unreadable: %s: %s" % (base_of(path), e))
        return {}
    finally:
        f.close()


def music_folder(folder):
    """{"tags": {file: tags}, "various": albums with several artists, "album_artist": {album: the artist on
    every track}, "video_stems": names of videos here}"""
    if folder not in MUSIC_SEEN:
        try:
            names = xbmcvfs.listdir(ensure_slash(folder))[1]
        except Exception:
            names = []
        tags = dict((n, read_music_tags(join(folder, n))) for n in names
                    if split_name(n)[1].lower() in MUSIC and not n.startswith("."))
        artists = {}
        for t in tags.values():
            if t.get("album") and t.get("artist") and not t.get("albumartist"):
                artists.setdefault(t["album"].lower(), set()).add(t["artist"])
        shared = dict((a, shared_artist(sorted(who))) for a, who in artists.items())
        MUSIC_SEEN[folder] = {"tags": tags, "album_artist": shared,
                              "various": set(a for a, who in artists.items()
                                             if len(set(w.lower() for w in who)) > 1 and not shared[a]),
                              "video_stems": set(split_name(n)[0].lower() for n in names if split_name(n)[1].lower() in VIDEO),
                              "images": sorted(n for n in names if split_name(n)[1].lower() in IMAGE_EXTS
                                               and not n.startswith("."))}
    return MUSIC_SEEN[folder]


def in_artist_folder(path, dest):
    """Already at Music\\Artist\\...\\Something\\file: that's someone's own order, so it stays
    (Kodi reads the tags wherever a song is). Loose files in Music or an artist's folder still move."""
    root = _norm(ensure_slash(kind_root("Music", dest))).rstrip("/") + "/"
    full = _norm(path)
    return full.startswith(root) and full[len(root):].count("/") >= 2


def plan_music_file(path, filename, dest):
    folder = parent_of(path)
    if in_artist_folder(path, dest):
        return path, "MUSIC", ""  # the scan counts this as already sorted
    seen = music_folder(folder)
    if split_name(filename)[0].lower() in seen["video_stems"]:
        return None, "audio that belongs to the video with the same name", ""
    tags = seen["tags"].get(filename)
    if tags is None:
        tags = read_music_tags(path)
    album = (tags.get("album") or "").lower()
    parts, kind, note = plan_music(filename, folder, tags, album in seen["various"], seen["album_artist"].get(album, ""))
    log("music plan: %s | tags: artist=%s album=%s albumartist=%s | %s" % (
        filename, tags.get("artist", "-"), tags.get("album", "-"), tags.get("albumartist", "-"),
        "/".join(parts[1:]) if parts else kind))
    if parts is None:
        return None, kind, ""
    return from_rel((FOLDER_NAMES["Music"],) + tuple(parts[1:]), dest), "MUSIC", note


def plan_cover(path, filename, dest):
    """A picture goes with the album in its folder (the main one as cover.jpg). With no music beside it (the
    songs were sorted before, without their art), it goes to that album in the library if the folder's
    "Artist - Album" name finds one. None otherwise."""
    folder = parent_of(path)
    seen = music_folder(folder)
    images = seen.get("images") or []
    for name in sorted(seen["tags"]):
        target = plan_music_file(join(folder, name), name, dest)[0]
        if target:
            return join(parent_of(target), cover_name(filename, images)), "MUSIC", ""
    if seen["tags"]:
        return None
    album = library_album_for(base_of(folder.rstrip("/\\")), dest)
    if not album:
        return None
    if [n for n in _listdir_files(album) if COVER_RE.match(n)]:
        return join(album, filename), "MUSIC", "art for an album already in the library"
    return join(album, cover_name(filename, images)), "MUSIC", "art for an album already in the library"


def _listdir_files(folder):
    try:
        return xbmcvfs.listdir(ensure_slash(folder))[1]
    except Exception:
        return []


def _key(text):
    return re.sub(r"[^a-z0-9]+", "", (text or "").lower())


def album_from_folder(name):
    """("Skrillex", "Recess") from a download's folder name like "Skrillex - Recess [2014] [Mp3-320]-V3nom".
    None when it doesn't read as Artist - Album."""
    m = re.match(r"^\s*(.+?)\s+[-\u2013\u2014]\s+(.+)$", name or "")
    if not m:
        return None
    artist, album = m.group(1), m.group(2)
    album = re.split(r"\s*[\[(]|\s+(?:mp3|flac|320|web|cd)\b|-\w+$", album, 1, flags=re.I)[0].strip(" .-")
    return (artist.strip(), album) if _key(artist) and _key(album) else None


def library_album_for(folder_name, dest):
    """The library folder (Music/Artist/Album) of the album a download's folder was named after, or None."""
    parsed = album_from_folder(folder_name)
    if not parsed:
        return None
    artist, album = parsed
    root = ensure_slash(kind_root("Music", dest))
    try:
        artists = xbmcvfs.listdir(root)[0]
    except Exception:
        return None
    want_a, want_b = _key(artist), _key(album)
    for a in artists:
        if _key(a) != want_a and _key(a.split(",")[0]) != want_a:
            continue
        try:
            albums = xbmcvfs.listdir(ensure_slash(join(root, a)))[0]
        except Exception:
            continue
        hits = [b for b in albums if _key(b) and (_key(b).startswith(want_b) or want_b.startswith(_key(b)))]
        if len(hits) == 1:
            return ensure_slash(join(root, a, hits[0]))
    return None


def plan_for(path, filename, dest):
    """Returns (target or None, kind or skip reason, note)."""
    ext = split_name(filename)[1].lower()
    if ext in MUSIC:
        return plan_music_file(path, filename, dest)
    if ext in IMAGE_EXTS:  # any picture in an album's folder goes with the album
        cover = plan_cover(path, filename, dest)
        if cover:
            return cover
    parts, kind, note = plan_name(filename, parent_of(path))
    if kind.startswith("YouTube") or (kind == "tutorial" and __import__("sortlib").from_youtube(parent_of(path))):
        searched = _search_parts(filename, parts)
        if searched is not parts:
            parts, kind = searched, "tutorial"
    if parts is None and kind.startswith("YouTube"):
        pick = load_cache(data_file(YT_PICKS)).get(filename)
        if not pick:
            return None, kind, ""  # say why, not "too small" (a short YouTube video isn't a sample)
        import sortlib
        parts, kind = tuple(pick) + (safe(sortlib.plain_title(split_name(filename)[0])) + split_name(filename)[1],), "tutorial"
    # Short tutorial videos are real lessons, not samples: only other videos need the minimum size.
    if (kind != "tutorial" and setting_on("skip_small") and split_name(filename)[1] in VIDEO
            and 0 <= size_of(path) < MIN_VIDEO_BYTES):
        return None, "sample/too small", ""
    if parts is None:
        return None, kind, ""
    parts = (FOLDER_NAMES.get(parts[0], parts[0]),) + tuple(parts[1:])
    parts = use_library_names(parts, dest)
    if split_name(filename)[1] in SUBS:
        parts = parts[:-1] + ("Subs",) + parts[-1:]  # Kodi looks in "Subs" next to the video
    return from_rel(parts, dest), kind.upper(), note


def show_of(target, dest):
    """'<dest>/TV/Show Name/Season 01/x.mkv' -> 'Show Name'."""
    parts = rel_of(target, dest)
    return parts[1] if len(parts) > 2 else parts[-1]


def dup_key(target):
    """Same episode/movie regardless of .mkv/.mp4; subs and comics keep their extension."""
    stem, ext = split_name(target)
    return (stem if ext in VIDEO else target).lower()


def find_existing(target):
    """Existing file at destination for the same episode/movie (any video extension)."""
    if xbmcvfs.exists(target):
        return target
    stem, ext = split_name(base_of(target))
    if ext not in VIDEO:
        return None
    folder = parent_of(target)
    if not xbmcvfs.exists(folder):
        return None
    _, files = xbmcvfs.listdir(folder)
    for f in files:
        fs, fe = split_name(f)
        if fe in VIDEO and fs.lower() == stem.lower():
            return folder + f
    return None


# ---------- file operations ----------
# Set by the move loop: called as hook(bytes_done, bytes_total) while a file
# copies; returns True to stop the copy (the half-copied file is removed).
COPY_HOOK = [None]
COPY_CHUNK = 4 * 1024 * 1024
PART = ".kodisorter.part"


class CopyStopped(Exception):
    pass


# Set by the move loop: shows the step after copying (closing, renaming,
# checking, deleting) on screen. Every step is also logged with its time, so
# if one hangs, Kodi's log shows which.
STEP_HOOK = [None]


def step(name, text):
    if STEP_HOOK[0]:  # big files only: 1000 subtitles would flood the log
        log("  step: %s - %s" % (text, name))
        STEP_HOOK[0](text)


def copy_with_progress(src, dst, total):
    """Copy in chunks so progress can be shown and a copy can be stopped part
    way. Writes straight to dst: the Xbox's drives can't rename files, so a
    temp-name-then-rename copy doesn't work there. A half copy is deleted on
    failure, and on Resume by remove_partial_copy (size check)."""
    hook = COPY_HOOK[0]
    part = dst + PART
    if xbmcvfs.exists(part):  # left by 1.11.x
        log("removing a half copy left by an earlier run: %s" % base_of(part))
        xbmcvfs.delete(part)
    fin = xbmcvfs.File(src)
    fout = xbmcvfs.File(dst, "w")
    done, ok = 0, False
    try:
        # Stop at the known size instead of reading until the end: on the Xbox
        # the final empty read past the end may never return.
        while total <= 0 or done < total:
            data = fin.readBytes(COPY_CHUNK if total <= 0 else min(COPY_CHUNK, total - done))
            if not data:
                break
            if not fout.write(data):
                raise IOError("write failed (drive full?)")
            done += len(data)
            if hook and hook(done, total):
                raise CopyStopped()
        if total > 0 and done != total:
            raise IOError("read %d of %d bytes" % (done, total))
        ok = True
    finally:
        name = base_of(dst)
        step(name, "copied - closing source file")
        fin.close()
        step(name, "closing new file (saving it to the drive)")
        fout.close()
        if not ok:
            xbmcvfs.delete(dst)
    return done


NO_RENAME = [None]  # True on a device whose drives can't rename (Xbox)
RENAME_FAILS = set()  # (source drive, destination drive) pairs where rename failed
MADE_DIRS = set()
# Folders Sortovia parks things in. A ".nomedia" file inside makes Kodi's
# library scan skip the folder, so parked videos never show up as shows.
PARK_DIRS = ("_replaced", "_no english", "_unpacked")
# "_No English", "_No Spanish" ...: files without audio in the person's language
NO_LANG_RE = re.compile(r"^_no [a-z]+$", re.I)
PARK_RE = re.compile(r"^(.*?[\\/](?:_replaced|_no [a-z]+|_unpacked))(?=[\\/]|$)", re.I)
NOMEDIA_DONE = set()


def mark_nomedia(path):
    """Put a .nomedia file in the park folder (_Unpacked etc.) that path is in."""
    m = PARK_RE.match(path or "")
    if not m:
        return
    root = ensure_slash(m.group(1))
    if _norm(root) in NOMEDIA_DONE:
        return
    NOMEDIA_DONE.add(_norm(root))
    flag = root + ".nomedia"
    try:
        if not xbmcvfs.exists(flag):
            xbmcvfs.mkdirs(root)
            f = xbmcvfs.File(flag, "w")
            try:
                wrote = f.write("Sortovia: tells Kodi's library scan to skip this folder\n")
            finally:
                f.close()
            if xbmcvfs.exists(flag):
                log("added .nomedia to %s (Kodi won't scan it)" % masked(root))
            else:
                log("couldn't add .nomedia to %s: write returned %r, file not there afterwards" % (masked(root), wrote))
        else:
            log(".nomedia already in %s" % masked(root))
    except Exception as e:
        log("couldn't add .nomedia to %s: %s" % (masked(root), e))


def mark_park_folders(*bases):
    """.nomedia in park folders left by earlier runs."""
    for base in set(b for b in bases if b):
        for name in ("_Replaced", PREF[0].no_folder, "_Unpacked"):
            folder = join(base, name)
            if _norm(ensure_slash(folder)) not in NOMEDIA_DONE and xbmcvfs.exists(ensure_slash(folder)):
                mark_nomedia(folder)


def _drive(path):
    m = re.match(r"^(win-lib://[^/]*/[A-Za-z]:|[a-z]+://[^/]*|[A-Za-z]:|/)", path or "")
    return (m.group(1) if m else path[:8]).lower()


def move_file(src, dst, known_size=None):
    """Rename if possible (same drive, instant); else copy, check size, delete.
    On the Xbox a rename never works: after the first failure for a pair of
    drives it isn't tried again (each failed attempt cost time per file)."""
    src_size = None
    if xbmcvfs.exists(dst):
        if split_name(dst)[1] in VIDEO or in_archive(src):
            return False, "destination already exists - nothing overwritten"
        src_size, dst_size = size_of(src), size_of(dst)
        if not (0 <= dst_size < src_size):
            return False, "destination already exists - nothing overwritten"
        xbmcvfs.delete(dst)  # a small file cut short by an interrupted run: copy it again
        log("redoing a half-copied %s (%d of %d bytes)" % (base_of(dst), dst_size, src_size))
    folder = parent_of(dst)
    if _norm(folder) not in MADE_DIRS:
        xbmcvfs.mkdirs(folder)
        MADE_DIRS.add(_norm(folder))
        mark_nomedia(folder)
    pair = (_drive(src), _drive(dst))
    if NO_RENAME[0] is None:
        try:
            import devices
            NO_RENAME[0] = not devices.can_rename(my_device())
        except Exception:
            NO_RENAME[0] = False
    if pair not in RENAME_FAILS and not NO_RENAME[0]:
        if xbmcvfs.rename(src, dst) and xbmcvfs.exists(dst):
            return True, "moved"
        RENAME_FAILS.add(pair)
    if src_size is None:
        # The scan's size is reused for small files only: a big video may still
        # have been downloading then, so it's measured again right now.
        small = known_size is not None and 0 <= known_size < MIN_VIDEO_BYTES
        src_size = known_size if small else size_of(src)
    written = None
    try:
        written = copy_with_progress(src, dst, src_size)
    except CopyStopped:
        return False, "stopped part way - half copy removed, original kept"
    except Exception as e:
        log("chunked copy of %s failed (%s), trying Kodi's copy" % (base_of(dst), e))
        step(base_of(dst), "trying again with Kodi's own copy (no progress shown)")
        if xbmcvfs.exists(dst):
            xbmcvfs.delete(dst)
        if not xbmcvfs.copy(src, dst):
            return False, "copy failed (%s) - original kept" % e
    step(base_of(dst), "checking the size of the copy")
    if written is not None and 0 < src_size < MIN_VIDEO_BYTES and not in_archive(src):
        dst_size = written  # small file: every byte was counted as it was written
    else:
        dst_size = size_of(dst)
    if in_archive(src):
        # The archive itself is kept (parked in _Unpacked), so nothing is lost
        # if this check is weaker than for normal files.
        if dst_size <= 0 or (src_size > 0 and src_size != dst_size):
            xbmcvfs.delete(dst)
            return False, "unpack failed (%s vs %s bytes) - archive kept" % (src_size, dst_size)
        return True, "unpacked" if src_size > 0 else "unpacked (size could not be checked)"
    if src_size <= 0 and not in_archive(src):
        again = size_of(src)  # the first size check can fail on a busy network share
        log("size of %s was %s before the copy, %s now" % (base_of(src), src_size, again))
        src_size = again
    if src_size < 0 or src_size != dst_size:
        xbmcvfs.delete(dst)
        return False, "size mismatch (%s vs %s) - copy removed, original kept" % (src_size, dst_size)
    step(base_of(dst), "deleting the original")
    if not xbmcvfs.delete(src):
        return True, "copied + size verified, but the original could not be deleted"
    step(base_of(dst), "done")
    return True, "copied + size verified"


def replaced_path(old, dest):
    out = join(dest, "_Replaced", *rel_of(old, dest))
    n = 2
    while xbmcvfs.exists(out):
        stem, ext = split_name(out)
        out = "%s (%d)%s" % (stem, n, ext)
        n += 1
    return out


def replace_file(src, dst, old, dest, delete_old):
    """Move the old copy aside (or delete it), then move the new one in. Restores on failure."""
    # No renames here: the Xbox's drives can't rename, so every "move" is a
    # copy + delete. The new file stays at the source until its copy is checked.
    if delete_old:
        if old.replace("\\", "/").lower() == dst.replace("\\", "/").lower():
            step(base_of(dst), "deleting the old lower-quality copy")
            xbmcvfs.delete(old)  # same name: must go first (new one is still safe at the source)
            ok, how = move_file(src, dst)
            return (True, "replaced (old deleted)") if ok else (False, "new copy failed (%s) - "
                                                                "old copy was deleted, new one is still at the source" % how)
        ok, how = move_file(src, dst)
        if not ok:
            return False, "new copy failed (%s) - old copy kept" % how
        xbmcvfs.delete(old)
        return True, "replaced (old deleted)"
    parked = replaced_path(old, dest)
    step(base_of(dst), "moving the old copy to _Replaced first")
    ok, how = move_file(old, parked)
    if not ok:
        return False, "couldn't move old copy aside (%s) - nothing changed" % how
    ok, how = move_file(src, dst)
    if ok:
        return True, "replaced (old copy in _Replaced)"
    move_file(parked, old)  # put the old one back
    return False, "new copy failed (%s) - old copy restored" % how


# ---------- scan cache ----------
# Reading audio tracks is the slow part of a scan (it opens every video).
# Results are saved as the scan goes, so a scan that was stopped or crashed
# picks up where it left off, and files already checked are not re-read.
CACHE_SAVE_EVERY = 20


def data_file(name):
    try:
        folder = xbmcvfs.translatePath("special://profile/addon_data/script.kodisorter/")
        xbmcvfs.mkdirs(folder)
        return folder + name
    except Exception as e:
        log("no addon_data folder: %s" % e)
        return None


def cache_file():
    return data_file("scan_cache.json")


# ---------- resume an unfinished run ----------
# session.json exists only while a run is in progress. If Kodi is closed or
# crashes (or the run is stopped), it is still there next time and the add-on
# offers to resume with the same folders and choices.
def session_file():
    return data_file("session.json")


def clear_session(path):
    if path and xbmcvfs.exists(path):
        xbmcvfs.delete(path)


def remove_partial_copy(prev):
    """A file that was mid-copy when the run died is incomplete: delete it."""
    cur = prev.get("in_progress") or {}
    src, dst = cur.get("src"), cur.get("dst")
    if not dst:
        return
    for tmp in (dst + ".kodisorter.tmp", dst + PART):
        if xbmcvfs.exists(tmp):
            xbmcvfs.delete(tmp)
            log("removed half-copied %s" % tmp)
    # Only a copy SMALLER than a still-present original is half-copied. If the
    # original is gone, the move finished (originals are deleted only after
    # the size check) and the copy is the only one left: never touch it.
    # (Kodi on the Xbox reports size 0, not an error, for a missing file -
    # 1.12.2 and older deleted a finished copy because of that.)
    if not src or not xbmcvfs.exists(dst):
        return
    if not in_archive(src) and not xbmcvfs.exists(src):
        log("last file was finished (original gone) - keeping %s" % dst)
        return
    src_size, dst_size = size_of(src), size_of(dst)
    if src_size > 0 and 0 <= dst_size < src_size:
        xbmcvfs.delete(dst)
        log("removed half-copied %s (%d of %d bytes)" % (dst, dst_size, src_size))


VAULT_FILE = "vault.json"   # how to recognise the passcode (the passcode itself isn't kept)
PROP_VAULT = "kodisorter.vault"
SECRET_FILES = ("phone.json", "realdebrid.json", "watch.json", "feeds.json")


def _is_secret(path):
    return os.path.basename(path.replace("\\", "/")) in SECRET_FILES


def _vault_key():
    try:
        return home().getProperty(PROP_VAULT)
    except Exception:
        return ""


def load_cache(path):
    if not path or not xbmcvfs.exists(path):
        return {}
    try:
        f = xbmcvfs.File(path)
        try:
            data = json.loads(f.read() or "{}")
        finally:
            f.close()
        if vault.is_sealed(data):
            key = _vault_key()
            return vault.unseal_json(key, data) if key else {}
        return data
    except Exception as e:
        log("cache unreadable, starting fresh: %s" % e)
        return {}


def save_cache(path, cache, verify=True):
    """Write JSON; returns True if it could be read back (or just written, if verify=False)."""
    if not path:
        return False
    try:
        stored = cache
        if _is_secret(path) and load_cache(data_file(VAULT_FILE)).get("salt"):
            key = _vault_key()
            if not key:
                log("not saving %s: locked" % base_of(path))
                return False  # never write a secret in the clear while protection is on
            stored = vault.seal_json(key, cache)
        f = xbmcvfs.File(path, "w")
        try:
            f.write(json.dumps(stored))
        finally:
            f.close()
        return load_cache(path) == json.loads(json.dumps(cache)) if verify else True
    except Exception as e:
        log("could not save %s: %s" % (path, e))
        return False


def _vault_rewrite(old_key, new_key):
    """Re-save every secret file for a new key ("" = not protected)."""
    for name in SECRET_FILES:
        path = data_file(name)
        if not path or not xbmcvfs.exists(path):
            continue
        f = xbmcvfs.File(path)
        try:
            data = json.loads(f.read() or "{}")
        finally:
            f.close()
        if vault.is_sealed(data):
            data = vault.unseal_json(old_key, data)
        f = xbmcvfs.File(path, "w")
        try:
            f.write(json.dumps(vault.seal_json(new_key, data) if new_key else data))
        finally:
            f.close()


def vault_menu(dlg):
    """Turn passcode protection on or off."""
    state = load_cache(data_file(VAULT_FILE))
    if state.get("salt"):
        if not vault_unlock(dlg):
            return
        if dlg.yesno(ADDON, "Turn off the passcode? Saved passwords and keys go back to being stored as plain text "
                     "on this device.", nolabel="Keep it on", yeslabel="Turn off"):
            _vault_rewrite(_vault_key(), "")
            save_cache(data_file(VAULT_FILE), {})
            home().clearProperty(PROP_VAULT)
            toast("Passcode off")
        return
    dlg.ok(ADDON, "A passcode encrypts your saved phone password, Real-Debrid sign-in, TMDb key and feed addresses on this "
           "device.\n\nYou type it once each time Kodi starts. Until you do, anything that needs them waits.\n\n"
           "It can't be recovered. If you forget it, you erase those saved details and enter them again. Your files "
           "and library aren't affected.")
    first = dlg.input("Choose a passcode", option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not first:
        return
    if dlg.input("Type it again", option=xbmcgui.ALPHANUM_HIDE_INPUT) != first:
        dlg.ok(ADDON, "Those didn't match, so nothing changed.")
        return
    state, key = vault.setup(first)
    _vault_rewrite("", key)
    save_cache(data_file(VAULT_FILE), state)
    home().setProperty(PROP_VAULT, key)
    toast("Passcode on")


def vault_unlock(dlg):
    """Ask for the passcode if protection is on and it isn't unlocked. True when usable."""
    state = load_cache(data_file(VAULT_FILE))
    if not state.get("salt") or _vault_key():
        return True
    while True:
        typed = dlg.input("Sortovia passcode", option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not typed:
            return False
        key = vault.unlock(state, typed)
        if key:
            home().setProperty(PROP_VAULT, key)
            return True
        if dlg.yesno(ADDON, "That passcode isn't right. If you've forgotten it, you can erase the saved passwords and "
                     "keys and enter them again.", nolabel="Try again", yeslabel="Erase them"):
            for name in SECRET_FILES:
                if data_file(name) and xbmcvfs.exists(data_file(name)):
                    xbmcvfs.delete(data_file(name))
            save_cache(data_file(VAULT_FILE), {})
            return True


def cache_key(path, size):
    return "%s|%d" % (stable_path(path), size)


# ---------- phone over Wi-Fi ----------
# The phone runs a file server (kodi-share = WebDAV for phone storage, or the
# primitive ftpd app = FTP for a USB drive on the phone). The Xbox is on the
# phone's hotspot, so the phone is the Xbox's gateway. Android can change the
# hotspot address each time it's switched on, so saved paths hold the word
# PHONE and it's swapped for the current address when a run starts.
PHONE = "PHONE"
PHONE_KINDS = {
    "dav": {"label": "phone storage (companion app or kodi-share)", "port": "8080", "user": "kodi"},
    "ftp": {"label": "USB drive on the phone (primitive ftpd app)", "port": "12345", "user": "user"},
}


def stable_path(path):
    """Path with the phone's address and password taken out (for cache keys)."""
    return re.sub(r"^(dav|davs|ftp)://[^/]*", r"\1://phone", path or "")


def masked(path):
    """Path safe to show or log: password hidden."""
    return re.sub(r"^([a-z]+://[^:/@]+):[^@/]*@", r"\1:***@", path or "")


IP_RE = re.compile(r"^\d+\.\d+\.\d+\.\d+$")


def _port_open(ip, port, wait=1.0):
    import socket
    try:
        socket.create_connection((ip, port), wait).close()
        return True
    except Exception:
        return False


def _is_share(ip, port, wait=1.5):
    """Is the phone's share listening here? For kodi-share (WebDAV) the reply
    must come from rclone: Kodi's own web server (the Kore remote) also uses
    port 8080, on the Xbox and maybe other devices. FTP: an open port is enough."""
    if not _port_open(ip, port, wait):
        return False
    if port == int(PHONE_KINDS["ftp"]["port"]):
        return True
    try:
        from urllib.request import Request, urlopen
    except ImportError:
        from urllib2 import Request, urlopen
    req = Request("http://%s:%d/" % (ip, port), headers={"Depth": "0"})
    req.get_method = lambda: "PROPFIND"
    try:
        resp = urlopen(req, timeout=4)
        headers = resp.info()
        resp.close()
    except Exception as e:
        headers = getattr(e, "headers", None) or getattr(e, "hdrs", None)
    realm = (headers.get("WWW-Authenticate", "") if headers is not None else "") or ""
    # rclone = kodi-share in Termux; kodisorter = the Android companion app
    return "rclone" in realm.lower() or "kodisorter" in realm.lower()


def _my_ip():
    """The Xbox's own address on the hotspot."""
    ip = (xbmc.getInfoLabel("Network.IPAddress") or "").strip()
    if IP_RE.match(ip) and not ip.startswith(("0.", "127.")):
        return ip
    import socket
    try:  # no packet is sent: this only asks which local address would be used
        sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sk.connect(("192.0.2.1", 9))
        ip = sk.getsockname()[0]
        sk.close()
        return ip
    except Exception:
        return ""


def _scan_subnet(port, me):
    """Look for the phone's share on the Xbox's own network (x.x.x.1-254)."""
    import threading
    prefix = me.rsplit(".", 1)[0] + "."
    found = []

    def probe(n):
        ip = prefix + str(n)
        # Devices on the hotspot answer in a few ms; 0.6 s is plenty.
        if ip != me and not found and _is_share(ip, port, 0.6):
            found.append(ip)
    for start in (1, 128):  # two batches: about a second when the phone isn't sharing
        threads = [threading.Thread(target=probe, args=(n,)) for n in range(start, min(start + 127, 255))]
        for t in threads:
            t.daemon = True
            t.start()
        for t in threads:
            t.join(3)
        if found:
            break
    return found[0] if found else ""


def phone_address(dlg, ask=True, port=8080):
    """The phone's address on the hotspot. Tries the last address that worked,
    Kodi's gateway, then searches the Xbox's network for the share's port.
    (Kodi on the Xbox doesn't report the gateway, and Android can change the
    hotspot address each time it's turned on.) Typed by hand as a last resort."""
    saved = load_cache(data_file("phone.json"))
    tried = []
    for ip in (saved.get("ip", ""), (xbmc.getInfoLabel("Network.GatewayAddress") or "").strip()):
        if IP_RE.match(ip) and not ip.startswith("0.") and ip not in tried:
            tried.append(ip)
            if _is_share(ip, port):
                return _remember_ip(saved, ip)
    me = _my_ip()
    if me:
        ip = _scan_subnet(port, me)
        log("searched %s.x for the phone's share on port %d: %s" % (me.rsplit(".", 1)[0], port, ip or "not found"))
        if ip:
            return _remember_ip(saved, ip)
    if not ask or dlg is None:
        return ""
    ip = dlg.input("Phone's address (kodi-share shows it as Address)", saved.get("ip", ""))
    return _remember_ip(saved, ip.strip()) if ip and ip.strip() else ""


def _remember_ip(saved, ip):
    if saved.get("ip") != ip:
        saved["ip"] = ip
        save_cache(data_file("phone.json"), saved)
    return ip


def resolve_src(src, dlg):
    """Swap PHONE for the phone's current address."""
    if "@%s:" % PHONE not in src:
        return src
    m = re.search(r"@%s:(\d+)" % PHONE, src)
    ip = phone_address(dlg, port=int(m.group(1)) if m else 8080)
    return src.replace("@%s:" % PHONE, "@%s:" % ip) if ip else src


def phone_source(dlg, kind):
    """Build (and test) the saved-path form of a phone share, or None."""
    info = PHONE_KINDS[kind]
    saved = load_cache(data_file("phone.json"))
    creds = saved.get(kind, {})
    if not creds.get("pass"):
        pw = dlg.input("Password for %s (shown on the phone)" % info["label"])
        if not pw:
            return None
        user = info["user"]
        if kind == "ftp":
            user = dlg.input("User name set in primitive ftpd", info["user"]) or info["user"]
        creds = {"user": user, "pass": pw, "port": creds.get("port", info["port"])}
        saved[kind] = creds
        save_cache(data_file("phone.json"), saved)
    base = "%s://%s:%s@%s:%s/" % (kind, quote(creds["user"], ""), quote(creds["pass"], ""),
                                  PHONE, creds["port"])
    real = resolve_src(base, dlg)
    if PHONE in real.split("@", 1)[-1].split("/")[0] or not phone_reachable(real):
        msg = ("Can't reach the phone (%s).\n" % masked(real) +
               ("On the phone, tap Start sharing in the companion app, or start kodi-share in Termux,"
                if kind == "dav" else "Start primitive ftpd on the phone") +
               " and keep this device on the phone's hotspot or the same Wi-Fi.")
        if dlg.yesno(ADDON, msg + "\nWrong password? Forget it and ask again next time.",
                     nolabel="OK", yeslabel="Forget password"):
            saved = load_cache(data_file("phone.json"))
            saved.pop(kind, None)
            save_cache(data_file("phone.json"), saved)
        return None
    # Pick a folder inside the share. Kodi's own folder browser can't open a place that
    # isn't a Kodi source (it shows the source list instead), so the phone's folders are
    # listed here directly. Back = the whole Download folder.
    return base + pick_phone_folder(dlg, real, "Download" if kind == "dav" else "USB drive")


def pick_phone_folder(dlg, real, top="Download"):
    """Walk the phone's folders. Returns the chosen folder relative to the share root
    ("" = the whole share: Back at the top, as before)."""
    rel = ""
    while True:
        try:
            dirs = sorted((d for d in xbmcvfs.listdir(real + rel)[0] if not d.startswith(".")), key=str.lower)
        except Exception:
            dirs = []
        here = (top + "/" + rel).rstrip("/")
        shown = shown_path(here, "")
        opts = ["Use this folder: %s" % shown] + ["%s/" % shown_path(d, "") for d in dirs]
        pick = dlg.select("Phone: %s" % shown, opts)
        if pick < 0:
            if not rel:
                return ""  # Back at the top = all of Download (as before)
            rel = rel.rstrip("/").rsplit("/", 1)[0] + "/" if "/" in rel.rstrip("/") else ""
            continue
        if pick == 0:
            return rel
        rel = rel + dirs[pick - 1] + "/"


# ---------- send logs to the phone ----------
# When kodi-share runs on the phone, Kodi's logs are copied to
# Download/KodiSorterLogs on the phone over the hotspot (no mobile data), so
# they can be read there. Quiet and quick: skipped if the phone isn't sharing.
LOG_DIR = "SortoviaLogs"
LOG_MAX = 3 * 1024 * 1024  # last 3 MB of each log is plenty


def _read_tail(path, limit):
    try:
        f = xbmcvfs.File(path)
        try:
            size = f.size()
            if size > limit:
                f.seek(size - limit, 0)
            return bytes(f.readBytes())
        finally:
            f.close()
    except Exception as e:
        log("can't read %s: %s" % (path, e))
        return b""


def _dav_ok(ip, port, user, pw):
    """True if the phone's share accepts this password."""
    import base64
    try:
        from urllib.request import Request, urlopen
    except ImportError:
        from urllib2 import Request, urlopen
    auth = base64.b64encode(("%s:%s" % (user, pw)).encode()).decode()
    req = Request("http://%s:%d/" % (ip, port), headers={"Authorization": "Basic " + auth, "Depth": "0"})
    req.get_method = lambda: "PROPFIND"
    try:
        urlopen(req, timeout=10).close()
        return True
    except Exception as e:
        return getattr(e, "code", None) in (207, 405)


def send_logs(why, dlg=None, files=None, folder=LOG_DIR):
    """PUT kodi.log (and kodi.old.log on start-up) to the phone. Returns a short status.
    With dlg: if the phone is sharing but no password is saved yet, ask for it.
    files: [(name, bytes)] to send instead of the logs (e.g. a report).
    folder: where in the phone's Download folder (made if needed, e.g. "A/B")."""
    import socket
    if not setting_on("use_phone"):
        return "using a phone is off in Sortovia's settings"
    if why in ("start", "during-run", "end") and not setting_on("send_logs"):
        return "sending logs is off in Sortovia's settings"
    saved = load_cache(data_file("phone.json"))
    creds = saved.get("dav") or {}
    if not creds.get("pass") and why != "manual":
        # Nobody has set up a phone: don't search their network for one.
        return "phone share not set up"
    port = int(creds.get("port", 8080))
    ip = phone_address(dlg if why == "manual" else None, ask=(why == "manual"), port=port)
    if not ip:
        return "phone not found - is the phone sharing, and on the same Wi-Fi or hotspot as this device?"
    if not _port_open(ip, port, 2):
        return "phone not sharing"
    if not creds.get("pass"):
        if dlg is None:
            return "phone share not set up"
        while True:
            pw = dlg.input("Your phone is sharing - type the password it shows (once)")
            if not pw:
                return "no password typed"
            if _dav_ok(ip, port, "kodi", pw.strip()):
                break
            if not dlg.yesno(ADDON, "That password didn't work. Try again?", nolabel="Skip", yeslabel="Try again"):
                return "wrong password"
        creds = {"user": "kodi", "pass": pw.strip(), "port": str(port)}
        saved = load_cache(data_file("phone.json"))  # re-read: the address was just saved
        saved["dav"] = creds
        save_cache(data_file("phone.json"), saved)
        toast("Password saved - logs now go to your phone automatically")
    import base64
    try:
        from urllib.request import Request, urlopen
    except ImportError:
        from urllib2 import Request, urlopen
    auth = base64.b64encode(("%s:%s" % (creds["user"], creds["pass"])).encode()).decode()
    base = "http://%s:%d/%s/" % (ip, port, quote(folder))

    def call(method, url, data=None):
        req = Request(url, data=data, headers={"Authorization": "Basic " + auth})
        req.get_method = lambda: method
        try:
            urlopen(req, timeout=20).close()
            return True
        except Exception as e:
            code = getattr(e, "code", None)
            return code == 405 and method == "MKCOL"  # 405 = folder already there

    parts = folder.split("/")
    for i in range(1, len(parts) + 1):  # each level of the folder
        call("MKCOL", "http://%s:%d/%s/" % (ip, port, quote("/".join(parts[:i]))))
    logdir = "special://logpath/"
    stamp = time.strftime("%Y%m%d-%H%M%S")
    names = [("kodi.log", "kodi-%s-%s.log" % (stamp, why))]
    if why == "start":
        names.append(("kodi.old.log", "kodi-%s-previous-session.log" % stamp))
    if files:
        sent = sum(1 for name, data in files if call("PUT", base + name, data))
        log("sent to phone: %s" % ", ".join(n for n, _ in files))
        return "sent %d file(s) to the phone" % sent
    sent = 0
    for src, dst in names:
        data = _read_tail(logdir + src, LOG_MAX)
        if data and call("PUT", base + dst, data):
            sent += 1
    log("logs sent to phone: %d file(s) (%s)" % (sent, why))
    return "sent %d log(s) to the phone" % sent


def phone_reachable(url):
    try:
        dirs, files = xbmcvfs.listdir(url)
        return bool(dirs or files) or xbmcvfs.exists(url)
    except Exception:
        return False


# ---------- self-update ----------
# The "repository" add-on can't connect on this Xbox, but Kodi can read the
# same web page fine, so the add-on checks it directly on every run.
UPDATE_BASE = "https://akaguyver.github.io/kodi-repo/"
ADDON_ID = "script.kodisorter"


def _vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:3])


def _fetch_kodi(url):
    f = xbmcvfs.File(url)
    try:
        chunks = []
        while True:
            b = f.readBytes(65536)
            if not b:
                break
            chunks.append(bytes(b))
        return b"".join(chunks)
    finally:
        f.close()


def _fetch_python(url, headers=None):
    try:
        from urllib.request import urlopen, Request
    except ImportError:
        from urllib2 import urlopen, Request
    h = {"User-Agent": "Sortovia", "Cache-Control": "no-cache"}
    h.update(headers or {})
    req = Request(url, headers=h)
    resp = urlopen(req, timeout=20)
    try:
        return resp.read()
    finally:
        resp.close()


FETCH_LOG = []


def _fetch(url):
    """Download a URL: Kodi's own downloader first (read in chunks - GitHub
    sends compressed replies with no length), then Python's as a fallback.
    The ?t= part stops any cache from handing back an old copy. What each
    method did is kept in FETCH_LOG so a failure can be shown on screen."""
    url += ("&" if "?" in url else "?") + "t=%d" % int(time.time())
    for name, method in (("Kodi", _fetch_kodi), ("Python", _fetch_python)):
        try:
            data = method(url)
        except Exception as e:
            FETCH_LOG.append("%s downloader: %s" % (name, e))
            continue
        if data:
            FETCH_LOG.append("%s downloader: OK, %d bytes" % (name, len(data)))
            return data
        FETCH_LOG.append("%s downloader: got nothing back" % name)
    raise IOError("could not download %s" % url.split("?")[0].rsplit("/", 1)[-1])


# GitHub's API serves the file straight from the repo. The Pages site sits
# behind a cache that can hand out the old addons.xml for ~10 minutes after
# a release, which looked like "no update" on the Xbox.
UPDATE_CHANNEL = "dev/" if devtools else ""  # a device with the dev tools keeps getting them
UPDATE_API = "https://api.github.com/repos/akaguyver/kodi-repo/contents/%saddons.xml" % UPDATE_CHANNEL


def _fetch_api():
    hdr = {"Accept": "application/vnd.github.raw"}
    try:
        data = _fetch_kodi(UPDATE_API + "|" + "&".join("%s=%s" % (k, quote(v)) for k, v in
                                                        dict(hdr, **{"User-Agent": "Sortovia"}).items()))
        if data and b"<addons" in data:
            FETCH_LOG.append("GitHub API (Kodi): OK")
            return data
    except Exception as e:
        FETCH_LOG.append("GitHub API (Kodi): %s" % e)
    try:
        data = _fetch_python(UPDATE_API, hdr)
        if data and b"<addons" in data:
            FETCH_LOG.append("GitHub API (Python): OK")
            return data
    except Exception as e:
        FETCH_LOG.append("GitHub API (Python): %s" % e)
    return None


def latest_version():
    """Newest version on GitHub. Raises if it can't be read."""
    data = _fetch_api() or _fetch(UPDATE_BASE + UPDATE_CHANNEL + "addons.xml")
    xml = data.decode("utf-8", "ignore")
    if not xml.strip():
        raise IOError("empty reply from GitHub")
    m = re.search(r'<addon[^>]*id="%s"[^>]*version="([^"]+)"' % re.escape(ADDON_ID), xml)
    if not m:
        raise IOError("Sortovia not listed on the update page")
    return m.group(1)


UPDATE_WAIT = 12  # seconds; with mobile data off the check would otherwise hang


def latest_version_within(seconds, tick=None):
    """latest_version() with a time limit (no internet can mean long timeouts).
    tick(fraction of the wait used) runs 5 times a second; True from it = stop waiting."""
    import threading
    box = {}

    def work():
        try:
            box["v"] = latest_version()
        except Exception as e:
            box["e"] = e
    t = threading.Thread(target=work)
    t.daemon = True
    t.start()
    end = time.time() + seconds
    while t.is_alive() and time.time() < end:
        t.join(0.2)
        if tick and tick(1 - (end - time.time()) / seconds):
            raise UpdateSkipped("skipped")
    if "v" in box:
        return box["v"]
    raise box.get("e") or IOError("no reply within %d seconds - no internet?" % seconds)


class UpdateSkipped(Exception):
    pass


def toast(msg, ms=4000):
    try:
        xbmcgui.Dialog().notification("Sortovia", msg, xbmcgui.NOTIFICATION_INFO, ms)
    except Exception:
        log(msg)


# The repo's files straight from GitHub: there the new zip exists the moment
# it's pushed. The Pages site can lag a minute or more behind (seen: version
# found via the API, zip still 404 on Pages), so it's only the fallback.
RAW_BASE = "https://raw.githubusercontent.com/akaguyver/kodi-repo/main/"


def _download_zip(version):
    errors = []
    for base in (RAW_BASE, UPDATE_BASE):
        url = "%s%s%s/%s-%s.zip" % (base, UPDATE_CHANNEL, ADDON_ID, ADDON_ID, version)
        try:
            data = _fetch(url)
            want = _fetch(url + ".md5").decode("ascii", "ignore").strip().split(" ")[0]
        except Exception as e:
            errors.append("%s: %s" % (base.split("/")[2], e))
            continue
        if data and hashlib.md5(data).hexdigest() == want:
            return data
        errors.append("%s: checksum mismatch" % base.split("/")[2])
    raise IOError("download failed (%s)" % "; ".join(errors))


def install_update(version, folder):
    """Download, verify and unpack the new version over this add-on's folder."""
    data = _download_zip(version)
    prefix = ADDON_ID + "/"
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        members = [n for n in z.namelist() if n.startswith(prefix) and not n.endswith("/")]
        if not any(n == prefix + "addon.xml" for n in members):
            raise ValueError("download is not a Sortovia add-on")
        for n in members:
            rel = n[len(prefix):]
            if rel.startswith(("/", "\\")) or ".." in rel.replace("\\", "/").split("/"):
                raise ValueError("bad path in download: %s" % n)
        for n in members:
            out = os.path.join(folder, *n[len(prefix):].split("/"))
            if not os.path.isdir(os.path.dirname(out)):
                os.makedirs(os.path.dirname(out))
            with open(out + ".new", "wb") as fh:
                fh.write(z.read(n))
            os.replace(out + ".new", out)
    xbmc.executebuiltin("UpdateLocalAddons")


def check_for_update(dlg, manual=False, splash=None):
    """Returns True if an update was installed (caller should stop).
    Runs on every launch; manual=True is the "Check for updates now" item.
    splash: the start-up screen; it shows the wait, Cancel skips the check,
    and it's closed before any question is asked."""
    del FETCH_LOG[:]
    current = "?"
    tick = None
    if splash is not None:
        def tick(frac):
            splash.update(int(min(frac, 1) * 100), "Checking for updates...\n(Cancel to skip)")
            return splash.iscanceled()
    try:
        me = xbmcaddon.Addon()
        current = me.getAddonInfo("version")
        folder = xbmcvfs.translatePath(me.getAddonInfo("path"))
        newest = latest_version_within(UPDATE_WAIT if not manual else 60, tick)
    except UpdateSkipped:
        _close(splash)
        log("update check skipped (Cancel on the start-up screen)")
        toast("Update check skipped (%s)" % current, 3000)
        return False
    except Exception as e:
        _close(splash)
        log("update check failed: %s | %s" % (e, " | ".join(FETCH_LOG)))
        if manual:
            dlg.ok(ADDON, "Couldn't check for updates (you have %s).\n%s\n%s\n"
                   "Carrying on without updating." % (current, e, "\n".join(FETCH_LOG[-2:])))
        else:
            # Normal when the phone's mobile data is off: just say so in the corner.
            toast("No internet - skipped the update check (%s)" % current, 3000)
        return False
    log("update check: have %s, newest %s | %s" % (current, newest, " | ".join(FETCH_LOG)))
    _close(splash)
    if _vtuple(newest) <= _vtuple(current):
        if manual:
            dlg.ok(ADDON, "You have the newest version (%s)." % current)
        else:
            toast("Up to date (%s)" % current, 3000)
        return False
    if not yesno_default_yes(dlg, "Sortovia %s is available (you have %s).\nUpdate now?" % (newest, current),
                             nolabel="Not now", yeslabel="Update"):
        return False
    try:
        install_update(newest, folder)
    except Exception as e:
        log("update failed: %s" % e)
        dlg.ok(ADDON, "Update failed: %s\nNothing was changed. Carrying on with %s." % (e, current))
        return False
    dlg.ok(ADDON, "Updated to %s.\n%s" % (newest, "Open Sortovia again to use the new version." if manual
                                          else "The menu will now reload with the new version."))
    return True


# ---------- comics: tidy, .cbr -> .cbz, turned pages ----------
COMICS_PREF = "comics.json"  # addon_data: {"convert": bool, "turn": 1|6|8}


def comics_pref():
    p = load_cache(data_file(COMICS_PREF))
    return {"convert": setting_on("convert_comics"), "turn": p.get("turn", 1)}


def _read_exact(url):
    f = xbmcvfs.File(url)
    try:
        size, chunks, done = f.size(), [], 0
        while size <= 0 or done < size:  # stop at the size: the read past the end can hang on the Xbox
            b = f.readBytes(1024 * 1024 if size <= 0 else min(1024 * 1024, size - done))
            if not b:
                break
            chunks.append(bytes(b))
            done += len(b)
        return b"".join(chunks)
    finally:
        f.close()


# ---------- free up space on the Xbox ----------
def _mb(n):
    return "%.1f GB" % (n / 1e9) if n >= 1e9 else "%d MB" % round(n / 1e6) if n >= 1e6 else "%d KB" % max(1, round(n / 1e3))


def dir_size(path, stop=lambda: False):
    total = 0
    try:
        dirs, files = xbmcvfs.listdir(path)
    except Exception:
        return 0
    for f in files:
        try:
            total += xbmcvfs.Stat(path + f).st_size()
        except Exception:
            pass
    for d in dirs:
        if stop():
            break
        total += dir_size(path + d + "/", stop)
    return total


# Folders Kodi itself keeps in its temp folder, said plainly.
SAFE_TEMP = {"addons": "Kodi's leftovers from installing add-ons (safe to delete)",
             "scrapers": "The library scraper's cache of show and movie info (safe - fetched again when needed)",
             "archive_cache": "Pages Kodi unpacked from .cbr/.rar files to show them (safe)"}


def temp_label(name):
    low = name.lower()
    if low.startswith("kodisorter-export"):
        return "Sortovia's leftover backup export %s (safe)" % name[len("kodisorter-export-"):]
    if low.startswith(("kodisorter", "comic-")):
        return "Sortovia leftover: %s (safe)" % name
    if low in SAFE_TEMP:
        return SAFE_TEMP[low]
    return "Kodi's temporary folder \"%s\" (delete only if you know what it is)" % name


def space_rows(stop=lambda: False):
    """[(label, size, path, is_dir, preselected)] of what can be removed from the Xbox's storage."""
    rows = []
    temp = "special://temp/"
    try:
        dirs, files = xbmcvfs.listdir(temp)
    except Exception:
        dirs, files = [], []
    ours = lambda n: n.lower().startswith(("kodisorter", "comic-")) or "archive" in n.lower() or "rar" in n.lower()
    for d in dirs:
        size = dir_size(temp + d + "/", stop)
        if size:
            rows.append((temp_label(d), size, temp + d + "/", True, ours(d) or d.lower() in SAFE_TEMP))
    for f in files:
        if f.lower().endswith(".log"):
            continue  # Kodi's own log
        try:
            size = xbmcvfs.Stat(temp + f).st_size()
        except Exception:
            continue
        if size:
            rows.append(("Temporary: %s" % f, size, temp + f, False, ours(f) or f.lower().endswith((".tmp", ".cbz", ".zip"))))
    pk = "special://home/addons/packages/"
    size = dir_size(pk, stop)
    if size:
        rows.append(("Old add-on install files (addons/packages)", size, pk, True, True))
    stamps = [st for st, _ in backup.list_backups(backup.HOME_DIR)]
    on_drive = bool(backup.drive_dir(load_cache(data_file("last_settings.json")).get("dest")))
    for st in (stamps if on_drive else stamps[1:]):  # backups belong on the drive now
        size = dir_size(backup.HOME_DIR + st + "/", stop)
        rows.append(("Library backup %s on this device (backups now go on the drive)" % st, size,
                     backup.HOME_DIR + st + "/", True, True))
    return sorted(rows, key=lambda r: -r[1])


def free_space(dlg):
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Measuring what's on this device's storage...")
    try:
        rows = space_rows(prog.iscanceled)
        art = dir_size("special://masterprofile/Thumbnails/", prog.iscanceled)
    finally:
        prog.close()
    free = xbmc.getInfoLabel("System.FreeSpace") or "?"
    if not rows:
        dlg.ok(ADDON, "Nothing to clear. Free: %s.\nKodi's artwork cache uses %s (not cleared here - Kodi needs "
                      "it for posters)." % (free, _mb(art)))
        return
    newest = all_backups()
    kept = ("newest backup %s kept" % newest[0][1]) if newest else "no backups yet"
    picks = dlg.multiselect("Free: %s - %s - tick what to delete" % (free, kept),
                            ["%s  -  %s" % (label, _mb(size)) for label, size, _, _, _ in rows],
                            preselect=[i for i, r in enumerate(rows) if r[4]])
    if not picks:
        return
    freed = 0
    for i in picks:
        label, size, path, is_dir, _ = rows[i]
        ok = False
        try:
            if is_dir and path.endswith("addons/packages/"):
                for f in xbmcvfs.listdir(path)[1]:
                    xbmcvfs.delete(path + f)
                ok = True
            elif is_dir:
                ok = xbmcvfs.rmdir(path, True)
            else:
                ok = xbmcvfs.delete(path)
        except Exception as e:
            log("couldn't delete %s: %s" % (path, e))
        if ok:
            freed += size
        log("free space: %s %s (%s)" % ("deleted" if ok else "couldn't delete", path, _mb(size)))
    dlg.ok(ADDON, "Freed about %s.\nFree now: %s.\nKodi's artwork cache uses %s (kept - Kodi needs it)." %
           (_mb(freed), xbmc.getInfoLabel("System.FreeSpace") or "?", _mb(art)))


# ---------- Real-Debrid ----------
PROP_RD = "kodisorter.rd"            # status text while a Real-Debrid download runs
PROP_RD_STOP = "kodisorter.rd.stop"
PROP_RD_PAUSE = "kodisorter.rd.pause"  # set: the Real-Debrid download waits, its half-done file kept open
RD_WHERE = "rd_where.json"  # {"where": "phone" | "xbox"}: which device downloads Real-Debrid files (phone when unset)
PROP_RD_WAIT = "kodisorter.rd.wait"  # status text while waiting for Real-Debrid to fetch torrents
PROP_RD_WATCH = "kodisorter.rd.watch"
PROP_AUTOSORT = "kodisorter.autosort"  # set while the Xbox is watching the phone for finished downloads
AUTOSORT = "autosort.json"  # {"off": True when turned off, "tried": {folder/name: size} already sorted once}
RD_FILE = "realdebrid.json"
RD_QUEUE = "rd_queue.json"           # torrents to download as soon as Real-Debrid has them
RD_WATCH_EVERY = 15                  # seconds between checks
RD_STALL = 30 * 60                   # Real-Debrid fetching a torrent with no progress this long: get it another way
FEEDS_FILE = "feeds.json"            # {"feeds": [{"name", "url"}]}; the address may hold a private key


def rd_client():
    import realdebrid
    return realdebrid.RD(lambda: load_cache(data_file(RD_FILE)), lambda st: save_cache(data_file(RD_FILE), st))


def rd_folder(dlg=None):
    """<library drive>\\Downloads\\Real-Debrid\\ (made if needed)."""
    root = backup.drive_dir(load_cache(data_file("last_settings.json")).get("dest") or "")
    if root:
        folder = root.replace(backup.DRIVE_DIR, "Downloads") + "Real-Debrid/"
        xbmcvfs.mkdirs(folder)
        if xbmcvfs.exists(folder):
            return folder
    if dlg is not None:
        pick = dlg.browse(0, "Real-Debrid downloads go where?", "files")
        return ensure_slash(pick) if pick else None
    return None


def rd_sign_in(dlg):
    import realdebrid
    rd = rd_client()
    how = dlg.select("Sign in to Real-Debrid", ["With a code on my phone (easiest)",
                                                "Type an API token (real-debrid.com/apitoken)"])
    try:
        if how == 1:
            tok = dlg.input("Real-Debrid API token")
            if tok:
                rd.use_api_token(tok)
        elif how == 0:
            dev = rd.device_start()
            try:
                _rd_qr_wait(rd, dev)
            except Exception as e:  # no QR window on this Kodi: the plain code screen
                log("Real-Debrid QR screen failed (%s), showing the code only" % e)
                _rd_code_wait(rd, dev)
        if rd.signed_in():
            u = rd.user()
            rd.state["username"] = u.get("username", "")
            rd.state["premium_until"] = (u.get("expiration") or "")[:10]
            rd.save(rd.state)
            dlg.ok(ADDON, "Signed in to Real-Debrid as %s%s." % (
                u.get("username", "?"), (" (premium until %s)" % rd.state["premium_until"]) if u.get("type") == "premium"
                else " - note: downloads need a premium account"))
    except realdebrid.RDError as e:
        dlg.ok(ADDON, str(e))


def _rd_code_wait(rd, dev):
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "On your phone, open %s\nand enter the code:  %s" % (
        dev.get("verification_url", "real-debrid.com/device"), dev["user_code"]))
    end = time.time() + int(dev.get("expires_in", 600))
    try:
        while time.time() < end and not prog.iscanceled():
            prog.update(int(100 - (end - time.time()) * 100 / max(int(dev.get("expires_in", 600)), 1)))
            if rd.device_poll(dev):
                break
            xbmc.sleep(int(dev.get("interval", 5)) * 1000)
    finally:
        prog.close()


def _rd_qr_wait(rd, dev):
    """Sign-in screen: a QR code that opens Real-Debrid's approve page for this code
    (scan it with the phone's camera), and the code to type at real-debrid.com/device."""
    import qrpng
    link = dev.get("direct_verification_url") or dev.get("verification_url") or "https://real-debrid.com/device"
    qr = "special://temp/kodisorter-rd-%s.png" % dev["user_code"]  # new name per code: Kodi caches images by name
    bg = "special://temp/kodisorter-rd-bg.png"
    for path, data in ((qr, qrpng.qr_png(link)), (bg, qrpng.solid_png(20))):
        out = _VfsWriter(path)
        try:
            out.write(data)
        finally:
            out.close()

    class CodeWindow(xbmcgui.WindowDialog):
        closed = False

        def onAction(self, action):
            if action.getId() in (9, 10, 13, 92):  # back / previous menu / stop
                self.closed = True
                self.close()

    win = CodeWindow()
    win.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, bg))
    win.addControl(xbmcgui.ControlImage(90, 130, 460, 460, qr))
    box = xbmcgui.ControlTextBox(600, 130, 620, 460, font="font13", textColor="FFFFFFFF")
    win.addControl(box)
    end = time.time() + int(dev.get("expires_in", 600))
    text = ("[B]Sign in to Real-Debrid[/B]\n\n"
            "Scan the code with your phone's camera. It opens Real-Debrid for this sign-in - tap Allow.\n\n"
            "Or open [B]real-debrid.com/device[/B] and type:\n\n[B]%s[/B]\n\n" % dev["user_code"])
    mon = xbmc.Monitor()
    win.show()
    try:
        while not win.closed and time.time() < end and not mon.abortRequested():
            box.setText(text + "Waiting... %d min left. Back = cancel." % max(1, int((end - time.time()) / 60)))
            if rd.device_poll(dev):
                break
            if mon.waitForAbort(int(dev.get("interval", 5))):
                break
    finally:
        win.close()
        for path in (qr, bg):
            xbmcvfs.delete(path)


def _rd_ready(dlg):
    rd = rd_client()
    if not rd.signed_in():
        rd_sign_in(dlg)
        rd = rd_client()
    return rd if rd.signed_in() else None


def rd_download(dlg, files, group="", folder=None, auto=False, where=None):
    """Download [(url, name, size)] into the Real-Debrid folder, in the background
    (Kodi stays usable; the top of the menu shows progress and Stop). On this device they go on the
    saved list first (rd_jobs) and rd_run works through it, so they survive Kodi closing.
    auto: asked for already, so no questions; says the result in a corner of the screen.
    Returns "stopped" if the person stopped it."""
    total = sum(f[2] for f in files)
    phone_ok = bool((load_cache(data_file("phone.json")).get("dav") or {}).get("pass"))
    on_phone = phone_ok and (where or load_cache(data_file(RD_WHERE)).get("where", "phone")) == "phone"
    if not auto and not where:
        here = ["On this Xbox (to the library drive)"]
        there = ["On the phone (into Download/Real-Debrid, then sort from there)"] if phone_ok else []
        opts = (there + here) if on_phone else (here + there)
        pick = dlg.select("Download %d file(s), %s - where?" % (len(files), _mb(total)), opts + ["Cancel"])
        if pick < 0 or pick >= len(opts):
            return
        on_phone = opts[pick] in there
    if on_phone:
        return rd_download_on_phone(dlg, files, group, auto)
    folder = folder or rd_folder(dlg)
    if not folder:
        return
    if group:
        folder = join(folder, safe(group)) + "/"
        xbmcvfs.mkdirs(folder)
    jobs = rd_jobs()
    for url, name, size in files:
        jobs.add(url, safe(name), size, folder, group)  # on the saved list first, so nothing is lost if Kodi closes
    if home().getProperty(PROP_RD):
        toast("Added to the Real-Debrid downloads: %d file(s) start after the one downloading now." % len(files), 6000)
        return
    return rd_run(dlg, auto)


RD_JOBS = "rd_jobs.json"  # Real-Debrid downloads on this device: queued, half done, failed and finished (dlqueue.Jobs)


def rd_jobs():
    import dlqueue
    return dlqueue.Jobs(lambda: load_cache(data_file(RD_JOBS)), lambda st: save_cache(data_file(RD_JOBS), st, verify=False))


class _VfsReader(object):
    def __init__(self, path):
        self.f = xbmcvfs.File(path)

    def read(self, n):
        return bytes(self.f.readBytes(n))

    def close(self):
        self.f.close()


class _RdFiles(object):
    """The file functions dlqueue.fetch needs, on Kodi's own file access."""
    exists = staticmethod(lambda p: bool(xbmcvfs.exists(p)))
    size = staticmethod(lambda p: size_of(p))
    delete = staticmethod(lambda p: xbmcvfs.delete(p))
    writer = staticmethod(lambda p: _VfsWriter(p))
    reader = staticmethod(lambda p: _VfsReader(p))

    @staticmethod
    def rename(a, b):
        if NO_RENAME[0]:
            return False
        try:
            return bool(xbmcvfs.rename(a, b))
        except Exception:
            return False

    @staticmethod
    def appender(path):
        """Python's own file, opened to add to the end - only where Python sees the same file Kodi does.
        (Kodi's files can only be written from the start.) None means: carry on in a new piece."""
        try:
            native = xbmcvfs.translatePath(path)
            if "://" in native or os.path.getsize(native) != size_of(path):
                return None
            return open(native, "ab")
        except Exception:
            return None


def _rd_open(url, start):
    """Ask for a file, or for the rest of it from byte `start`."""
    try:
        from urllib.request import Request, urlopen
    except ImportError:
        from urllib2 import Request, urlopen
    headers = {"User-Agent": "Sortovia"}
    if start:
        headers["Range"] = "bytes=%d-" % start
    return urlopen(Request(url, headers=headers), timeout=60)


def rd_run(dlg, auto=False):
    """Work through the saved list of Real-Debrid downloads on this device, one at a time, in the background
    (Kodi stays usable; the top of the menu shows progress, Pause and Stop). Each carries on from the part already
    on the drive. A failed one keeps its part and stays on the list for Try again; Stop removes them.
    auto: no questions; says the result in a corner of the screen. Returns "stopped" if the person stopped it."""
    import dlqueue
    if home().getProperty(PROP_RD):
        return
    home().setProperty(PROP_RD, "starting")
    home().clearProperty(PROP_RD_STOP)
    jobs = rd_jobs()
    jobs.interrupted()  # nothing else is downloading: what was cut off is queued again
    monitor = xbmc.Monitor()
    bar = xbmcgui.DialogProgressBG()
    bar.create("Real-Debrid", "Starting")
    done_bytes, ok, n, report, stopped, closing, folder = 0, 0, 0, [], False, False, ""
    try:
        while True:
            job = jobs.next()
            if not job:
                break
            n += 1
            name, size, folder = job["name"], job.get("size") or 0, job["folder"]
            dst = folder + name
            left = len([j for j in jobs.all() if j.get("state") == "queued"]) - 1
            total = done_bytes + size + sum(j.get("size") or 0 for j in jobs.all()
                                            if j.get("state") == "queued" and j["id"] != job["id"])
            if xbmcvfs.exists(dst) and size and size_of(dst) == size:
                report.append("ALREADY  %s" % name)
                jobs.set(job["id"], state="done", got=size, error="")
                done_bytes += size
                ok += 1
                continue
            jobs.set(job["id"], state="downloading", error="")
            seen = {"at": time.time(), "got": dlqueue.have_bytes(dst, _RdFiles), "shown": 0, "saved": time.time()}

            def check():
                if home().getProperty(PROP_RD_STOP):
                    raise CopyStopped()
                if monitor.abortRequested():
                    raise KodiClosing()

            def tick(got, size_now, job=job, name=name, n=n, left=left, total=total, seen=seen):
                check()
                if home().getProperty(PROP_RD_PAUSE):
                    jobs.set(job["id"], state="paused", got=got)
                    home().setProperty(PROP_RD, "paused at %s, %d of %d" % (_mb(got), n, n + left))
                    bar.update(0, "Real-Debrid", "Paused - Sortovia's menu has Carry on\n%s" % name)
                    while home().getProperty(PROP_RD_PAUSE):
                        if monitor.waitForAbort(0.5):
                            raise KodiClosing()
                        check()
                    jobs.set(job["id"], state="downloading")
                    seen.update(at=time.time(), got=got)
                    return True  # the connection has gone stale: ask for the rest again
                now = time.time()
                if now - seen["shown"] > 1:
                    seen["shown"] = now
                    speed = (got - seen["got"]) / max(now - seen["at"], 1)
                    pct = int((done_bytes + got) * 100 / max(total, got, 1))
                    status = "%d of %d, %d%% - %s/s" % (n, n + left, pct, _mb(speed))
                    home().setProperty(PROP_RD, status)
                    bar.update(pct, "Real-Debrid", "%s\n%s" % (status, name))
                if now - seen["saved"] > 30:  # so the list shows how far it got
                    seen["saved"] = now
                    jobs.set(job["id"], got=got)

            def nap(seconds, name=name):
                home().setProperty(PROP_RD, "connection lost - trying again")
                bar.update(0, "Real-Debrid", "The connection dropped - trying again in %d s\n%s" % (seconds, name))
                for _ in range(int(seconds * 2)):
                    if monitor.waitForAbort(0.5):
                        raise KodiClosing()
                    check()

            def joining(done, total_now, name=name):
                check()
                if time.time() - seen["shown"] > 1:
                    seen["shown"] = time.time()
                    bar.update(int(done * 100 / max(total_now, 1)), "Real-Debrid", "Putting the pieces together\n%s" % name)

            try:
                got = dlqueue.fetch(job["url"], dst, size, _RdFiles, _rd_open, tick, nap, joining=joining)
                jobs.set(job["id"], state="done", got=got, size=size or got, error="")
                ok += 1
                done_bytes += size or got
                report.append("OK   %s (%s)" % (name, _mb(got)))
            except CopyStopped:
                for j in jobs.all():
                    if j.get("state") in ("queued", "downloading", "paused"):
                        dlqueue.drop_pieces(j["folder"] + j["name"], _RdFiles)
                jobs.remove(states=("queued", "downloading", "paused"))
                report.append("STOPPED  %s - half download removed" % name)
                stopped = True
            except KodiClosing:
                jobs.set(job["id"], state="queued", got=dlqueue.have_bytes(dst, _RdFiles))
                report.append("KODI CLOSED  %s - carries on next time" % name)
                closing = True
            except Exception as e:
                jobs.set(job["id"], state="failed", got=dlqueue.have_bytes(dst, _RdFiles), error=str(e)[:200])
                report.append("FAIL %s (%s) - the part downloaded is kept" % (name, e))
            log("real-debrid: " + report[-1])
            if stopped or closing:
                break
    finally:
        bar.close()
        home().clearProperty(PROP_RD)
        home().clearProperty(PROP_RD_STOP)
        home().clearProperty(PROP_RD_PAUSE)
    if closing or not n:
        return
    failed = len([r for r in report if r.startswith("FAIL")])
    again = ("\n%d failed: Downloads > Downloads on the phone has Retry all failed." % failed) if failed else ""
    text = "%d of %d downloaded to %s\n\n%s%s" % (ok, n, friendly(folder), "\n".join(report), again)
    if auto or dlg is None:
        if not stopped:
            toast("Real-Debrid: %d of %d downloaded.%s" % (ok, n, " %d failed - Downloads has Retry all failed." % failed
                                                          if failed else " Real-Debrid > Sort the downloads files them."), 10000)
        return "stopped" if stopped else None
    if ok and dlg.yesno(ADDON, "Real-Debrid: %d of %d downloaded.%s\nSort them into your library now?" % (ok, n, again),
                        nolabel="Later", yeslabel="Sort now"):
        rd_sort(dlg, session_file())
    elif not ok:
        dlg.textviewer("%s - Real-Debrid" % ADDON, text)


class KodiClosing(Exception):
    """Kodi is shutting down: leave the half-done file and the list as they are."""


def rd_download_on_phone(dlg, files, group="", auto=False):
    """Real-Debrid's unlocked files downloaded by the phone (aria2), into Download/Real-Debrid/<group>."""
    phone = _phone_quiet(dlg)
    sent, problems = 0, []
    for url, name, size in files:
        try:
            r = phone.call("/tor/add", {"uri": url, "kind": "Real-Debrid", "group": group, "out": safe(name)}) if phone \
                else {"error": "can't find the phone"}
            if r.get("id"):
                sent += 1
                rd_phone_sizes(add={r["id"]: {"url": url, "name": safe(name), "size": size, "group": group}})
            else:
                problems.append("%s: %s" % (name, r.get("error") or "?"))
        except Exception as e:
            problems.append("%s: %s" % (name, e))
    for p in problems:
        log("real-debrid on the phone: %s" % p)
    if sent:
        toast("The phone is downloading %d file(s) into Download/Real-Debrid. Downloads > Downloads on the phone "
              "shows them, and sorts them when done." % sent, 8000)
    if problems and not auto and dlg is not None:
        dlg.ok(ADDON, "The phone didn't take %d:\n%s" % (len(problems), "\n".join(problems[:5])))
    if problems and not sent:
        return "failed"


RD_PHONE = "rd_phone.json"  # {"files": {the phone's download id: {"url", "name", "size", "group"}}}: sizes to check


def rd_phone_sizes(add=None, keep=None):
    """What Real-Debrid said about each file handed to the phone, by the phone's download id, so a finished
    download can be checked against its real size. add: new ones; keep: the ids still on the phone's list."""
    st = load_cache(data_file(RD_PHONE)).get("files") or {}
    if add or (keep is not None and set(st) - set(keep)):
        st.update(add or {})
        if keep is not None:
            st = dict((k, v) for k, v in st.items() if k in keep)
        save_cache(data_file(RD_PHONE), {"files": st}, verify=False)
    return st


def _phone_dav():
    """dav://... of the phone's Download folder, or "" when the phone isn't set up."""
    c = load_cache(data_file("phone.json")).get("dav") or {}
    if not c.get("pass"):
        return ""
    return "dav://%s:%s@%s:%s/" % (quote(c.get("user", "kodi"), ""), quote(c["pass"], ""), PHONE, c.get("port", "8080"))


def rd_phone_again(dlg, phone, j):
    """A Real-Debrid file that arrived on the phone short: remove the short file and download it again."""
    info = rd_phone_sizes().get(j["id"]) or {}
    if not info.get("url"):
        return False
    base = _phone_dav()
    if base:
        short = base + "Real-Debrid/" + (safe(info["group"]) + "/" if info.get("group") else "") + info["name"]
        if xbmcvfs.exists(short) and 0 <= size_of(short) < info["size"]:
            xbmcvfs.delete(short)
    try:
        phone.call("/tor/remove", {"id": j["id"]})
        r = phone.call("/tor/add", {"uri": info["url"], "kind": "Real-Debrid", "group": info.get("group", ""),
                                    "out": info["name"]})
    except Exception as e:
        r = {"error": str(e)}
    if not r.get("id"):
        if dlg is not None:
            dlg.ok(ADDON, "The phone couldn't start %s again: %s" % (info["name"], r.get("error") or "?"))
        return False
    rd_phone_sizes(add={r["id"]: info})
    return True


def unpack_phone_albums(dlg, src):
    """Real-Debrid packs a many-file torrent (an album) into one archive. Before sorting, each archive with music
    in it under src is unpacked into the folder it's in, every file's size checked, and the archive is then
    parked in _Unpacked. .zip opens with Kodi alone; .rar needs Kodi's Archive support add-on (said if missing).
    Returns (albums unpacked, [problems])."""
    import dlqueue
    found = []
    try:
        dirs, files = xbmcvfs.listdir(src)
    except Exception:
        return 0, []
    for folder, names in [(src, files)] + [(src + d + "/", None) for d in dirs if not d.startswith((".", "_"))]:
        if names is None:
            try:
                names = xbmcvfs.listdir(folder)[1]
            except Exception:
                names = []
        found += [folder + f for f in names if f.lower().endswith((".zip", ".rar")) and not LATER_VOLUME_RE.search(f)]
    done, problems = 0, []
    prog = xbmcgui.DialogProgress() if found else None
    if prog:
        prog.create(ADDON, "Looking inside packed albums...")
    try:
        for path in found:
            items = open_archive(path)
            if items is None:
                problems.append("%s: Kodi couldn't open it%s" % (base_of(path), " - .rar needs Kodi's Archive support "
                                "add-on (Add-ons > Install from repository > VFS add-ons)" if path.lower().endswith(".rar") else ""))
                continue
            plan = dlqueue.unpack_plan([u for u, _ in items], parent_of(path), tuple(MUSIC))
            bad = ""
            for i, (inner, dst) in enumerate(plan):
                if prog.iscanceled():
                    return done, problems + ["%s: stopped part way - the archive is kept" % base_of(path)]
                prog.update(int(100 * i / len(plan)), "Unpacking %s\n%s" % (base_of(path), base_of(dst)))
                want = size_of(inner)
                if xbmcvfs.exists(dst) and want > 0 and size_of(dst) == want:
                    continue
                xbmcvfs.mkdirs(parent_of(dst))
                if not xbmcvfs.copy(inner, dst) or (want > 0 and size_of(dst) != want):
                    xbmcvfs.delete(dst)
                    bad = "%s: couldn't unpack %s - the archive is kept" % (base_of(path), base_of(dst))
                    break
            if bad:
                problems.append(bad)
            elif plan:
                done += 1
                parked = park_archive(path)
                log("unpacked %d file(s) from %s%s" % (len(plan), base_of(path), "" if parked else " (archive left where it is)"))
    finally:
        if prog:
            prog.close()
    return done, problems


def rd_where_toggle(dlg):
    st = load_cache(data_file(RD_WHERE))
    now = st.get("where", "phone")
    pick = dlg.select("Real-Debrid files download on", ["The phone (faster here)%s" % ("  - now" if now == "phone" else ""),
                                                        "This Xbox%s" % ("  - now" if now == "xbox" else "")])
    if pick >= 0:
        st["where"] = ["phone", "xbox"][pick]
        save_cache(data_file(RD_WHERE), st)


def rd_torrents(dlg):
    import realdebrid
    import youtube
    rd = _rd_ready(dlg)
    if not rd:
        return
    try:
        ts = rd.torrents()
    except realdebrid.RDError as e:
        dlg.ok(ADDON, str(e))
        return
    if not ts:
        dlg.ok(ADDON, "Nothing in your Real-Debrid torrents yet. Add a magnet link here, or on real-debrid.com.")
        return
    picked = youtube.select2(dlg, "My Real-Debrid torrents - tick one, or several to get them all at once",
                             [tuple(youtube._short(x, 70) for x in realdebrid.torrent_lines(t)) for t in ts], multi=True)
    if not picked:
        return
    if len(picked) > 1:
        return rd_torrents_many(dlg, rd, [ts[i] for i in picked])
    t = ts[picked[0]]
    try:
        if t.get("status") == "waiting_files_selection":
            rd.call("/torrents/selectFiles/%s" % t["id"], {"files": "all"})
        if t.get("status") != "downloaded":
            if t.get("status") in realdebrid.FAILED:
                dlg.ok(ADDON, "%s\n%s" % realdebrid.torrent_lines(t))
            elif dlg.yesno(ADDON, "%s\n%s\nDownload it automatically as soon as Real-Debrid has it?"
                           % realdebrid.torrent_lines(t), nolabel="No", yeslabel="Yes"):
                folder = rd_folder(dlg)
                if folder:
                    rd_queue_save(rd_queue() + [{"id": t["id"], "name": t.get("filename") or "Torrent", "folder": folder}])
                    rd_watch()
            return
        files = rd.torrent_files(t["id"])
        if not files:
            dlg.ok(ADDON, "Real-Debrid has no files for that one.")
            return
        everything = list(range(len(files)))
        chosen = everything
        if len(files) > 1:
            total = sum(b for _, b, _ in files)
            how = dlg.select("%d files, %s" % (len(files), realdebrid.size_text(total)),
                             ["Download all %d" % len(files), "Pick the ones I want", "Pick the ones I don't want",
                              "Cancel"])
            if how in (1, 2):
                rows = [(youtube._short(n, 60), realdebrid.size_text(b)) for n, b, _ in files]
                videos = [i for i, f in enumerate(files) if realdebrid.is_video(f[0])]
                ticked = (videos or everything) if how == 1 else []
                picked = youtube.select2(dlg, "Tick the ones to download" if how == 1 else "Tick the ones to leave out",
                                         rows, multi=True, preselect=ticked)
                if picked is None:
                    return
                chosen = picked if how == 1 else [i for i in everything if i not in picked]
            elif how != 0:
                return
        if not chosen:
            return
        prog = xbmcgui.DialogProgress()
        prog.create(ADDON, "Unlocking the links on Real-Debrid...")
        try:
            todo = [rd.unrestrict(files[i][2]) for i in chosen]
        finally:
            prog.close()
    except realdebrid.RDError as e:
        dlg.ok(ADDON, str(e))
        return
    rd_download(dlg, todo, t.get("filename", ""))


def rd_torrents_many(dlg, rd, chosen):
    """Several of My torrents at once: every file of the ready ones downloads (one folder each), and the rest
    download by themselves as soon as Real-Debrid has them."""
    import realdebrid
    ready = [t for t in chosen if t.get("status") == "downloaded"]
    dead = [t for t in chosen if t.get("status") in realdebrid.FAILED]
    later = [t for t in chosen if t not in ready and t not in dead]
    phone_ok = bool((load_cache(data_file("phone.json")).get("dav") or {}).get("pass"))
    opts = (["On the phone (into Download/Real-Debrid, then sort from there)"] if phone_ok else []) + \
        ["On this Xbox (to the library drive)"]
    pick = dlg.select("Download %d torrents (%d ready now) - where?" % (len(chosen) - len(dead), len(ready)),
                      opts + ["Cancel"])
    if pick < 0 or pick >= len(opts):
        return
    where = "phone" if phone_ok and pick == 0 else "xbox"
    folder = rd_folder(dlg)
    if not folder:
        return
    problems = ["%s: %s" % (t.get("filename") or "?", realdebrid.torrent_lines(t)[1]) for t in dead]
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Unlocking the links on Real-Debrid...")
    batches = []
    try:
        for n, t in enumerate(ready):
            prog.update(int(100 * n / max(1, len(ready))), t.get("filename") or "")
            try:
                batches.append((t, [rd.unrestrict(f[2]) for f in rd.torrent_files(t["id"])]))
            except realdebrid.RDError as e:
                problems.append("%s: %s" % (t.get("filename") or "?", e))
    finally:
        prog.close()
    for t, todo in batches:
        if todo:
            rd_download(dlg, todo, t.get("filename", ""), folder=folder, auto=True, where=where)
    for t in later:
        try:
            if t.get("status") == "waiting_files_selection":
                rd.call("/torrents/selectFiles/%s" % t["id"], {"files": "all"})
        except realdebrid.RDError as e:
            problems.append("%s: %s" % (t.get("filename") or "?", e))
            continue
        rd_queue_save(rd_queue() + [{"id": t["id"], "name": t.get("filename") or "Torrent", "folder": folder,
                                     "where": where}])
    if later:
        rd_watch()
    if problems:
        dlg.ok(ADDON, "Not downloaded:\n%s" % "\n".join(problems[:8]))
    toast("%d downloading now, %d start when Real-Debrid has them" % (len(batches), len(later)), 6000)


def rd_magnet(dlg):
    import realdebrid
    rd = _rd_ready(dlg)
    if not rd:
        return
    m = dlg.input("Magnet link (paste it with Kore on the phone)")
    if not m:
        return
    if not m.strip().startswith("magnet:"):
        dlg.ok(ADDON, "That isn't a magnet link (it should start with magnet:).")
        return
    rd_send(dlg, [{"title": "Magnet link", "magnet": m.strip()}])


def rd_queue():
    return load_cache(data_file(RD_QUEUE)).get("items") or []


def rd_queue_save(items):
    save_cache(data_file(RD_QUEUE), {"items": items})


def rd_send(dlg, releases, where=None, fallback=None, fallback_name=None):
    """Send releases to Real-Debrid, then download each by itself as soon as it's ready."""
    import realdebrid
    rd = _rd_ready(dlg)
    folder = rd and rd_folder(dlg)
    if not folder:
        return
    on_phone = where == "phone" or (where is None and load_cache(data_file(RD_WHERE)).get("where", "phone") == "phone"
                                    and (load_cache(data_file("phone.json")).get("dav") or {}).get("pass"))
    place = "the phone (Download/Real-Debrid)" if on_phone else friendly(folder)
    extra = "\nWhat Real-Debrid can't get downloads as a torrent on the phone." if fallback == "phone" else \
        "\nWhat Real-Debrid can't get goes to %s." % (fallback_name or "your torrent client") if fallback else ""
    if not dlg.yesno(ADDON, "Send %d to Real-Debrid, and download automatically to %s as soon as each one is ready?%s\n"
                     "This keeps working in the background, and carries on when you next open Sortovia if Kodi is closed."
                     % (len(releases), place, extra), nolabel="Cancel", yeslabel="Send"):
        return
    items, failed = rd_queue(), []
    refused = []
    for r in releases:
        try:
            tid = rd.add_source(r)
            alive, why = realdebrid.first_look(rd, tid)
            if not alive:  # e.g. a dead magnet: say so now, not when it's clicked later
                log("real-debrid: %s failed at once: %s" % (r.get("title"), why))
                failed.append("%s (%s)" % (r.get("title") or "?", why))
                refused.append(r)
                continue
            items.append({"id": tid, "name": r.get("title") or "Torrent", "folder": folder,
                          "uri": r.get("magnet") or r.get("torrent_url") or "", "where": where, "fallback": fallback})
        except Exception as e:  # e.g. the connection dropped, or a bad link
            log("real-debrid: couldn't add %s: %s" % (r.get("title"), type(e).__name__))
            failed.append(r.get("title") or "?")
            refused.append(r)
    rd_queue_save(items)
    if failed and not rd_fallback(dlg, refused, to=fallback):
        dlg.ok(ADDON, "Real-Debrid couldn't take:\n%s" % "\n".join(failed))
    if len(failed) < len(releases):
        toast("Sent to Real-Debrid. It downloads by itself when ready.", 6000)
        rd_watch()


RD_AUTO = "rd_auto.json"  # {"on": download new torrents by themselves, "seen": torrent ids already looked at}


def rd_auto_toggle(dlg):
    st = load_cache(data_file(RD_AUTO))
    if st.get("on"):
        st["on"] = False
        save_cache(data_file(RD_AUTO), st)
        dlg.ok(ADDON, "New torrents in your Real-Debrid account are no longer downloaded by themselves.")
        return
    rd = _rd_ready(dlg)
    folder = rd and rd_folder(dlg)
    if not folder:
        return
    try:
        st["seen"] = [t["id"] for t in rd.torrents()]  # what's there now is left alone
    except Exception as e:
        dlg.ok(ADDON, "Couldn't read your Real-Debrid account: %s" % e)
        return
    st.update(on=True, folder=folder)
    save_cache(data_file(RD_AUTO), st)
    dlg.ok(ADDON, "From now on, anything you add to Real-Debrid - from the phone (tap a magnet link and choose "
           "Sortovia), the website or another app - downloads to %s by itself as soon as Real-Debrid has it, "
           "whenever Sortovia is open." % friendly(folder))


def rd_pick_new():
    """Torrents added to the account since the last look go on the list to download by themselves."""
    st = load_cache(data_file(RD_AUTO))
    if not st.get("on"):
        return
    try:
        now = rd_client().torrents()
    except Exception as e:
        log("real-debrid: couldn't look for new torrents: %s" % type(e).__name__)
        return
    seen = set(st.get("seen") or [])
    queued = set(i["id"] for i in rd_queue())
    new = [t for t in now if t["id"] not in seen and t["id"] not in queued]
    if new:
        rd_queue_save(rd_queue() + [{"id": t["id"], "name": t.get("filename") or "Torrent",
                                     "folder": st.get("folder") or rd_folder()} for t in new])
        toast("%d new on Real-Debrid: downloading by itself when ready" % len(new), 5000)
    st["seen"] = sorted(seen | set(t["id"] for t in now))[-500:]
    save_cache(data_file(RD_AUTO), st)
    if rd_queue():
        rd_watch()

TOR_CLIENTS = "torclients.json"  # {"clients": [{id, name, kind, url, user, pass}], "fallback": ask|auto|off, "to": id}
RD_FAILED = "rd_failed.json"     # {"items": [{"title", "magnet"}]}: torrents Real-Debrid couldn't get, to send elsewhere
RD_HOSTS = "rd_hosts.json"       # {"time", "patterns"}: the file-host links Real-Debrid can unlock, kept a day


def tor_targets():
    """[(label, client)]: the phone's own downloader, then the clients the person added."""
    st = load_cache(data_file(TOR_CLIENTS))
    import torclients
    out, clients = [], st.get("clients") or []
    mine = [c for c in clients if torclients.on_phone(c)]  # e.g. BiglyBT on the phone, behind its VPN
    for c in mine:
        out.append(("%s on the phone (then Sortovia sorts it from Download/Torrents)" % c["name"], c))
    if not mine and (load_cache(data_file("phone.json")).get("dav") or {}).get("pass"):
        out.append(("The phone (downloads into Download/Torrents, then Sortovia sorts it)", {"id": "phone", "kind": "phone"}))
    out += [("%s (%s)" % (c["name"], torclients.KIND_NAMES.get(c["kind"], c["kind"])), c) for c in clients if c not in mine]
    return out


def _phone_quiet(dlg=None):
    import youtube
    c = load_cache(data_file("phone.json")).get("dav") or {}
    ip = c.get("pass") and phone_address(dlg, ask=dlg is not None, port=int(c.get("port", 8080)))
    return youtube.Phone(ip, c.get("user", "kodi"), c["pass"]) if ip else None


def _client_on_phone(client, dlg=None):
    """A client whose address says "phone" (e.g. http://phone:9093/transmission/rpc, for BiglyBT on the phone):
    the phone's address right now, since the hotspot's address changes."""
    import re
    url = client.get("url") or ""
    if not re.match(r"^\w+://phone[:/]", url, re.I):
        return client
    p = _phone_quiet(dlg)
    if not p:
        return client
    ip = p.base.split("://", 1)[1].rsplit(":", 1)[0]
    return dict(client, url=re.sub(r"^(\w+://)phone", lambda m: m.group(1) + ip, url, flags=re.I))


def tor_send(dlg, client, releases):
    """Hand torrents to a client. Returns how many it took."""
    import torclients
    phone = _phone_quiet(dlg) if client["kind"] == "phone" else None
    took, problems = 0, []
    for r in releases:
        uri = r.get("magnet") or r.get("torrent_url")
        if not uri:
            continue
        try:
            torclients.send(_client_on_phone(client), uri, phone)
            took += 1
        except Exception as e:
            problems.append("%s: %s" % (r.get("title") or "?", e))
            log("torrent client %s at %s: %s" % (client.get("name") or client["kind"], client.get("url", ""), e))
    if problems and dlg is not None:
        dlg.ok(ADDON, "Not taken:\n%s" % "\n".join(problems[:6]))
    if took:
        toast("%d sent to %s" % (took, "the phone" if client["kind"] == "phone" else client.get("name")), 5000)
    return took


def rd_fallback(dlg, releases, to=None):
    """Real-Debrid couldn't get these torrents: send them to the phone or another client, as the person chose
    (ask, by itself, or keep them on a list). True when something was done with them."""
    releases = [r for r in releases if r.get("magnet") or r.get("torrent_url")]
    if not releases:
        return False
    st = load_cache(data_file(TOR_CLIENTS))
    targets = tor_targets()
    how = "auto" if to else st.get("fallback", "auto")  # unset: straight to the phone (or the first client)
    if how == "off" or not targets:
        return False
    if how == "auto":
        want = to or st.get("to")
        client = next((c for _, c in targets if c["id"] == want), targets[0][1])
        return tor_send(dlg, client, releases) > 0
    if dlg is None:  # in the background: keep them for Real-Debrid > Couldn't get
        saved = load_cache(data_file(RD_FAILED)).get("items") or []
        save_cache(data_file(RD_FAILED), {"items": saved + releases})
        toast("Real-Debrid couldn't get %s. Real-Debrid > Couldn't get, to download it another way"
              % (releases[0].get("title") if len(releases) == 1 else "%d torrents" % len(releases)), 10000)
        return True
    pick = dlg.select("Real-Debrid couldn't get %d. Download with:" % len(releases), [t for t, _ in targets] + ["Leave it"])
    if pick < 0 or pick >= len(targets):
        return False
    return tor_send(dlg, targets[pick][1], releases) > 0


def rd_failed_menu(dlg):
    items = load_cache(data_file(RD_FAILED)).get("items") or []
    if not items:
        dlg.ok(ADDON, "Nothing waiting: every torrent Real-Debrid couldn't get has been dealt with.")
        return
    chosen = dlg.multiselect("Real-Debrid couldn't get these - tick to download another way", [r.get("title") or "?" for r in items])
    if not chosen:
        return
    targets = tor_targets()
    if not targets:
        dlg.ok(ADDON, "Set up the phone first, or add a torrent client under Indexes and categories.")
        return
    pick = dlg.select("Download with", [t for t, _ in targets])
    if pick < 0:
        return
    tor_send(dlg, targets[pick][1], [items[i] for i in chosen])
    save_cache(data_file(RD_FAILED), {"items": [r for i, r in enumerate(items) if i not in chosen]})


def rd_hosts(rd):
    """Real-Debrid's file-host link patterns, compiled; read again once a day."""
    import realdebrid
    st = load_cache(data_file(RD_HOSTS))
    if not st.get("patterns") or time.time() - st.get("time", 0) > 86400:
        try:
            st = {"time": time.time(), "patterns": rd.host_regexes()}
            save_cache(data_file(RD_HOSTS), st)
        except Exception as e:
            log("real-debrid: couldn't read its file hosts: %s" % type(e).__name__)
    return realdebrid.compile_hosts(st.get("patterns"))


def _page_text(url):
    try:
        from urllib.request import Request, urlopen
    except ImportError:
        from urllib2 import Request, urlopen
    resp = urlopen(Request(url, headers={"User-Agent": "Mozilla/5.0 (Sortovia for Kodi)"}), timeout=30)
    try:
        return resp.read(4 * 1024 * 1024).decode("utf-8", "replace")
    finally:
        resp.close()


def rd_unlock_links(dlg, rd, links, group=""):
    """Tick file-host links; Real-Debrid unlocks them, then they download to the drive."""
    import realdebrid
    chosen = dlg.multiselect("%d file-host links Real-Debrid can unlock - tick the ones to download" % len(links),
                             [realdebrid.link_label(u) for u in links], preselect=list(range(len(links))))
    if not chosen:
        return
    files, problems = [], []
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Real-Debrid is unlocking the links...")
    try:
        for n, i in enumerate(chosen):
            if prog.iscanceled():
                break
            prog.update(int(100 * n / len(chosen)), realdebrid.link_label(links[i]))
            try:
                files.append(rd.unrestrict(links[i]))
            except Exception as e:
                problems.append("%s: %s" % (realdebrid.link_label(links[i]), e))
    finally:
        prog.close()
    if problems:
        dlg.ok(ADDON, "Real-Debrid couldn't unlock %d:\n%s" % (len(problems), "\n".join(problems[:5])))
    if files:
        rd_download(dlg, files, group)


def rd_grab(dlg, url=None):
    """Get links from a web page: every link on it that Real-Debrid can unlock."""
    rd = _rd_ready(dlg)
    if not rd:
        return
    url = url or dlg.input("Web page address (a forum post, blog or release page)")
    if not url:
        return
    if not url.startswith("http"):
        url = "https://" + url
    try:
        text = _page_text(url)
    except Exception as e:
        dlg.ok(ADDON, "Couldn't open that page: %s" % (getattr(e, "reason", None) or e))
        return
    import realdebrid
    links = realdebrid.find_links(text, rd_hosts(rd))
    if not links:
        dlg.ok(ADDON, "No links on that page that Real-Debrid can unlock.\n(Some sites only show their links after you "
               "sign in or solve a check; those can't be read from here.)")
        return
    m = re.search(r"<title[^>]*>([^<]+)", text, re.I)
    rd_unlock_links(dlg, rd, links, (m.group(1).strip() if m else "")[:60])


def ddl_links(rd, hits):
    """The file-host links of feed posts: from the post's text, else from its page."""
    import realdebrid
    hosts, links = rd_hosts(rd), []
    for h in hits:
        found = realdebrid.find_links(h.get("text", "") + " " + h.get("page", ""), hosts)
        if not found and h.get("page"):
            try:
                found = realdebrid.find_links(_page_text(h["page"]), hosts)
            except Exception as e:
                log("couldn't open a feed post's page: %s" % type(e).__name__)
        links += [u for u in found if u not in links]
    return links


def _phone_tor_jobs(phone):
    """(the phone's downloads, None), or (None, what to tell the person) when it can't say."""
    if not phone:
        return None, "Can't find the phone. Start kodi-share in Termux and keep the Xbox on its hotspot or Wi-Fi."
    try:
        r = phone.call("/tor/jobs")
    except Exception as e:
        return None, "The phone's helper didn't answer (%s). In Termux: kodi-share stop, then kodi-share." % e
    if "jobs" not in r:
        return None, "The phone's helper is older than this. In Termux: kodi-share stop, then kodi-share."
    if not r.get("installed"):
        return None, ("The phone needs its torrent downloader first. In Termux type:\n\npkg install aria2\n\n"
                      "then kodi-share stop, and kodi-share.")
    return r["jobs"], None


def _sort_phone_downloads(dlg, spath, short=0):
    """Sort what has finished downloading on the phone (packed Real-Debrid albums are unpacked first).
    short: how many Real-Debrid files arrived short. True if a sort was started."""
    last = load_cache(data_file("last_settings.json"))
    if not last.get("dest"):
        dlg.ok(ADDON, "Do one sort with Transfer and sort first, so Sortovia knows where your library is.")
        return False
    base = _phone_dav()
    if not base:
        dlg.ok(ADDON, "Can't find the phone. Start kodi-share in Termux and keep the Xbox on its hotspot or Wi-Fi.")
        return False
    bt_jobs()  # finished BiglyBT torrents into Download/Torrents first
    have = []
    for folder in ("Real-Debrid", "Torrents"):
        try:
            dirs, files = xbmcvfs.listdir(base + folder + "/")
        except Exception:
            dirs, files = [], []
        if [n for n in dirs + files if not n.startswith(".")]:
            have.append(folder)
    if not have:
        dlg.ok(ADDON, "Nothing has finished downloading on the phone yet (Download/Real-Debrid and Download/Torrents are empty).")
        return False
    which = 0 if len(have) == 1 else dlg.select("Sort which?", ["Download/%s" % f for f in have])
    if which < 0:
        return False
    src = base + have[which] + "/"
    if have[which] == "Real-Debrid":
        if short and not dlg.yesno(ADDON, "%d Real-Debrid file(s) arrived short and are listed under Failed.\nSort the rest "
                                   "now? (Try the short ones again first to sort everything together.)" % short,
                                   nolabel="Go back", yeslabel="Sort the rest"):
            return False
        _, problems = unpack_phone_albums(dlg, src)  # packed albums become plain songs first
        if problems:
            dlg.ok(ADDON, "Couldn't unpack:\n%s\n\nThe rest is sorted as usual." % "\n".join(problems[:5]))
    run(dlg, spath or "", src, last["dest"], last.get("mode", ASK), last.get("delete_old", False),
        last.get("lang_mode", 0), last.get("nfo_mode", 3), last.get("sub_mode", 0), last.get("empty_mode", 1))
    return True


def _tor_retry(dlg, phone, body):
    """Ask the phone to start failed downloads again from the part it has. True if it did."""
    try:
        r = phone.call("/tor/retry", body)
    except Exception as e:
        r = {"error": str(e)}
    if r.get("error"):
        dlg.ok(ADDON, "The phone's helper is older than this, so it can't try again by itself. In Termux: kodi-share "
               "stop, then kodi-share - failed downloads start again when it restarts." if r["error"] == "not found"
               else "The phone couldn't try again: %s" % r["error"])
        return False
    return True


def phone_torrents(dlg, spath=None):
    """Every download in one list: the phone's torrents and Real-Debrid files, and Real-Debrid downloads on this
    device. The buttons at the top list one group at a time (waiting for peers, downloading, queued, paused,
    failed, done). Pause, carry on, try a failed one again (or all of them), remove, and sort the finished ones."""
    import dlqueue
    import torclients
    import youtube
    phone = _phone_quiet(dlg)
    shown = dlqueue.ALL

    def group_of(e):
        return dlqueue.tor_group(e[1]) if e[0] in ("phone", "bt") else dlqueue.box_group(e[1])

    while True:
        box = rd_jobs().all()
        tor, problem = _phone_tor_jobs(phone)
        bt = bt_jobs(phone)
        if tor is None and not box and not bt:
            dlg.ok(ADDON, problem)
            return
        if tor is not None:  # a Real-Debrid file that finished smaller than Real-Debrid said has failed
            tor = dlqueue.mark_short(tor, rd_phone_sizes(keep=[j["id"] for j in tor]))
        jobs = [("phone", j) for j in tor or []] + [("bt", j) for j in bt] + [("box", j) for j in box]
        shown = dlqueue.shown_group(jobs, group_of, shown)
        n = dlqueue.counts(jobs, group_of)
        busy = any(j["state"] in ("active", "waiting") for j in (tor or []) + bt)
        rows = [((a, b), ("show", key)) for key, a, b in dlqueue.buttons(jobs, group_of, shown)]
        if n[dlqueue.FAILED]:
            rows.append((("Retry all failed (%d)" % n[dlqueue.FAILED], "each carries on from the part already downloaded"),
                         ("retry_all",)))
        if n[dlqueue.GAVE_UP]:
            rows.append((("Try all the tried-3x ones again (%d)" % n[dlqueue.GAVE_UP],
                          "back on the queue - they may have peers by now"), ("retry_gaveup",)))
        rd_try = [j for j in (tor or []) + bt if j.get("uri") and j.get("kind", "Torrents") == "Torrents"
                  and dlqueue.tor_group(j) in (dlqueue.PEERS, dlqueue.QUEUED, dlqueue.GAVE_UP)]
        if rd_try and rd_client().signed_in():
            rows.append((("Real-Debrid takes the ones it already has (%d to check)" % len(rd_try),
                          "those download from Real-Debrid instead; the rest stay on the phone's queue"), ("rd_try",)))
        if tor is None:
            rows.append((("The phone isn't answering - select to look again", " ".join(problem.split())), ("refresh",)))
        else:
            rows.append((("Sort the finished downloads",
                          "Download/Torrents and Download/Real-Debrid on the phone, into your library"), ("sort",)))
            if any(j["state"] in ("active", "waiting", "paused") for j in tor + bt):
                rows.append((("Pause all on the phone" if busy else "Carry on with all on the phone", ""), ("pause_all",)))
        if n[dlqueue.DONE] or any(j["state"] == "removed" for j in tor or []):
            rows.append((("Clear finished from this list", "the files stay where they are"), ("clear",)))
        rows.append((("Move finished downloads to the Xbox by themselves: %s" % ("on" if autosort_on() else "off"),
                      "sorted into your library as each one finishes, with the settings of your last sort"),
                     ("autosort",)))
        rows.append((("Refresh", ""), ("refresh",)))
        for e in dlqueue.only(jobs, group_of, shown):
            a, b = torclients.job_lines(e[1]) if e[0] in ("phone", "bt") else dlqueue.box_lines(e[1])
            if e[0] == "bt":
                b = "%s - %s" % (e[1]["where"], b)
            rows.append(((youtube._short(a, 60), youtube._short(b, 70)), ("job", e)))
        title = "Downloads (%d)" % len(jobs) if shown == dlqueue.ALL else \
            "Downloads - %s (%d of %d)" % (dlqueue.GROUP_NAMES[shown], n[shown], len(jobs))
        pick = youtube.select2(dlg, title, [r[0] for r in rows])
        if pick < 0:
            return
        act = rows[pick][1]
        if act[0] == "show":
            shown = act[1]
        elif act[0] == "sort":
            if _sort_phone_downloads(dlg, spath, len([j for j in tor if j.get("short")])):
                return
        elif act[0] == "pause_all":
            if tor:
                phone.call("/tor/pause" if busy else "/tor/resume", {"all": True})
            for c in bt_clients():
                _bt_quiet(c, None, "pause" if busy else "resume")
        elif act[0] == "retry_all":
            for j in tor or []:
                if j.get("short"):
                    rd_phone_again(dlg, phone, j)
            if any(j["state"] == "error" and not j.get("short") for j in tor or []):
                _tor_retry(dlg, phone, {"all": True})
            if rd_jobs().retry():
                xbmc.executebuiltin("RunPlugin(%s?action=rd_resume)" % PLUGIN)
                xbmc.sleep(500)
        elif act[0] == "autosort":
            st = load_cache(data_file(AUTOSORT))
            st["off"] = autosort_on()
            save_cache(data_file(AUTOSORT), st)
            if autosort_on():
                xbmc.executebuiltin("RunPlugin(%s?action=phone_autosort)" % PLUGIN)
        elif act[0] == "rd_try":
            rd_take_queue(dlg, phone, rd_try)
        elif act[0] == "retry_gaveup":
            _tor_retry(dlg, phone, {"gaveup": True})
        elif act[0] == "clear":
            for j in tor or []:
                if j["state"] in ("complete", "removed") and not j.get("short"):
                    phone.call("/tor/remove", {"id": j["id"]})
            rd_jobs().remove(states=("done",))
        elif act[0] == "job" and act[1][0] == "phone":
            _phone_job_menu(dlg, phone, act[1][1])
        elif act[0] == "job" and act[1][0] == "bt":
            _bt_job_menu(dlg, act[1][1])
        elif act[0] == "job":
            _box_job_menu(dlg, act[1][1])


def rd_take_queue(dlg, phone, jobs):
    """Torrents waiting on the phone: the ones Real-Debrid already has download from Real-Debrid (to the phone)
    instead, and come off the phone's torrent queue. The rest stay where they are."""
    import realdebrid
    rd = _rd_ready(dlg)
    folder = rd and rd_folder(dlg)
    if not folder:
        return
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Asking Real-Debrid about %d torrents..." % len(jobs))
    took, items = [], rd_queue()
    try:
        for n, j in enumerate(jobs):
            if prog.iscanceled():
                break
            prog.update(int(100 * n / len(jobs)), "%d taken so far" % len(took), j.get("name") or "")
            try:
                tid = rd.has_ready({"title": j.get("name"), "magnet": j["uri"]})
            except realdebrid.RDError as e:
                log("real-debrid: queue check %s: %s" % (j.get("name"), e))
                if "signed" in str(e):
                    break
                continue
            if not tid:
                continue
            items.append({"id": tid, "name": j.get("name") or "Torrent", "folder": folder, "uri": j["uri"],
                          "where": "phone"})
            took.append(j)
            try:
                if j.get("client"):
                    _bt_quiet(_bt_client(j["client"]), [j["tid"]], "remove")
                else:
                    phone.call("/tor/remove", {"id": j["id"]})
            except Exception as e:
                log("couldn't take %s off the phone's queue: %s" % (j.get("name"), e))
    finally:
        prog.close()
        rd_queue_save(items)
    if took:
        rd_watch()
    dlg.ok(ADDON, "Real-Debrid had %d of %d ready. Those download from Real-Debrid now; the rest stay on the "
                  "phone's queue." % (len(took), len(jobs)))


class _AutoDialog(object):
    """Stands in for the dialogs while a sort runs by itself: moves in the background, keeps what's already in the
    library rather than replacing it, and says the rest in a corner of the screen."""
    def select(self, heading, options, *a, **kw):
        return 0 if "scan finished" in heading and "nothing to move" not in heading else -1

    def yesno(self, *a, **kw):
        return False

    def ok(self, heading, text="", *a, **kw):
        log("auto sort: %s" % " ".join(str(text).split()))
        toast(" ".join(str(text).split())[:120], 8000)

    def multiselect(self, *a, **kw):
        return None

    def input(self, *a, **kw):
        return ""

    def textviewer(self, *a, **kw):
        pass

    def notification(self, *a, **kw):
        pass


def autosort_on():
    return not load_cache(data_file(AUTOSORT)).get("off")


def _autosort_new(base):
    """Folders under Download (Torrents, Real-Debrid) with a finished download not sorted before."""
    st = load_cache(data_file(AUTOSORT))
    if st.get("v") != 2:  # 1.64.4: album art left behind before can now be moved, so look at everything once more
        st.update(v=2, tried={})
        save_cache(data_file(AUTOSORT), st)
    tried = st.get("tried") or {}
    out = []
    for folder in ("Real-Debrid", "Torrents"):
        try:
            dirs, files = xbmcvfs.listdir(base + folder + "/")
        except Exception:
            continue
        names = [n for n in dirs + files if not n.startswith(".") and not n.endswith(".part")]
        if [n for n in names if folder + "/" + n not in tried]:
            out.append((folder, names))
    return out


def phone_autosort():
    """In the background: every two minutes, look at the phone; when a download has finished (into Download/Torrents
    or Download/Real-Debrid), sort it onto the Xbox with the settings of the last sort. Stops when the phone has
    nothing left downloading and nothing new to sort, or when Kodi closes."""
    if home().getProperty(PROP_AUTOSORT) or not autosort_on():
        return
    last = load_cache(data_file("last_settings.json"))
    if not last.get("dest"):
        return
    home().setProperty(PROP_AUTOSORT, "1")
    monitor = xbmc.Monitor()
    idle = 0
    try:
        while not monitor.abortRequested() and autosort_on():
            phone = _phone_quiet(None)
            tor, _ = _phone_tor_jobs(phone)  # asking also moves finished torrents into Download/Torrents
            bt = bt_jobs(phone)  # and finished BiglyBT ones
            base = resolve_src(_phone_dav(), None) if _phone_dav() and phone else ""
            busy = any(j.get("state") in ("active", "waiting") for j in (tor or []) + bt)
            todo = _autosort_new(base) if base and not home().getProperty(PROP_RUN) else []
            if any(j.get("kind") == "Real-Debrid" and j.get("state") in ("active", "waiting") for j in tor or []):
                todo = [t for t in todo if t[0] != "Real-Debrid"]  # an album arrives a file at a time: wait for all of it
            for folder, names in todo:
                st = load_cache(data_file(AUTOSORT))
                st.setdefault("tried", {}).update((folder + "/" + n, 1) for n in names)
                save_cache(data_file(AUTOSORT), st)  # one go each, so something the sort leaves isn't tried forever
                log("auto sort: %d finished in Download/%s go to the Xbox" % (len(names), folder))
                toast("Finished downloads: moving %d from the phone to the Xbox" % len(names), 6000)
                src = base + folder + "/"
                if folder == "Real-Debrid":
                    unpack_phone_albums(_AutoDialog(), src)
                run(_AutoDialog(), "", src, last["dest"], last.get("mode", ASK), last.get("delete_old", False),
                    last.get("lang_mode", 0), last.get("nfo_mode", 3), last.get("sub_mode", 0), last.get("empty_mode", 1))
            idle = 0 if (busy or todo) else idle + 1  # (no phone counts as quiet: the service looks again later)
            if idle >= 3:  # nothing downloading and nothing new for six minutes
                break
            if monitor.waitForAbort(120):
                break
    finally:
        home().clearProperty(PROP_AUTOSORT)


def bt_clients():
    """Transmission-style clients on the phone (BiglyBT), with the phone's address filled in."""
    import torclients
    out = []
    for c in load_cache(data_file(TOR_CLIENTS)).get("clients") or []:
        if c.get("kind") == "transmission" and torclients.on_phone(c):
            out.append(_client_on_phone(c))
    return out


def _bt_client(cid):
    return next((c for c in bt_clients() if c["id"] == cid), None)


def _bt_quiet(c, tids, what):
    import torclients
    try:
        if c:
            torclients.tr_act(c, tids, what)
    except Exception as e:
        log("torrent client %s: %s %s: %s" % (c.get("name"), what, tids, e))


def bt_jobs(phone=None):
    """BiglyBT's torrents on the phone. Finished ones are taken off BiglyBT and moved into Download/Torrents,
    where Sortovia sorts from (a half-done one is never sorted)."""
    import torclients
    out = []
    for c in bt_clients():
        try:
            jobs = torclients.tr_jobs(c)
        except Exception as e:
            log("torrent client %s: %s" % (c.get("name"), e))
            continue
        for j in jobs:
            if j["state"] == "complete" and _bt_collect(c, j):
                j["state"] = "complete"
                j["moved"] = True
            out.append(j)
    return out


def _bt_collect(c, j):
    """Move a finished BiglyBT torrent from its folder under Download to Download/Torrents. True when moved."""
    base = resolve_src(_phone_dav(), None) if _phone_dav() else ""
    d = (j.get("dir") or "").replace("\\", "/")
    if not base or "/Download/" not in d + "/":
        return False
    rel = (d + "/").split("/Download/", 1)[1].strip("/")
    name = j["name"].replace("[METADATA]", "")
    src = "%s%s/%s" % (base, rel, name) if rel else base + name
    dst = base + "Torrents/" + name
    if rel == "Torrents":
        _bt_quiet(c, [j["tid"]], "remove")
        return True
    _bt_quiet(c, [j["tid"]], "pause")  # BiglyBT lets go of the files first
    try:
        xbmcvfs.mkdirs(base + "Torrents/")
        ok = xbmcvfs.rename(src, dst) or xbmcvfs.rename(src + "/", dst + "/")
    except Exception as e:
        log("couldn't move %s into Download/Torrents: %s" % (name, e))
        ok = False
    if ok:
        _bt_quiet(c, [j["tid"]], "remove")
        log("moved finished torrent %s from Download/%s into Download/Torrents" % (name, rel))
    else:
        log("couldn't move %s from Download/%s into Download/Torrents" % (name, rel))
    return bool(ok)


def _bt_job_menu(dlg, j):
    import torclients
    import youtube
    c = _bt_client(j["client"])
    name, status = torclients.job_lines(j)
    if j["state"] == "error":
        what = dlg.select(youtube._short(name, 60), ["Try again", "Remove it (the part downloaded stays)",
                                                      "Show the whole error"])
        acts = {0: "resume", 1: "remove"}
        if what == 2:
            dlg.ok(ADDON, "%s\n\n%s" % (name, j.get("error") or "%s gave no reason." % j["where"]))
    else:
        what = dlg.select("%s (%s)" % (youtube._short(name, 50), j["where"]),
                          ["Pause", "Carry on", "Remove it (the part downloaded stays)"])
        acts = {0: "pause", 1: "resume", 2: "remove"}
    if what in acts:
        _bt_quiet(c, [j["tid"]], acts[what])


def _phone_job_menu(dlg, phone, j):
    import torclients
    import youtube
    name, status = torclients.job_lines(j)
    if j["state"] == "gaveup":
        what = dlg.select(youtube._short(name, 60), ["Try again (back on the queue, carries on from the part it has)",
                                                      "Remove from the list"])
        if what >= 0:
            if what == 0:
                _tor_retry(dlg, phone, {"id": j["id"]})
            else:
                phone.call("/tor/remove", {"id": j["id"]})
        return
    if j["state"] == "error":
        what = dlg.select(youtube._short(name, 60), ["Try again (carries on from the part it has)", "Remove from the list",
                                                      "Show the whole error"])
        if what == 0:
            rd_phone_again(dlg, phone, j) if j.get("short") else _tor_retry(dlg, phone, {"id": j["id"]})
        elif what == 1:
            phone.call("/tor/remove", {"id": j["id"]})
        elif what == 2:
            dlg.ok(ADDON, "%s\n\n%s" % (name, j.get("error") or "The phone's downloader gave no reason."))
        return
    what = dlg.select(youtube._short(name, 60), ["Pause", "Carry on", "Remove from the list (a finished one stays in Download/Torrents)"])
    if what >= 0:
        phone.call(["/tor/pause", "/tor/resume", "/tor/remove"][what], {"id": j["id"]})


def _box_job_menu(dlg, j):
    """One Real-Debrid download on this device: try again, pause, remove."""
    import dlqueue
    import youtube
    jobs, dst, state = rd_jobs(), j["folder"] + j["name"], j.get("state")
    head = youtube._short(j["name"], 60)
    if state == "failed":
        what = dlg.select(head, ["Try again (carries on from the part it has)", "Remove it (and the part downloaded)",
                                 "Show the whole error"])
        if what == 0 and jobs.retry(j["id"]):
            xbmc.executebuiltin("RunPlugin(%s?action=rd_resume)" % PLUGIN)
            xbmc.sleep(500)
        elif what == 1:
            dlqueue.drop_pieces(dst, _RdFiles)
            jobs.remove(j["id"])
        elif what == 2:
            dlg.ok(ADDON, "%s\n\n%s" % (j["name"], j.get("error") or "?"))
    elif state in ("downloading", "paused") and home().getProperty(PROP_RD):
        paused = bool(home().getProperty(PROP_RD_PAUSE))
        what = dlg.select(head, ["Carry on" if paused else "Pause (the part downloaded is kept)",
                                 "Stop it and the ones queued behind it (half-done files are removed)", "Leave it"])
        if what == 0:
            home().clearProperty(PROP_RD_PAUSE) if paused else home().setProperty(PROP_RD_PAUSE, "1")
        elif what == 1:
            home().setProperty(PROP_RD_STOP, "1")
            xbmc.sleep(1500)
    elif state == "done":
        if dlg.yesno(ADDON, "Remove from the list?\n(the file stays on the drive)\n%s" % j["name"],
                     nolabel="Keep", yeslabel="Remove"):
            jobs.remove(j["id"])
    else:  # queued, or cut off and about to be queued again
        what = dlg.select(head, ["Start it now" if not home().getProperty(PROP_RD) else "Leave it queued",
                                 "Remove it (and any part downloaded)"])
        if what == 0 and not home().getProperty(PROP_RD):
            xbmc.executebuiltin("RunPlugin(%s?action=rd_resume)" % PLUGIN)
            xbmc.sleep(500)
        elif what == 1:
            dlqueue.drop_pieces(dst, _RdFiles)
            jobs.remove(j["id"])


def tor_clients_setup(dlg):
    import torclients
    while True:
        st = load_cache(data_file(TOR_CLIENTS))
        clients = st.get("clients") or []
        how = st.get("fallback", "auto")
        to = next((t for t, c in tor_targets() if c["id"] == st.get("to")), tor_targets()[0][0] if tor_targets() else "the phone")
        pick = dlg.select("Torrent clients", [
            "Add a torrent client (on the phone or the network)", "Remove a torrent client",
            "Test a torrent client, or fix its address",
            "When Real-Debrid can't get a torrent: %s" % {"ask": "ask what to do", "auto": "send it to %s" % to,
                                                          "off": "do nothing"}[how]])
        if pick < 0:
            return
        if pick == 0:
            k = dlg.select("Which kind?", [n for _, n, _ in torclients.KINDS])
            if k < 0:
                continue
            kind, kname, example = torclients.KINDS[k]
            name = dlg.input("A name for it (e.g. BiglyBT on the phone)", kname)
            url = name and dlg.input("Its address, e.g. %s (on the phone: write phone in place of the address)" % example,
                                     example)
            if not url:
                continue
            user = dlg.input("User name (empty if none)") if kind != "aria2" else ""
            pw = dlg.input("Password%s (empty if none)" % (" or secret" if kind == "aria2" else ""),
                           option=xbmcgui.ALPHANUM_HIDE_INPUT)
            client = {"id": "t%d" % int(time.time()), "name": name, "kind": kind, "url": url.strip(), "user": user, "pass": pw}
            clients.append(client)
            st["clients"] = clients
            save_cache(data_file(TOR_CLIENTS), st)
            if tor_client_test(dlg, client):
                dlg.ok(ADDON, "Added %s. It's offered when you send a torrent, and when Real-Debrid can't get one." % name)
            continue
        elif pick == 1:
            if not clients:
                dlg.ok(ADDON, "You haven't added any torrent clients.")
                continue
            i = dlg.select("Remove which?", [c["name"] for c in clients])
            if i >= 0:
                st["clients"] = clients[:i] + clients[i + 1:]
        elif pick == 2:
            if not clients:
                dlg.ok(ADDON, "You haven't added any torrent clients.")
                continue
            i = dlg.select("Test which?", ["%s  (%s)" % (c["name"], c["url"]) for c in clients])
            if i >= 0:
                tor_client_test(dlg, clients[i])
            continue
        else:
            targets = tor_targets()
            opts = ["Ask what to do"] + ["Send it by itself to %s" % t for t, _ in targets] + ["Do nothing"]
            i = dlg.select("When Real-Debrid can't get a torrent", opts)
            if i < 0:
                continue
            if i == 0:
                st["fallback"] = "ask"
            elif i == len(opts) - 1:
                st["fallback"] = "off"
            else:
                st["fallback"], st["to"] = "auto", targets[i - 1][1]["id"]
        save_cache(data_file(TOR_CLIENTS), st)


def tor_client_test(dlg, client):
    """Try a torrent client; if it doesn't answer, say why and offer to fix its address, user or password.
    Saves any fix. True when it answered."""
    import torclients
    while True:
        try:
            what = torclients.test(_client_on_phone(client, dlg))
            log("torrent client %s at %s: %s" % (client["name"], client["url"], what))
            dlg.ok(ADDON, "%s answered: %s" % (client["name"], what))
            return True
        except Exception as e:
            log("torrent client %s at %s: %s" % (client["name"], client["url"], e))
            fix = dlg.select("%s didn't answer: %s" % (client["name"], e),
                             ["Change the address (now %s)" % client["url"], "Change the user name and password",
                              "Try again", "Leave it for now"]) if dlg.yesno(
                ADDON, "%s at %s didn't answer:\n%s\n%s" % (client["name"], client["url"], e, torclients.advice(client, e)),
                nolabel="Leave it", yeslabel="Fix it") else 3
        if fix == 0:
            url = dlg.input("Its remote-control address", client["url"])
            if url:
                client["url"] = url.strip()
        elif fix == 1:
            client["user"] = dlg.input("User name (empty if none)", client.get("user", ""))
            client["pass"] = dlg.input("Password (empty if none)", option=xbmcgui.ALPHANUM_HIDE_INPUT)
        elif fix != 2:
            return False
        st = load_cache(data_file(TOR_CLIENTS))
        st["clients"] = [client if c["id"] == client["id"] else c for c in st.get("clients") or []]
        save_cache(data_file(TOR_CLIENTS), st)


def send_search_results(dlg, picked):
    """Search results ticked: torrents go to Real-Debrid or a torrent client; file-host posts are unlocked."""
    ddl = [h for h in picked if h.get("page") and not h.get("magnet") and not h.get("torrent_url")]
    torrents_ = [h for h in picked if h not in ddl]
    if torrents_:
        targets = tor_targets()
        rd_on = rd_client().signed_in()
        phone = [c for _, c in targets if c["id"] == "phone"]
        phone_ok = bool((load_cache(data_file("phone.json")).get("dav") or {}).get("pass"))
        opts, acts = [], []
        if phone and rd_on:
            opts.append("The phone: Real-Debrid first, and what it can't get downloads as a torrent")
            acts.append(lambda: rd_send(dlg, torrents_, where="phone", fallback="phone"))
        if rd_on:
            opts.append("This Xbox through Real-Debrid (to the library drive)")
            acts.append(lambda: rd_send(dlg, torrents_, where="xbox"))
        for label, c in targets:
            if rd_on and c["id"] == "phone":
                continue  # Real-Debrid is always tried first; the phone downloads only what it can't get
            if rd_on:  # e.g. BiglyBT: Real-Debrid first, and the client gets only what Real-Debrid can't
                opts.append("Real-Debrid first, and what it can't get goes to %s" % c.get("name", label))
                acts.append(lambda c=c: rd_send(dlg, torrents_, where="phone" if phone_ok else "xbox", fallback=c["id"],
                                                fallback_name=c.get("name")))
            opts.append(label)
            acts.append(lambda c=c: tor_send(dlg, c, torrents_))
        pick = dlg.select("Send %d torrent%s to" % (len(torrents_), "" if len(torrents_) == 1 else "s"), opts) if len(opts) > 1 else 0
        if 0 <= pick < len(acts):
            acts[pick]()
    if ddl:
        rd = _rd_ready(dlg)
        if not rd:
            return
        links = ddl_links(rd, ddl)
        if not links:
            dlg.ok(ADDON, "Those posts have no links Real-Debrid can unlock.")
            return
        rd_unlock_links(dlg, rd, links, ddl[0]["title"][:60] if len(ddl) == 1 else "")


TORRENT_PREFS = "torrents.json"


def torrent_search(dlg, group=None):
    """Search the indexes in a category, tick results, and Real-Debrid fetches them (then they download by themselves)."""
    import torrents
    import youtube
    prefs = load_cache(data_file(TORRENT_PREFS))
    prefs["feeds"] = load_cache(data_file(FEEDS_FILE)).get("feeds") or []  # Real-Debrid > Add a feed: searchable too
    names = list(torrents.groups(prefs))
    if group is None:
        pick = dlg.select("Search torrents - which category?", ["%s  (%d indexes)" % (n, len(torrents.in_group(prefs, n)))
                                                               for n in names] + ["Indexes and categories..."])
        if pick < 0:
            return
        if pick == len(names):
            torrent_setup(dlg)
            return
        group = names[pick]
    q = dlg.input("Search %s for" % group, prefs.get("last", ""))
    if not q:
        return
    prefs["last"] = q
    save_cache(data_file(TORRENT_PREFS), dict((k, v) for k, v in prefs.items() if k != "feeds"))
    bar = CornerProgress("%s: searching %s" % (ADDON, group))
    bar("searching %d indexes" % len(torrents.in_group(prefs, group)))
    try:
        res, problems = torrents.search(prefs, group, q)
    finally:
        bar.close()
    note = ("  (no answer from %s)" % ", ".join(sorted(problems))) if problems else ""
    for name, why in problems.items():
        log("torrent search: %s: %s" % (name, why))
    if not res:
        dlg.ok(ADDON, "Nothing found for \"%s\" in %s.%s" % (q, group, note))
        return
    chosen = youtube.select2(dlg, "%d found%s - tick to send to Real-Debrid" % (len(res), note),
                             [(youtube._short(a, 70), b) for a, b in (torrents.result_lines(h) for h in res[:100])], multi=True)
    if chosen:
        send_search_results(dlg, [res[i] for i in chosen])


def torrent_setup(dlg):
    import torrents
    while True:
        prefs = load_cache(data_file(TORRENT_PREFS))
        prefs["feeds"] = load_cache(data_file(FEEDS_FILE)).get("feeds") or []
        pick = dlg.select("Indexes and categories", [
            "Turn indexes on or off", "Add an index: Jackett or Prowlarr (Torznab)", "Add an index: a site's RSS feed",
            "Remove an index you added", "Categories: choose which indexes each one searches", "Add a category",
            "Remove a category", "Torrent clients (the phone, or one on your network)"])
        if pick < 0:
            return
        if pick == 7:
            tor_clients_setup(dlg)
            continue
        every = torrents.indexes(prefs)
        if pick == 0:
            on = dlg.multiselect("Tick the indexes to use", [ix["name"] for ix in every],
                                 preselect=[i for i, ix in enumerate(every) if ix["on"]])
            if on is not None:
                prefs["off"] = [ix["id"] for i, ix in enumerate(every) if i not in on]
        elif pick in (1, 2):
            name = dlg.input("A name for it (e.g. the tracker's name)")
            if not name:
                continue
            if pick == 1:
                url = dlg.input("Its Torznab address (Jackett: Copy Torznab Feed; Prowlarr: the indexer's API URL)")
                key = dlg.input("Its API key (from Jackett's or Prowlarr's page; empty if none)") if url else ""
                ix = {"kind": "torznab", "url": url, "key": key}
            else:
                url = dlg.input("The site's RSS feed address (if it has a search feed, put {q} where the words go)")
                ix = {"kind": "rss", "url": url}
            if not url:
                continue
            ix.update(id="c%d" % (len(prefs.get("custom") or []) + 1 + len(every)), name=name)
            prefs["custom"] = list(prefs.get("custom") or []) + [ix]
            dlg.ok(ADDON, "Added %s. It's searched in Everything; add it to other categories under Categories." % name)
        elif pick == 3:
            custom = prefs.get("custom") or []
            if not custom:
                dlg.ok(ADDON, "You haven't added any indexes.")
                continue
            i = dlg.select("Remove which?", [ix["name"] for ix in custom])
            if i >= 0:
                prefs["custom"] = custom[:i] + custom[i + 1:]
        elif pick == 4:
            g = torrents.groups(prefs)
            names = list(g)
            i = dlg.select("Which category?", names)
            if i < 0:
                continue
            on = dlg.multiselect("%s searches these" % names[i], [ix["name"] for ix in every],
                                 preselect=[j for j, ix in enumerate(every) if ix["id"] in g[names[i]]])
            if on is not None:
                prefs.setdefault("groups", {})[names[i]] = [every[j]["id"] for j in on]
        elif pick == 5:
            name = (dlg.input("Name of the new category (e.g. My releases)") or "").strip()
            if not name:
                continue
            on = dlg.multiselect("%s searches these" % name, [ix["name"] for ix in every])
            prefs.setdefault("groups", {})[name] = [every[j]["id"] for j in on or []]
            prefs["removed_groups"] = [n for n in prefs.get("removed_groups") or [] if n != name]
        elif pick == 6:
            names = list(torrents.groups(prefs))
            i = dlg.select("Remove which category?", names)
            if i >= 0:
                prefs.setdefault("groups", {}).pop(names[i], None)
                prefs["removed_groups"] = list(set(prefs.get("removed_groups") or []) | {names[i]})
        save_cache(data_file(TORRENT_PREFS), dict((k, v) for k, v in prefs.items() if k != "feeds"))


def rd_watch():
    """Check the list of waiting torrents until every one is downloaded. Runs in the background."""
    import realdebrid
    if home().getProperty(PROP_RD_WATCH):
        return
    home().setProperty(PROP_RD_WATCH, "1")
    monitor = xbmc.Monitor()
    try:
        while rd_queue():
            if home().getProperty(PROP_RD_STOP):
                rd_queue_save([])
                home().clearProperty(PROP_RD_STOP)
                toast("Stopped. What's already on Real-Debrid stays under My torrents.")
                return
            status = ""
            rd = rd_client()
            for item in rd_queue():
                try:
                    kind, what = rd.check(item["id"])
                    if kind == "ready" and home().getProperty(PROP_RD) and not _rd_to_phone(item.get("where")):
                        kind, what = "wait", "A download is finishing first"  # one at a time on this Xbox
                    elif kind == "wait" and _rd_stalled(rd, item):
                        continue
                    if kind == "ready":
                        home().clearProperty(PROP_RD_WAIT)
                        todo = [rd.unrestrict(link) for _, _, link in what]
                        rd_queue_save([i for i in rd_queue() if i["id"] != item["id"]])
                        if rd_download(None, todo, item["name"], item["folder"], auto=True, where=item.get("where")) == "stopped":
                            rd_queue_save([])
                            return
                    elif kind == "failed":
                        rd_queue_save([i for i in rd_queue() if i["id"] != item["id"]])
                        if not rd_fallback(None, [{"title": item["name"], "magnet": item.get("uri", "")}] if item.get("uri") else [],
                                           to=item.get("fallback")):
                            toast("%s: %s" % (item["name"], what), 10000)
                    elif not status or (getattr(rd, "last", {}) or {}).get("progress"):
                        status = "%s - %s" % (item["name"], what)  # one that's moving, if any, over a stuck one
                except realdebrid.RDError as e:
                    status = status or "%s - %s" % (item["name"], e)
                except Exception as e:  # a dropped connection: it stays on the list for the next check
                    log("real-debrid: check failed: %s" % type(e).__name__)
                    status = status or "%s - waiting for a connection" % item["name"]
            left = len(rd_queue())
            if left:
                home().setProperty(PROP_RD_WAIT, "%d waiting: %s" % (left, status))
            for _ in range(RD_WATCH_EVERY):
                if monitor.waitForAbort(1):
                    return  # Kodi is closing: the list is saved for next time
                if home().getProperty(PROP_RD_STOP):
                    break
    finally:
        home().clearProperty(PROP_RD_WAIT)
        home().clearProperty(PROP_RD_WATCH)


def _rd_to_phone(where):
    """True when a Real-Debrid download goes to the phone (its downloader runs many at once)."""
    phone_ok = bool((load_cache(data_file("phone.json")).get("dav") or {}).get("pass"))
    return phone_ok and (where or load_cache(data_file(RD_WHERE)).get("where", "phone")) == "phone"


def _rd_stalled(rd, item, now=None):
    """Real-Debrid has been fetching this torrent with no progress for RD_STALL: take it off Real-Debrid and send
    it to the torrent client instead, so it doesn't sit there for ever. True when that was done."""
    info = getattr(rd, "last", None) or {}
    if info.get("status") not in ("downloading", "queued", "magnet_conversion", "compressing"):
        return False
    now = now or time.time()
    mark = [info.get("status"), info.get("progress") or 0]
    items = rd_queue()
    me = next((i for i in items if i["id"] == item["id"]), None)
    if me is None:
        return False
    if me.get("seen", [None])[0] != mark:
        me["seen"] = [mark, now]
        rd_queue_save(items)
        return False
    if now - me["seen"][1] < RD_STALL or not item.get("uri"):
        return False
    log("real-debrid: %s made no progress for %d min (%s %s%%): getting it another way"
        % (item["name"], RD_STALL // 60, mark[0], mark[1]))
    try:
        rd.delete(item["id"])
    except Exception as e:
        log("real-debrid: couldn't remove %s: %s" % (item["name"], e))
    rd_queue_save([i for i in rd_queue() if i["id"] != item["id"]])
    if rd_fallback(None, [{"title": item["name"], "magnet": item["uri"]}], to=item.get("fallback")):
        toast("Real-Debrid was stuck on %s - downloading it as a torrent instead" % item["name"], 10000)
    return True


def rd_read_feeds(http=None):
    """(releases from every feed, names of feeds that failed). Feed addresses are never logged."""
    import feeds
    import realdebrid
    lists, failed = [], []
    for f in load_cache(data_file(FEEDS_FILE)).get("feeds") or []:
        try:
            code, body = (http or realdebrid._http)(f["url"])
            if code != 200:
                raise ValueError("answered %s" % code)
            lists.append(feeds.parse(body, f["name"]))
        except Exception as e:
            log("feed %s couldn't be read: %s" % (f["name"], type(e).__name__))
            failed.append(f["name"])
    return feeds.merge(lists), failed


def rd_releases(dlg):
    """Everything in the feeds the person added: pick some and they go to Real-Debrid."""
    import feeds
    import realdebrid
    import youtube
    if not load_cache(data_file(FEEDS_FILE)).get("feeds"):
        dlg.ok(ADDON, "Add a feed first: the RSS address of your uploads, from your tracker's profile or help page.")
        rd_feed_add(dlg)
        if not load_cache(data_file(FEEDS_FILE)).get("feeds"):
            return
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Reading your feeds...")
    try:
        rows, failed = rd_read_feeds()
    finally:
        prog.close()
    if failed:
        dlg.ok(ADDON, "Couldn't read: %s" % ", ".join(failed))
    if not rows:
        if not failed:
            dlg.ok(ADDON, "Nothing with a torrent or magnet link in your feeds.")
        return
    words = dlg.input("Filter by title (leave empty for all %d)" % len(rows))
    shown = feeds.matching(rows, words)
    if not shown:
        dlg.ok(ADDON, "Nothing matches that.")
        return
    chosen = youtube.select2(dlg, "My releases - tick what to get", [
        (youtube._short(r["title"], 70), " - ".join(x for x in (
            realdebrid.size_text(r["size"]) if r["size"] else "", r["feed"]) if x)) for r in shown], multi=True)
    if chosen:
        rd_send(dlg, [shown[i] for i in chosen])


def rd_feed_add(dlg):
    import feeds
    import realdebrid
    name = dlg.input("A name for this feed (e.g. the tracker's name)")
    if not name:
        return
    url = dlg.input("The feed's address (paste it with Kore on the phone)")
    if not url:
        return
    url = url.strip()
    try:
        code, body = realdebrid._http(url)
        if code != 200:
            raise ValueError("it answered %s" % code)
        count = len(feeds.parse(body, name))
    except Exception as e:
        log("feed %s couldn't be read: %s" % (name, type(e).__name__))
        dlg.ok(ADDON, "That address didn't return a feed, so it wasn't added.")
        return
    saved = load_cache(data_file(FEEDS_FILE))
    saved["feeds"] = [f for f in saved.get("feeds") or [] if f["name"] != name] + [{"name": name, "url": url}]
    save_cache(data_file(FEEDS_FILE), saved)
    dlg.ok(ADDON, "Added %s. It has %d release(s) right now." % (name, count))


def rd_feed_remove(dlg):
    saved = load_cache(data_file(FEEDS_FILE))
    have = saved.get("feeds") or []
    if not have:
        dlg.ok(ADDON, "You haven't added any feeds.")
        return
    pick = dlg.select("Remove which feed?", [f["name"] for f in have])
    if pick >= 0:
        saved["feeds"] = have[:pick] + have[pick + 1:]
        save_cache(data_file(FEEDS_FILE), saved)


def rd_link(dlg):
    import realdebrid
    rd = _rd_ready(dlg)
    if not rd:
        return
    link = dlg.input("File-host link (paste it with Kore on the phone)")
    if not link:
        return
    try:
        url, name, size = rd.unrestrict(link)
    except realdebrid.RDError as e:
        dlg.ok(ADDON, str(e))
        return
    rd_download(dlg, [(url, name, size)])


def rd_history(dlg):
    import realdebrid
    import youtube
    rd = _rd_ready(dlg)
    if not rd:
        return
    try:
        hs = [h for h in rd.history() if h.get("download")]
    except realdebrid.RDError as e:
        dlg.ok(ADDON, str(e))
        return
    if not hs:
        dlg.ok(ADDON, "No recent Real-Debrid downloads.")
        return
    chosen = youtube.select2(dlg, "Recent Real-Debrid downloads - pick to get them again",
                             [(youtube._short(h.get("filename", "?"), 60), "%s - %s" % (
                                 realdebrid.size_text(h.get("filesize")), (h.get("generated") or "")[:10])) for h in hs],
                             multi=True)
    if chosen:
        rd_download(dlg, [(hs[i]["download"], hs[i].get("filename", "download"), int(hs[i].get("filesize") or 0))
                          for i in chosen])


PASTE_SITE = "https://paste.kodi.tv/"
ISSUES = "https://github.com/sortovia/sortovia/issues/new"


def _upload_report(text):
    """Puts the cleaned log on Kodi's paste site. Returns its code."""
    from urllib.request import Request, urlopen
    req = Request(PASTE_SITE + "documents", data=text.encode("utf-8"),
                  headers={"User-Agent": "Sortovia", "Content-Type": "text/plain; charset=utf-8"})
    resp = urlopen(req, timeout=60)
    try:
        return json.loads(resp.read().decode("utf-8"))["key"]
    finally:
        resp.close()


def _qr_screen(title, text, link):
    """A QR code for the phone's camera, with text beside it, until Back."""
    import qrpng
    path = "special://temp/sortovia-qr-%d.png" % int(time.time())
    out = _VfsWriter(path)
    try:
        out.write(qrpng.qr_png(link, scale=6))
    finally:
        out.close()

    class Window(xbmcgui.WindowDialog):
        def onAction(self, action):
            if action.getId() in screens.BACK or action.getId() == screens.SELECT:
                self.close()

    win = Window()
    win.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, screens.MEDIA + "panel.png"))
    win.addControl(xbmcgui.ControlImage(60, 120, 480, 480, path))
    win.addControl(xbmcgui.ControlLabel(60, 40, 1160, 44, "[B]%s[/B]" % title, font="font13", textColor="FF2EC4B6"))
    box = xbmcgui.ControlTextBox(590, 120, 630, 500, font="font13", textColor="FFFFFFFF")
    win.addControl(box)
    box.setText(text + "\n\nBack: close")
    win.doModal()
    del win
    xbmcvfs.delete(path)


def send_problem_report(dlg):
    """Clean the log, show it if asked, upload it, and give the person a link for the developer."""
    import report
    try:
        from urllib.parse import quote as q
    except ImportError:
        from urllib import quote as q
    try:
        cleaned = report.scrub(decode_text(backup._read("special://logpath/kodi.log")))
    except Exception as e:
        log("reading the log failed: %s" % type(e).__name__)
        dlg.ok(ADDON, "Couldn't read Kodi's log on this device.")
        return
    while True:
        pick = dlg.select("Send a problem report to the developer", [
            "Upload the report",
            "First, read exactly what will be sent",
            "Cancel"])
        if pick == 1:
            dlg.textviewer("%s - what will be sent" % ADDON, cleaned)
        elif pick == 0:
            break
        else:
            return
    if not dlg.yesno(ADDON, "The report is Kodi's recent log. Passwords, keys, sign-ins, user names and network addresses "
                     "are removed, but it can still include the names of your files and folders.\n\n"
                     "It goes on paste.kodi.tv, Kodi's public log site, where anyone with the link can read it.",
                     nolabel="Cancel", yeslabel="Upload"):
        return
    try:
        code = _upload_report(cleaned)
    except Exception as e:
        log("uploading the report failed: %s" % type(e).__name__)
        dlg.ok(ADDON, "Couldn't upload the report. Check this device's internet connection and try again.")
        return
    version = xbmcaddon.Addon().getAddonInfo("version")
    body = "Sortovia %s\nLog: %s%s\n\nWhat happened:\n" % (version, PASTE_SITE, code)
    link = "%s?title=%s&body=%s" % (ISSUES, q("Problem report " + code), q(body))
    log("problem report uploaded: %s" % code)
    try:
        _qr_screen("Your report is ready: %s" % code,
                   "One last step: scan this code with your phone's camera. It opens a report to the developer with the "
                   "log link filled in. Add what happened, then submit it. It needs a free GitHub account.\n\n"
                   "Your report code is [B]%s[/B]. Keep it in case you're asked." % code, link)
    except Exception:
        dlg.ok(ADDON, "Your report code is %s.\nGive it to the developer on the Sortovia GitHub page." % code)


def rd_sort(dlg, spath):
    folder = rd_folder(dlg)
    last = load_cache(data_file("last_settings.json"))
    if not folder or not last.get("dest"):
        dlg.ok(ADDON, "Sort something once first (Sort my downloads), so Sortovia knows your library drive.")
        return
    run(dlg, spath, folder, last["dest"], last.get("mode", ASK), last.get("delete_old", False),
        last.get("lang_mode", 0), last.get("nfo_mode", 0), last.get("sub_mode", 0), last.get("empty_mode", 1))


def rd_account(dlg):
    rd = rd_client()
    if not rd.signed_in():
        rd_sign_in(dlg)
        return
    if dlg.yesno(ADDON, "Real-Debrid: signed in as %s%s." % (rd.state.get("username") or "?",
                 (", premium until %s" % rd.state["premium_until"]) if rd.state.get("premium_until") else ""),
                 nolabel="OK", yeslabel="Sign out"):
        rd.sign_out()


WORK_DIR = "_Sortovia temp"
OLD_WORK_DIR = "_Kodi Sorter temp"


def work_dir(near=None):
    """A work folder on the library drive (big temporary files never go on the Xbox's
    own small storage). near: any path on that drive; default the last destination.
    Falls back to Kodi's temp folder when no drive is known."""
    base = near or load_cache(data_file("last_settings.json")).get("dest")
    root = backup.drive_dir(base) if base else None
    if root:
        folder = root.replace(backup.DRIVE_DIR, WORK_DIR)
        old = root.replace(backup.DRIVE_DIR, OLD_WORK_DIR)
        if xbmcvfs.exists(old):  # only ever held temporary files
            xbmcvfs.rmdir(old, True)
        xbmcvfs.mkdirs(folder)
        mark_nomedia(folder)
        if xbmcvfs.exists(folder):
            return folder
    return "special://temp/"


class _VfsWriter(object):
    def __init__(self, path):
        self.f = xbmcvfs.File(path, "w")

    def write(self, b):
        if self.f.write(bytearray(b)) is False:
            raise IOError("write failed (drive full?)")

    def close(self):
        self.f.close()


def convert_comic(path, turn=1, work=None):
    """Rewrite a .cbr or .cbz as a .cbz next to it (pages stored as they are, JPEGs
    given the orientation tag). It's built in the work folder on the same drive, checked,
    then copied into place; the original goes only after that. Returns (ok, message, new path)."""
    items = open_archive(path)
    if not items:
        return False, ("Kodi couldn't open it" + (" - .cbr needs Kodi's Archive support add-on"
                                                  if path.lower().endswith(".cbr") else "")), path
    urls = [u for u, _ in items]
    top = os.path.commonprefix(urls)
    top = top[:top.rfind("/") + 1]
    tmp = (work or work_dir(path)) + "comic-%d.cbz" % int(time.time())
    turned = other = 0
    try:
        out = _VfsWriter(tmp)
        try:
            z = comics.StoredZip(out.write)
            for rel in comics.page_order([u[len(top):] for u in urls]):
                data = _read_exact(top + rel)
                if comics.ext_of(rel) in (".jpg", ".jpeg"):
                    if turn != 1 or comics.orientation_of(data) != 1:  # upright: only undo a turn
                        data = comics.set_orientation(data, turn)
                    turned += 1
                elif comics.ext_of(rel) in comics.IMAGES:
                    other += 1
                z.add(rel, data)
            size = z.close()
        finally:
            out.close()
        if size_of(tmp) != size or len(open_archive(tmp) or []) != len(urls):
            return False, "the new .cbz didn't check out - original kept", path
        stem = split_name(base_of(path))[0]
        dst = parent_of(path) + stem + ".cbz"
        same = _norm(dst) == _norm(path)
        if not same and xbmcvfs.exists(dst):
            return False, "a .cbz with that name is already there - left as it is", path
        if same and not xbmcvfs.delete(path):
            return False, "couldn't replace it (is it open?)", path
        try:
            copy_with_progress(tmp, dst, size)
        except Exception as e:
            log("comic copy failed (%s), trying Kodi's copy" % e)
            xbmcvfs.delete(dst)
            xbmcvfs.copy(tmp, dst)
        if size_of(dst) != size:
            xbmcvfs.delete(dst)
            if same:  # the original is gone: the checked copy stays in the work folder
                keep = parent_of(tmp) + base_of(dst)
                xbmcvfs.copy(tmp, keep)
                return False, "couldn't write it back - the new copy is in %s" % friendly(keep), path
            return False, "copying the .cbz failed - original kept", path
        if not same:
            xbmcvfs.delete(path)
        notes = []
        if turn != 1 and other:
            notes.append("%d non-JPEG pages can't be turned" % other)
        return True, "%d pages%s%s" % (len(urls), ", turned %s" % comics.turn_label(turn) if turn != 1 and turned else "",
                                      (" (%s)" % "; ".join(notes)) if notes else ""), dst
    except Exception as e:
        log("converting %s failed: %s" % (path, e))
        return False, "failed: %s - original kept" % e, path
    finally:
        if xbmcvfs.exists(tmp):
            xbmcvfs.delete(tmp)


def _comics_root(dlg):
    return library_folder("Comics", dlg)


def _comic_files(root, exts):
    out = []
    for path, name in walk(root):
        if comics.ext_of(name) in exts:
            parts = [p for p in re.split(r"[\\/]", path[len(root):]) if p][:-1]
            out.append((path, parts, name))
    return out


def comics_pending():
    """Comics a stopped conversion still has to do: (paths that still exist, turn)."""
    p = load_cache(data_file(COMICS_PREF))
    todo = [x for x in p.get("pending") or [] if xbmcvfs.exists(x)]
    return todo, p.get("pending_turn", 1)


def _save_pending(todo, turn):
    p = load_cache(data_file(COMICS_PREF))
    if todo:
        p["pending"], p["pending_turn"] = todo, turn
    else:
        p.pop("pending", None)
        p.pop("pending_turn", None)
    save_cache(data_file(COMICS_PREF), p)


def convert_many(dlg, paths, turn):
    """Convert one comic after another. Cancel stops after the comic being done
    (never half way); the rest is remembered, to carry on later."""
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Comics")
    lines, ok, stopped = [], 0, False
    _save_pending(list(paths), turn)
    for i, p in enumerate(paths):
        if prog.iscanceled():
            stopped = True
            lines.append("STOPPED by you - %d comic(s) left. Carry on later: File > Convert > "
                         "Convert .cbr comics to .cbz." % (len(paths) - i))
            break
        prog.update(int(i * 100 / max(len(paths), 1)), "Comic %d of %d\n%s\n(Cancel = stop after this comic; "
                    "the rest can be done later)" % (i + 1, len(paths), base_of(p)))
        good, msg, new = convert_comic(p, turn)
        ok += good
        lines.append("%s  %s  (%s)" % ("OK  " if good else "FAIL", base_of(new), msg))
        log("comic: " + lines[-1])
        _save_pending(list(paths[i + 1:]), turn)
    prog.close()
    if not stopped:
        _save_pending([], turn)
    dlg.textviewer("%s - comics" % ADDON, "%d of %d done\n\n%s" % (ok, len(paths), "\n".join(lines)))


def choose_comics(dlg, root, files, heading):
    """Tick which comics (all ticked to start). Returns the chosen paths."""
    rel = [p[len(root):] if p.startswith(root) else base_of(p) for p in files]
    picks = dlg.multiselect(heading, rel, preselect=list(range(len(files))))
    return [files[i] for i in picks] if picks else []


def tidy_comics(dlg, root):
    files = _comic_files(root, comics.COMICS_ALL)
    moves, docs = comics.plan_tidy([(parts, name) for _, parts, name in files])
    by_key = dict(((tuple(parts), name), path) for path, parts, name in files)
    if not moves and not docs:
        dlg.ok(ADDON, "The Comics folder is already tidy: every comic is in its series folder.")
        return
    lines = ["%s  ->  %s/%s" % ("/".join(parts + [name]), series, name) for parts, name, series in moves]
    if docs:
        lines += ["", "Not comics (PDFs an old version filed here) - you choose next:"] + ["  " + n for _, n in docs]
    dlg.textviewer("%s - organise the Comics folder" % ADDON, "\n".join(lines))
    done, failed, left = 0, [], set()
    if moves and dlg.yesno(ADDON, "Move %d comic(s) into their series folders?" % len(moves),
                           nolabel="Cancel", yeslabel="Move"):
        prog = xbmcgui.DialogProgress()
        prog.create(ADDON, "Organising comics")
        for i, (parts, name, series) in enumerate(moves):
            prog.update(int(i * 100 / len(moves)), name)
            src = by_key[(tuple(parts), name)]
            ok, how = move_file(src, join(root, series, name))
            done += ok
            if ok and parts:
                left.add(join(root, *parts))
            elif not ok:
                failed.append("%s (%s)" % (name, how))
        prog.close()
        for d in left:  # "Ironclad (2)" once it's empty
            try:
                ds, fs = xbmcvfs.listdir(ensure_slash(d))
                if not ds and not [f for f in fs if f.lower() != ".nomedia"]:
                    for f in fs:
                        xbmcvfs.delete(join(d, f))
                    xbmcvfs.rmdir(ensure_slash(d)) or xbmcvfs.rmdir(d)
            except Exception:
                pass
    moved_docs = 0
    if docs:
        target = (backup.drive_dir(root) or root).replace(backup.DRIVE_DIR, "Documents")
        if dlg.yesno(ADDON, "%d PDF/EPUB file(s) loose in Comics look like documents (bills, manuals).\n"
                     "Move them to %s?" % (len(docs), friendly(target)), nolabel="Leave them", yeslabel="Move"):
            for parts, name in docs:
                moved_docs += move_file(by_key[(tuple(parts), name)], target + name)[0]
    dlg.ok(ADDON, "Moved %d comic(s) into series folders%s.%s" % (
        done, (" and %d document(s) to Documents" % moved_docs) if moved_docs else "",
        ("\nNot moved: " + "; ".join(failed[:5])) if failed else ""))


def comics_convert(dlg, root):
    todo, turn = comics_pending()
    if todo:
        how = dlg.select("Converting comics was stopped - %d left" % len(todo),
                         ["Carry on with the %d left" % len(todo), "Choose comics again"])
        if how < 0:
            return
        if how == 0:
            convert_many(dlg, todo, turn)
            return
    cbr = [p for p, _, n in _comic_files(root, (".cbr",))]
    if not cbr:
        dlg.ok(ADDON, "No .cbr comics in %s." % friendly(root))
        return
    chosen = choose_comics(dlg, root, cbr, "Convert which comics to .cbz? (untick the ones to leave)")
    if chosen and dlg.yesno(ADDON, "Convert %d comic(s) to .cbz?\nEach takes about as long as copying it, and the "
                            ".cbr is deleted once its .cbz checks out. Cancel stops after the comic being done."
                            % len(chosen), nolabel="Cancel", yeslabel="Convert"):
        convert_many(dlg, chosen, comics_pref()["turn"])


def comics_turn(dlg, root):
    t = dlg.select("Turn the pages", [label for _, label in comics.TURNS])
    if t < 0:
        return
    turn = comics.TURNS[t][0]
    save_cache(data_file(COMICS_PREF), dict(comics_pref(), turn=turn))
    every = [p for p, _, n in _comic_files(root, (".cbz", ".cbr"))]
    how = dlg.select("Turn which comics? (%d in all)" % len(every),
                     ["Try one comic first (recommended)", "Choose which comics (all ticked)",
                      "Only new ones from now on"])
    if how == 0:
        one = dlg.browse(1, "Pick a comic to try", "files", ".cbz|.cbr", False, False, root)
        if one and not one.endswith(("/", "\\")):
            convert_many(dlg, [one], turn)
            dlg.ok(ADDON, "Open it under Pictures to check. If it's the wrong way round, choose the "
                          "other direction here; \"Upright\" puts it back.")
    elif how == 1 and every:
        chosen = choose_comics(dlg, root, every, "Turn which comics? (untick the ones to leave)")
        if chosen:
            convert_many(dlg, chosen, turn)


def comics_menu(dlg):
    root = _comics_root(dlg)
    if not root:
        return
    while True:
        pref = comics_pref()
        pick = dlg.select("Comics - %s" % friendly(root),
                          ["Organise the folder (each comic into its series folder; merges duplicate folders)",
                           "Convert .cbr comics to .cbz (they open much faster)",
                           "Turn pages for a monitor on its side - now: %s (change)" % comics.turn_label(pref["turn"]),
                           "When sorting new comics, convert .cbr to .cbz: %s (change)" % ("yes" if pref["convert"] else "no"),
                           "Why .cbz, and how turning works"])
        if pick < 0:
            return
        if pick == 0:
            tidy_comics(dlg, root)
        elif pick == 1:
            comics_convert(dlg, root)
        elif pick == 2:
            comics_turn(dlg, root)
        elif pick == 3:
            set_setting("convert_comics", not pref["convert"])
        else:
            dlg.textviewer("%s - comics" % ADDON, comics.__doc__.strip())


def convert_new_comics(moved_ok, prog, report):
    """After a sort: new .cbr comics become .cbz (and get the chosen page turn)."""
    pref = comics_pref()
    new = [it["target"] for it in moved_ok if it.get("target", "").lower().endswith(".cbr")]
    if not (pref["convert"] and new):
        return
    for i, p in enumerate(new):
        prog.update(int(i * 100 / len(new)), "Converting comics to .cbz: %d of %d\n%s" % (i + 1, len(new), base_of(p)))
        ok, msg, out = convert_comic(p, pref["turn"])
        report.append("%s  %s -> .cbz  (%s)" % ("OK  " if ok else "NOTE", base_of(p), msg))
        log(report[-1])


# ---------- library backup ----------
BACKUP_STATE = "backup.json"  # addon_data: last backup's time and counts


def _backup_places():
    """The library drive only (the Xbox's own storage is small); Kodi's home folder
    only when no drive is known yet."""
    drive = backup.drive_dir(load_cache(data_file("last_settings.json")).get("dest"))
    return [drive] if drive else [backup.HOME_DIR]


def _clear_xbox_backups():
    """Backups older versions kept on the Xbox's own storage."""
    for stamp, _ in backup.list_backups(backup.HOME_DIR):
        xbmcvfs.rmdir(backup.HOME_DIR + stamp + "/", True)


def backup_bases():
    return [b for b in (backup.drive_dir(load_cache(data_file("last_settings.json")).get("dest")), backup.HOME_DIR) if b]


def all_backups():
    """[(base, stamp, info)] on the drive and the Xbox, newest first."""
    out = []
    for base in backup_bases():
        out += [(base, st, info) for st, info in backup.list_backups(base)]
    return sorted(out, key=lambda r: r[1], reverse=True)


def _backup_to_phone(stamp, files):
    if not (load_cache(data_file("phone.json")).get("dav") or {}).get("pass"):
        return False
    status = send_logs("backup", files=files, folder="SortoviaBackups/" + stamp)
    return status == "sent %d file(s) to the phone" % len(files)


def backup_line():
    return load_cache(data_file(BACKUP_STATE)).get("made") or "never"


BACKUP_ITEMS = "backup-items.json"  # addon_data: every library item as the last backup saw it
FULL_EVERY = 7 * 24 * 3600  # Kodi's own (slow) export at most once a week; changes-only backups in between


class CornerProgress(object):
    """Kodi's small progress bar in the top-right corner: Kodi stays usable while it shows."""
    def __init__(self, heading):
        self.started = time.time()
        try:
            self.bar = xbmcgui.DialogProgressBG()
            self.bar.create(heading, "starting...")
        except Exception:
            self.bar = None

    def __call__(self, what, sec=0, pct=None):
        if self.bar is None:
            return
        took = sec or int(time.time() - self.started)
        try:
            self.bar.update(pct if pct is not None else min(95, 5 + took), message="%s (%s)" % (what, _secs(took)))
        except Exception:
            pass

    def close(self):
        _close(self.bar)


def _secs(n):
    return "%d s" % n if n < 60 else "%d min %02d s" % (n // 60, n % 60)


def backup_now(dlg=None, full=None, background=False):
    """Make a library backup: only what changed since the last one (seconds), with Kodi's own export
    once a week or when full=True. Nothing changed means nothing to save. Progress shows in the
    top-right corner. background=True returns at once and says how it went in a notification."""
    if background:
        import threading
        threading.Thread(target=backup_now, kwargs={"full": full}).start()
        toast("Backing up the library - progress is in the top-right corner, keep using Kodi", 4000)
        return True
    state = load_cache(data_file(BACKUP_STATE))
    bar = CornerProgress("%s: library backup" % ADDON)
    try:
        bar("reading the library")
        print_before = backup.fingerprint()  # taken first, so a change during the export is caught next time
        try:
            now = backup.snapshot()
        except Exception as e:
            log("library snapshot failed: %s" % e)
            now = None
        before = load_cache(data_file(BACKUP_ITEMS)).get("items")
        items = backup.changes(before, now) if (now is not None and before is not None) else None
        if items is not None and not any(items[k] for k in ("added", "changed", "removed")) and \
                print_before and print_before == state.get("fingerprint") and not full:
            state["time"] = time.time()
            save_cache(data_file(BACKUP_STATE), state)
            log("library unchanged since the backup of %s: nothing to save" % state.get("made", "?"))
            bar.close()
            msg = "Nothing in the library changed since the backup of %s - it's still up to date." % state.get("made", "?")
            if dlg is not None:
                toast(msg, 4000)
            return True
        if full is None:
            full = items is None or time.time() - state.get("full_time", 0) > FULL_EVERY
        info, saved = backup.make_backup(_backup_places(), _backup_to_phone, log=log, work=work_dir(), full=full,
                                         items=items, tick=bar)
    except Exception as e:
        log("library backup failed: %s" % e)
        bar.close()
        if dlg is not None:
            dlg.ok(ADDON, "Library backup failed: %s" % e)
        else:
            toast("Library backup failed: %s" % e, 6000)
        return False
    bar.close()
    state.update({"time": time.time(), "made": info["made"], "counts": info["counts"], "fingerprint": print_before})
    if full:
        state["full_time"], state["full_made"] = time.time(), info["made"]
    save_cache(data_file(BACKUP_STATE), state)
    if now is not None:
        save_cache(data_file(BACKUP_ITEMS), {"made": info["made"], "items": now})
    if backup.HOME_DIR not in saved:
        try:
            _clear_xbox_backups()
        except Exception as e:
            log("clearing old backups on the Xbox failed: %s" % e)
    where = ", ".join("the phone" if p == "phone" else "Kodi's home folder" if p == backup.HOME_DIR
                      else friendly(p) for p in saved)
    what = "full backup" if full else "changes saved (%s)" % backup.changes_line(items or {})
    toast("Library backed up: %s. Saved to %s." % (what, where), 5000)
    return True


def backup_if_changed():
    """The daily backup: nothing changed since the last one means nothing to save."""
    state = load_cache(data_file(BACKUP_STATE))
    now = backup.fingerprint()
    if now and now == state.get("fingerprint"):
        state["time"] = time.time()  # look again tomorrow
        save_cache(data_file(BACKUP_STATE), state)
        log("library unchanged since the backup of %s: skipping today's backup" % state.get("made", "?"))
        return False
    return backup_now()


def auto_fix_tv():
    """Start-up, in the background: a show Kodi made out of the whole TV folder is taken out of the library by itself
    (entries only), and a second scan of the TV folder under another spelling is stopped, so it doesn't come back."""
    import missing
    try:
        shows = missing._rpc("VideoLibrary.GetTVShows", {"properties": ["file", "episode"]}).get("tvshows", [])
        bad = wrong_shows(shows, _lib_key(library_folder("TV") or ""))
    except Exception as e:
        log("TV check failed: %s" % e)
        return
    stopped = _stop_duplicate_tv_sources(None)
    if not bad:
        return
    backup_now()
    gone = 0
    for sh, why in bad:
        try:
            missing._rpc("VideoLibrary.RemoveTVShow", {"tvshowid": sh["tvshowid"]})
            gone += 1
            log("removed the wrong show %s (%s)" % (sh.get("label"), why))
        except Exception as e:
            log("couldn't remove show %s: %s" % (sh.get("label"), e))
    if gone:
        toast("Removed %s from the TV library: %s%s" % (
            "a show that wasn't real" if gone == 1 else "%d shows that weren't real" % gone,
            ", ".join(sh.get("label", "?") for sh, _ in bad), " (and stopped what kept adding it)" if stopped else ""), 8000)


def check_library_backup(dlg):
    """Start-up: warn if the library suddenly shrank, else back it up once a day (in the background)."""
    state = load_cache(data_file(BACKUP_STATE))
    try:
        now = backup.counts()
    except Exception as e:
        log("library count failed: %s" % e)
        return
    import threading
    threading.Thread(target=auto_fix_tv).start()
    lost = backup.shrunk(now, state.get("counts") or {})
    if lost:
        if state.get("warned") != now:
            state["warned"] = now
            save_cache(data_file(BACKUP_STATE), state)
            if dlg.yesno(ADDON, "Kodi's library suddenly got smaller since the backup of %s.\n%s.\n"
                         "Changing a source's content type can do this. Your backup is kept - see how to put it back?"
                         % (state.get("made", "?"), lost), nolabel="Not now", yeslabel="Show me"):
                dlg.textviewer("%s - restore the library" % ADDON, backup.RESTORE_HELP)
        return  # no automatic backup while it's smaller: keep the good ones
    if not (now["episodes"] or now["movies"]) or time.time() - state.get("time", 0) < backup.EVERY:
        return
    if not setting_on("auto_backup"):
        return
    import threading
    threading.Thread(target=backup_if_changed).start()


def wrong_movies(movies, episode_keys, tv_root):
    """Movie entries that are really TV episodes (left by a scan of a whole drive set to
    Movies). movies: [{"movieid", "label", "file"}]. Returns [(movie, reason)]."""
    out = []
    for m in movies:
        key = _lib_key(m.get("file"))
        if not key:
            continue
        if key in episode_keys:
            why = "also in your TV library as an episode"
        elif tv_root and key.startswith(tv_root + "/"):
            why = "its file is in your TV folder"
        elif EP_TAG_RE.search(key.rsplit("/", 1)[-1]):
            why = "its file is named like an episode"
        else:
            continue
        out.append((m, why))
    return out


PARK_KEY_RE = re.compile(r"/(?:_replaced|_unpacked|_no [a-z]+)/", re.I)


def wrong_episodes(eps, movie_keys, roots):
    """Episode entries that aren't TV episodes. eps: [{"episodeid", "label", "file"}];
    roots: {"Movies": key, "Tutorials": key, "TV": key}. Returns [(episode, reason)]."""
    out = []
    for e in eps:
        key = _lib_key(e.get("file"))
        if not key:
            continue
        under = lambda k: bool(roots.get(k)) and key.startswith(roots[k] + "/")
        if PARK_KEY_RE.search("/" + key + "/"):
            why = "its file is in a set-aside folder (%s)" % PARK_KEY_RE.search("/" + key + "/").group(0).strip("/")
        elif under("Movies"):
            why = "its file is in your Movies folder"
        elif under("Tutorials"):
            why = "its file is in Tutorials"
        elif key in movie_keys and not under("TV"):
            why = "it's also in your Movies library"
        else:
            continue
        out.append((e, why))
    return out


def wrong_shows(shows, tv_root):
    """TV show entries whose folder is the whole TV folder, or holds other shows' folders: Kodi made one show out of
    many (it happens when the TV folder itself is scanned as a show), and its episodes repeat the real shows'.
    shows: [{"tvshowid", "label", "file"}]. Returns [(show, reason)]."""
    keys = [(sh, _lib_key(sh.get("file"))) for sh in shows]
    out = []
    for sh, key in keys:
        if not key:
            continue
        if tv_root and key == tv_root:
            out.append((sh, "its folder is your whole TV folder"))
        elif any(other.startswith(key + "/") for _, other in keys if other and other != key):
            out.append((sh, "its folder holds other shows' folders"))
    return out


def duplicate_tv_sources(rows):
    """Folders Kodi scans as TV shows twice, under two spellings (D:\\\\TV\\ and D:/TV\\): scanning the odd one
    makes Kodi list every episode again and turn the whole TV folder into one show. rows: [(idPath, strPath, strContent)].
    Returns [(idPath, strPath)] to stop scanning: the spellings with a doubled \\ or /, when a cleaner one remains."""
    tv = [(i, p) for i, p, c in rows if c == "tvshows"]
    odd = lambda p: bool(re.search(r"[\\/]{2}", re.sub(r"^[a-z-]+://[^/]*/", "", p or "")))
    out = []
    for i, p in tv:
        key = _lib_key(p)
        if odd(p) and any(j != i and _lib_key(q) == key and not odd(q) for j, q in tv):
            out.append((i, p))
    return out


def _stop_duplicate_tv_sources(dlg):
    """Stops Kodi scanning a TV folder a second time under another spelling (the library entries only; no files).
    Returns how many it stopped."""
    name = backup.newest_db(backup.VIDEO_DB)[0]
    if not name:
        return 0
    try:
        sqlite3 = drive_letter._sqlite()
        conn = sqlite3.connect(_db_path(name), timeout=30, isolation_level=None)
        try:
            bad = duplicate_tv_sources(conn.execute("SELECT idPath, strPath, strContent FROM path").fetchall())
            if bad:
                conn.execute("BEGIN IMMEDIATE")
                conn.executemany("UPDATE path SET strContent='', strScraper='', strSettings='' WHERE idPath=?",
                                 [(i,) for i, _ in bad])
                conn.execute("COMMIT")
        finally:
            conn.close()
    except Exception as e:
        log("couldn't check the TV sources: %s" % e)
        return 0
    for _, p in bad:
        log("stopped the duplicate TV source %s (same folder as another TV source)" % p)
    return len(bad)


def _remove_wrong_shows(dlg, tv_root):
    """Offers to take shows made from the whole TV folder out of the library (entries only, never files).
    False when the person cancelled."""
    import missing
    try:
        shows = missing._rpc("VideoLibrary.GetTVShows", {"properties": ["file", "episode"]}).get("tvshows", [])
    except Exception as e:
        log("couldn't read the TV shows: %s" % e)
        return True
    bad = wrong_shows(shows, tv_root)
    stopped = _stop_duplicate_tv_sources(dlg)
    if not bad:
        if stopped:
            dlg.ok(ADDON, "Kodi was scanning your TV folder twice, under two spellings. Sortovia stopped the second one, "
                   "so its shows and episodes aren't added twice.")
        return True
    if not backup_now(dlg) and not dlg.yesno(ADDON, "Some TV entries aren't real shows, but the backup didn't work. "
                                             "Remove them anyway?", nolabel="Cancel", yeslabel="Remove"):
        return False
    gone = 0
    for sh, _ in bad:
        try:
            missing._rpc("VideoLibrary.RemoveTVShow", {"tvshowid": sh["tvshowid"]})
            gone += 1
        except Exception as ex:
            log("couldn't remove show %s: %s" % (sh.get("label"), ex))
    log("removed %d wrong show entries" % gone)
    dlg.textviewer("%s - not real shows, removed" % ADDON, "Removed %d of %d shows that weren't real (library entries only - "
                   "your files and your other shows stay as they are):\n\n%s%s" % (gone, len(bad), "\n".join(
                       "%s  (%s episodes)  -  %s\n    %s" % (sh.get("label", "?"), sh.get("episode", "?"), why,
                                                         shown_path(sh.get("file", ""), "")) for sh, why in bad),
                       "\n\nKodi was also scanning your TV folder a second time under another spelling, which is what kept "
                       "making this show. That's stopped now, so it won't come back." if stopped else ""))
    return True


def _clean_kodi(content):
    """Kodi's own clean-up for entries whose files are gone."""
    import missing
    try:
        missing._rpc("VideoLibrary.Clean", {"showdialogs": True, "content": content})
        toast("Kodi is removing entries whose files are gone. Its progress is in the top-right corner - "
              "you can keep using Kodi.", 6000)
    except Exception as e:
        log("Kodi's library clean (%s) failed: %s" % (content, e))


def clean_tv_library(dlg):
    import missing
    roots = dict((k, _lib_key(library_folder(k) or "")) for k in ("TV", "Movies", "Tutorials"))
    if not _remove_wrong_shows(dlg, roots.get("TV")):
        return
    try:
        eps = missing._rpc("VideoLibrary.GetEpisodes", {"properties": ["file", "showtitle", "season", "episode"]}
                           ).get("episodes", [])
        bad = wrong_episodes(eps, library_files("MOVIE"), roots)
    except Exception as e:
        dlg.ok(ADDON, "Couldn't read Kodi's library: %s" % e)
        return
    if bad:
        dlg.textviewer("%s - not TV episodes" % ADDON, "\n".join(
            "%s S%02dE%02d %s  -  %s\n    %s" % (e.get("showtitle", "?"), e.get("season", 0), e.get("episode", 0),
                                              e.get("label", ""), why, shown_path(e.get("file", ""), ""))
            for e, why in bad))
        if not dlg.yesno(ADDON, "Remove these %d entries from the TV library?\nOnly the library entries go - no files "
                         "are deleted. A library backup is made first." % len(bad), nolabel="Cancel", yeslabel="Remove"):
            return
        if not backup_now(dlg) and not dlg.yesno(ADDON, "The backup didn't work. Remove the entries anyway?",
                                                 nolabel="Cancel", yeslabel="Remove"):
            return
        gone = 0
        for e, _ in bad:
            try:
                missing._rpc("VideoLibrary.RemoveEpisode", {"episodeid": e["episodeid"]})
                gone += 1
            except Exception as ex:
                log("couldn't remove episode %s: %s" % (e.get("label"), ex))
        log("removed %d wrong episode entries" % gone)
        dlg.ok(ADDON, "Removed %d of %d wrong episode entries.\nNext, Kodi removes entries whose files are gone." %
               (gone, len(bad)))
    elif not dlg.yesno(ADDON, "No wrong episodes: all %d are TV episodes in the right place.\nAlso let Kodi remove "
                       "entries whose files are gone?" % len(eps), nolabel="No", yeslabel="Yes"):
        return
    _clean_kodi("tvshows")


def fix_wrong_movies(dlg):
    import missing
    tv = library_folder("TV")
    try:
        movies = missing._rpc("VideoLibrary.GetMovies", {"properties": ["file", "year"]}).get("movies", [])
        bad = wrong_movies(movies, library_files("TV"), _lib_key(tv) if tv else "")
    except Exception as e:
        dlg.ok(ADDON, "Couldn't read Kodi's library: %s" % e)
        return
    if not bad:
        if dlg.yesno(ADDON, "No wrong movie entries: none of your %d movies is a TV episode.\nAlso let Kodi remove "
                     "entries whose files are gone?" % len(movies), nolabel="No", yeslabel="Yes"):
            _clean_kodi("movies")
        return
    dlg.textviewer("%s - TV episodes listed as movies" % ADDON, "\n".join(
        "%s (%s)  -  %s\n    %s" % (m.get("label"), m.get("year") or "?", why, shown_path(m.get("file", ""), ""))
        for m, why in bad))
    if not dlg.yesno(ADDON, "Remove these %d entries from the Movies library?\nOnly the library entries go - "
                     "no files are deleted, and the episodes stay under TV shows. A library backup is made first."
                     % len(bad), nolabel="Cancel", yeslabel="Remove"):
        return
    if not backup_now(dlg) and not dlg.yesno(ADDON, "The backup didn't work. Remove the entries anyway?",
                                             nolabel="Cancel", yeslabel="Remove"):
        return
    gone = 0
    for m, _ in bad:
        try:
            missing._rpc("VideoLibrary.RemoveMovie", {"movieid": m["movieid"]})
            gone += 1
        except Exception as e:
            log("couldn't remove movie %s: %s" % (m.get("label"), e))
    log("removed %d wrong movie entries" % gone)
    dlg.ok(ADDON, "Removed %d of %d wrong movie entries.\nNext, Kodi removes entries whose files are gone." %
           (gone, len(bad)))
    _clean_kodi("movies")


def _where(base):
    return "this device" if base == backup.HOME_DIR else friendly(base)


def letter_backups():
    """[(folder, stamp, info)] of the backups kept for each drive letter, newest first."""
    out = []
    for base in backup_bases():
        for folder in backup.letter_bases(base):
            out += [(folder, st, info) for st, info in backup.list_backups(folder)]
    return sorted(out, key=lambda r: r[1], reverse=True)


def backups_list(dlg):
    rows = ["%s   %s   (%s)%s" % (st, backup.counts_line(info.get("counts") or {}), _where(base),
                                   "   changes only: %s" % info.get("changes", "?") if info.get("kind") == "changes" else "")
            for base, st, info in all_backups() + letter_backups()]
    dlg.textviewer("%s - backups" % ADDON, "\n".join(rows) or "No backups yet.")


def restore_backup(dlg):
    rows = [r for r in all_backups() if r[2].get("kind") != "changes"] + [r for r in letter_backups() if r[2].get("xml_bytes")]
    if not rows:
        dlg.ok(ADDON, "No library backups yet.")
        return
    pick = dlg.select("Restore which backup?",
                      ["%s%s   %s" % (st, "   for %s:" % info["drive"] if info.get("drive") else "",
                                      backup.counts_line(info.get("counts") or {})) for base, st, info in rows])
    if pick < 0:
        return
    base, st, info = rows[pick]
    try:
        backup.stage_restore(base, st)
    except Exception as e:
        dlg.ok(ADDON, "Couldn't get the backup ready: %s" % e)
        return
    dlg.textviewer("%s - restore the library" % ADDON,
                   "The backup of %s is ready.\n\nNow in Kodi: Settings > Media > Library > (Videos) Import library > "
                   "Home folder > Kodi library restore > %s > OK.\n\n%s" % (st, st, backup.RESTORE_HELP))


def remove_old_backups(dlg):
    rows = all_backups()
    if not rows:
        dlg.ok(ADDON, "No library backups to remove.")
        return
    newest = rows[0]
    keep_auto = set(id(r) for r in [r for r in rows if r[0] != backup.HOME_DIR][:2])  # newest 2 on the drive
    picks = dlg.multiselect("Remove which backups? (the newest is kept)",
                            ["%s   %s   (%s)" % (st, backup.counts_line(info.get("counts") or {}), _where(base))
                             for base, st, info in rows[1:]],
                            preselect=[i for i, r in enumerate(rows[1:]) if id(r) not in keep_auto])
    if not picks:
        return
    gone = sum(1 for i in picks if xbmcvfs.rmdir(rows[1:][i][0] + rows[1:][i][1] + "/", True))
    dlg.ok(ADDON, "Removed %d of %d backup(s). Kept the newest, %s." % (gone, len(picks), newest[1]))


# Sortovia's own saved files that can hold a folder on the library drive.
SAVED_WITH_FOLDERS = ("last_settings.json", "onboarding.json", "youtube.json", "rd_queue.json", COMICS_PREF, "session.json")
KODI_FILES_WITH_FOLDERS = ("sources.xml", "favourites.xml", "advancedsettings.xml")


def _swap_bytes(data, old, new):
    return drive_letter.swap_text(data.decode("utf-8", "surrogateescape"), old, new).encode("utf-8", "surrogateescape")


def _kodi_files():
    """[(name, bytes)] of Kodi's own files that list folders, for the ones this device has."""
    out = []
    for name in KODI_FILES_WITH_FOLDERS:
        path = "special://profile/" + name
        if xbmcvfs.exists(path):
            out.append((name, backup._read(path)))
    return out


def _switch_saved_folders(kodi_files, old, new):
    """Point Kodi's sources and favourites and Sortovia's saved folders at the new letter.
    Returns the names of any that couldn't be saved."""
    failed = []
    for name, data in kodi_files:
        changed = _swap_bytes(data, old, new)
        if changed != data and not backup._write("special://profile/" + name, changed):
            failed.append(name)
    for name in SAVED_WITH_FOLDERS:
        path = data_file(name)
        saved = load_cache(path)
        if saved:
            changed = json.loads(drive_letter.swap_text(json.dumps(saved), old, new))
            if changed != saved and not save_cache(path, changed):
                failed.append(name)
    return failed


def ensure_picture_cache_folder():
    """If advancedsettings.xml keeps Kodi's picture cache on a drive, make sure the folder is there. Kodi can't
    create it, and with no folder it fetches every picture again instead of saving it. Returns what it made."""
    path = "special://profile/advancedsettings.xml"
    try:
        if not xbmcvfs.exists(path):
            return ""
        m = re.search(r"<from>\s*special://[^<]*Thumbnails/?\s*</from>\s*<to>\s*(win-lib://[^<]+?)\s*</to>",
                      backup._read(path).decode("utf-8", "replace"))
        if not m or not any(_listdir_or_nothing(re.match(r"^win-lib://[^/]*/[A-Za-z]:[\\/]*", m.group(1)).group(0))):
            return ""  # no such setting, or the drive isn't there
        folder = ensure_slash(m.group(1))
        made = ""
        for sub in "0123456789abcdef":
            if not xbmcvfs.exists(folder + sub + "/"):
                xbmcvfs.mkdirs(folder + sub + "/")
                made = folder
        if made:
            log("made Kodi's picture cache folder: %s (restart Kodi to use it)" % friendly(made))
        return made
    except Exception as e:
        log("picture cache folder: %s" % e)
        return ""


def _listdir_or_nothing(path):
    try:
        return xbmcvfs.listdir(path)
    except Exception:
        return [], []


def _library_databases():
    """[(name, bytes, queries for its files)] for Kodi's video and music libraries."""
    out = []
    for prefix, queries in ((backup.VIDEO_DB, drive_letter.VIDEO_FILES), (backup.MUSIC_DB, drive_letter.MUSIC_FILES)):
        name, data = backup.newest_db(prefix)
        if name:
            out.append((name, data, queries))
    return out


def _db_path(name):
    return xbmcvfs.translatePath("special://database/" + name)


def _choose_new_letter(dlg, databases):
    """(old, new, date of a backup that's already up to date) once the person agrees, or None after saying why not."""
    files = []
    for name, _, queries in databases:
        files += drive_letter.library_files(_db_path(name), queries)
    found = drive_letter.diagnose(files, _listdir_or_nothing)
    if not found["moved"]:
        if found["lost"]:
            dlg.ok(ADDON, "Your library's files on %s: weren't found on any drive. Check the drive is plugged in, then "
                   "try again. Nothing was changed." % ", ".join(found["lost"]))
        elif found["ok"]:
            dlg.ok(ADDON, "Nothing to fix: your library's files are on %s:, where Kodi expects them."
                   % ", ".join(found["ok"]))
        else:
            dlg.ok(ADDON, "Your library has nothing on an external drive, so there's nothing to fix.")
        return None
    old, hits = found["moved"][0]
    new = hits[0]
    if len(hits) > 1:
        pick = dlg.select("Your library's files are on more than one drive. Use which?", ["%s:" % h for h in hits])
        if pick < 0:
            return None
        new = hits[pick]
    affected = _on_letter(databases, old)
    names = _library_names(affected)
    saved = backup.existing_copy(backup.drive_dir("win-lib://removable/%s:\\" % new), old, affected)
    first = ("An up-to-date backup of your %s library from %s already exists, so Sortovia won't make another for %s:."
             % (names, saved, old)) if saved else "Sortovia will first back up your %s library as it is for %s:." % (names, old)
    if not dlg.yesno(ADDON, "Kodi's %s library points to %s:, but your files are now on %s:.\n\n%s\n\nIt will then point "
                     "Kodi at %s: and save a copy for %s:. It won't move or delete any files."
                     % (names, old, new, first, new, new), nolabel="Cancel", yeslabel="Fix it"):
        return None
    return old, new, saved


def _on_letter(databases, letter):
    """[(name, bytes)] of the libraries with folders on that letter. Only these are changed and
    backed up: a copy of any other library wouldn't match the letter it's saved under."""
    return [(n, d) for n, d, _ in databases if drive_letter.uses_letter(_db_path(n), letter)]


def _library_names(databases):
    kinds = ["video" if n.startswith(backup.VIDEO_DB) else "music" for n, _ in databases]
    return " and ".join(kinds)


def fix_drive_letter(dlg):
    """Point Kodi's libraries and Sortovia at the drive's new letter, keeping a backup for each letter."""
    prog = None
    try:
        databases = _library_databases()
        if not databases or not all(data for _, data, _ in databases):
            dlg.ok(ADDON, "Couldn't read Kodi's library database. Nothing was changed.")
            return False
        letters = _choose_new_letter(dlg, databases)
        if not letters:
            return False
        old, new, saved = letters
        affected = _on_letter(databases, old)
        stamp = time.strftime("%Y-%m-%d %H%M")
        drive = "win-lib://removable/%s:\\" % new
        base = backup.drive_dir(drive)
        prog = xbmcgui.DialogProgress()
        prog.create(ADDON, "Getting ready to switch to %s:..." % new if saved else
                    "Saving the library backup for %s:...\n(Kodi's export can take a minute)" % old)
        xml = None
        if not saved and any(n.startswith(backup.VIDEO_DB) for n, _ in affected):
            try:
                xml = backup.export_xml(work=work_dir(drive))
            except Exception as e:  # the database copy still protects the library
                log("drive letter: export failed: %s" % e)
        count = backup.counts()
        kodi_files = _kodi_files()
        if not saved:
            backup.save_letter_copy(base, old, stamp, count, xml, affected, kodi_files)
        prog.update(50, "Pointing Kodi at %s:..." % new)
        done = []
        for n, _ in affected:
            try:
                changed = drive_letter.rewrite_db(_db_path(n), old, new)
            except drive_letter.DriveLetterError as e:
                raise drive_letter.DriveLetterError(
                    "%s%s" % (e, " Already updated: %s. Run this again to finish." % ", ".join(done) if done else ""))
            done.append(n)
            log("drive letter: %s %s: to %s:, %d values changed" % (n, old, new, changed))
        failed = _switch_saved_folders(kodi_files, old, new)
        prog.update(80, "Saving the library backup for %s:..." % new)
        second = ""
        try:
            now = [(n, backup._read("special://database/" + n)) for n, _ in affected]
            backup.save_letter_copy(base, new, stamp, count, _swap_bytes(xml, old, new) if xml else None, now,
                                    [(n, _swap_bytes(d, old, new)) for n, d in kodi_files])
        except Exception as e:
            log("drive letter: second backup failed: %s" % e)
            second = "\nThe backup for %s: couldn't be saved, so make one from this menu after restarting." % new
    except Exception as e:  # stopped before Kodi's libraries were all changed
        log("drive letter: stopped: %s" % e)
        _close(prog)
        dlg.ok(ADDON, "Couldn't fix the drive letter: %s" % e)
        return False
    _close(prog)
    trouble = "\nThese couldn't be updated: %s." % ", ".join(failed) if failed else ""
    done_text = ("Kodi's library now points to %s:. Backups for both letters are in the _Kodi library backups "
                 "folder on the drive.%s%s\n\n" % (new, second, trouble))
    if my_device() == "xbox":  # Kodi's own exit often hangs on an Xbox, so don't offer it
        dlg.ok(ADDON, done_text + "Now restart Kodi so it loads your updated folders: press the Xbox button, highlight "
               "Kodi, press the Menu button and choose Quit, then open Kodi again. If the letter changes again, run this again.")
    elif dlg.yesno(ADDON, done_text + "Restart Kodi so it loads your updated folders. If the letter changes again, run "
                   "this again. Close Kodi now?", nolabel="Later", yeslabel="Close Kodi"):
        xbmc.executebuiltin("Quit")
    return True


PROP_MUSIC_BUSY = "kodisorter.music_busy"  # time.time() while a slow music tool runs


def one_at_a_time(tool):
    """Run a slow music tool once: clicking again while it works says so instead of starting another."""
    def run_it(dlg, *args):
        try:
            started = float(home().getProperty(PROP_MUSIC_BUSY) or 0)
        except ValueError:
            started = 0
        if time.time() - started < 3600:
            dlg.ok(ADDON, "Sortovia is already working on your music. It will show the result when it's done.")
            return None
        home().setProperty(PROP_MUSIC_BUSY, str(time.time()))
        try:
            return tool(dlg, *args)
        finally:
            home().clearProperty(PROP_MUSIC_BUSY)
    return run_it


def _progress(heading):
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, heading)

    def step(done, total, name):
        if total:
            prog.update(int(done * 100 / total), "%s\n%d of %d\n%s" % (heading, done + 1, total, name))
        else:
            prog.update(0, "%s\n%s" % (heading, name))
        return prog.iscanceled()
    return prog, step


def _music_albums(name):
    import musicart
    return musicart.read_albums(_db_path(name))


def _check_music_art(dlg):
    """Which albums have art, compared with the oldest saved copy of the music library. Changes nothing."""
    import musicart
    name = backup.newest_db(backup.MUSIC_DB)[0]
    if not name:
        dlg.ok(ADDON, "Kodi doesn't have a music library yet, so there's nothing to check.")
        return None
    old_copy = data_file("music-before.db")
    before = None
    prog, step = _progress("Checking your music art...")
    try:
        now = _music_albums(name)
        copies = [r for r in letter_backups() if backup.MUSIC_DB in (r[2].get("db") or "")]
        if copies:
            folder, stamp, info = copies[-1]  # the oldest: from before any switch
            kept = [n for n in info["db"].split(", ") if n.startswith(backup.MUSIC_DB)][0]
            with open(old_copy, "wb") as f:
                f.write(backup._read(folder + stamp + "/" + kept))
            before = musicart.read_albums(old_copy)
        found = musicart.compare(now, before, _listdir_or_nothing, step)
        info = musicart.status(_db_path(name))
    except Exception as e:
        log("music art check failed: %s" % e)
        _close(prog)
        dlg.ok(ADDON, "Couldn't check your music art: %s\nNothing was changed." % e)
        return None
    finally:
        if old_copy and os.path.exists(old_copy):
            os.remove(old_copy)
    _close(prog)
    text = musicart.report(found, before is not None, info)
    log("music art check:\n" + text)
    if (load_cache(data_file("phone.json")).get("dav") or {}).get("pass"):
        send_logs("music art", files=[("music-art-report.txt", text.encode("utf-8"))])
    dlg.textviewer("%s - music art" % ADDON, text)
    return found


check_music_art = one_at_a_time(_check_music_art)


def _set_music_art(dlg):
    """Point albums with no art at the picture in their folder. Only Kodi's library changes."""
    import missing
    import musicart
    name = backup.newest_db(backup.MUSIC_DB)[0]
    if not name:
        dlg.ok(ADDON, "Kodi doesn't have a music library yet.")
        return 0
    prog, step = _progress("Checking which albums need art...")
    try:
        wanted = musicart.needs_art(_music_albums(name), _listdir_or_nothing, step)
    except Exception as e:
        log("set music art: %s" % e)
        _close(prog)
        dlg.ok(ADDON, "Couldn't read your music library: %s\nNothing was changed." % e)
        return 0
    _close(prog)
    if not wanted:
        dlg.ok(ADDON, "Every album with a picture in its folder already has art.")
        return 0
    if not dlg.yesno(ADDON, "%d albums have a picture in their folder that Kodi isn't using. Use those as their covers?"
                     "\n\nNo files are changed or renamed. If you rebuild the music library, run this again."
                     % len(wanted), nolabel="Cancel", yeslabel="Use them"):
        return 0
    done, failed = _apply_music_art(wanted)
    log("set music art: %d set, %d failed" % (done, len(failed)))
    dlg.ok(ADDON, "Set art for %d albums.%s Kodi may need a moment to show them." % (
        done, " These failed: %s." % ", ".join(failed) if failed else ""))
    return done


def _apply_music_art(wanted, step=None):
    import missing
    prog = None
    if step is None:
        prog, step = _progress("Setting album art...")
    done, failed = 0, []
    for i, (album, picture) in enumerate(wanted):
        if step(i, len(wanted), album["name"]):
            break
        try:
            missing._rpc("AudioLibrary.SetAlbumDetails", {"albumid": album["id"], "art": {"thumb": picture}})
            done += 1
        except Exception as e:
            log("set music art: %s: %s" % (album["name"], e))
            failed.append(album["name"])
    _close(prog)
    return done, failed


set_music_art = one_at_a_time(_set_music_art)


def _set_artist_art(dlg):
    """Use pictures in artists' own folders when Kodi has none. Only Kodi's library changes."""
    import missing
    import musicart
    name = backup.newest_db(backup.MUSIC_DB)[0]
    root = library_folder("Music", dlg)
    if not (name and root):
        dlg.ok(ADDON, "Kodi doesn't have a music library yet.")
        return 0
    prog, step = _progress("Looking for artist pictures...")
    done, failed = 0, []
    try:
        folders = dict((d.lower(), d) for d in _listdir_or_nothing(root)[0])
        artists = [a for a in musicart.read_artists(_db_path(name)) if a["name"].lower() in folders]
        for i, artist in enumerate(artists):
            if step(i, len(artists), artist["name"]):
                break
            where = join(root, folders[artist["name"].lower()]) + "/"
            art = musicart.artist_art_files(_listdir_or_nothing(where)[1])
            if art:
                try:
                    missing._rpc("AudioLibrary.SetArtistDetails", {"artistid": artist["id"],
                                                                   "art": dict((k, where + v) for k, v in art.items())})
                    done += 1
                except Exception as e:
                    log("set artist art: %s: %s" % (artist["name"], e))
                    failed.append(artist["name"])
    except Exception as e:
        log("set artist art: %s" % e)
        _close(prog)
        dlg.ok(ADDON, "Couldn't set artist art: %s\nNothing else was changed." % e)
        return done
    _close(prog)
    log("set artist art: %d set, %d failed" % (done, len(failed)))
    dlg.ok(ADDON, "Set art for %d artists.%s\n\nPut a picture in an artist's folder to use it, such as %sArtist\\artist.jpg "
           "and fanart.jpg, then run this again." % (done, " These failed: %s." % ", ".join(failed) if failed else "", friendly(root)))
    return done


set_artist_art = one_at_a_time(_set_artist_art)


TAG_BACKUPS = "Tag backups"


def _read_id3_head(path):
    """A file's whole ID3v2 tag, without reading its audio."""
    import id3write
    f = xbmcvfs.File(path)
    try:
        head = bytes(f.readBytes(10))
        size = id3write.tag_size(head)
        if not size:
            return b""
        f.seek(0, 0)
        return bytes(f.readBytes(size))
    finally:
        f.close()


def _track_info(path, name):
    """What Fix music tags needs to know about one MP3. {"unsupported": reason} if it can't be changed."""
    import id3write
    info = {"name": name, "path": path}
    try:
        tag = _read_id3_head(path)
        if tag:
            info["version"], frames = id3write.parse(tag)
            info["artist"] = " / ".join(id3write.text_values(frames, "TPE1" if info["version"] > 2 else "TP1"))
            info["album"] = "".join(id3write.text_values(frames, "TALB" if info["version"] > 2 else "TAL")[:1])
            info["albumartist"] = "".join(id3write.text_values(frames, "TPE2" if info["version"] > 2 else "TP2")[:1])
            info["artists"] = id3write.user_values(frames, "ARTISTS")
            info["date"] = next(("".join(id3write.text_values(frames, f)[:1]) for f in ("TDRC", "TYER", "TYE")
                                 if id3write.text_values(frames, f)), "")
        else:
            info["unsupported"] = "no ID3v2 tag"
    except id3write.Unsupported as e:
        info["unsupported"] = str(e)
    except Exception as e:
        info["unsupported"] = "couldn't read it (%s)" % e
    return info


MUSIC_TAG_CACHE = "music_tags.json"  # tags already read: a file that hasn't changed isn't read again


def _file_stamp(path):
    """The size and date of a file, to tell if it changed, or None if they can't be known."""
    try:
        st = xbmcvfs.Stat(path)
        size, when = st.st_size(), st.st_mtime()
        return [size, when] if size > 0 and when else None
    except Exception:
        return None


def _music_folders_under(root, path):
    """The folder names between the Music folder and a file that could name an artist."""
    import sortlib
    root_n, folder = _norm(ensure_slash(root)).rstrip("/") + "/", _norm(parent_of(path))
    if not folder.startswith(root_n):
        return []
    depth = len(folder[len(root_n):].split("/"))  # _norm lower-cases, so take the names from the real path
    parts = [p for p in re.split(r"[\\/]+", parent_of(path)) if p][-depth:]
    return [p for p in parts[:-1] if not sortlib.CATEGORY_FOLDER_RE.match(p)]


def _tag_key(path):
    """One file written with either slash is one entry in what's remembered."""
    return re.sub(r"[\\/]+", "/", path).lower()


def _plan_music_tags(root, step, quick=False, only=None, credits=()):
    """([(album, folder, plan, tracks)], [(file, why it's left)], stopped) for the MP3s under root, or just
    only ([(path, name)]) so a big library isn't listed. quick: trust what was saved about files already
    seen, without asking the drive about each one. credits: other artist credits, for consistent spelling."""
    import musicfix
    files = list(only or [])
    for p, n in (() if only else walk(root)):  # listing a drive's folders is the slow start, so show it moving
        if step(0, 0, "Finding your MP3s: %d so far" % len(files)):
            return [], [], True
        if split_name(n)[1].lower() == ".mp3" and not n.startswith("."):
            files.append((p, n))
    groups, left, stopped = {}, [], False
    cache_path = data_file(MUSIC_TAG_CACHE)
    known = load_cache(cache_path) if cache_path else {}
    fresh = dict(known) if only else {}  # a run over a few files keeps what's known about the others
    reused = 0
    for i, (path, name) in enumerate(files):
        if step(i, len(files), name):
            stopped = True
            break
        entry = known.get(_tag_key(path)) or {}
        if quick and entry:
            stamp, info = entry["stamp"], dict(entry["info"], path=path, name=name)
            reused += 1
        else:
            stamp = _file_stamp(path)
            if stamp and entry.get("stamp") == stamp:
                info = dict(entry["info"], path=path, name=name)
                reused += 1
            else:
                info = _track_info(path, name)
        if stamp and not info.get("unsupported"):
            fresh[_tag_key(path)] = {"stamp": stamp, "info": dict(info, path=path, name=name)}
        if info.get("unsupported"):
            left.append((name, info["unsupported"]))
        elif not info.get("album"):
            left.append((name, "no album tag"))
        else:
            groups.setdefault((parent_of(path), info["album"].lower()), []).append(info)
    if not stopped and cache_path:
        save_cache(cache_path, fresh, verify=False)
    log("tag fix: %s scan, %d files, %d read again" % ("quick" if quick else "full", len(files), len(files) - reused))
    every = [t for tracks in groups.values() for t in tracks]
    spellings = musicfix.spellings_from([t.get("artist", "") for t in every] + list(credits),
                                        sorted(set(f for t in every for f in _music_folders_under(root, t["path"]))))
    plans = []
    for (folder, _), tracks in sorted(groups.items()):
        names = _music_folders_under(root, tracks[0]["path"])
        plan = musicfix.plan_album(tracks, names, spellings)
        if plan["changes"]:
            plans.append((tracks[0]["album"], folder, plan, tracks))
    return plans, left, stopped


def _remember_tracks(paths):
    """Save what changed files now hold, so a quick scan doesn't rely on old information."""
    cache_path = data_file(MUSIC_TAG_CACHE)
    known = load_cache(cache_path)
    for path in paths:
        info, stamp = _track_info(path, base_of(path)), _file_stamp(path)
        if stamp and not info.get("unsupported"):
            known[_tag_key(path)] = {"stamp": stamp, "info": info}
        else:
            known.pop(_tag_key(path), None)
    save_cache(cache_path, known, verify=False)


def _write_checked(path, data):
    """Write data to path and read it back. On an Xbox nothing can be renamed, so a full copy is kept
    next to the file until the file itself is confirmed. Returns False and leaves that copy if not."""
    temp = join(parent_of(path), "." + base_of(path) + ".sortovia.tmp")
    if not (backup._write(temp, data) and backup._read(temp) == data):
        xbmcvfs.delete(temp)
        return False
    if not (backup._write(path, data) and backup._read(path) == data):
        log("tag fix: %s wasn't written correctly; a full copy is in %s" % (base_of(path), base_of(temp)))
        return False
    xbmcvfs.delete(temp)
    return True


def _apply_music_tags(root, chosen, step):
    """Write the chosen albums' tags, saving each file's old tag first. Returns (changed, failures, backup folder)."""
    import id3write
    base = backup.drive_dir(root) or root
    folder = "%s%s/%s/" % (base, TAG_BACKUPS, time.strftime("%Y-%m-%d %H%M"))
    xbmcvfs.mkdirs(folder)
    jobs = []
    for album, where, plan, tracks in chosen:
        by_name = dict((t["name"], t) for t in tracks)
        jobs += [(album, plan["album_artist"], c, by_name[c["name"]]) for c in plan["changes"]]
    manifest = []
    changed, failures, written = 0, [], []
    for i, (album, main, change, track) in enumerate(jobs):
        if step(i, len(jobs), track["name"]):
            break
        try:
            data = backup._read(track["path"])
            new, old = id3write.retag(data, artists=change["artists"], display=change["display"], album_artist=main,
                                      year=change.get("year"))
            if new[len(new) - (len(data) - len(old)):] != data[len(old):]:
                raise id3write.Unsupported("the audio wouldn't have stayed the same")
            kept = "%04d.id3" % i
            if not backup._write(folder + kept, old or b""):
                raise IOError("couldn't save its old tag")
            manifest.append({"path": track["path"], "tag": kept})
            if not backup._write(folder + "manifest.json", json.dumps(manifest).encode("utf-8")):
                raise IOError("couldn't save the undo list")
            if not _write_checked(track["path"], new):
                raise IOError("the new file didn't read back the same")
            changed += 1
            written.append(track["path"])
        except Exception as e:
            log("tag fix: %s: %s" % (track["name"], e))
            failures.append("%s: %s" % (track["name"], e))
    _remember_tracks(written)
    return changed, failures, folder


def _music_scanning():
    try:
        return bool(xbmc.getCondVisibility("Library.IsScanningMusic"))
    except AttributeError:  # not inside Kodi
        return False


def _run_music_job(start, limit=1800, is_scan=True):
    """Start a scan or clean with no dialog of Kodi's and wait for Kodi to say it finished. A scan also
    counts as finished once Kodi has stopped scanning, in case that message never comes.
    False if Kodi is closing or it took too long."""
    finished = []
    try:
        class Watch(xbmc.Monitor):
            def onScanFinished(self, library):
                if library == "music":
                    finished.append(library)

            def onCleanFinished(self, library):
                if library == "music":
                    finished.append(library)
        monitor = Watch()
    except AttributeError:  # not inside Kodi
        start()
        return True
    start()
    began = time.time()
    while not finished:
        if time.time() - began > limit or monitor.waitForAbort(0.5):
            return False
        if is_scan and time.time() - began > 5 and not _music_scanning():
            return True
    return True


def _song_count():
    """The songs Kodi can show. A scan can leave songs pointing at folder records that have gone: they
    still count as rows in the database, but they don't appear in the library."""
    import musicart
    name = backup.newest_db(backup.MUSIC_DB)[0]
    return musicart.status(_db_path(name))["linked"] if name else 0


def _save_music_copy():
    """Save the music library as it is now, ready for Restore the music library. False if it couldn't be."""
    dest = load_cache(data_file("last_settings.json")).get("dest") or ""
    letter = drive_letter.letter_of(dest)
    name, data = backup.newest_db(backup.MUSIC_DB)
    if not (letter and name and data):
        return False
    backup.save_letter_copy(backup.drive_dir(dest), letter, time.strftime("%Y-%m-%d %H%M"), backup.counts(), None, [(name, data)])
    return True


def _stages(heading):
    """One progress bar for a whole job. stage(start, end, text) gives a step for that stretch of the bar."""
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, heading)

    def stage(start, end, text):
        def step(done, total, name):
            percent = start + (end - start) * done / max(total, 1)
            prog.update(int(percent), "%s\n%s" % (text, name))
            return prog.iscanceled()
        return step
    return prog, stage


def _remove_duplicate_songs_now():
    import musicart
    name = backup.newest_db(backup.MUSIC_DB)[0]
    removed = musicart.remove_duplicates(_db_path(name)) if name else 0
    if removed:
        log("music update: removed %d duplicate songs" % removed)
    return removed


def _update_music_library(folders, stage, start=0):
    """Rescan only these folders, remove duplicates, clean, and set any missing art, on one progress bar.
    Stops before the clean if Kodi can show fewer songs. Returns a sentence saying how it went."""
    import missing
    import musicart
    span = 100 - start
    at = lambda share: start + span * share // 100
    stage(at(0), at(5), "Saving a copy of your music library...")(0, 1, "")
    if not _save_music_copy():
        log("music update: no copy saved")
        return "Couldn't save a copy of your music library first, so it wasn't updated."
    name = backup.newest_db(backup.MUSIC_DB)[0]
    known = musicart.song_folders(_db_path(name))
    # Kodi's own address for each folder: written any other way, it would add the songs again.
    targets = sorted(set(known.get(musicart._folder_key(f), f) for f in folders))
    before = _song_count()
    scan = stage(at(5), at(50), "Rescanning the changed albums...")
    for i, folder in enumerate(targets):
        scan(i, len(targets), base_of(folder.rstrip("\\/")))
        if not _run_music_job(lambda: missing._rpc("AudioLibrary.Scan", {"directory": folder, "showdialogs": False})):
            return "Kodi's rescan didn't finish, so nothing was removed from the library."
    stage(at(50), at(55), "Checking for duplicates...")(0, 1, "")
    removed = _remove_duplicate_songs_now()
    after = _song_count()
    log("music update: %d songs before, %d after, %d folders scanned, %d duplicates removed"
        % (before, after, len(targets), removed))
    if after < before:
        return ("Kodi can now show %d songs, down from %d, so Sortovia stopped before removing anything. Use Restore the "
                "music library in Library > Backups, pick the newest copy with %d songs, then restart Kodi."
                % (after, before, before))
    found = drive_letter.diagnose(drive_letter.library_files(_db_path(name), drive_letter.MUSIC_FILES), _listdir_or_nothing)
    if found["moved"] or found["lost"]:
        return "The rescan finished. Some music wasn't found on the drive, so the library wasn't cleaned."
    stage(at(55), at(75), "Cleaning the library...")(0, 1, "")
    if not _run_music_job(lambda: missing._rpc("AudioLibrary.Clean", {"showdialogs": False}), limit=180, is_scan=False):
        return "Kodi's clean-up didn't finish. Your %d songs are still there." % _song_count()
    changed = set(musicart._folder_key(f) for f in targets)  # checking every album's folder took most of a minute
    albums = [a for a in _music_albums(name) if not a["art"] or musicart._folder_key(a["folder"]) in changed]
    wanted = musicart.needs_art(albums, _listdir_or_nothing, stage(at(75), at(90), "Checking album art..."))
    done, failed = _apply_music_art(wanted, stage(at(90), 100, "Setting album art...")) if wanted else (0, [])
    log("music update: %d album covers set, %d failed" % (done, len(failed)))
    return "Your music library is up to date: %d songs. Set art for %d albums." % (_song_count(), done)




def _music_copies(letter):
    """[(folder, stamp, name of the music database, its song count)] saved for this drive letter, newest first."""
    import musicart
    temp = data_file("music-copy.db")
    out = []
    for folder, stamp, info in letter_backups():
        if info.get("drive") != letter or backup.MUSIC_DB not in (info.get("db") or ""):
            continue
        name = [n for n in info["db"].split(", ") if n.startswith(backup.MUSIC_DB)][0]
        try:
            with open(temp, "wb") as f:
                f.write(backup._read(folder + stamp + "/" + name))
            out.append((folder, stamp, name, musicart.status(temp)["song"]))
        except Exception as e:
            log("music restore: %s %s: %s" % (stamp, name, e))
    if os.path.exists(temp):
        os.remove(temp)
    return out


def _restore_music_library(dlg):
    """Put a saved copy of the music database back, through SQLite so it's safe while Kodi is open."""
    import sqlite3
    if _music_scanning():
        dlg.ok(ADDON, "Kodi is scanning your music. Try again when it has finished.")
        return False
    name = backup.newest_db(backup.MUSIC_DB)[0]
    dest = load_cache(data_file("last_settings.json")).get("dest") or ""
    letter = drive_letter.letter_of(dest)
    if not name or not letter:
        dlg.ok(ADDON, "Couldn't find Kodi's music library or your drive. Nothing was changed.")
        return False
    copies = _music_copies(letter)
    if not copies:
        dlg.ok(ADDON, "There are no saved copies of your music library for %s:. Nothing was changed." % letter)
        return False
    pick = dlg.select("Restore which copy? Now: %d songs" % _song_count(),
                      ["%s   %d songs" % (c[1], c[3]) for c in copies])
    if pick < 0:
        return False
    folder, stamp, kept, songs = copies[pick]
    if not dlg.yesno(ADDON, "Replace Kodi's music library (%d songs now) with the copy from %s (%d songs)?\n\nNo music files "
                     "change. Sortovia saves the current library first."
                     % (_song_count(), stamp, songs), nolabel="Cancel", yeslabel="Restore"):
        return False
    temp = data_file("music-restore.db")
    try:
        base = backup.drive_dir(dest)
        backup.save_letter_copy(base, letter, time.strftime("%Y-%m-%d %H%M"), backup.counts(), None,
                                [(name, backup._read("special://database/" + name))])
        with open(temp, "wb") as f:
            f.write(backup._read(folder + stamp + "/" + kept))
        source, target = sqlite3.connect(temp), sqlite3.connect(_db_path(name), timeout=30)
        try:
            source.backup(target)
        finally:
            target.close()
            source.close()
    except Exception as e:
        log("music restore failed: %s" % e)
        dlg.ok(ADDON, "Couldn't restore your music library: %s" % e)
        return False
    finally:
        if os.path.exists(temp):
            os.remove(temp)
    log("music restore: from %s, %d songs now" % (stamp, _song_count()))
    dlg.ok(ADDON, "Restored: %d songs. Restart Kodi so it shows them%s." % (
        _song_count(), ": press the Xbox button, highlight Kodi, press the Menu button and choose Quit, then open Kodi again"
        if my_device() == "xbox" else ""))
    return True


restore_music_library = one_at_a_time(_restore_music_library)


def _rescan_one_album(dlg):
    """Rescan the one folder picked, to bring tag changes into Kodi's library without a full scan."""
    name = backup.newest_db(backup.MUSIC_DB)[0]
    if not name:
        dlg.ok(ADDON, "Kodi doesn't have a music library yet.")
        return False
    try:
        folders = {}
        for album in _music_albums(name):
            folders.setdefault(album["folder"], album["name"])
    except Exception as e:
        log("rescan one album: %s" % e)
        dlg.ok(ADDON, "Couldn't read your music library: %s\nNothing was changed." % e)
        return False
    rows = sorted(folders.items(), key=lambda r: r[1].lower())
    pick = dlg.select("Rescan which album?", [r[1] for r in rows])
    if pick < 0:
        return False
    folder, album = rows[pick]
    log("rescan one album: %s" % album)
    prog, stage = _stages("Rescanning %s..." % album)
    try:
        summary = _update_music_library([folder], stage)
    except Exception as e:
        log("rescan one album: %s" % e)
        summary = "It didn't finish: %s" % e
    _close(prog)
    dlg.ok(ADDON, summary)
    return True


rescan_one_album = one_at_a_time(_rescan_one_album)




TAG_MODES = ("Quick scan: fix tags, then update and clean the library",
             "Full scan: check every file on the drive, then fix, update and clean",
             "Quick scan: show the changes first, then fix and update",
             "Quick scan: fix tags only")


def _songs_of_artist(songs, artist):
    import sortlib
    return [s for s in songs if sortlib._names(artist, s["artist"])]


def _pick_music(dlg, songs, heading="Fix tags by", told=None):
    """Choose by artist or by album. Returns the songs chosen, or [] if none. told, a list, gets "artist" or
    "album" added, for callers that work differently by album."""
    import musicfix
    how = dlg.select(heading, ["Artist", "Album"])
    if how < 0:
        return []
    if told is not None:
        told.append(("artist", "album")[how])
    if how == 0:
        names = {}
        for s in songs:
            for n in musicfix.split_artists(s["artist"]):
                names.setdefault(n.lower(), n)
        artists = sorted(names.values(), key=lambda n: n.lower())
        picks = dlg.multiselect("Which artists? Nothing changes until you choose OK.", artists)
        chosen = []
        for i in picks or []:
            chosen += _songs_of_artist(songs, artists[i])
        return chosen
    albums = {}
    for s in songs:
        albums.setdefault((s["album"].lower(), _tag_key(s["folder"])), []).append(s)
    rows = sorted(albums, key=lambda k: k)
    picks = dlg.multiselect("Which albums? Nothing changes until you choose OK.",
                            ["%s (%d tracks)" % (albums[k][0]["album"], len(albums[k])) for k in rows])
    return [s for i in picks or [] for s in albums[rows[i]]]


def _whole_folders(songs, chosen):
    """Every MP3 in the folders of the songs chosen, so an album stays consistent: [(path, name)]."""
    folders = set(_tag_key(s["folder"]) for s in chosen)
    seen, out = set(), []
    for s in songs:
        key = _tag_key(s["folder"] + s["file"])
        if _tag_key(s["folder"]) in folders and key not in seen:
            seen.add(key)
            out.append((s["folder"] + s["file"], s["file"]))
    return out


def _library_mp3s():
    """The MP3s Kodi lists, from its database, so nothing on the drive is touched. [] if there's no library."""
    import musicart
    name = backup.newest_db(backup.MUSIC_DB)[0]
    if not name:
        return []
    return [s for s in musicart.library_songs(_db_path(name)) if split_name(s["file"])[1].lower() == ".mp3"]


def _plan_rows_as_songs(plans):
    return [{"file": t["name"], "folder": where, "artist": t.get("artist", ""), "album": album}
            for album, where, _, tracks in plans for t in tracks]


def _fix_music_tags(dlg, artist=""):
    """Choose how, then by artist or album, then one progress bar for everything. Quick scans start from
    Kodi's own list and read only what was chosen, so library size doesn't matter. From the artist
    context menu: only that artist."""
    import musicfix
    mode = 0 if artist else dlg.select("Fix music tags (MP3)", list(TAG_MODES))
    if mode < 0:
        return 0
    root = library_folder("Music", dlg)
    if not root:
        return 0
    only = None
    credits = []
    picked_first = False
    try:
        songs = _library_mp3s() if mode != 1 else []
    except Exception as e:
        log("tag fix: Kodi's list couldn't be read: %s" % e)
        songs = []
    if songs:  # quick: choose now, and read only that
        credits = [s["artist"] for s in songs]
        chosen = _songs_of_artist(songs, artist) if artist else _pick_music(dlg, songs)
        if not chosen:
            if artist:
                dlg.ok(ADDON, "Kodi's library has no MP3s for %s." % artist)
            return 0
        only = _whole_folders(songs, chosen)
        picked_first = True
    prog, step = _progress("Checking your music tags...")
    try:
        plans, left, stopped = _plan_music_tags(root, step, quick=mode != 1, only=only, credits=credits)
    except Exception as e:
        log("tag fix: reading failed: %s" % e)
        _close(prog)
        dlg.ok(ADDON, "Couldn't read your music: %s\nNothing was changed." % e)
        return 0
    _close(prog)
    if stopped:
        dlg.ok(ADDON, "Stopped. Nothing was changed.")
        return 0
    if artist and not picked_first:
        plans = _plans_for_artist(plans, artist)
    text = "\n\n".join(musicfix.preview(album, plan) for album, _, plan, _ in plans)
    if left:
        text += "\n\nLeft as they are:\n" + "\n".join("   %s (%s)" % row for row in left)
    log("tag fix plan: %d albums to change, %d files left\n%s" % (len(plans), len(left), text))
    if not plans:
        dlg.ok(ADDON, "%s MP3 tags are already up to date.%s" % (
            "%s's" % artist if artist else "These" if picked_first else "Your",
            " %d files were left as they are." % len(left) if left else ""))
        return 0
    if mode == 2:
        dlg.textviewer("%s - planned tag changes" % ADDON, text)
    if artist:
        count = sum(len(row[2]["changes"]) for row in plans)
        if not setting_on("context_auto", False) and not dlg.yesno(
                ADDON, "Fix tags on %d tracks in %d albums for %s, then update and clean the library?\n\nTo skip this "
                "question, turn it off in Settings > Music." % (count, len(plans), artist), nolabel="Cancel", yeslabel="Fix them"):
            return 0
        final = plans
    elif picked_first:
        final = plans
    else:
        wanted = set(_tag_key(s["folder"]) for s in _pick_music(dlg, _plan_rows_as_songs(plans)))
        final = [row for row in plans if _tag_key(row[1]) in wanted]
    if not final:
        dlg.ok(ADDON, "Nothing was changed.")
        return 0
    tracks = sum(len(c[2]["changes"]) for c in final)
    update = mode != 3
    prog, stage = _stages("Fixing your music tags...")
    summary = ""
    changed, failures = 0, []
    try:
        changed, failures, folder = _apply_music_tags(root, final, stage(0, 50 if update else 100, "Writing tags..."))
        log("tag fix: %d changed, %d failed, undo data in %s" % (changed, len(failures), friendly(folder)))
        if update and changed:
            summary = _update_music_library([where for _, where, _, _ in final], stage, start=50)
    except Exception as e:
        log("tag fix: %s" % e)
        summary = "It didn't finish: %s" % e
    _close(prog)
    dlg.ok(ADDON, "Updated tags on %d of %d tracks.%s\n%s\nYou can undo the tags from File." % (
        changed, tracks, " %d failed: %s." % (len(failures), "; ".join(failures[:4])) if failures else "", summary))
    return changed


GENRE_FILE = "genre_settings.json"   # Discogs token, Last.fm key, the person's own genre list
GENRE_LOOKUPS = "genre_lookups.json"  # what the sources said, so a rerun doesn't ask again
ITUNES_WAIT = 3.1  # Apple asks for about 20 searches a minute
DEEZER_WAIT = 0.2
DISCOGS_WAIT = (1.1, 2.6)  # seconds between questions, with and without a token (60 and 25 a minute)
LASTFM_WAIT = 0.25
GENRE_ARTISTS = "genre_artists.json"  # the genres the person chose for each artist and track
GENRE_SAMPLE = 20  # tracks looked up per artist; enough to suggest genres without a long wait
GENRE_RETRIES = 3
GENRE_RETRY_WAIT = 10  # seconds


def _genre_fetch(url, headers):
    """Discogs and Last.fm explain refusals in the reply itself, so the reply is what's wanted. A dropped
    connection is tried again, so one blip doesn't end a long run."""
    try:
        from urllib.error import HTTPError, URLError
    except ImportError:
        from urllib2 import HTTPError, URLError
    for attempt in range(GENRE_RETRIES + 1):
        try:
            return _fetch_python(url, headers)
        except HTTPError as e:
            if e.code in (400, 403, 404):
                return e.read()
            raise
        except (URLError, OSError):
            if attempt == GENRE_RETRIES:
                raise
            time.sleep(GENRE_RETRY_WAIT)


def genre_settings(dlg):
    """Set the Discogs token, the Last.fm key and the genre list."""
    import genretag
    cfg = load_cache(data_file(GENRE_FILE))
    how = dlg.select("Music genres", [
        "Discogs token (discogs.com/settings/developers)%s" % (": saved" if cfg.get("discogs") else ""),
        "Last.fm API key (last.fm/api/account/create)%s" % (": saved" if cfg.get("lastfm") else ""),
        "My genre list (%d genres)" % len(cfg.get("genres") or genretag.DEFAULT_GENRES)])
    if how < 0:
        return
    if how == 2:
        typed = dlg.input("Your genres, with commas between them",
                          ", ".join(cfg.get("genres") or genretag.DEFAULT_GENRES))
        if typed:
            cfg["genres"] = genretag.parse_list(typed)
    else:
        name = ("discogs", "lastfm")[how]
        typed = dlg.input(("Discogs token", "Last.fm API key")[how], cfg.get(name, ""))
        if typed:
            cfg[name] = typed.strip()
    if typed:
        save_cache(data_file(GENRE_FILE), cfg)


GENRE_COLOURS = {"discogs": "FFF09A58", "lastfm": "FF49C6CD"}


def _choose_genres(dlg, title, subtitle, sources, picks, one_track, genres):
    """The genre screen, or Kodi's own list if it can't open. Returns (what happened, genres on)."""
    import genretag
    import screens
    names = genretag.order_genres(genres, sources)
    kinds = dict((g, genretag.kind_of(sources.get(g, ()))) for g in names)
    chosen = genretag.default_picks(names, sources) if picks is None else picks
    try:
        return screens.pick_genres(title, subtitle, names, kinds, chosen, one_track)
    except Exception as e:
        log("genre screen couldn't open: %s" % e)

    def row(g):
        if kinds[g] == "both":
            half = len(g) // 2
            return "[COLOR %s]%s[/COLOR][COLOR %s]%s[/COLOR]" % (GENRE_COLOURS["discogs"], g[:half], GENRE_COLOURS["lastfm"], g[half:])
        return "[COLOR %s]%s[/COLOR]" % (GENRE_COLOURS[kinds[g]], g) if kinds[g] in GENRE_COLOURS else g
    on = dlg.multiselect(title, [row(g) for g in names], preselect=[names.index(g) for g in chosen if g in names])
    return ("stop", list(chosen)) if on is None else ("save", [names[i] for i in on])


def _review_track(dlg, group, artist_tags, choice, genres):
    """Give one track its own genres, separate from its artist's."""
    import genretag
    rows = sorted(group["rows"], key=lambda r: r["title"].lower())
    pick = dlg.select("%s: which track?" % group["name"], [r["title"] for r in rows])
    if pick < 0:
        return
    row = rows[pick]
    slot = genretag.key(genretag.clean_title(row["title"]))
    tracks = choice.setdefault("tracks", {})
    featured = genretag.featured_genres([row], load_cache(data_file(GENRE_ARTISTS)))
    names, sources, start = genretag.screen_choices(
        [row], genretag.with_featured(genretag.track_suggestions(row, artist_tags, genres), featured), genres)
    picks = tracks.get(slot) or list(choice.get("genres", [])) + [g for g in featured if g not in choice.get("genres", [])]
    outcome, on = _choose_genres(dlg, "%s - %s" % (group["name"], row["title"]), "Only this track. Nothing is written to your files.",
                                 sources, picks or start, False, names)
    if outcome == "save":
        tracks[slot] = on


def _review_artists(dlg, rows, artist_tags, genres):
    """Show the genre screen for each artist. Each answer is kept at once, so stopping loses nothing."""
    import genretag
    path = data_file(GENRE_ARTISTS)
    choices = load_cache(path)
    groups = genretag.group_by_artist(rows)
    for i, group in enumerate(groups):
        names, sources, start = genretag.screen_choices(group["rows"], genretag.with_featured(
            genretag.artist_suggestions(group, artist_tags.get(group["key"], []), genres),
            genretag.featured_genres(group["rows"], choices)), genres)
        saved = choices.get(group["key"])
        choice = dict(saved, tracks=dict(saved.get("tracks", {}))) if saved else {"name": group["name"]}
        picks = saved.get("genres") if saved else start
        now = genretag.tagged_now(group["rows"])
        subtitle = "Artist %d of %d, %d tracks.%s" % (i + 1, len(groups), len(group["rows"]),
                                                      "  Tagged now: " + now if now else "  No genre tagged yet.")
        while True:
            outcome, picks = _choose_genres(dlg, group["name"], subtitle, sources, picks, True, names)
            if outcome != "track":
                break
            choice["genres"] = picks
            _review_track(dlg, group, artist_tags.get(group["key"], []), choice, genres)
        if outcome == "save":
            choice["genres"] = picks
            choices[group["key"]] = choice
            save_cache(path, choices)
        elif outcome == "stop":
            break
    return choices


def _audius_genres():
    """A lookup of the genre, mood and tags artists gave the track on Audius (free, no key)."""
    import genretag
    import remotemusic
    host = []

    def lookup(artist, title):
        if not host:
            host.append(remotemusic.audius_host(_genre_fetch))
        for track in remotemusic.audius_search(_genre_fetch, host[0], artist, title):
            if genretag._same_track(artist, title, track.get("artist"), track.get("title")):
                return track.get("tags") or []
        return []
    return lookup


def _review_tracks(dlg, rows, artist_tags, genres):
    """One genre screen per track, for albums: a crossover track can differ from its artist. Each track starts
    with what was chosen before, else its artist's genres plus its featured artists'. Each answer is kept at once."""
    import genretag
    path = data_file(GENRE_ARTISTS)
    choices = load_cache(path)
    ordered = sorted(rows, key=lambda r: (r.get("album", "").lower(), r["title"].lower()))
    for i, row in enumerate(ordered):
        main = genretag.main_artist(row["artist"])
        group_key = genretag.key(main)
        choice = choices.get(group_key) or {"name": main}
        tracks = dict(choice.get("tracks", {}))
        slot = genretag.key(genretag.clean_title(row["title"]))
        featured = genretag.featured_genres([row], choices)
        artist_picks = list(choice.get("genres", []))
        picks = tracks.get(slot) or artist_picks + [g for g in featured if g not in artist_picks]
        names, sources, start = genretag.screen_choices(
            [row], genretag.with_featured(genretag.track_suggestions(row, artist_tags.get(group_key, []), genres), featured), genres)
        now = genretag.tagged_now([row])
        subtitle = "Track %d of %d, by %s.%s" % (i + 1, len(ordered), row["artist"],
                                                 "  Tagged now: " + now if now else "  No genre tagged yet.")
        outcome, on = _choose_genres(dlg, row["title"], subtitle, sources, picks or start, False, names)
        if outcome == "save":
            tracks[slot] = on
            choice["tracks"] = tracks
            choices[group_key] = choice
            save_cache(path, choices)
        elif outcome == "stop":
            break
    return choices


def _genre_dry_run(dlg):
    """Look up the chosen tracks, let the person choose genres per artist, and show what each track would
    get. The choices are saved. No music file changes."""
    import genretag
    import musicart
    name = backup.newest_db(backup.MUSIC_DB)[0]
    songs = musicart.genre_songs(_db_path(name)) if name else []
    if not songs:
        dlg.ok(ADDON, "Kodi's music library is empty, so there are no tracks to look up.")
        return 0
    how = []
    chosen = _pick_music(dlg, songs, "Find genres by", how)
    if not chosen:
        return 0
    cfg = load_cache(data_file(GENRE_FILE))
    genres = cfg.get("genres") or genretag.DEFAULT_GENRES
    token, api_key = cfg.get("discogs", ""), cfg.get("lastfm", "")
    sources = [("discogs", lambda a, t: genretag.lookup_discogs(_genre_fetch, a, t, token),
                DISCOGS_WAIT[0 if token else 1])]
    if api_key:
        sources.append(("lastfm", lambda a, t: genretag.lookup_lastfm(_genre_fetch, a, t, api_key), LASTFM_WAIT))
    sources += [("itunes", lambda a, t: genretag.lookup_itunes(_genre_fetch, a, t), ITUNES_WAIT),
                ("deezer", lambda a, t: genretag.lookup_deezer(_genre_fetch, a, t), DEEZER_WAIT),
                ("audius", _audius_genres(), DEEZER_WAIT)]
    cache = load_cache(data_file(GENRE_LOOKUPS))
    sample, rest = genretag.sample_songs(chosen, GENRE_SAMPLE)
    prog, step = _progress("Looking up genres...")
    artist_tags = {}
    try:
        rows, failed, stopped = genretag.scan(sample, sources, genres, cache, step, time.sleep)
        if api_key and "lastfm" not in failed and not stopped:
            for group in genretag.group_by_artist(rows):
                slot = "lastfm_artist|%s" % group["key"]
                if slot not in cache:
                    try:
                        cache[slot] = genretag.lookup_lastfm_artist(_genre_fetch, group["name"], api_key)
                    except Exception as e:
                        failed["lastfm"] = str(e)
                        break
                    time.sleep(LASTFM_WAIT)
                artist_tags[group["key"]] = cache[slot]
        rows += genretag.scan(rest, [], genres, {}, lambda i, n, t: False, time.sleep)[0]
    finally:
        _close(prog)
    save_cache(data_file(GENRE_LOOKUPS), cache, False)
    asked = rows[:len(sample)]  # the rest were only matched against the choices, not looked up
    hits = genretag.found_counts(asked, [s for s, _, _ in sources])

    def used(source, words="used"):
        if source in failed:
            return "couldn't be used: %s" % failed[source]
        return "%s, found %d of %d tracks" % (words, hits.get(source, 0), len(asked))
    status = ["Discogs: %s" % used("discogs", "used" if token else "used without a token, so it's slower"),
              "Last.fm: %s" % (used("lastfm") if api_key else "no key yet, so nothing is suggested by both"),
              "Apple Music: %s" % used("itunes"),
              "Deezer: %s" % used("deezer"),
              "Audius: %s" % used("audius"),
              "Beatport: not connected"]
    if stopped:
        choices = {}
    elif how == ["album"]:
        choices = _review_tracks(dlg, rows, artist_tags, genres)  # albums: each track on its own
    else:
        choices = _review_artists(dlg, rows, artist_tags, genres)
    new = genretag.new_genres(choices, genres)
    if new and dlg.yesno(ADDON, "You chose %d genres that aren't on your list:\n%s\n\nAdd them to your list?"
                         % (len(new), ", ".join(new)), nolabel="Not now", yeslabel="Add them"):
        cfg["genres"] = list(genres) + new
        save_cache(data_file(GENRE_FILE), cfg)
    genretag.apply_choices(rows, choices)
    text = genretag.report(rows, status, stopped)
    log("genre dry run: %d tracks\n%s" % (len(rows), text))
    dlg.textviewer("%s - genres" % ADDON, text)
    if not stopped:
        _write_genres(dlg, rows)
    return len(rows)


def _write_genres(dlg, rows):
    """After the review: write the chosen genres into the MP3s, saving each file's old tag first so Undo the
    last music tag fix puts it back, then bring the change into Kodi's library."""
    import genretag
    import id3write
    chosen = [r for r in rows if r.get("keep") and r.get("path")]
    mp3 = [r for r in chosen if r["path"].lower().endswith(".mp3")]
    if not mp3:
        if chosen:
            dlg.ok(ADDON, "Only MP3 files can have their genres written for now, and none of these are MP3s. Your choices are saved.")
        return 0
    other = len(chosen) - len(mp3)
    if not dlg.yesno(ADDON, "Write the genres you chose into %d MP3 files?\n\nSeveral genres go in as one text, such as "
                     "\"Dubstep / Riddim\": Kodi lists each genre, and rekordbox and Serato show the whole text.%s\n\n"
                     "Each file's old tag is saved first: File > Undo the last music tag fix puts them back."
                     % (len(mp3), " %d files that aren't MP3s are left as they are." % other if other else ""),
                     nolabel="Not now", yeslabel="Write them"):
        return 0
    root = library_folder("Music", dlg)
    if not root:
        return 0
    folder = "%s%s/%s/" % (backup.drive_dir(root) or root, TAG_BACKUPS, time.strftime("%Y-%m-%d %H%M"))
    xbmcvfs.mkdirs(folder)
    manifest, failures, written = [], [], []
    prog, step = _progress("Writing genres...")
    try:
        for i, row in enumerate(mp3):
            if step(i, len(mp3), base_of(row["path"])):
                break
            try:
                data = backup._read(row["path"])
                new, old = id3write.retag(data, genre=genretag.format_tag(row["keep"]))
                if new[len(new) - (len(data) - len(old)):] != data[len(old):]:
                    raise id3write.Unsupported("the audio wouldn't have stayed the same")
                kept = "%04d.id3" % i
                if not backup._write(folder + kept, old or b""):
                    raise IOError("couldn't save its old tag")
                manifest.append({"path": row["path"], "tag": kept})
                if not backup._write(folder + "manifest.json", json.dumps(manifest).encode("utf-8")):
                    raise IOError("couldn't save the undo list")
                if not _write_checked(row["path"], new):
                    raise IOError("the new file didn't read back the same")
                written.append(row["path"])
            except Exception as e:
                log("genre write: %s: %s" % (base_of(row["path"]), e))
                failures.append("%s: %s" % (base_of(row["path"]), e))
    finally:
        _close(prog)
    _remember_tracks(written)
    summary = ""
    if written:
        prog, stage = _stages("Updating Kodi's library...")
        try:
            summary = _update_music_library(sorted(set(parent_of(p) for p in written)), stage)
        except Exception as e:
            log("genre write: update: %s" % e)
            summary = "Updating the library didn't finish: %s" % e
        _close(prog)
    dlg.ok(ADDON, "Wrote genres into %d of %d files.%s\n%s" % (len(written), len(mp3),
           " These failed: %s." % "; ".join(failures[:5]) if failures else "", summary))
    return len(written)


genre_dry_run = one_at_a_time(_genre_dry_run)


def _plans_for_artist(plans, artist):
    """The albums this artist leads or is credited on. "Band" also matches a credit like "Band/Guest"."""
    import sortlib
    return [row for row in plans if sortlib._names(artist, row[2]["album_artist"]) or
            any(sortlib._names(artist, t.get("artist", "")) for t in row[3])]


fix_music_tags = one_at_a_time(_fix_music_tags)


def _undo_music_tags(dlg):
    """Put back the old tags from the newest Fix music tags run."""
    import id3write
    root = library_folder("Music", dlg)
    if not root:
        return 0
    parent = "%s%s/" % (backup.drive_dir(root) or root, TAG_BACKUPS)
    stamps = sorted(backup.list_backups(parent), reverse=True)
    if not stamps:
        dlg.ok(ADDON, "There are no tag changes to undo.")
        return 0
    stamp = stamps[0][0]
    folder = parent + stamp + "/"
    try:
        manifest = json.loads(backup._read(folder + "manifest.json").decode("utf-8"))
    except Exception as e:
        dlg.ok(ADDON, "Couldn't read the undo list: %s\nNothing was changed." % e)
        return 0
    if not dlg.yesno(ADDON, "Put back the old tags on %d tracks, from %s?" % (len(manifest), stamp),
                     nolabel="Cancel", yeslabel="Undo"):
        return 0
    prog, step = _progress("Putting back your old tags...")
    done, failures = 0, []
    for i, row in enumerate(manifest):
        if step(i, len(manifest), base_of(row["path"])):
            break
        try:
            if not _write_checked(row["path"], id3write.put_back(backup._read(row["path"]), backup._read(folder + row["tag"]))):
                raise IOError("the file didn't read back the same")
            done += 1
        except Exception as e:
            log("tag undo: %s: %s" % (base_of(row["path"]), e))
            failures.append(base_of(row["path"]))
    _close(prog)
    if done == len(manifest):
        xbmcvfs.rmdir(folder, True)
    _remember_tracks([row["path"] for row in manifest])
    log("tag undo: %d of %d" % (done, len(manifest)))
    prog, stage = _stages("Updating Kodi's library...")
    try:
        summary = _update_music_library([parent_of(row["path"]) for row in manifest], stage)
    except Exception as e:
        log("tag undo: update: %s" % e)
        summary = "Updating the library didn't finish: %s" % e
    _close(prog)
    dlg.ok(ADDON, "Put back %d of %d tracks.%s\n%s" % (done, len(manifest),
           " These failed: %s." % ", ".join(failures[:8]) if failures else "", summary))
    return done


undo_music_tags = one_at_a_time(_undo_music_tags)


CLEAN_KINDS = ("TV", "Movies", "Music")


def clean_library(dlg):
    """Pick what to clean, then clean each in turn."""
    picks = dlg.multiselect("Clean which library?", list(CLEAN_KINDS))
    for i in picks or []:
        {"TV": clean_tv_library, "Movies": fix_wrong_movies, "Music": clean_music_library}[CLEAN_KINDS[i]](dlg)


def clean_music_library(dlg):
    """Kodi's own clean-up for songs whose files are gone, but never while the drive looks missing."""
    import missing
    name = backup.newest_db(backup.MUSIC_DB)[0]
    if not name:
        dlg.ok(ADDON, "Kodi doesn't have a music library yet, so there's nothing to clean.")
        return False
    try:
        found = drive_letter.diagnose(drive_letter.library_files(_db_path(name), drive_letter.MUSIC_FILES),
                                      _listdir_or_nothing)
    except Exception as e:
        log("music clean: check failed: %s" % e)
        dlg.ok(ADDON, "Couldn't check your music library: %s\nNothing was changed." % e)
        return False
    if found["moved"] or found["lost"]:
        dlg.ok(ADDON, "Your music on %s: wasn't found there, so cleaning now could remove it from the library. Check the "
               "drive is plugged in, or use Drive letter changed? Fix the library first. Nothing was changed."
               % ", ".join([old for old, _ in found["moved"]] + found["lost"]))
        return False
    if not dlg.yesno(ADDON, "Remove songs from Kodi's music library when their files are gone?\n\nThis never deletes "
                     "files. Kodi shows its own progress.", nolabel="Cancel", yeslabel="Clean"):
        return False
    try:
        missing._rpc("AudioLibrary.Clean", {"showdialogs": True})
    except Exception as e:
        log("Kodi's music library clean failed: %s" % e)
        dlg.ok(ADDON, "Kodi couldn't clean the music library: %s" % e)
        return False
    return True




def backup_menu(dlg):
    state = load_cache(data_file(BACKUP_STATE))
    while True:
        pick = dlg.select("Kodi library backup - last: %s" % (state.get("made") or "never"),
                          ["Back up the library now",
                           "How to put a backup back (restore)",
                           "List the backups on this device",
                           "Clean movie library (TV episodes listed as movies)",
                           "Clean TV library (entries that aren't TV episodes)",
                           "Full backup now (Kodi's own export - slow, done weekly by itself)"])
        if pick < 0:
            return
        if pick == 0:
            backup_now(background=True)
        elif pick == 5:
            backup_now(full=True, background=True)
        elif pick == 1:
            restore_backup(dlg)
        elif pick == 3:
            fix_wrong_movies(dlg)
            state = load_cache(data_file(BACKUP_STATE))
        elif pick == 4:
            clean_tv_library(dlg)
            state = load_cache(data_file(BACKUP_STATE))
        else:
            backups_list(dlg)


def _close(splash):
    if splash is not None:
        try:
            splash.close()
        except Exception:
            pass


# ---------- start-up ----------
# Opening Sortovia used to show nothing for 8-20 s while it sent the logs to
# the phone and then checked for updates, so it got clicked twice. Now a splash
# shows at once, both run at the same time, and a second click is ignored.
PROP_STARTING = "kodisorter.starting"  # time.time() while the splash is up
START_LOCK_SECS = 90  # a stale flag (a crash mid start-up) stops counting after this


def already_starting():
    """True if another Sortovia is on its start-up screen right now."""
    try:
        t = float(home().getProperty(PROP_STARTING) or 0)
    except ValueError:
        t = 0
    return 0 < time.time() - t < START_LOCK_SECS


def _send_start_logs():
    try:
        send_logs("start")
    except Exception as e:
        log("sending start-up logs failed: %s" % e)


def start_up(dlg):
    """Splash, logs to the phone (in the background) and the update check.
    Returns True if an update was installed (stop: the user reopens it)."""
    home().setProperty(PROP_STARTING, str(time.time()))
    try:
        splash = xbmcgui.DialogProgress()
        splash.create(ADDON, "Starting...")
        if (load_cache(data_file("phone.json")).get("dav") or {}).get("pass"):
            import threading
            threading.Thread(target=_send_start_logs).start()  # finishes on its own
        if not setting_on("check_updates"):
            _close(splash)
            return False
        return check_for_update(dlg, splash=splash)
    finally:
        home().clearProperty(PROP_STARTING)


def yesno_default_yes(dlg, msg, nolabel, yeslabel):
    """Yes/no with the YES button highlighted (Kodi 20+), plain yes/no on older Kodi."""
    try:
        return dlg.yesno(ADDON, msg, nolabel=nolabel, yeslabel=yeslabel,
                         defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
    except (TypeError, AttributeError):
        return dlg.yesno(ADDON, msg, nolabel=nolabel, yeslabel=yeslabel)


# ---------- main ----------
def _kodi_lang():
    try:
        return xbmc.getLanguage(xbmc.ISO_639_1)
    except Exception:
        return "en"


def standard_folder(okind):
    """Where a kind goes without a folder of its own, for the screen: "E:\\Movies".
    Based on the last run's destination; None before the first run."""
    dest = load_cache(data_file("last_settings.json")).get("dest")
    if not dest or "://" in dest and not dest.startswith("win-lib://"):
        return None
    try:
        root, names = resolve_dest(dest)
    except Exception:
        return None
    kind = ONBOARD_KIND.get(okind)
    return friendly(join(root, names.get(kind, kind))) if kind else None


def device_guess():
    import devices
    import socket
    head = ""
    try:  # the first lines of Kodi's log name the device model
        f = xbmcvfs.File("special://logpath/kodi.log")
        try:
            head = bytes(f.readBytes(16384)).decode("utf-8", "ignore")
        finally:
            f.close()
    except Exception:
        pass
    try:
        host = socket.gethostname()
    except Exception:
        host = ""
    try:
        return devices.detect(xbmc.getCondVisibility, xbmc.getInfoLabel, head, host)
    except Exception:
        return "other"


def my_device():
    ob = onboarding_state()
    return ob.device() if ob else device_guess()


def onboarding_state():
    """Welcome screen / what to sort / guide (onboarding.py). None if it can't load."""
    try:
        import onboarding
        me = xbmcaddon.Addon()
        return onboarding.Onboarding(xbmcvfs.translatePath(me.getAddonInfo("path")),
                                     data_file("onboarding.json"), me.getAddonInfo("version"), ADDON,
                                     checker=check_library_folder, std_folder=standard_folder,
                                     kodi_lang=_kodi_lang(), device_guess=device_guess(),
                                     set_phone=lambda on: set_setting("use_phone", on))
    except Exception as e:
        log("onboarding not available: %s" % e)
        return None


# ---------- can Kodi's library read an existing folder? ----------
REMEMBER = [True]  # False for a one-off run (reorganizing a library folder): keeps "Same as last time"
EP_TAG_RE = re.compile(r"(?<![a-z0-9])(?:s\d{1,2}[ ._\-]?e\d{1,3}|\d{1,2}x\d{2,3})(?![0-9])", re.I)


def _lib_key(path):
    """Library and folder paths compared the same way (Kodi writes win-lib://removable/E:\\TV/...)."""
    p = path or ""
    if re.search(r"%[0-9a-fA-F]{2}", p):
        try:
            from urllib.parse import unquote
        except ImportError:
            from urllib import unquote
        p = unquote(p)
    p = re.sub(r"^win-lib://[^/]*/", "", p).replace("\\", "/")
    return re.sub(r"/{2,}", "/", p).rstrip("/").lower()


def library_files(kind):
    """Files Kodi's video library already has (episodes or movies), as _lib_key()s."""
    import missing
    if kind == "TV":
        r = missing._rpc("VideoLibrary.GetEpisodes", {"properties": ["file"]}).get("episodes", [])
    else:
        r = missing._rpc("VideoLibrary.GetMovies", {"properties": ["file"]}).get("movies", [])
    return set(_lib_key(x.get("file")) for x in r if x.get("file"))


def video_sources():
    import missing
    r = missing._rpc("Files.GetSources", {"media": "video"}).get("sources", [])
    return [_lib_key(x.get("file")) for x in r if x.get("file")]


def folder_report(kind, folder, dest, lib, sources, progress=None):
    """What Kodi can make of the videos in an existing TV or Movies folder.
    Pure apart from listing the folder. kind: "TV" or "Movies"."""
    top = _lib_key(folder)
    rep = {"videos": 0, "in_library": 0, "readable": 0, "unreadable": [], "moves": 0, "move_bytes": 0,
           "is_source": any(top == s or top.startswith(s + "/") for s in sources)}
    for path, name in walk(folder):
        if split_name(name)[1] not in VIDEO or name.startswith(".") or "sample" in name.lower():
            continue
        size = size_of(path)
        if setting_on("skip_small") and 0 <= size < MIN_VIDEO_BYTES:
            continue
        rep["videos"] += 1
        if progress and rep["videos"] % 25 == 0:
            progress(rep["videos"], name)
        rel = [x for x in re.split(r"[\\/]", path[len(ensure_slash(folder)):]) if x]
        stem = split_name(name)[0]
        if _lib_key(path) in lib:
            rep["in_library"] += 1
        elif kind == "TV" and EP_TAG_RE.search(stem) and len(rel) >= 2:
            rep["readable"] += 1  # an episode number, inside a show folder
        elif kind == "Movies" and (split_year(stem)[1] or (len(rel) >= 2 and split_year(rel[-2])[1])):
            rep["readable"] += 1  # a year in the file or folder name
        else:
            rep["unreadable"].append("/".join(rel))
        target, k, _ = plan_for(path, name, dest)
        if target and not already_sorted(path, target):
            rep["moves"] += 1
            rep["move_bytes"] += max(size, 0)
    if rep["in_library"]:
        rep["is_source"] = True  # Kodi's library already has videos from here: it is scanned
    return rep


def check_library_folder(dlg, okind, folder):
    """After someone picks their own TV/Movies folder: tell them if Kodi's library
    can't read it, and offer to reorganize it. Returns True to reorganize."""
    kind = ONBOARD_KIND.get(okind)
    if kind not in ("TV", "Movies"):
        return False
    KIND_DIRS[kind] = folder
    DIR_CACHE.clear()
    dest = parent_of(folder)
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Checking %s - can Kodi's library read it?" % friendly(folder))
    try:
        try:
            lib, sources = library_files(kind), video_sources()
            log("video sources Kodi reports: %s" % ", ".join(sources) or "none")
        except Exception as e:
            log("library check: %s" % e)
            lib, sources = set(), []
        rep = folder_report(kind, folder, dest, lib, sources,
                            lambda n, name: prog.update(0, "Checking %s\n%d videos so far\n%s" % (friendly(folder), n, name)))
    finally:
        prog.close()
    log("library folder check %s: %s" % (friendly(folder), dict((k, v if not isinstance(v, list) else len(v))
                                                                for k, v in rep.items())))
    word = "episodes" if kind == "TV" else "movies"
    if not rep["videos"]:
        return False
    problems = []
    if not rep["is_source"]:
        problems.append("This folder isn't a Kodi video source yet, so the library never looks in it. "
                        "Add it: Videos > Files > Add videos, pick the folder, and set \"This directory contains\" to %s."
                        % ("TV shows" if kind == "TV" else "Movies"))
    elif not rep["in_library"] and rep["readable"]:
        problems.append("Kodi's library has none of these %s. The source may be set to the wrong type: Videos > Files > "
                        "highlight the folder > context menu > Set content > %s, then Update library."
                        % (word, "TV shows" if kind == "TV" else "Movies"))
    bad = rep["unreadable"]
    if bad:
        problems.append("%d of %d videos have names or folders Kodi can't read%s, e.g.:\n  %s" % (
            len(bad), rep["videos"], " (no episode number, or not inside a show folder)" if kind == "TV" else
            " (no year in the file or folder name)", "\n  ".join(bad[:4])))
    if not problems:
        dlg.ok(ADDON, "%s looks good: Kodi's library has %d of its %d %s and can read the rest."
               % (friendly(folder), rep["in_library"], rep["videos"], word))
        return False
    gb = rep["move_bytes"] / 1e9
    hours = rep["move_bytes"] / (30e6 * 3600)  # the Xbox copies, then deletes, at about 30 MB/s
    dlg.textviewer("%s - %s" % (ADDON, friendly(folder)), "\n\n".join(problems) + (
        "\n\nSortovia can reorganize this folder into Kodi-style folders (Show\\Season 01\\Show S01E02.mkv, "
        "Movie (Year)\\Movie (Year).mkv), inside the same folder. That would move or rename %d files (%.1f GB)%s. "
        "You see the full list before anything moves; files Sortovia can't place stay where they are." % (
            rep["moves"], gb, ", which can take about %.1f hours" % hours if hours >= 0.5 else "")
        if rep["moves"] else ""))
    if not rep["moves"]:
        return False
    return dlg.yesno(ADDON, "Reorganize %s into folders Kodi can recognize?\n(%d files, %.1f GB - a preview comes first)"
                     % (friendly(folder), rep["moves"], gb), nolabel="Leave it as it is", yeslabel="Reorganize")


def reorganize_folder(dlg, spath, okind, folder):
    """Sort an existing library folder in place, with safe choices: ask before replacing,
    no audio check, NFOs and subtitles left alone, only folders this run empties removed."""
    REMEMBER[0] = False
    try:
        run(dlg, spath, folder, parent_of(folder), ASK, False, 3, 3, 0, 1)
    finally:
        REMEMBER[0] = True


def youtube_menu(dlg, spath, last, only=None):
    """Search/queue YouTube downloads on the phone; optionally sort the finished ones."""
    import youtube

    def creds():
        return load_cache(data_file("phone.json")).get("dav") or {}

    def find_ip():
        return phone_address(dlg, ask=True, port=int(creds().get("port", 8080)))
    ypath = data_file("youtube.json")

    def saved_dest():
        """Where YouTube downloads are sorted: the drive picked once, else the last run's drive."""
        d = load_cache(ypath).get("dest") or last.get("dest") or ""
        return d if d and ("://" not in d or d.startswith("win-lib://")) else ""

    def tutorials_at(d):
        own = (onboarding_state().folders() if onboarding_state() else {}).get("TUTORIAL")
        return friendly(own or join(resolve_dest(d)[0], "Tutorials")) if (own or d) else ""

    def pick_dest():
        d = dlg.browse(0, "YouTube videos go to which drive? (e.g. E:)", "files")
        if d:
            y = load_cache(ypath)
            y["dest"] = d
            save_cache(ypath, y)
            toast("YouTube downloads will be sorted into %s from now on" % tutorials_at(d))
        return d
    youtube.REMEMBER = _yt_remember_search
    while True:
        what = youtube.menu(dlg, find_ip, creds, log,
                            dest_line=lambda: tutorials_at(saved_dest()) or "not chosen yet", only=only)
        if what == "details":
            d = saved_dest()
            if d or pick_dest():
                yt_details(dlg, saved_dest())
            if only is not None:
                return
            continue
        if what == "dest":
            pick_dest()
            if only is not None:
                return
            continue
        if what != "sort":
            return
        break
    c = creds()
    src = "dav://%s:%s@%s:%s/YouTube/" % (quote(c.get("user", "kodi"), ""), quote(c["pass"], ""),
                                           PHONE, c.get("port", "8080"))
    dest = saved_dest() or pick_dest()  # asked once; after that it goes straight there
    if not dest:
        return
    if pick_unrecognised(dlg, src) is None:
        return
    try:
        phone = youtube.Phone(find_ip(), c.get("user", "kodi"), c["pass"])
        _yt_save_meta(phone.call("/yt/meta").get("meta"))  # the details of new downloads come with them
    except Exception as e:
        log("youtube details: %s" % e)
    log("sorting YouTube downloads into %s" % tutorials_at(dest))
    # Same choices as the last run; YouTube downloads don't need the audio check.
    run(dlg, spath, src, dest, last.get("mode", ASK), last.get("delete_old", False), 3,
        last.get("nfo_mode", 3), last.get("sub_mode", 0), last.get("empty_mode", 1))


YT_META = "youtube-meta.json"    # {key: channel, upload date, link ...} of each YouTube video
YT_PICKS = "youtube-picks.json"  # {file name: [folder, subfolder]}: videos picked by hand to be sorted
YT_SEARCHES = "youtube-searches.json"  # {video key: [folders in Tutorials]}: from the search each video was found with


def _yt_remember_search(items, query):
    import sortlib
    import youtube
    folders = sortlib.search_folder(query)
    if not folders:
        return
    saved = load_cache(data_file(YT_SEARCHES))
    for it in items:
        k = youtube.meta_key(it.get("title") or "")
        if k:
            saved[k] = folders
    save_cache(data_file(YT_SEARCHES), saved)


def _search_parts(filename, parts):
    """A YouTube video found with a search: into the search's folder in Tutorials (or a folder there that means the
    same), unless it was already recognised as a program or a kind of music video."""
    import sortlib
    import youtube
    if parts is not None and not (parts[0] == "Tutorials" and len(parts) == 3 and parts[1] == "Other"):
        return parts
    folders = load_cache(data_file(YT_SEARCHES)).get(youtube.meta_key(filename))
    if not folders:
        return parts
    if len(folders) == 1:
        try:
            have = xbmcvfs.listdir(ensure_slash(kind_root("Tutorials", load_cache(data_file("last_settings.json")).get("dest") or "")))[0]
        except Exception:
            have = []
        folders = [sortlib.similar_folder(folders[0], have) or folders[0]]
    stem, ext = split_name(filename)
    return ("Tutorials",) + tuple(folders) + (safe(sortlib.plain_title(stem)) + ext,)


def _yt_phone(dlg):
    import youtube
    c = load_cache(data_file("phone.json")).get("dav") or {}
    if not c.get("pass"):
        return None
    ip = phone_address(dlg, ask=True, port=int(c.get("port", 8080)))
    return youtube.Phone(ip, c.get("user", "kodi"), c["pass"]) if ip else None


def _yt_save_meta(meta):
    import youtube
    idx = load_cache(data_file(YT_META))
    new = youtube.merge_meta(idx, meta)
    save_cache(data_file(YT_META), idx)
    return idx, new


def _yt_roots(dest):
    import sortlib
    own = (onboarding_state().folders() if onboarding_state() else {}).get("TUTORIAL")
    root = resolve_dest(dest)[0] if dest else ""
    return [r for r in (own or (root and join(root, "Tutorials")), root and join(root, sortlib.MUSIC_DJ),  # (1.56 put it here)
                        root and join(root, "YouTube videos")) if r]


def _yt_sorted_videos(dest):
    """[(folder, file)] of the videos sorted into Tutorials, Music and DJing and YouTube videos."""
    out = []

    def walk(folder, depth):
        try:
            dirs, files = xbmcvfs.listdir(ensure_slash(folder))
        except Exception:
            return
        out.extend((folder, f) for f in files if split_name(f)[1].lower() in VIDEO)
        if depth:
            for d in dirs:
                walk(join(folder, d), depth - 1)
    for r in _yt_roots(dest):
        walk(r, 2)
    return out


def _yt_write_nfos(dest, idx):
    """A .nfo next to each sorted video whose details are known, so a library set to local information shows them."""
    import youtube
    made = 0
    for folder, f in _yt_sorted_videos(dest):
        m = idx.get(youtube.meta_key(f))
        nfo = join(folder, split_name(f)[0] + ".nfo")
        if m and not xbmcvfs.exists(nfo):
            try:
                fh = xbmcvfs.File(nfo, "w")
                try:
                    fh.write(bytearray(youtube.nfo_xml(m, f).encode("utf-8")))
                finally:
                    fh.close()
                made += 1
            except Exception as e:
                log("couldn't write %s: %s" % (nfo, e))
    return made


def yt_details(dlg, dest):
    """Find the channel, upload date and link of every YouTube video already downloaded (on the phone or sorted),
    in the background with progress in the corner."""
    import threading
    import youtube
    phone = _yt_phone(dlg)
    if not phone:
        dlg.ok(ADDON, "Can't reach the phone. Start kodi-share in Termux and try again.")
        return
    names = [f for _, f in _yt_sorted_videos(dest)]

    def work():
        bar = CornerProgress("%s: YouTube video details" % ADDON)
        try:
            total = [0]

            def tick(r):
                total[0] = max(total[0], r.get("left", 0) + r.get("done", 0) + r.get("failed", 0))
                bar("%d left to look up" % r.get("left", 0), pct=int(100 * (total[0] - r.get("left", 0)) / max(1, total[0])))
            r = youtube.look_up_meta(phone, names, everything=True, progress=tick)
            idx, new = _yt_save_meta(r.get("meta"))
            nfos = _yt_write_nfos(dest, idx)
            log("youtube details: %d known, %d new, %d not found, %d .nfo written" % (len(idx), new, r.get("failed", 0), nfos))
            toast("YouTube details: %d videos known (%d new%s). Hold down a video and choose YouTube video (Sortovia)."
                  % (len(idx), new, ", %d not found on YouTube" % r["failed"] if r.get("failed") else ""), 8000)
        except Exception as e:
            log("youtube details failed: %s" % e)
            toast("Looking up the YouTube details failed: %s" % e, 6000)
        finally:
            bar.close()
    threading.Thread(target=work).start()
    toast("Looking up channels and upload dates on the phone - progress is in the top-right corner", 5000)


def pick_unrecognised(dlg, src):
    """Downloads that don't look like lessons or music: tick any to sort anyway, and say where.
    Returns None when the person cancelled."""
    import sortlib
    try:
        files = xbmcvfs.listdir(ensure_slash(src))[1]
    except Exception:
        return True
    picks = load_cache(data_file(YT_PICKS))
    left = [f for f in sorted(files) if split_name(f)[1].lower() in VIDEO and not f.startswith(".")
            and f not in picks and plan_name(f, "YouTube")[0] is None]
    while left:
        chosen = dlg.multiselect("%d video%s don't look like lessons or music. Tick any to sort anyway (the rest stay "
                                 "on the phone)" % (len(left), " doesn't" if len(left) == 1 else "s"),
                                 [sortlib.plain_title(f) for f in left])
        if chosen is None:
            return True
        if not chosen:
            return True
        where = dlg.select("Sort the %d ticked video%s into" % (len(chosen), "" if len(chosen) == 1 else "s"),
                           ["Tutorials (then choose the program)", "%s (then choose the kind)" % sortlib.MUSIC_DJ,
                            "YouTube videos (everything else)"])
        if where < 0:
            continue
        if where == 0:
            subjects = sorted(set(n for n, _ in sortlib.TUTORIAL_SUBJECTS)) + ["Other"]
            i = dlg.select("Which program are they about?", subjects + ["Type a name..."])
            if i < 0:
                continue
            sub = subjects[i] if i < len(subjects) else (dlg.input("Folder name inside Tutorials") or "").strip()
            pick = ["Tutorials", safe(sub)] if sub else None
        elif where == 1:
            kinds = [n for n, _ in sortlib.MUSIC_DJ_KINDS]
            i = dlg.select("What kind?", kinds)
            pick = ["Tutorials", sortlib.MUSIC_DJ, kinds[i]] if i >= 0 else None
        else:
            pick = ["YouTube videos"]
        if not pick:
            continue
        for i in chosen:
            picks[left[i]] = pick
        save_cache(data_file(YT_PICKS), picks)
        left = [f for j, f in enumerate(left) if j not in chosen]
    return True


def yt_video(dlg, path):
    """Hold down a sorted YouTube video: its channel and upload date, more from the channel, the rest of a series."""
    import youtube
    name = base_of(path)
    m = load_cache(data_file(YT_META)).get(youtube.meta_key(name))
    phone = None
    if not m:
        if not dlg.yesno(ADDON, "Sortovia doesn't know this video's YouTube details yet.\nLook them up now on the phone?",
                         nolabel="Cancel", yeslabel="Look up"):
            return
        phone = _yt_phone(dlg)
        if not phone:
            dlg.ok(ADDON, "Can't reach the phone. Start kodi-share in Termux and try again.")
            return
        prog = xbmcgui.DialogProgress()
        prog.create(ADDON, "Looking for this video on YouTube...")
        try:
            r = youtube.look_up_meta(phone, [name], progress=lambda r: not prog.iscanceled())
            m = _yt_save_meta(r.get("meta"))[0].get(youtube.meta_key(name))
        except Exception as e:
            log("youtube lookup: %s" % e)
            prog.close()
            dlg.ok(ADDON, "Couldn't look it up: %s" % e)
            return
        prog.close()
        if not m:
            dlg.ok(ADDON, "Couldn't find this video on YouTube by its name.")
            return

    class LazyPhone(object):
        def call(self, *a, **kw):
            p = phone or _yt_phone(dlg)
            if not p:
                raise RuntimeError("Can't reach the phone. Start kodi-share in Termux and try again.")
            return p.call(*a, **kw)
    youtube.video_menu(dlg, LazyPhone(), m, name)


def running_menu(dlg, status):
    """A move is going on in the background: keep going or stop it."""
    if True:
        send_logs("during-run")  # so a run that's still going can be followed
        flag = home().getProperty(PROP_STOP)
        if flag == STOP_NOW:
            dlg.ok(ADDON, "Already stopping (%s) - give it a few seconds." % status)
            return
        opts = ["Keep going",
                "Stop after this file (finish it first)",
                "Stop now (the half-copied file is removed, the original stays)"]
        if flag == STOP_AFTER:
            opts[0] = "Keep going (cancel the stop)"
            opts[1] = "Stop after this file - already chosen"
        pick = dlg.select("Sortovia is moving files (%s)" % status, opts)
        if pick == 0:
            home().clearProperty(PROP_STOP)
        elif pick == 1:
            home().setProperty(PROP_STOP, STOP_AFTER)
            toast("Will stop after this file. Open Sortovia later and choose Resume.")
        elif pick == 2:
            home().setProperty(PROP_STOP, STOP_NOW)
            toast("Stopping now. Open Sortovia later and choose Resume.")


PROP_OPENED = "kodisorter.opened"  # when the start-up checks last ran (this Kodi session)
PROP_REORG = "kodisorter.reorganize"
STARTUP_EVERY = 600  # seconds: reopening within 10 minutes skips the checks


def startup_due():
    try:
        t = float(home().getProperty(PROP_OPENED) or 0)
    except ValueError:
        t = 0
    return time.time() - t > STARTUP_EVERY


def startup_checks(dlg):
    """Opening Sortovia: update check, welcome screen, library backup check.
    Returns True if an update was installed (the person opens it again)."""
    home().setProperty(PROP_OPENED, str(time.time()))
    bring_settings_back()
    if ensure_picture_cache_folder():
        toast("Made Kodi's picture folder on your drive. Restart Kodi so it saves artwork there.", 6000)
    vault_unlock(dlg)
    if start_up(dlg):
        home().clearProperty(PROP_OPENED)
        return True
    ob = onboarding_state()
    set_language()
    if ob and not ob.first_run(dlg, returning=bool(load_cache(data_file("last_settings.json")).get("src"))):
        ob.whats_new(dlg)
        if not ob.state.get("device"):
            ob.choose_device(dlg)  # new question for people who saw the welcome screen before
        elif ob.state["device"] != ob.device_guess and not ob.state.get("device_rechecked"):
            ob.state["device_rechecked"] = True  # 1.37.0 took an Xbox for a Windows PC: ask once more
            ob.save()
            ob.state.pop("device")
            ob.choose_device(dlg)
    set_language()  # the welcome screen may have just set it
    if ob and ob.pop_reorganize():
        home().setProperty(PROP_REORG, json.dumps(list(ob.last_reorganize)))
    check_library_backup(dlg)
    return False


def script_main():
    """Run as a script (older shortcuts): just open the menu."""
    open_menu()


def new_sort(dlg, spath):
    """Choose folders and choices, then sort."""
    where = 0
    if setting_on("use_phone"):
        where = dlg.select("Where are the downloads?",
                           ["A folder or drive on this device",
                            "My phone over Wi-Fi - %s" % PHONE_KINDS["dav"]["label"],
                            "My phone over Wi-Fi - %s" % PHONE_KINDS["ftp"]["label"]])
    if where < 0:
        return
    if where == 0:
        src = dlg.browse(0, "Where are the downloads?", "files")
    else:
        src = phone_source(dlg, "dav" if where == 1 else "ftp")
    if not src:
        return
    dest = dlg.browse(0, "Where do they go? (library drive, e.g. E:)", "files")
    if not dest:
        return

    mode = dlg.select("If a better copy of something you already have is found:",
                      ["Ask me each time",
                       "Always keep the better copy (higher res, else bigger file)",
                       "Never replace existing files"])
    if mode < 0:
        return
    delete_old = False
    if mode != NEVER:
        delete_old = dlg.select("What to do with the copy being replaced?",
                                ["Move it to a _Replaced folder (safe - delete later)",
                                 "Delete it"]) == 1

    lang_mode = dlg.select("Video files with NO %s audio track (Settings > Your language to change):" % LN(),
                           ["Leave them on the source drive (skip)",
                            "Move them to a %s folder" % PREF[0].no_folder,
                            "Delete them",
                            "Don't check audio languages"])
    if lang_mode < 0:
        return
    import nfos
    nfo_mode = dlg.select("Release .nfo files (the text notes that come with downloads):", nfos.NFO_CHOICES)
    if nfo_mode < 0:
        return
    sub_mode = ask_sub_mode(dlg)
    if sub_mode < 0:
        return
    empty_mode = dlg.select("Leftovers in the source (empty folders, exact duplicates of library files):",
                            ["Delete them (recommended)",
                             "Keep them (only remove folders this run empties)"])
    if empty_mode < 0:
        return
    run(dlg, spath, src, dest, mode, delete_old, lang_mode, nfo_mode, sub_mode, empty_mode)


MODE_NAMES = ["ask each time", "always keep the better copy", "never replace"]
def lang_mode_name(mode):
    return ["skip no-%s files" % LN(), "move no-%s to %s" % (LN(), PREF[0].no_folder),
            "delete no-%s files" % LN(), "don't check audio"][mode]


def read_text(path):
    try:
        f = xbmcvfs.File(path)
        try:
            return f.read()
        finally:
            f.close()
    except Exception:
        return ""


def write_text(path, text):
    try:
        f = xbmcvfs.File(path, "w")
        f.write(text)
        f.close()
        return True
    except Exception as e:
        log("could not write %s: %s" % (path, e))
        return False


def gb(n):
    # same units as the scan report (1 GB = 1024 MB)
    return "%.1f GB" % (n / 1024.0 ** 3) if n >= 1024 ** 3 else "%d MB" % (n / 1024.0 ** 2)


def file_progress(prog, i, count, short):
    """Progress hook for one file: bar moves through this file's share of the
    run; text shows e.g. "3 of 41 - 1.2 of 3.7 GB - 24 MB/s - about 2 min left"."""
    start = [time.time()]
    last = [0.0]
    prev = [0]

    def hook(done, total):
        now = time.time()
        if done < prev[0]:  # a second copy for this item (old copy to _Replaced, then the new one)
            start[0] = now
        prev[0] = done
        if now - last[0] >= 1 or (total > 0 and done >= total):
            last[0] = now
            frac = float(done) / total if total > 0 else 0
            speed = done / max(now - start[0], 0.001)
            line = "%d of %d - %s" % (i + 1, count, gb(done))
            if total > 0:
                line += " of %s (%d%%)" % (gb(total), frac * 100)
            line += " - %.0f MB/s" % (speed / 1024.0 ** 2)
            if total > 0 and speed > 0 and done < total:
                left = (total - done) / speed
                line += " - about %s left" % ("%d min" % (left // 60 + 1) if left >= 60 else "%d s" % left)
            prog.update(int((i + min(frac, 1)) * 100 / count), "%s\n%s" % (line, short))
            home().setProperty(PROP_RUN, "%d of %d, %d%% of this file" % (i + 1, count, frac * 100))
        return prog.canceled(mid_file=True)
    return hook


def step_progress(prog, i, count, short):
    def show(text):
        prog.update(int((i + 1) * 100 / count) - 1 if count else 0,
                    "%d of %d - %s (%s)\n%s" % (i + 1, count, text, time.strftime("%H:%M:%S"), short))
        home().setProperty(PROP_RUN, "%d of %d, %s" % (i + 1, count, text))
    return show


def find_missing_episodes(dlg):
    """Compare the Kodi TV library with TVmaze; show, save and send the list."""
    import missing
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Reading your TV library...")

    def progress(i, n, title):
        prog.update(int(i * 100 / max(n, 1)), "Checking show %d of %d\n%s" % (i + 1, n, title))
    try:
        text, data = missing.find_missing(progress, prog.iscanceled)
    except Exception as e:
        prog.close()
        log("missing episodes failed: %s" % e)
        dlg.ok(ADDON, "Couldn't check for missing episodes:\n%s\n(This needs internet for TVmaze.)" % e)
        return
    prog.close()
    text = add_where_to_watch(dlg, data) or text
    write_text(data_file("missing_episodes.txt"), text)
    save_cache(data_file("missing_episodes.json"), data)
    log("missing episodes: %s" % text.splitlines()[1] if len(text.splitlines()) > 1 else "")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    sent = send_logs("missing", dlg, files=[
        ("missing-episodes-%s.txt" % stamp, text.encode("utf-8")),
        ("missing-episodes-%s.json" % stamp, json.dumps(data, indent=1).encode("utf-8"))])
    dlg.textviewer("%s - missing episodes (phone: %s)" % (ADDON, sent), text)


# ---------- where to watch (TMDb) ----------
WATCH_FILE = "watch.json"


def watch_settings(dlg, change=False):
    """Returns (TMDb, region, [service ids]) or None. Asks for whatever is missing
    (everything when change=True): API key, country, the services you pay for."""
    import whereto
    cfg = load_cache(data_file(WATCH_FILE))
    if change or not cfg.get("key"):
        if not cfg.get("key"):
            dlg.ok(ADDON, "Where-to-watch uses TMDb's free streaming data. It needs a free API key, once:\n"
                   "On your phone: themoviedb.org > sign up > Settings > API > create (personal use).\n"
                   "Then copy the 'API Key' and paste it in the next box (Kore's keyboard can paste).")
        key = dlg.input("TMDb API key", cfg.get("key", ""))
        if not key:
            return None
        tm = whereto.TMDb(key)
        try:
            regions = tm.regions()
        except Exception as e:
            dlg.ok(ADDON, "That key didn't work: %s" % e)
            return None
        cfg["key"] = key.strip()
        save_cache(data_file(WATCH_FILE), cfg)
    tm = whereto.TMDb(cfg["key"])
    if change or not cfg.get("region"):
        regions = tm.regions()
        if not regions:
            dlg.ok(ADDON, "TMDb didn't send the list of countries - check the internet connection and try again.")
            return None
        codes = [c for c, _ in regions]
        cur = cfg.get("region") or "US"
        pick = dlg.select("Your country", ["%s (%s)" % (n, c) for c, n in regions],
                          preselect=codes.index(cur) if cur in codes else -1)
        if pick < 0:
            return None
        cfg["region"] = codes[pick]
        save_cache(data_file(WATCH_FILE), cfg)
    if change or "services" not in cfg:
        services = tm.services(cfg["region"])
        ids = [i for i, _ in services]
        chosen = dlg.multiselect("Tick the streaming services you pay for",
                                 [n for _, n in services],
                                 preselect=[ids.index(i) for i in cfg.get("services", []) if i in ids])
        if chosen is None:
            if "services" not in cfg:
                return None
        else:
            cfg["services"] = [ids[i] for i in chosen]
            save_cache(data_file(WATCH_FILE), cfg)
    return tm, cfg["region"], cfg.get("services", [])


def add_where_to_watch(dlg, data):
    """Add where-to-watch lines to the missing-episodes data; returns the new report or None."""
    import missing
    import whereto
    if not any(r.get("missing") for r in data.get("shows", [])):
        return None
    if not load_cache(data_file(WATCH_FILE)).get("key"):
        if not dlg.yesno(ADDON, "Also show where each missing season is streaming (your services, free "
                         "services, buy/rent)? Needs a free TMDb key - takes a few minutes once.",
                         nolabel="Not now", yeslabel="Set it up"):
            return None
    setup = watch_settings(dlg)
    if not setup:
        return None
    tm, region, mine = setup
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Checking where to watch...")
    try:
        whereto.annotate(data, tm, region, mine, lambda i, n, t: prog.update(
            int(i * 100 / max(n, 1)), "Where to watch: show %d of %d\n%s" % (i + 1, n, t)))
    finally:
        prog.close()
    return missing.report(data, footer=whereto.ATTRIBUTION + " Country: %s." % region)


def where_to_watch_menu(dlg):
    import whereto
    pick = dlg.select("Where to watch", ["Search for a show",
                                         "Change my country / streaming services / TMDb key"])
    if pick == 1:
        if watch_settings(dlg, change=True):
            toast("Where-to-watch settings saved")
        return
    if pick != 0:
        return
    setup = watch_settings(dlg)
    if not setup:
        return
    tm, region, mine = setup
    title = dlg.input("Show name")
    if not title:
        return
    try:
        hits = tm.search(title)
    except Exception as e:
        dlg.ok(ADDON, "TMDb search failed: %s" % e)
        return
    if not hits:
        dlg.ok(ADDON, "No show called '%s' on TMDb." % title)
        return
    choice = dlg.select("Which one?", [label for _, label in hits]) if len(hits) > 1 else 0
    if choice < 0:
        return
    tid, label = hits[choice]
    s = whereto.summarize(tm.providers(tid, region), mine)
    lines = ["%s - where to watch (%s)" % (label, region), "",
             "On your services: " + (", ".join(s["yours"]) or "none"),
             "Free (with ads): " + (", ".join(s["free"]) or "none"),
             "Other subscriptions: " + (", ".join(s["other_subs"]) or "none"),
             "Buy / rent: " + (", ".join(s["buy_rent"]) or "none"), "",
             "Availability can differ by season; the missing-episodes list checks each season.",
             whereto.ATTRIBUTION]
    dlg.textviewer("%s - where to watch" % ADDON, "\n".join(lines))


TEXT_TYPES = ".nfo|.txt|.srt|.ass|.ssa|.sub|.vtt|.log|.md|.diz|.sfv|.xml|.json|.ini|.cfg"


def decode_text(raw):
    """NFO files are often old DOS text (box-drawing art), not UTF-8."""
    if raw[:3] == b"\xef\xbb\xbf":
        raw = raw[3:]
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16", "replace")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("cp437", "replace")


def view_text_file(dlg):
    """Pick an .nfo/.txt/subtitle file anywhere Kodi can reach and show it."""
    last = load_cache(data_file("last_settings.json")).get("src", "")
    start = "" if "@%s:" % PHONE in last else last
    while True:
        path = dlg.browse(1, "Pick a text / NFO file", "files", TEXT_TYPES, False, False, start)
        if not path or path == start:
            return
        try:
            f = xbmcvfs.File(path)
            try:
                raw = bytes(f.readBytes(2 * 1024 * 1024))
            finally:
                f.close()
        except Exception as e:
            dlg.ok(ADDON, "Couldn't open %s:\n%s" % (base_of(path), e))
            return
        dlg.textviewer(base_of(path), decode_text(raw) or "(empty file)")
        start = parent_of(path)


def nfo_audio_hint(path, arc, src, index, texts):
    """(eng, langs, nfo name) from the nearest release NFO, or None.
    Looks inside the same archive, then the video's folder, then folders above
    it - but never the source folder itself (NFOs there could be about anything)."""
    import nfos
    cands = list(index.get(("arc", arc), [])) if arc else []
    root = _norm(src)
    d = _norm(parent_of(arc or path))
    while not cands and d.startswith(root + "/"):
        cands = list(index.get(d, []))
        d = d.rsplit("/", 1)[0]
    found, used = set(), None
    for p in cands:
        if p not in texts:
            try:
                f = xbmcvfs.File(p)
                try:
                    texts[p] = decode_text(bytes(f.readBytes(256 * 1024)))
                finally:
                    f.close()
            except Exception:
                texts[p] = ""
        langs = nfos.audio_languages(texts[p])
        if langs:
            found.update(langs)
            used = used or base_of(p)
    if not found:
        return None
    langs = sorted(found)
    return (PREF[0].code in found), langs, used


# ---------- after a sort: release NFOs and empty folders ----------
def _under(path, folder):
    return _norm(path).startswith(_norm(folder) + "/")


def release_folder(path, src):
    """Nearest folder above path (below the source folder) named like a release
    ('Show.S01.1080p.x265-GRP', 'Movie.2019.1080p'), or None."""
    import nfos
    root = _norm(src)
    d = parent_of(path)
    while _norm(d).startswith(root + "/"):
        if nfos.looks_like_release(base_of(d)):
            return d
        d = parent_of(d)
    return None


def tidy_plan(src, leftovers, video_paths, will_move):
    """{release folder: [leftover files]} for release folders whose videos are
    all gone or about to be moved (so the release is finished)."""
    out, verdict = {}, {}
    vids = [(_norm(v), v) for v in video_paths]
    moving = set(_norm(p) for p in will_move)
    for path in leftovers:
        r = release_folder(path, src)
        if not r:
            continue
        key = _norm(r)
        if key not in verdict:
            verdict[key] = all(n in moving for n, _ in vids if n.startswith(key + "/"))
        if verdict[key]:
            out.setdefault(r, []).append(path)
    return out


JUNK_EXTS = (".nfo", ".sfv", ".md5", ".srr", ".url", ".txt")


def junk_plan(src, leftovers, done):
    """Release junk outside a finished release folder: files whose OWN name is a
    release name ('Ironclad_Ultimate_[1080p-AC3].sfv' next to sorted episodes,
    'Sams.Sandwiches.S15.1080p.x265-GAMMA.nfo' alone in a folder). {folder: [files]}"""
    import nfos
    taken = set(_norm(p) for files in done.values() for p in files)
    out = {}
    for path in leftovers:
        name = base_of(path)
        if _norm(path) in taken or split_name(name)[1] not in JUNK_EXTS:
            continue
        if name.lower().startswith("kodi_sorter_log") or not nfos.looks_like_release(split_name(name)[0]):
            continue
        out.setdefault(parent_of(path), []).append(path)
    return out


def _videos_left(folder):
    """Any real video (not a sample) or archive still under folder?"""
    try:
        for path, name in walk(folder):
            ext = split_name(name)[1]
            if ext in ARCHIVES or (ext in VIDEO and size_of(path) >= MIN_VIDEO_BYTES):
                return True
    except Exception:
        return True
    return False


def _guess_items(release, dest):
    """What a finished release folder was, from its name, if that's in the library
    (used to make a Kodi .nfo when no video moved in this run)."""
    name = base_of(release)
    parts, kind, _ = plan_name(name + ".mkv")
    if parts and kind == "movie":
        t = join(dest, *parts)
        if find_existing(t):
            return [{"kind": "MOVIE", "target": t, "arc": None, "src": ""}]
    m = re.match(r"^(?P<show>.+?)[ ._\-]+s(?P<s>\d{1,2})(?:e\d+)?(?:[ ._\-]|$)", name, re.I)
    if m:
        show, year = split_year(m.group("show"))
        show_dir = safe("%s (%s)" % (show, year) if year else show)
        if xbmcvfs.exists(ensure_slash(join(kind_root("TV", dest), show_dir))):
            return [{"kind": "TV", "arc": None, "src": "",
                     "target": join(kind_root("TV", dest), show_dir, "Season %02d" % int(m.group("s")), "x.mkv")}]
    return []


def tidy_after_sort(src, dest, moved, leftovers, video_paths, nfo_mode, report, extra_dirs=()):
    """Finished release folders (no real videos left in them): turn release NFOs
    into Kodi .nfo files (IMDb link) if asked, move the leftovers (.nfo, .sfv,
    .txt, screenshots, samples) to <src>/_Unpacked - or delete the NFOs, or leave
    everything - then delete folders left empty. Never the source folder itself."""
    import nfos
    plan = tidy_plan(src, leftovers, video_paths, [it["src"] for it in moved])
    junk = junk_plan(src, leftovers, plan)
    folders = dict((_norm(parent_of(it["src"])), parent_of(it["src"])) for it in moved if not it["arc"])
    folders.update((_norm(d), d) for d in extra_dirs)
    made = parked = deleted = 0
    jobs = [(r, f, True) for r, f in sorted(plan.items())] + [(r, f, False) for r, f in sorted(junk.items())]
    for release, files, check in jobs:
        if check and _videos_left(release):
            continue  # something is still there (skipped, failed or new): leave this release alone
        folders[_norm(release)] = release
        items = [it for it in moved if not it["arc"] and it["kind"] in ("TV", "MOVIE") and _under(it["src"], release)] \
            or _guess_items(release, dest)
        for path in files:
            folders[_norm(parent_of(path))] = parent_of(path)
            name = base_of(path)
            if split_name(name)[1] == ".nfo":
                text = ""
                try:
                    f = xbmcvfs.File(path)
                    try:
                        text = decode_text(bytes(f.readBytes(512 * 1024)))
                    finally:
                        f.close()
                except Exception:
                    pass
                if nfos.is_kodi_nfo(text):
                    stem = split_name(name)[0].lower()
                    mine = [it for it in items if it.get("src") and split_name(base_of(it["src"]))[0].lower() == stem]
                    if mine:
                        new = split_name(mine[0]["target"])[0] + ".nfo"
                        if not xbmcvfs.exists(new):
                            ok, how = move_file(path, new)
                            report.append("%s  %s -> %s  (Kodi .nfo moved with its video)" % (
                                "OK " if ok else "ERR", name, new.replace(dest, "")))
                            continue
                elif nfo_mode in nfos.MAKE_KODI:
                    its = items or ([] if check else _guess_items(split_name(path)[0], dest))
                    for line in make_kodi_nfos(nfos.imdb_ids(text), its, dest, nfos):
                        report.append("NFO  %s -> %s" % (name, line))
                        made += 1
                if nfo_mode == 1 and not nfos.is_kodi_nfo(text):
                    if xbmcvfs.delete(path):
                        deleted += 1
                    continue
            if nfo_mode == 3:
                continue
            rel = path[len(ensure_slash(src)):] if path.startswith(ensure_slash(src)) else name
            ok, how = move_file(path, join(src, "_Unpacked", *re.split(r"[\\/]", rel)))
            if ok:
                parked += 1
            else:
                report.append("ERR  %s  (leftover could not be moved: %s)" % (name, how))
    if parked or deleted:
        report.append("OK   release leftovers (.nfo, .sfv, .txt, screenshots, samples): %d moved to _Unpacked%s"
                      % (parked, ", %d .nfo deleted" % deleted if deleted else ""))
    removed = remove_empty_folders(src, list(folders.values()))
    if removed:
        report.append("OK   removed %d empty folder(s): %s" % (len(removed), ", ".join(removed[:10]) +
                                                            (" ..." if len(removed) > 10 else "")))
    log("tidy-up: %d release folder(s), %d Kodi .nfo made, %d leftovers moved, %d deleted, %d empty folder(s) removed"
        % (len(plan), made, parked, deleted, len(removed)))


class TitleFixer(object):
    """Movies named in another language ('Bolshoi Gorod 3 (2026)') get their
    English title from TMDb - only when TMDb confirms the name is one of that
    movie's alternative/translated titles. Needs the TMDb key from the
    where-to-watch setup; answers are cached in titles.json."""

    def __init__(self):
        self.ready, self.tm, self.cache, self.dirty = False, None, {}, False
        key = load_cache(data_file(WATCH_FILE)).get("key")
        if key and setting_on("rename_foreign"):
            import whereto
            self.tm = whereto.TMDb(key)
            self.cache = load_cache(data_file("titles.json"))
            self.ready = True

    def fix(self, target, dest):
        rel = rel_of(target, dest)
        if len(rel) < 3 or rel[0] != FOLDER_NAMES["Movies"]:
            return target
        folder = rel[1]
        m = re.match(r"^(.*) \((\d{4})\)$", folder)
        title, year = (m.group(1), m.group(2)) if m else (folder, None)
        key = "v2|%s|%s" % (title.lower(), year or "")
        if key not in self.cache:
            import whereto
            try:
                notes = []
                self.cache[key] = whereto.english_title(self.tm, title, year, notes, language=PREF[0].tmdb) or ""
                self.dirty = True
                if not self.cache[key] and notes:
                    log("title check %s: %s" % (folder, " | ".join(notes)[:600]))
            except Exception as e:
                log("Movie title lookup failed for %s: %s" % (folder, e))
                if "refused" in str(e):
                    self.ready = False  # bad key: stop asking
                return target
        eng = self.cache[key]
        if not eng:
            return target
        new_folder = safe("%s (%s)" % (eng, year) if year else eng)
        parts = [new_folder if i == 1 else p for i, p in enumerate(rel)]
        if parts[-1].lower().startswith(folder.lower()):
            parts[-1] = new_folder + parts[-1][len(folder):]
        log("Movie title: %s -> %s" % (folder, new_folder))
        return from_rel(parts, dest)

    def save(self):
        if self.dirty:
            save_cache(data_file("titles.json"), self.cache)


# ---------- subtitle languages to keep ----------
SUB_KEEP_ALL, SUB_DELETE, SUB_PARK = 0, 1, 2


def sub_keep_langs():
    return load_cache(data_file("subs.json")).get("keep") or [PREF[0].code]


def lang_name(code):
    import nfos
    words = nfos.LANG_WORDS.get(code)
    return words[0].capitalize() if words else code


def sub_lang_code(name, strict=True):
    """Language of a subtitle, or None. strict: only a Kodi-style code after a
    dot ('Show S01E01.en.forced.srt' -> 'en'), so a title like 'Fin (2021).srt'
    is never read as Finnish. Not strict (release names like '11_English.srt'):
    language words in the file name count too."""
    import nfos
    stem = split_name(base_of(name))[0]
    for part in stem.split(".")[1:]:
        if part.lower() in nfos.LANG_WORDS:
            return part.lower()
    if strict:
        return None
    suffix = nfos.sub_suffix(base_of(name))
    return suffix.split(".")[1] if suffix else None


def unwanted_sub(name, keep, strict=True):
    code = sub_lang_code(name, strict)
    return code is not None and code not in keep  # unknown language: kept


def ask_sub_mode(dlg):
    """The subtitle question in 'choose again'; -1 = cancelled."""
    import nfos
    while True:
        keep = sub_keep_langs()
        names = "/".join(lang_name(c) for c in keep)
        pick = dlg.select("Subtitles in other languages (keeping: %s):" % names,
                          ["Keep all subtitle languages",
                           "Keep only %s - DELETE the others (fastest)" % names,
                           "Keep only %s - move the others to _Unpacked" % names,
                           "Change which languages to keep..."])
        if pick != 3:
            return pick
        codes = list(nfos.LANG_WORDS)  # most common first (English, Japanese, Spanish, French ...)
        chosen = dlg.multiselect("Subtitle languages to keep", [lang_name(c) for c in codes],
                                 preselect=[codes.index(c) for c in keep if c in codes])
        if chosen:
            save_cache(data_file("subs.json"), {"keep": [codes[i] for i in chosen]})


def match_orphan_subs(orphans, groups, src, dest, progress=None):
    """Subtitles named only by language ('Subs/Show.S01E01.../11_English.srt'):
    find their video from the folder names - a video moved in this run, or one
    already in the library - and file them as <video folder>/Subs/<video>.en.srt.
    Yields (item, None) or (None, skip line)."""
    import nfos
    root = _norm(src)
    videos = [it for items in groups.values() for it in items if it["kind"] in ("TV", "MOVIE") and not it["arc"]]
    by_stem, by_dir = {}, {}
    for v in videos:
        by_stem.setdefault(split_name(base_of(v["src"]))[0].lower(), []).append(v)
        by_dir.setdefault(_norm(parent_of(v["src"])), []).append(v)
    planned = dict((dup_key(v["target"]), v["target"]) for v in videos)
    found_cache, used = {}, {}

    def video_for(path):
        d = parent_of(path)
        while _norm(d).startswith(root + "/"):
            nm = base_of(d)
            if nm.lower() not in nfos.SUBS_FOLDERS:
                if len(by_stem.get(nm.lower(), [])) == 1:
                    return by_stem[nm.lower()][0]["target"]
                parts, kind, _ = plan_name(nm + ".mkv")
                if parts and kind in ("tv", "movie"):
                    t = join(dest, *parts)
                    if dup_key(t) in planned:
                        return planned[dup_key(t)]
                    if t not in found_cache:
                        found_cache[t] = find_existing(t)
                    return found_cache[t]
                if len(by_dir.get(_norm(d), [])) == 1:
                    return by_dir[_norm(d)][0]["target"]
                if nfos.looks_like_release(nm):
                    return None  # e.g. a season pack's own Subs folder: can't tell which episode
            d = parent_of(d)
        return None

    for path, name, label in orphans:
        if progress:
            progress(path)
        vt = video_for(path)
        if not vt:
            yield None, "SKIP  %s  (subtitle - couldn't tell which video it belongs to)" % label, path
            continue
        stem, ext = split_name(base_of(vt))[0], split_name(name)[1]
        suffix = nfos.sub_suffix(name)
        key = (vt.lower(), suffix, ext)
        used[key] = used.get(key, 0) + 1
        if used[key] > 1:
            suffix += ".%d" % used[key]
        target = join(parent_of(vt), "Subs", stem + suffix + ext)
        yield {"src": path, "name": name, "target": target, "kind": "SUB", "note": "", "arc": None,
               "label": label, "res": None, "size": size_of(path), "eng": None, "langs": []}, None, path


def audio_fits(a, v_src, v_arc, v_name, v_target, src, dest):
    """Does the separate audio file `a` belong to this video? Same archive (or
    same folder / release folder), same episode number, and same show when the
    audio's own name has one."""
    if a["arc"] or v_arc:
        if a["arc"] != v_arc:
            return False
    elif not _under(a["src"], parent_of(v_src)):
        rf = release_folder(a["src"], src)
        if not rf or _norm(rf) != _norm(release_folder(v_src, src) or ""):
            return False
    if a["tag"] != episode_tag(v_name):
        return False
    return not a["show"] or a["show"] == show_of(v_target, dest).lower()


def match_audio_tracks(tracks, groups, src, dest):
    """Separate audio files -> <video folder>/<video name>.mka (Kodi plays it as
    an extra audio track) - only when the video has no English audio of its own,
    so a release that already has English doesn't get a second copy of it.
    Yields (item, None) or (None, skip line)."""
    videos = [it for items in groups.values() for it in items
              if it["kind"] in ("TV", "MOVIE") and split_name(it["name"])[1] in VIDEO]
    used = {}
    for a in tracks:
        targets = {}
        for v in videos:
            if audio_fits(a, v["src"], v["arc"], v["name"], v["target"], src, dest):
                targets[dup_key(v["target"])] = v["target"]
        if len(targets) != 1:
            yield None, "SKIP  %s  (separate audio track - %s)" % (
                a["label"], "matches more than one video" if targets else "couldn't tell which video it belongs to")
            continue
        vt = list(targets.values())[0]
        own = None
        for v in videos:
            if dup_key(v["target"]) != dup_key(vt):
                continue
            if "own_eng" not in v:
                v["own_eng"] = v["eng"]
            if v["own_eng"] is None:  # inside an archive, or audio check off: look now
                v["own_eng"] = english_status(v["src"], v["name"])[0]
            own = own or v["own_eng"]
        if own:
            yield None, "SKIP  %s  (separate audio track - the video already has %s audio)" % (a["label"], LN())
            continue
        stem, ext = split_name(a["name"])
        suffix = sub_lang(stem)[1]  # keeps a ".en" the file name already had
        key = (vt.lower(), suffix, ext.lower())
        used[key] = used.get(key, 0) + 1
        if used[key] > 1:
            suffix += ".%d" % used[key]
        target = join(parent_of(vt), split_name(base_of(vt))[0] + suffix + ext.lower())
        yield {"src": a["src"], "name": a["name"], "target": target, "kind": "AUDIO", "note": "", "arc": a["arc"],
               "label": a["label"], "res": None, "size": size_of(a["src"]), "eng": a["eng"],
               "langs": a["langs"]}, None


def read_text(path, limit=512 * 1024):
    try:
        f = xbmcvfs.File(path)
        try:
            return decode_text(bytes(f.readBytes(limit)))
        finally:
            f.close()
    except Exception:
        return ""


def make_quality_nfos(moved, src, dest, report):
    """Movies moved this run get a Kodi 'combination' .nfo: quality tags (codec,
    10-bit, source, bit rate) plus the IMDb/TMDb link, so Kodi still fetches all
    the normal info. Never touches an nfo Sortovia didn't write (or that was
    only a link). Kodi has no tags on TV episodes, so TV is left alone."""
    import nfos
    movies = [it for it in moved if it["kind"] == "MOVIE"]
    if not movies:
        return
    key = load_cache(data_file(WATCH_FILE)).get("key")
    tm = None
    if key:
        import whereto
        tm = whereto.TMDb(key)
    cache = load_cache(data_file("movie_ids.json"))
    dirty = made = 0
    for it in movies:
        target = it["target"]
        nfo = split_name(target)[0] + ".nfo"
        old = read_text(nfo) if xbmcvfs.exists(nfo) else ""
        if old and not nfos.our_url_nfo(old):
            continue  # a real Kodi nfo (or someone else's): leave it
        origin = it["arc"] or it["src"]
        names = [base_of(it["src"]), base_of(origin)]
        folder = parent_of(origin)
        text = ""
        if _norm(folder) != _norm(src):
            names.append(base_of(folder))
            try:
                files = xbmcvfs.listdir(ensure_slash(folder))[1]
            except Exception:
                files = []
            for f in files:
                if split_name(f)[1] == ".nfo":
                    t = read_text(join(folder, f))
                    if nfos.is_kodi_nfo(t):
                        text = None  # the release brought Kodi's own nfo: the tidy-up moves that one in
                        break
                    text = text or t
            if text is None:
                continue
        rel = rel_of(target, dest)
        m = re.match(r"^(.*) \((\d{4})\)$", rel[1] if len(rel) > 2 else "")
        title, year = (m.group(1), m.group(2)) if m else (split_name(rel[-1])[0], None)
        imdb = (nfos.imdb_ids(text) or nfos.imdb_ids(old) or [None])[0]
        tmdb = runtime = 0
        ck = "%s|%s" % (title.lower(), year or "")
        if tm and ck not in cache:
            try:
                import whereto
                cache[ck] = list(whereto.movie_ids(tm, title, year) or [])
                dirty = 1
            except Exception as e:
                log("TMDb lookup for quality tags failed (%s): %s" % (title, e))
        if cache.get(ck):
            tmdb, imdb2, runtime = cache[ck]
            imdb = imdb or imdb2
        url = nfos.url_nfo(imdb) if imdb else ("https://www.themoviedb.org/movie/%d\n" % tmdb if tmdb else "")
        short = nfo.replace(dest, "")
        if not url:
            report.append("NOTE  %s  (no quality tags: couldn't identify the movie on IMDb/TMDb%s)" % (
                short, "" if tm else " - add a TMDb key under Where to watch"))
            continue
        tags = nfos.quality_tags(names, text, size_of(target), runtime)
        if not tags:
            continue
        if write_text(nfo, nfos.quality_nfo(tags, url)):
            made += 1
            report.append("TAGS  %s: %s" % (short, ", ".join(tags)))
    if dirty:
        save_cache(data_file("movie_ids.json"), cache)
    log("quality tags: %d movie .nfo file(s) written" % made)


def make_kodi_nfos(ids, items, dest, nfos):
    """Write URL nfos for the moved items; returns report lines. Never overwrites."""
    out = []
    if not ids or not items:
        return out
    movies = [it for it in items if it["kind"] == "MOVIE"]
    shows = {}
    for it in items:
        if it["kind"] == "TV":
            shows[parent_of(parent_of(it["target"]))] = show_of(it["target"], dest)
    if len(movies) == 1 and len(ids) >= 1 and not shows:
        target = movies[0]["target"]
        nfo = split_name(target)[0] + ".nfo"
        if not xbmcvfs.exists(nfo) and write_text(nfo, nfos.url_nfo(ids[0])):
            out.append("%s (IMDb %s)" % (nfo.replace(dest, ""), ids[0]))
    for show_dir, show in shows.items():
        nfo = show_dir + "tvshow.nfo"
        if xbmcvfs.exists(nfo):
            continue
        for tid in ids[:3]:  # the show's own id, not an episode's: check with TVmaze
            try:
                import missing
                found = missing._get("%s/lookup/shows?imdb=%s" % (missing.TVMAZE, tid))
            except Exception:
                found = None
            if found and nfos.same_show(found.get("name"), re.sub(r"\s*\(\d{4}\)$", "", show)):
                if write_text(nfo, nfos.url_nfo(tid)):
                    out.append("%s (IMDb %s, %s)" % (nfo.replace(dest, ""), tid, found.get("name")))
                break
    return out


def remove_empty_folders(src, folders):
    """Delete folders (deepest first) that are now empty, then their parents if
    they become empty too - never the source folder itself. Real paths are
    kept as they are: the phone share is case-sensitive."""
    root = _norm(src)
    removed, seen = [], set()
    todo = list(folders)
    while todo:
        todo.sort(key=lambda d: _norm(d).count("/"))
        d = todo.pop()  # deepest first
        n = _norm(d)
        if n in seen or n == root or not n.startswith(root + "/"):
            continue
        seen.add(n)
        try:
            dirs, files = xbmcvfs.listdir(ensure_slash(d))
        except Exception:
            continue
        if dirs or files:
            continue
        if xbmcvfs.rmdir(ensure_slash(d)) or xbmcvfs.rmdir(d.rstrip("/\\")):
            removed.append(d[len(ensure_slash(src)):].rstrip("/\\") or d)
            todo.append(parent_of(d))
    return removed


def phone_music_copies(src, dest, plan):
    """[{"from": path in the phone's Download, "to": "Artist/Album/file"}] for music moved off the phone. Music
    packed in an archive has no file of its own on the phone, so it's {"read": its archive:// address, "to"}
    instead: the Xbox reads it out of the archive and sends it to the phone."""
    m = re.match(r"^dav://[^/]+/(.*)$", src or "")
    if not m:
        return []
    try:
        from urllib.parse import unquote
    except ImportError:
        from urllib import unquote
    out = []
    for it in plan:
        if it.get("kind") != "MUSIC" or not (it.get("arc") or it["src"]).startswith(src):
            continue
        parts = rel_of(it["target"], dest)
        if parts and parts[0] == FOLDER_NAMES["Music"]:
            parts = parts[1:]
        if it.get("arc"):
            out.append({"read": it["src"], "to": "/".join(parts)})
            continue
        rel = unquote(m.group(1) + it["src"][len(src):])
        out.append({"from": rel.replace("\\", "/"), "to": "/".join(parts)})
    return out


def _read_bytes(url):
    f = xbmcvfs.File(url)
    try:
        return bytes(f.readBytes())
    finally:
        f.close()


def _offer_phone_music_copy(dlg, src, dest, plan):
    """Music moving off the phone: ask to keep a copy in the phone's own Music folder too."""
    import youtube
    files = phone_music_copies(src, dest, plan)
    if not files or not dlg.yesno(ADDON, "%d music file%s from the phone. Also keep a copy in the phone's Music folder "
                                  "(Music/Artist/Album)?" % (len(files), "" if len(files) == 1 else "s"),
                                  nolabel="No", yeslabel="Copy too"):
        return
    c = load_cache(data_file("phone.json")).get("dav") or {}
    ip = phone_address(dlg, ask=False, port=int(c.get("port", 8080)))
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Copying %d file(s) into the phone's Music folder..." % len(files))
    plain = [f for f in files if "from" in f]
    packed = [f for f in files if "read" in f]
    try:
        if not ip:
            raise RuntimeError("can't find the phone")
        phone = youtube.Phone(ip, c.get("user", "kodi"), c.get("pass", ""))
        r = phone.call("/phone/music", {"files": plain}, timeout=900) if plain else {"copied": 0, "already": 0, "failed": []}
        for i, f in enumerate(packed):
            if "copied" not in r or prog.iscanceled():
                break
            prog.update(int(100 * i / len(packed)), "Sending %s to the phone..." % f["to"].rsplit("/", 1)[-1])
            one = phone.put("/phone/music/file", f["to"], _read_bytes(f["read"]), timeout=300)
            for k in ("copied", "already"):
                r[k] += one.get(k, 0)
            if one.get("error"):
                if not one.get("copied") and not one.get("already") and one.get("old"):
                    r = one  # an older phone helper: say so below
                    break
                r["failed"].append(f["to"])
    except Exception as e:
        r = {"error": str(e)}
    finally:
        prog.close()
    if "copied" not in r:
        dlg.ok(ADDON, "The phone didn't make the copies (%s). On the phone: kodi-share stop, then kodi-share, "
               "and try again. The music is still moved as usual." % (r.get("error") or "an older phone helper"))
        return
    log("phone music copy: %d copied, %d already there, %d failed" % (r["copied"], r["already"], len(r["failed"])))
    toast("Copied %d into the phone's Music folder%s" % (r["copied"], " (%d already there)" % r["already"] if r["already"] else ""), 5000)


def run(dlg, spath, src, dest, mode, delete_old, lang_mode, nfo_mode=0, sub_mode=0, empty_mode=0):
    log("RUN START  from=%s  to=%s  duplicates=%s%s  audio=%s  nfo=%d  subs=%d keep %s" % (
        masked(src), dest, MODE_NAMES[mode], " (delete replaced)" if delete_old else "", lang_mode_name(lang_mode),
        nfo_mode, sub_mode, ",".join(sub_keep_langs())))
    try:
        _run(dlg, spath, src, dest, mode, delete_old, lang_mode, nfo_mode, sub_mode, empty_mode)
        mark_park_folders(src, dest)
    except Exception:
        import traceback
        log_block("ERROR", traceback.format_exc())
        dlg.ok(ADDON, "Something went wrong - nothing more was moved.\n"
               "You can send the developer a report from Help > Send a problem report.")
    finally:
        COPY_HOOK[0] = STEP_HOOK[0] = None
        home().clearProperty(PROP_RUN)
        home().clearProperty(PROP_STOP)
    log("RUN END")
    send_logs("end")


def _run(dlg, spath, src, dest, mode, delete_old, lang_mode, nfo_mode=0, sub_mode=0, empty_mode=0):
    log("language: %s" % set_language().name)
    check_lang = lang_mode != 3
    session = {"src": src, "dest": dest, "mode": mode, "delete_old": delete_old,
               "lang_mode": lang_mode, "nfo_mode": nfo_mode, "sub_mode": sub_mode, "empty_mode": empty_mode, "stage": "scanning",
               "started": time.strftime("%Y-%m-%d %H:%M")}
    if not save_cache(spath, session):
        toast("Couldn't save progress - Resume won't be offered if this run is interrupted", 6000)
    if REMEMBER[0]:
        save_cache(data_file("last_settings.json"), dict((k, session[k]) for k in
                                                     ("src", "dest", "mode", "delete_old", "lang_mode", "nfo_mode", "sub_mode", "empty_mode")))
    src = resolve_src(src, dlg)
    root, names = resolve_dest(dest)
    FOLDER_NAMES.update(names)
    KIND_DIRS.clear()
    DIR_CACHE.clear()
    MUSIC_SEEN.clear()
    ob = onboarding_state()
    for k, path in ((ob.folders() if ob else {}) or {}).items():
        if ONBOARD_KIND.get(k):
            KIND_DIRS[ONBOARD_KIND[k]] = path
            log("%s go into your own folder %s" % (ONBOARD_KIND[k], friendly(path)))
    if _norm(root) != _norm(dest):
        log("destination %s is the %s folder: library root %s" % (dest, base_of(dest), root))
    dest = root  # everything below works from the library root
    where_to = "Destination: movies -> %s, TV -> %s, comics -> %s, tutorials -> %s, music -> %s" % tuple(
        friendly(kind_root(k, dest)) for k in ("Movies", "TV", "Comics", "Tutorials", "Music"))
    log(where_to)
    if "://" in src and src.split("://")[0] in ("dav", "davs", "ftp") and not phone_reachable(src):
        dlg.ok(ADDON, "Can't reach %s.\nOn the phone: start sharing (companion app, kodi-share or primitive ftpd), "
               "and keep this device on the phone's hotspot or the same Wi-Fi. Then open Sortovia and choose Resume."
               % masked(src))
        return

    busy = xbmcgui.DialogProgress()
    busy.create(ADDON, "Listing files...")
    groups, skipped, no_eng = {}, [], []
    files = []
    archive_fail = []
    archive_of = {}
    skip = sorted_folders(dest)
    if _norm(dest).startswith(_norm(src)):
        log("destination is inside the source: skipping its TV/Movies/Comics folders")
    release_nfos = []
    nfo_index = {}  # folder (or ("arc", archive)) -> .nfo paths, for the audio fallback
    src_tree = {}
    for path, name in walk(src, skip, src_tree):
        ext = split_name(name)[1]
        if ext == ".nfo":
            release_nfos.append(path)
            nfo_index.setdefault(_norm(parent_of(path)), []).append(path)
        if ext not in ARCHIVES:
            files.append((path, name, None))
            continue
        if LATER_VOLUME_RE.search(name):
            continue  # opened through the first volume
        busy.update(0, "Opening archive\n%s" % name)
        inner = open_archive(path)
        if inner is None:
            archive_fail.append(name)
            skipped.append("ARCHIVE  %s  (can't open - see note at the top)" % name)
            continue
        archive_of[path] = name
        for url, iname in inner:
            files.append((url, iname, path))
            if split_name(iname)[1] == ".nfo":
                nfo_index.setdefault(("arc", path), []).append(url)
    cpath = cache_file()
    cache = load_cache(cpath) if check_lang else {}
    seen, fresh, reused, by_name, other = set(), 0, 0, 0, 0
    in_place = [0]
    from_nfo = [0]
    nfo_texts = {}
    import nfos
    orphan_subs, leftovers, video_paths = [], [], []
    audio_tracks = []  # separate audio files (an English dub in .mka ...): go next to their video
    for path, name, arc in files:
        if split_name(name)[1].lower() not in AUDIO or name.startswith("."):
            continue
        busy.update(0, "Checking separate audio tracks\n%s" % name)
        label = ("%s  (inside %s)" % (name, archive_of[arc])) if arc else shown_path(path, src)
        eng, langs = english_status(path, name) if check_lang else (None, [])
        if eng is None and check_lang and PREF[0].hint_re.search(base_of(parent_of(path))):
            eng, langs = True, (langs or []) + ["folder name says %s" % LN()]
        if eng is False:
            skipped.append("SKIP  %s  (separate audio track, no %s: %s)" % (label, LN(), ", ".join(langs)))
            continue
        parts, pkind, _ = plan_name(split_name(name)[0] + ".mkv")
        audio_tracks.append({"src": path, "name": name, "arc": arc, "label": label, "eng": eng,
                             "langs": langs or [], "tag": episode_tag(name),
                             "show": parts[1].lower() if parts and pkind == "tv" else None})
    titles = TitleFixer()
    keep_langs = sub_keep_langs()
    movies_seen = [0]
    unwanted_subs = []
    renamed = {}  # old movie folder -> (old target, new target)

    def tally():
        # e.g. "39 already checked, 6 new, 29 skipped by name, 2 other"
        t = "%d already checked, %d new, %d skipped by name" % (reused, fresh, by_name)
        t += (", %d other" % other if other else "")
        t += ", %d already sorted" % in_place[0] if in_place[0] else ""
        return t + (", %d audio from .nfo" % from_nfo[0] if from_nfo[0] else "")
    spec_path = data_file("specials.json")
    specials = {"by_name": load_cache(spec_path), "used": {}, "titles": {}}
    ob = onboarding_state()
    wanted = ob.wanted() if ob else None
    if ob and len(wanted) < 5:
        log("sorting only: %s (Settings > What to sort)" % ob.wanted_line())
    for i, (path, name, arc) in enumerate(files):
        if busy.iscanceled():
            save_cache(cpath, cache)
            busy.close()
            xbmcgui.Dialog().ok(ADDON, "Scan stopped after %d of %d files.\nNothing was moved. "
                                "Files already checked are remembered. Open Sortovia "
                                "again and choose Resume to carry on." % (i, len(files)))
            return
        busy.update(int(i * 100 / max(len(files), 1)),
                    "Step 1 of 3 - scanning %d of %d\n%s\n%s" % (i + 1, len(files), tally(), name))
        if split_name(name)[1].lower() in AUDIO and not name.startswith("."):
            continue  # separate audio track: checked above, matched to its video below
        target, kind, note = plan_for(path, name, dest)
        if target is None and arc and "rename by hand" in kind:
            # Inner file named "movie.mkv" etc: try the archive's own name.
            target, kind, note = plan_for(path, split_name(archive_of[arc])[0] + split_name(name)[1], dest)
        label = ("%s  (inside %s)" % (name, archive_of[arc])) if arc else shown_path(path, src)
        if not arc and split_name(name)[1] in VIDEO:
            if kind.startswith("sample"):
                leftovers.append(path)  # sample clip: release leftover
            else:
                video_paths.append(path)
        if target is not None and wanted is not None and kind in ("TV", "MOVIE", "COMIC", "TUTORIAL", "MUSIC") \
                and kind not in wanted:
            skipped.append("SKIP  %s  (%s - not ticked in Settings > What to sort)" % (label if arc else name, kind.lower()))
            by_name += 1
            continue
        if target is None and not arc and split_name(name)[1] in SUBS:
            orphan_subs.append((path, name, label))  # "11_English.srt": matched to a video below
            continue
        if target is None:
            if not arc and split_name(name)[1] in nfos.LEFTOVER_EXTS:
                leftovers.append(path)
            skipped.append("SKIP  %s  (%s)" % (label if arc else name, kind))
            by_name += 1
            continue
        if kind == "MOVIE":
            movies_seen[0] += 1
        if kind == "MOVIE" and titles.ready:
            new_target = titles.fix(target, dest)
            if new_target != target:
                renamed[_norm(parent_of(path))] = (target, new_target)
                note = "%s title from TMDb (was %s)" % (LN(), rel_of(target, dest)[1])
                target = new_target
        if sub_mode and not arc and split_name(name)[1] in SUBS and \
                (unwanted_sub(target, keep_langs) or unwanted_sub(name, keep_langs)):
            unwanted_subs.append(path)
            continue
        if not arc and already_sorted(path, target):
            in_place[0] += 1  # sorting a library folder: this one is where it belongs
            continue
        if note in (SPECIAL_GUESS_NOTE, CREDITS_NOTE):
            target = renumber_special(target, name, specials)
        item = {"src": path, "name": name, "target": target, "kind": kind, "note": note, "arc": arc,
                "label": label, "res": resolution(name), "size": size_of(path), "eng": None, "langs": []}
        needs_audio = check_lang and not arc and kind in ("TV", "MOVIE") and split_name(name)[1] in VIDEO
        if not needs_audio:
            other += 1  # subtitles, comics, files inside archives, or audio check turned off
        if needs_audio:
            key = cache_key(path, item["size"])
            seen.add(key)
            if key in cache:
                item["eng"], item["langs"] = cache[key]
                reused += 1
            else:
                item["eng"], item["langs"] = english_status(path, name)
                cache[key] = [item["eng"], item["langs"]]
                fresh += 1
                if fresh % CACHE_SAVE_EVERY == 0:
                    save_cache(cpath, cache)
        if check_lang and kind in ("TV", "MOVIE") and split_name(name)[1] in VIDEO and item["eng"] is None:
            # The file couldn't tell (inside an archive, or untagged tracks): ask a release NFO.
            hint = nfo_audio_hint(path, arc, src, nfo_index, nfo_texts)
            if hint:
                eng, langs, nfo_name = hint
                if eng is False and lang_mode == 2:
                    log("%s: %s says no %s audio - not deleting on an NFO's word" % (name, nfo_name, LN()))
                else:
                    item["eng"], item["langs"] = eng, langs + ["from %s" % nfo_name]
                    from_nfo[0] += 1
        if check_lang and item["eng"] is not True and kind in ("TV", "MOVIE") and split_name(name)[1] in VIDEO:
            dub = next((a for a in audio_tracks if a["eng"] and
                        audio_fits(a, path, arc, name, target, src, dest)), None)
            if dub:  # Japanese-only video with an English dub next to it: it has English
                item["own_eng"] = item["eng"]  # the video's own answer, for match_audio_tracks
                item["eng"], item["langs"] = True, list(item["langs"]) + ["%s in %s" % (LN(), dub["name"])]
        if check_lang and item["eng"] is False:
            if lang_mode == 0:
                skipped.append("NO %s AUDIO  %s  (%s)" % (LN().upper(), label if arc else name, lang_note(False, item["langs"])))
            else:
                no_eng.append(item)
            continue
        groups.setdefault(dup_key(target), []).append(item)

    titles.save()
    for path in list(leftovers):
        ren = renamed.get(_norm(parent_of(path)))
        if not ren:
            continue
        old_stem, new_stem = split_name(base_of(ren[0]))[0], split_name(base_of(ren[1]))[0]
        name = base_of(path)
        if name.lower().startswith(old_stem.lower()):
            name = new_stem + name[len(old_stem):]
        t = join(parent_of(ren[1]), name)
        leftovers.remove(path)
        groups.setdefault(dup_key(t), []).append(
            {"src": path, "name": base_of(path), "target": t, "kind": "EXTRA", "note": "", "arc": None,
             "label": masked(path.replace(src, "")), "res": None, "size": size_of(path), "eng": None, "langs": []})
    def stage(title, i, n, detail=""):
        """Progress for the work after the file-by-file scan (was a frozen '1433 of 1433')."""
        if i % 10 == 0 or i == n - 1:
            busy.update(int(i * 100 / max(n, 1)), "%s: %d of %d\n%s\n%s" % (title, i + 1, n, tally(), detail))

    sub_n = [0]

    def sub_progress(path):
        stage("Step 2 of 3 - matching subtitles to their videos", sub_n[0], len(orphan_subs), base_of(path))
        sub_n[0] += 1
    for it, why, path in match_orphan_subs(orphan_subs, groups, src, dest, sub_progress):
        if sub_mode and (unwanted_sub(it["target"], keep_langs) if it else unwanted_sub(path, keep_langs, False)):
            unwanted_subs.append(path)  # other language: deleted / parked, matched or not
        elif it:
            groups.setdefault(dup_key(it["target"]), []).append(it)
            other += 1
        else:
            skipped.append(why)
            by_name += 1

    for it, why in match_audio_tracks(audio_tracks, groups, src, dest):
        if it:
            groups.setdefault(dup_key(it["target"]), []).append(it)
            other += 1
        else:
            skipped.append(why)
            by_name += 1

    save_cache(spec_path, specials["by_name"])
    if check_lang:
        # Scan finished: forget files that are gone from this source folder.
        cache = dict((k, v) for k, v in cache.items() if k in seen or not k.startswith(stable_path(src)))
        save_cache(cpath, cache)

    plan, replaces = [], 0
    identical = []
    for g, (key, items) in enumerate(list(groups.items())):
        if busy.iscanceled():
            busy.close()
            xbmcgui.Dialog().ok(ADDON, "Stopped before anything was moved. Files already checked are "
                                "remembered - open Sortovia again and choose Resume to carry on.")
            return
        stage("Step 3 of 3 - checking what's already in your library", g, len(groups), base_of(items[0]["target"]))
        # Within this run: keep the best copy, skip the rest.
        best = items[0]
        for it in items[1:]:
            if is_better(it["res"], it["size"], best["res"], best["size"], it["eng"], best["eng"]):
                best = it
        for it in items:
            if it is not best:
                skipped.append("DUPLICATE  %s  (%s) - keeping %s (%s)" % (
                    it["name"], describe(it["res"], it["size"]),
                    best["name"], describe(best["res"], best["size"])))
        # Against what's already at the destination.
        old = find_existing(best["target"])
        if old:
            best["old"] = old
            best["old_res"] = resolution(base_of(old))
            best["old_size"] = size_of(old)
            best["old_eng"] = english_status(old, base_of(old))[0] if check_lang else None
            better = best["kind"] in ("TV", "MOVIE") and is_better(
                best["res"], best["size"], best["old_res"], best["old_size"],
                best["eng"], best["old_eng"])
            if not better or mode == NEVER:
                same = (best["size"] or 0) > 0 and best["size"] == best["old_size"] and \
                    split_name(best["src"])[1] == split_name(old)[1] and _norm(best["src"]) != _norm(old)
                if same and empty_mode == 0 and not best["arc"]:
                    identical.append(best["src"])  # a leftover copy of what's already sorted
                    skipped.append("IDENTICAL  %s - exact copy of %s already in the library: will be removed" % (
                        best["label"], base_of(old)))
                    continue
                skipped.append("EXISTS  %s  (%s) - keeping existing %s (%s)" % (
                    best["name"], describe(best["res"], best["size"]),
                    base_of(old), describe(best["old_res"], best["old_size"])))
                continue
            replaces += 1
        plan.append(best)
    busy.close()

    lines = ["%d file(s) to move (%d would replace a lower-quality copy), %d with no %s audio, %d skipped."
             % (len(plan), replaces, len(no_eng), LN(), len(skipped)), where_to + "\n"]
    # Notes are grouped by show and listed once at the top, not under every episode.
    notes, unknown_audio = {}, {}
    for it in plan:
        show = show_of(it["target"], dest)
        if it["note"]:
            notes.setdefault(it["note"], set()).add(show)
        if check_lang and it["kind"] in ("TV", "MOVIE") and it["eng"] is not True:
            unknown_audio[show] = unknown_audio.get(show, 0) + 1
    unpacking = sorted(set(archive_of[it["arc"]] for it in plan if it["arc"]))
    will_move = [it["src"] for it in plan] + ([it["src"] for it in no_eng] if lang_mode in (1, 2) else [])
    tidy_preview = tidy_plan(src, leftovers, video_paths, will_move) if nfo_mode != 3 else {}
    junk_preview = junk_plan(src, leftovers, tidy_preview) if nfo_mode != 3 else {}
    tidy_n = sum(len(v) for v in tidy_preview.values()) + sum(len(v) for v in junk_preview.values())
    phone = src.split("://")[0] in ("dav", "davs", "ftp")
    empties = empty_folders(src_tree, src, keep_top=phone) if empty_mode == 0 else []
    no_titles = movies_seen[0] and not titles.ready
    if notes or unknown_audio or archive_fail or unpacking or tidy_n or unwanted_subs or empties or no_titles \
            or identical:
        lines.append("Notes:")
        if identical:
            lines.append("  %d exact duplicate(s) of files already in the library will be DELETED (listed "
                         "below as IDENTICAL)" % len(identical))
        if empties:
            lines.append("  %d empty folder(s) will be removed: %s" % (len(empties), ", ".join(
                friendly(f[len(ensure_slash(src)):]) for f in empties[:8]) + (" ..." if len(empties) > 8 else "")))
        if no_titles:
            lines.append("  movie titles were NOT checked for other languages (e.g. a Polish title): "
                         "no TMDb key yet - choose 'Set up the TMDb key' in the menu")
        if unwanted_subs:
            lines.append("  %d subtitle file(s) not in %s will be %s" % (
                len(unwanted_subs), "/".join(lang_name(c) for c in keep_langs),
                "DELETED" if sub_mode == SUB_DELETE else "moved to _Unpacked"))
        if tidy_n:
            lines.append("  tidy-up: %d leftover file(s) (.nfo, .sfv, .txt, screenshots, samples) in %d finished "
                         "release folder(s) go to _Unpacked%s, then empty folders are removed: %s" % (
                             tidy_n, len(tidy_preview) + len(junk_preview),
                             " (release .nfo files deleted)" if nfo_mode == 1 else "",
                             ", ".join(sorted(base_of(r) for r in list(tidy_preview) + list(junk_preview))[:8]) +
                             (" ..." if len(tidy_preview) + len(junk_preview) > 8 else "")))
        if unpacking:
            lines.append("  will unpack videos from %d archive(s), each archive is then moved to an "
                         "_Unpacked folder if the drive allows it, else left where it is: %s" % (len(unpacking), ", ".join(unpacking)))
        if archive_fail:
            lines.append("  " + ARCHIVE_HELP)
        for note, shows in sorted(notes.items()):
            lines.append("  %s: %s" % (note, ", ".join(sorted(shows))))
        if unknown_audio:
            lines.append("  audio language unknown, moved anyway to be safe: %s" % ", ".join(
                "%s (%d)" % (k, v) for k, v in sorted(unknown_audio.items())))
        lines.append("")
    for it in plan:
        tag = "REPLACE" if it.get("old") else it["kind"]
        lines.append("[%s] %s\n    -> %s" % (tag, it["label"], it["target"].replace(dest, "")))
        if it.get("old"):
            lines.append("    new: %s   vs   existing: %s" % (
                describe(it["res"], it["size"]), describe(it["old_res"], it["old_size"])))
    if no_eng:
        verb = "MOVE to %s" % PREF[0].no_folder if lang_mode == 1 else "DELETE"
        lines.append("\n--- No %s audio: will %s ---" % (LN(), verb))
        for it in no_eng:
            lines.append("%s  (%s)" % (it["name"], lang_note(False, it["langs"])))
    if skipped:
        lines.append("\n--- Skipped (left where they are) ---")
        lines.extend(sorted(skipped))
    preview = "\n".join(lines)
    log_block("SCAN RESULT (%d files: %s)" % (len(files), tally()), preview)
    title = "%s - scan finished: %d files (%s)" % (ADDON, len(files), tally())
    tmdb_item = "Set up the TMDb key now to fix movie titles in other languages"
    if not plan and not no_eng and not tidy_n and not unwanted_subs and not empties and not identical:
        clear_session(spath)
        while True:
            opts = ["View the full list"] + ([tmdb_item] if no_titles else []) + ["Done"]
            pick = dlg.select(title + " - nothing to move", opts)
            if pick == 0:
                dlg.textviewer("%s - preview (nothing moved)" % ADDON, preview)
                continue
            if pick >= 0 and opts[pick] == tmdb_item and watch_settings(dlg):
                return _run(dlg, spath, session["src"], session["dest"], mode, delete_old, lang_mode,
                            nfo_mode, sub_mode, empty_mode)
            return
    what = "%d file(s)" % len(plan)
    if empties:
        what += " + remove %d empty folder(s)" % len(empties)
    if identical:
        what += " + delete %d duplicate(s)" % len(identical)
    if tidy_n:
        what += " + tidy %d leftover(s)" % tidy_n
    if unwanted_subs:
        what += " + %s %d foreign subtitle(s)" % ("delete" if sub_mode == SUB_DELETE else "park", len(unwanted_subs))
    if no_eng:
        what += " + %s %d with no %s audio" % (
            "move" if lang_mode == 1 else "DELETE", len(no_eng), LN())
    while True:
        choice = dlg.select(title, ["Move %s in the BACKGROUND - keep using Kodi" % what,
                                    "Move %s now, full screen" % what,
                                    "View the full list first (%d to move, %d skipped)" % (len(plan), len(skipped)),
                                    "Cancel - move nothing"] + ([tmdb_item] if no_titles else []))
        if choice == 4:
            if watch_settings(dlg):
                return _run(dlg, spath, session["src"], session["dest"], mode, delete_old, lang_mode,
                            nfo_mode, sub_mode, empty_mode)
            continue
        if choice == 2:
            dlg.textviewer("%s - preview (nothing moved yet)" % ADDON, preview)
            continue
        log("menu choice: %s" % {0: "move in background", 1: "move full screen", 2: "view list",
                                 3: "cancel"}.get(choice, "back"))
        if choice == 3:
            clear_session(spath)  # you chose not to move anything: nothing to resume
            return
        if choice not in (0, 1):
            return  # Back button: keep the run so it can be resumed
        break
    background = choice == 0
    _offer_phone_music_copy(dlg, src, dest, plan)

    def ask_replace(it):
        short = it["target"].replace(dest, "")
        return dlg.yesno(ADDON, "Replace existing copy?\n%s\nNew: %s\nExisting: %s" % (
            short, describe(it["res"], it["size"]), describe(it["old_res"], it["old_size"])),
            nolabel="Keep existing", yeslabel="Replace")

    if background and mode == ASK:
        # Ask every "replace?" question now, so nothing pops up while you watch.
        for it in plan:
            if it.get("old"):
                it["keep_old"] = not ask_replace(it)

    session["stage"] = "moving"
    save_cache(spath, session)

    home().clearProperty(PROP_STOP)
    home().setProperty(PROP_RUN, "starting")
    prog = Progress(background, ADDON, "Moving files...")
    if background:
        toast("Moving %d file(s) in the background. Open Sortovia again to stop." % len(plan), 6000)
    report, ok_count = [], 0
    moved_ok = []
    arc_ok, arc_count = {}, {}
    cancelled = False
    for i, it in enumerate(plan):
        if prog.canceled():
            cancelled = True
            report.append("STOPPED - remaining files untouched. Open Sortovia again and choose Resume.")
            break
        short = it["target"].replace(dest, "")
        home().setProperty(PROP_RUN, "%d of %d" % (i + 1, len(plan)))
        prog.update(int(i * 100 / len(plan)), "%d of %d\n%s" % (i + 1, len(plan), short))
        big = (it.get("size") or 0) >= MIN_VIDEO_BYTES
        COPY_HOOK[0] = file_progress(prog, i, len(plan), short) if big else None
        STEP_HOOK[0] = step_progress(prog, i, len(plan), short) if big else None
        # Remembered so Resume can remove a half copy. Not for replaces: the
        # target name may still hold the old copy, which must never be removed.
        # Small files (subtitles, .nfo) skip this: saving it twice per file was
        # most of their time, and move_file redoes a short leftover copy anyway.
        tracked = big and not it.get("old")
        if tracked:
            session["in_progress"] = {"src": it["src"], "dst": it["target"]}
            save_cache(spath, session, verify=False)
        if it.get("old"):
            if it.get("keep_old") or (mode == ASK and not background and not ask_replace(it)):
                report.append("KEPT  %s  (you chose to keep the existing copy)" % short)
                continue
            ok, how = replace_file(it["src"], it["target"], it["old"], dest, delete_old)
        else:
            ok, how = move_file(it["src"], it["target"], it.get("size"))
        ok_count += ok
        if ok:
            moved_ok.append(it)
        if it["arc"]:
            arc_ok[it["arc"]] = arc_ok.get(it["arc"], True) and ok
            arc_count[it["arc"]] = arc_count.get(it["arc"], 0) + 1
        COPY_HOOK[0] = STEP_HOOK[0] = None
        if tracked:
            session["in_progress"] = None  # finished (or failed safely): nothing half-done to clean up
            save_cache(spath, session, verify=False)
        stopped = how.startswith("stopped part way")
        report.append("%s  %s -> %s  (%s)" % ("OK " if ok else ("STOP" if stopped else "ERR"),
                                              it["label"], short, how))
        log(report[-1])
        if stopped:
            cancelled = True
            report.append("STOPPED - remaining files untouched. Open Sortovia again and choose Resume.")
            break
    for it in no_eng:
        if cancelled or prog.canceled():
            cancelled = True
            break
        if lang_mode == 1:
            nt = join(dest, PREF[0].no_folder, *rel_of(it["target"], dest))
            ok, how = move_file(it["src"], nt)
            how = ("moved to %s" % PREF[0].no_folder) if ok else how
        else:
            ok = xbmcvfs.delete(it["src"])
            how = "deleted" if ok else "delete failed"
        ok_count += bool(ok)
        report.append("%s  %s  (%s; %s)" % ("OK " if ok else "ERR", it["name"], lang_note(False, it["langs"]), how))
        log(report[-1])
    sub_dirs = []
    if identical and not cancelled:
        gone = 0
        for n, path in enumerate(identical):
            prog.update(int(n * 100 / len(identical)), "Removing exact duplicates: %d of %d" % (n + 1, len(identical)))
            if xbmcvfs.delete(path):
                gone += 1
                sub_dirs.append(parent_of(path))
        ok_count += gone
        report.append("OK   %d exact duplicate(s) of library files deleted%s" % (
            gone, "" if gone == len(identical) else ", %d failed" % (len(identical) - gone)))
        log(report[-1])
    if unwanted_subs and not cancelled:
        gone = failed = 0
        for n, path in enumerate(unwanted_subs):
            if n % 25 == 0:
                if prog.canceled():
                    cancelled = True
                    report.append("STOPPED while removing foreign subtitles - open Sortovia again to finish.")
                    break
                prog.update(int(n * 100 / len(unwanted_subs)), "Foreign subtitles: %d of %d" % (n + 1, len(unwanted_subs)))
            if sub_mode == SUB_DELETE:
                ok = xbmcvfs.delete(path)
            else:
                rel = path[len(ensure_slash(src)):] if path.startswith(ensure_slash(src)) else base_of(path)
                ok = move_file(path, join(src, "_Unpacked", *re.split(r"[\\/]", rel)), 0)[0]
            if ok:
                gone += 1
                sub_dirs.append(parent_of(path))
            else:
                failed += 1
        ok_count += gone
        report.append("OK   %d subtitle file(s) in other languages %s%s" % (
            gone, "deleted" if sub_mode == SUB_DELETE else "moved to _Unpacked",
            ", %d failed" % failed if failed else ""))
        log(report[-1])
    # Park archives only when every video planned from them was copied out OK.
    planned = {}
    for it in plan:
        if it["arc"]:
            planned[it["arc"]] = planned.get(it["arc"], 0) + 1
    for arc, n in planned.items():
        name = archive_of[arc]
        if arc_ok.get(arc) and arc_count.get(arc, 0) == n:
            parked = park_archive(arc)
            report.append("%s  %s  (%s)" % ("OK " if parked else "NOTE", name,
                          "archive moved to _Unpacked" if parked else "unpacked OK; archive left where it is - delete it when you're happy"))
        elif arc in arc_ok:
            report.append("NOTE  %s  (not every video came out OK - archive left where it is)" % name)
    if not cancelled:
        prog.update(100, "Finishing up: release .nfo files and empty folders")
        try:
            if nfo_mode == 4:  # nfos.QUALITY - before the tidy-up parks the release NFOs
                prog.update(100, "Writing quality tags for movies")
                make_quality_nfos(moved_ok, src, dest, report)
            tidy_after_sort(src, dest, moved_ok, leftovers, video_paths, nfo_mode, report, sub_dirs)
            convert_new_comics(moved_ok, prog, report)
            if empties:
                gone = 0
                for n, f in enumerate(empties):
                    if n % 10 == 0:
                        prog.update(int(n * 100 / len(empties)), "Removing empty folders: %d of %d" % (n + 1, len(empties)))
                    try:
                        d, fl = xbmcvfs.listdir(f)
                    except Exception:
                        continue
                    if not d and not fl and (xbmcvfs.rmdir(f) or xbmcvfs.rmdir(f.rstrip("/\\"))):
                        gone += 1
                ok_count += gone
                report.append("OK   removed %d of %d empty folder(s) found by the scan" % (gone, len(empties)))
                log(report[-1])
        except Exception as e:  # tidying must never spoil a finished sort
            log("tidy-up failed: %s" % e)
            report.append("NOTE  tidy-up of .nfo files / empty folders failed: %s" % e)
    prog.close()

    stamp = time.strftime("%Y-%m-%d %H:%M")
    total = len(plan) + len(no_eng) + len(unwanted_subs) + len(identical) + len(empties)
    text = "Sortovia run %s\n%d of %d actions done OK\n\n%s\n" % (stamp, ok_count, total, "\n".join(report))
    log_block("MOVE RESULT", text)
    write_text(join(dest, "kodi_sorter_log.txt"), text)
    write_text(data_file("last_report.txt"), text)
    done = "%s: %d of %d done OK." % ("Stopped" if cancelled else "Finished", ok_count, total)
    if background and xbmc.Player().isPlayingVideo():
        # Don't cover what you're watching: a note in the corner instead.
        toast(done + " Report: open Sortovia > View the report from the last move.", 10000)
    elif dlg.yesno(ADDON, done + "\nA log was saved as kodi_sorter_log.txt on the destination drive.",
                   nolabel="Close", yeslabel="View report"):
        dlg.textviewer("%s - done" % ADDON, text)
    if not cancelled:
        clear_session(spath)  # finished: nothing to resume next time
    if ok_count and any(it.get("kind") in ("TV", "MOVIE") for it in moved_ok):
        xbmc.executebuiltin("UpdateLibrary(video)")
    elif ok_count and not any(it.get("kind") == "MUSIC" for it in moved_ok):
        log("no library update: only tutorials/comics/leftovers changed (they aren't in Kodi's library)")
    if ok_count and any(it.get("kind") == "MUSIC" for it in moved_ok):
        xbmc.executebuiltin("UpdateLibrary(music)")


# ---------- the menu: categories in a Kodi folder list ----------
# Opening Sortovia runs script_main() (update check, welcome screen ...),
# which opens this list. Folders are categories; the other entries are
# actions, each run by do_action() in its own call.
PLUGIN = "plugin://%s/" % ADDON_ID


def open_menu():
    xbmc.executebuiltin("ActivateWindow(Programs,%s,return)" % PLUGIN)


def library_folder(kind, dlg=None):
    """The person's TV/Movies/Comics/Tutorials folder: their own one, else the standard
    folder on the last destination. With dlg, asks when neither is known."""
    ob = onboarding_state()
    key = {"TV": "TV", "Movies": "MOVIE", "Comics": "COMIC", "Tutorials": "TUTORIAL", "Music": "MUSIC"}[kind]
    own = ((ob.folders() if ob else {}) or {}).get(key)
    last = load_cache(data_file("last_settings.json"))
    folder = own or (last.get("dest") and join(resolve_dest(last["dest"])[0], FOLDER_NAMES.get(kind, kind)))
    if folder and xbmcvfs.exists(ensure_slash(folder)):
        return ensure_slash(folder)
    if dlg is not None:
        pick = dlg.browse(0, "Pick your %s folder" % kind, "files")
        return ensure_slash(pick) if pick else None
    return None


ORGANISE_KINDS = ("TV", "Movies", "Music", "Comics")


def organise_folders(dlg, spath):
    """Tick the folders to organise. Each shows its full list before anything moves."""
    picks = dlg.multiselect("Organise which folders?", list(ORGANISE_KINDS))
    for i in picks or []:
        if ORGANISE_KINDS[i] == "Comics":
            _comics(tidy_comics)(dlg, spath)
        else:
            tidy_library(dlg, spath, ORGANISE_KINDS[i])


def tidy_library(dlg, spath, kind):
    folder = library_folder(kind, dlg)
    if not folder:
        return
    if kind == "Music":
        if dlg.yesno(ADDON, "Organise %s?\nLoose songs go into Artist\\Album with a clear name. Songs already in folders "
                     "inside an artist's folder stay where they are. You see the full list first, and nothing is replaced "
                     "without asking." % friendly(folder),
                     nolabel="Cancel", yeslabel="Show me the list"):
            reorganize_folder(dlg, spath, kind, folder)
        return
    if dlg.yesno(ADDON, "Organise %s?\nEvery video is put into the folders Kodi expects (%s) with names Kodi can "
                 "read. You see the full list first, nothing is replaced without asking, and subtitles and NFOs "
                 "are left alone." % (friendly(folder), "Show\\Season 01" if kind == "TV" else "Movie (Year)"),
                 nolabel="Cancel", yeslabel="Show me the list"):
        reorganize_folder(dlg, spath, kind, folder)


def _item(label, plot, icon, menu=None, action=None):
    return {"label": label, "plot": plot, "icon": icon, "menu": menu, "action": action}


def menu_items(name):
    """The entries of one menu folder (pure apart from reading saved settings)."""
    last = load_cache(data_file("last_settings.json"))
    ob = onboarding_state()
    if name == "root":
        out = []
        status = home().getProperty(PROP_RUN)
        if status:
            out.append(_item("Moving files now (%s) - keep going or stop" % status,
                             "A sort is running in the background.", "DefaultIconInfo.png", action="running"))
        rd_status = home().getProperty(PROP_RD)
        rd_wait = home().getProperty(PROP_RD_WAIT)
        if rd_status:
            paused = bool(home().getProperty(PROP_RD_PAUSE))
            out.append(_item("Real-Debrid %s - %s" % ("paused" if paused else "downloading (%s)" % rd_status,
                                                       "carry on" if paused else "pause"),
                             "The half-done file is kept; it carries on from where it got to.", "DefaultNetwork.png",
                             action="rd_pause"))
            out.append(_item("Stop the Real-Debrid download", "Takes it and the ones queued behind it off the list; the "
                             "half-done file is removed. (Closing Kodi instead keeps it: it carries on next time.)",
                             "DefaultNetwork.png", action="rd_stop"))
        elif rd_wait:
            out.append(_item("Real-Debrid: %s - stop" % rd_wait, "It downloads by itself when ready. Select to stop "
                             "waiting; what's on Real-Debrid stays there.", "DefaultNetwork.png", action="rd_stop"))
        prev = load_cache(session_file())
        if prev.get("src") and prev.get("dest") and not status:
            out.append(_item("Resume the sort that didn't finish (%s)" % prev.get("started", "?"),
                             "From %s to %s, with the same choices." % (masked(prev["src"]), prev["dest"]),
                             "DefaultIconInfo.png", action="resume"))
        return out + [
            _item("Downloads", "Transfer and sort your downloads, YouTube and Real-Debrid.", "DefaultNetwork.png", menu="downloads"),
            _item("File", "Works on the files themselves: organise folders, fix music tags, comic tools, free up space.",
                  "DefaultFolder.png", menu="file"),
            _item("Library", "Works on what Kodi lists: clean, rescan, album art, backups.",
                  "DefaultTVShows.png", menu="library"),
            _item("Settings", "Every setting: updates, sorting, music, phone, privacy and movie data.",
                  "DefaultAddonService.png", action="settings"),
            _item("Help", "The guide, setup steps, version history and problem reports.",
                  "DefaultAddonHelper.png", menu="help")] + (
            [_item("Dev", "Testing tools. Not in public builds.", "DefaultIconInfo.png", menu="dev")] if devtools else [])
    if name == "downloads":
        return [_item("Transfer and sort", "Move downloads from a folder or your phone into TV, Movies, Comics, Tutorials "
                      "and Music.", "DefaultFolder.png", menu="sort"),
                _item("Download from YouTube", "Search YouTube here; your Android phone downloads, then they're sorted "
                      "into Tutorials. Needs the phone setup in the guide.", "DefaultAddonVideo.png", menu="youtube"),
                _item("Search torrents", "Many indexes at once, by category; Real-Debrid fetches what you tick, then it "
                      "downloads by itself.", "DefaultAddonsSearch.png", action="torrent_search"),
                _item("Downloads on the phone", "Torrents and Real-Debrid files downloading on the phone or here: which are "
                      "waiting for peers, downloading, queued or failed; pause, retry, and sort the finished ones.",
                      "DefaultNetwork.png", action="phone_torrents")] + [
            _item("Real-Debrid", "Optional, needs a premium account. Download what's in your account straight to "
                  "your library drive, then sort it.", "DefaultNetwork.png", menu="realdebrid")]
    if name == "dev" and devtools:
        return devtools.menu_items()
    if name == "sort":
        out = []
        if last.get("src") and last.get("dest"):
            out.append(_item("Same as last time: %s  ->  %s" % (masked(last["src"]), friendly(last["dest"])),
                             "The same folders and choices as the last sort.", "DefaultAddonsUpdates.png", action="same"))
        return out + [
            _item("Choose folders and choices", "Pick where the downloads are and where they go, then answer a "
                  "few questions. You see the full list before anything moves.", "DefaultFolder.png", action="new"),
            _item("View the report from the last move", "Every file that was moved or skipped, and why.",
                  "DefaultIconInfo.png", action="report")]
    if name == "youtube":
        return [
            _item("Search YouTube", "Search, then pick the videos to download (shows length, date and views).",
                  "DefaultAddonVideo.png", action="yt0"),
            _item("Type a YouTube link", "A video or a playlist.", "DefaultAddonVideo.png", action="yt1"),
            _item("Downloads", "Progress, pause and carry on, retry or remove.", "DefaultNetwork.png", action="yt2"),
            _item("Sort the finished downloads", "Put the downloaded videos into Tutorials.", "DefaultFolder.png",
                  action="yt3"),
            _item("Download quality", "Up to 4K, 1080p, 720p, 480p or sound only.", "DefaultAddonService.png",
                  action="yt6"),
            _item("Search results order", "Best match, newest, most viewed, longest or shortest.",
                  "DefaultAddonService.png", action="yt7"),
            _item("Where sorted videos go", "The drive or folder YouTube downloads are sorted into.",
                  "DefaultFolder.png", action="yt8"),
            _item("Cookies: how to set them up", "YouTube only allows downloads from a signed-in browser.",
                  "DefaultIconInfo.png", action="yt4"),
            _item("Import cookies now", "Pick up a new cookies.txt from the phone's Download folder.",
                  "DefaultAddonsUpdates.png", action="yt5"),
            _item("Look up channel and upload date", "For videos already downloaded: finds each one on YouTube.",
                  "DefaultIconInfo.png", action="yt9")]
    if name == "realdebrid":
        st = load_cache(data_file(RD_FILE))
        who = ("Account: %s%s" % (st.get("username") or "signed in",
                                  (" (premium until %s)" % st["premium_until"]) if st.get("premium_until") else "")
               if st.get("access_token") else "Sign in to Real-Debrid")
        return [
            _item(who, "With a code on your phone, or an API token.", "DefaultUser.png", action="rd_account"),
            _item("My releases", "Tick releases from the feeds you added. Real-Debrid fetches them, then they "
                  "download by themselves.", "DefaultNetwork.png", action="rd_releases"),
            _item("Add a feed", "The RSS address of your uploads on a tracker or site you use.",
                  "DefaultAddonsUpdates.png", action="rd_feed_add"),
            _item("Remove a feed", "Takes it off this list.", "DefaultAddonsUpdates.png", action="rd_feed_remove"),
            _item("My torrents", "What's in your Real-Debrid account. Pick one that's Ready, tick the files, "
                  "and they download to the drive.", "DefaultNetwork.png", action="rd_torrents"),
            _item("Search torrents", "Search many indexes at once, by category. Tick results: Real-Debrid fetches "
                  "them, then they download by themselves.", "DefaultAddonsSearch.png", action="torrent_search"),
            _item("Indexes and categories", "Turn indexes on or off, add Jackett, Prowlarr or a tracker's RSS, and "
                  "choose which indexes each category searches.", "DefaultAddonService.png", action="torrent_setup"),
            _item("Download on: %s" % ("this Xbox" if load_cache(data_file(RD_WHERE)).get("where") == "xbox" else "the phone"),
                  "Which device downloads the files Real-Debrid unlocks. You can also choose each time.",
                  "DefaultAddonService.png", action="rd_where"),
            _item("Download new torrents by themselves: %s" % ("on" if load_cache(data_file(RD_AUTO)).get("on") else "off"),
                  "Anything added to your account (from the phone, the website or another app) downloads as soon as "
                  "Real-Debrid has it.", "DefaultAddonsUpdates.png", action="rd_auto"),
            _item("Add a magnet link", "Real-Debrid fetches it, then it downloads by itself.",
                  "DefaultAddonsUpdates.png", action="rd_magnet"),
            _item("Unlock a file-host link", "A link from a file host Real-Debrid supports.",
                  "DefaultAddonsUpdates.png", action="rd_link"),
            _item("Get links from a web page", "A forum post, blog or release page: every Rapidgator, Nitroflare ... "
                  "link Real-Debrid can unlock on it. Tick them and they download.", "DefaultAddonsSearch.png", action="rd_grab"),
            _item("Couldn't get on Real-Debrid (%d)" % len(load_cache(data_file(RD_FAILED)).get("items") or []),
                  "Torrents Real-Debrid couldn't fetch: download them on the phone or another torrent client.",
                  "DefaultIconWarning.png", action="rd_failed"),
            _item("Recent downloads", "Files you unlocked before (on any device) - get them again.",
                  "DefaultIconInfo.png", action="rd_history"),
            _item("Sort the Real-Debrid downloads", "Put what's in Downloads\\Real-Debrid into your library, "
                  "with the same choices as your last sort.", "DefaultFolder.png", action="rd_sort")]
    if name == "file":
        pref = comics_pref()
        return [
            _item("Organise my folders", "Tick TV, Movies, Music or Comics. Each shows its full list before anything "
                  "moves. Music already in folders under an artist stays where it is.", "DefaultFolder.png", action="organise"),
            _item("Fix music tags (MP3)", "Updates MP3 tags to ID3v2.4, joins albums Kodi shows as several, and links "
                  "collaborations to each artist. Pick by artist or album. Files stay where they are.",
                  "DefaultMusicAlbums.png", action="music_tags"),
            _item("Undo the last music tag fix", "Puts back the old tags saved by Fix music tags.",
                  "DefaultMusicAlbums.png", action="music_tags_undo"),
            _item("Find genres", "Looks up tracks on Discogs, Last.fm, Apple Music, Deezer and Audius, then you choose each "
                  "artist's (or track's) genres. You see what each track would get, then choose whether to write them "
                  "into the files. Old tags are saved, so you can undo it.",
                  "DefaultMusicGenres.png", action="genre_dry_run"),
            _item("Convert .cbr comics to .cbz%s" % (" (%d left - carry on)" % len(comics_pending()[0])
                                                    if comics_pending()[0] else ""),
                  "A .cbz opens much faster in Kodi. Pick which ones; Cancel stops after the comic being done.",
                  "DefaultAddonPicture.png", action="comics_convert"),
            _item("Turn comic pages for a monitor on its side (now: %s)" % comics.turn_label(pref["turn"]),
                  "Try one comic first. Upright undoes it.", "DefaultAddonPicture.png", action="comics_turn"),
            _item("View a text / NFO file", "Reads old DOS-style NFO art correctly.", "DefaultIconInfo.png",
                  action="nfo"),
            _item("Free up space", "See what's using this device's storage and clear leftovers "
                  "(temporary files, old add-on downloads, backups that belong on the drive).", "DefaultAddonService.png",
                  action="free_space")]
    if name == "library":
        return [
            _item("Clean the library", "Pick TV, Movies or Music. Removes entries that are in the wrong place or whose "
                  "files are gone. Never deletes files.", "DefaultAddonService.png", action="clean_library"),
            _item("Rescan one album", "Brings one album's changes into Kodi's library without a full scan. Sortovia "
                  "saves a copy of the library first.", "DefaultMusicAlbums.png", action="music_rescan"),
            _item("Set album art from folders", "Uses the picture in an album's folder when Kodi shows no art, whatever "
                  "the picture is called. No files change.", "DefaultMusicAlbums.png", action="music_art_set"),
            _item("Set artist art from folders", "Uses a picture in the artist's own folder, such as Music\\Artist\\artist.jpg "
                  "and fanart.jpg, when Kodi shows none. No files change.", "DefaultMusicArtists.png", action="artist_art"),
            _item("Check music art", "Lists albums with no cover art and compares with your backup from before a drive "
                  "letter switch. Changes nothing.", "DefaultMusicAlbums.png", action="music_art"),
            _item("Play this music on your phone", "Lets the Sortovia phone app play and mix the songs in this "
                  "music library over Wi-Fi. Turns on Kodi's web server with your phone share's password.",
                  "DefaultMusicSongs.png", action="phone_music"),
            _item("Get tags from the phone", "Keys, tempos, energy and genres the Sortovia phone app worked out by listening "
                  "to this library's music, written into the MP3s. Old tags are saved so you can undo it.",
                  "DefaultMusicSongs.png", action="phone_tags"),
            _item("DJ and playlists", "Play a playlist in mixing order, see what mixes after a song, crossfade, and "
                  "make Kodi playlists from Spotify, Deezer or other playlists.", "DefaultMusicPlaylists.png", menu="dj"),
            _item("Find missing episodes", "Aired episodes you don't have, from seasons you have.",
                  "DefaultTVShows.png", action="missing"),
            _item("Where to watch a show", "Your services, free, or buy/rent (TMDb).", "DefaultTVShows.png",
                  action="wherewatch"),
            _item("Backups (last: %s)" % backup_line(), "Back up and restore the video and music libraries.",
                  "DefaultAddonsUpdates.png", menu="library_backups"),
            _item("Drive letter changed? Fix the library", "If your drive's letter changed (for example E: to D:), this "
                  "points your video and music libraries at the new one and keeps a backup for each letter. No files are moved.",
                  "DefaultHardDisk.png", action="drive_letter")]
    if name == "dj":
        return [
            _item("Play a playlist in mixing order", "Key order, build up or wind down: each song in a key that mixes "
                  "into the next, from the keys in the tags: the Sortovia phone app, Mixed In Key, rekordbox, Serato or "
                  "Traktor can write them.",
                  "DefaultMusicPlaylists.png", action="dj_order"),
            _item("What mixes after the song playing now", "Songs in your library in a key next to it and a close tempo. "
                  "Pick one to play next. Also there when you hold down a song.", "DefaultMusicSongs.png", action="dj_next"),
            _item("Crossfade between songs", "Kodi's own crossfade, so each song blends into the next. Kodi can't "
                  "match beats; the phone app's DJ mix can.", "DefaultAddonMusic.png", action="dj_crossfade"),
            _item("Make a Kodi playlist from another playlist", "From a CSV export (Spotify via Exportify or TuneMyMusic), "
                  "an M3U, a typed list or a Deezer link. Uses the songs you have; lists the ones you don't.",
                  "DefaultMusicPlaylists.png", action="playlist_convert"),
            _item("Read keys and tempos again", "After retagging songs with Mixed In Key. The tags are read again the "
                  "next time a DJ tool needs them. No files change.", "DefaultAddonService.png", action="dj_forget")]
    if name == "library_backups":
        return [
            _item("Back up the library now (last: %s)" % backup_line(), "Kodi's export with watched marks, plus "
                  "its database. It also runs by itself once a day.", "DefaultAddonsUpdates.png", action="backup"),
            _item("Restore a backup", "Pick a date; Sortovia gets it ready, then Kodi's Import library "
                  "puts it back.", "DefaultAddonsUpdates.png", action="restore"),
            _item("Restore the music library", "Puts back a saved copy of Kodi's music library, if it looks wrong or "
                  "empty. No music files change.", "DefaultAddonsUpdates.png", action="music_restore"),
            _item("List the backups", "When each was made, what was in the library, and where it is.",
                  "DefaultIconInfo.png", action="backups"),
            _item("Remove old library backups", "Frees space. The newest is always kept; the newest two on the "
                  "drive are kept unless you tick them.", "DefaultAddonService.png", action="remove_backups")]
    if name == "help":
        return [
            _item("Read the guide", "Every step and feature, by topic.", "DefaultIconInfo.png", action="guide"),
            _item("Show the welcome screen again", "", "DefaultIconInfo.png", action="welcome"),
            _item("How to add your folders to Kodi", "TV, Movies and Tutorials as sources, Comics under Pictures - "
                  "the steps for your device.", "DefaultIconInfo.png", action="sources_help"),
            _item("How to set up your phone", "Android and iPhone: import files over Wi-Fi.", "DefaultIconInfo.png",
                  action="guide_phone"),
            _item("Version history", "What each update added.", "DefaultIconInfo.png", action="history"),
            _item("Check for updates now", "Sortovia also checks every time it opens.", "DefaultAddonsUpdates.png",
                  action="update"),
            _item("Send a problem report to the developer", "Cleans Kodi's log, shows you what's in it, and sends it "
                  "if you agree.", "DefaultIconInfo.png", action="problem_report")]
    return []


def list_menu(handle, name):
    import xbmcplugin
    for it in menu_items(name):
        li = xbmcgui.ListItem(it["label"], it["plot"])
        li.setArt({"icon": it["icon"], "thumb": it["icon"]})
        try:
            li.getVideoInfoTag().setPlot(it["plot"])
        except Exception:
            try:
                li.setInfo("video", {"plot": it["plot"]})
            except Exception:
                pass
        if it["action"]:
            li.setProperty("IsPlayable", "false")
        url = PLUGIN + ("?menu=%s" % it["menu"] if it["menu"] else "?action=%s" % it["action"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=bool(it["menu"]))
    xbmcplugin.setContent(handle, "files")
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def _resume(dlg, spath):
    prev = load_cache(spath)
    if prev.get("src") and prev.get("dest"):
        remove_partial_copy(prev)
        run(dlg, spath, prev["src"], prev["dest"], prev["mode"], prev["delete_old"], prev["lang_mode"],
            prev.get("nfo_mode", 0), prev.get("sub_mode", 0), prev.get("empty_mode", 0))


def _same(dlg, spath):
    last = load_cache(data_file("last_settings.json"))
    if last.get("src") and last.get("dest"):
        run(dlg, spath, last["src"], last["dest"], last["mode"], last["delete_old"], last["lang_mode"],
            last.get("nfo_mode", 0), last.get("sub_mode", 0), last.get("empty_mode", 0))


def _report(dlg):
    dlg.textviewer("%s - last report" % ADDON, read_text(data_file("last_report.txt")) or "No report saved yet.")


def _ob(fn):
    """Help actions on the welcome-screen settings; a folder change may offer a reorganize."""
    def go(dlg, spath):
        ob = onboarding_state()
        if not ob:
            return
        fn(ob, dlg)
        set_language()
        if ob.pop_reorganize():
            reorganize_folder(dlg, spath, *ob.last_reorganize)
    return go


def _youtube(i):
    return lambda dlg, spath: youtube_menu(dlg, spath, load_cache(data_file("last_settings.json")), only=i)


def _comics(fn):
    def go(dlg, spath):
        root = library_folder("Comics", dlg)
        if root:
            fn(dlg, root)
    return go


def _welcome(ob, dlg):
    ob.state.pop("welcomed", None)
    ob.first_run(dlg)


ACTION_ARGS = {}  # anything else in the address that started an action
ACTIONS = {
    "tmdb_settings": lambda dlg, spath: watch_settings(dlg, change=True),
    "running": lambda dlg, spath: running_menu(dlg, home().getProperty(PROP_RUN)),
    "resume": _resume, "same": _same, "new": new_sort,
    "report": lambda dlg, spath: _report(dlg),
    "organise": lambda dlg, spath: organise_folders(dlg, spath),
    "comics_convert": _comics(comics_convert),
    "comics_turn": _comics(comics_turn),
    "backup": lambda dlg, spath: backup_now(background=True),
    "restore": lambda dlg, spath: restore_backup(dlg),
    "drive_letter": lambda dlg, spath: fix_drive_letter(dlg),
    "remove_backups": lambda dlg, spath: remove_old_backups(dlg),
    "backups": lambda dlg, spath: backups_list(dlg),
    "clean_library": lambda dlg, spath: clean_library(dlg),
    "phone_music": lambda dlg, spath: phone_music(dlg),
    "dj_order": lambda dlg, spath: dj_order(dlg),
    "phone_tags": lambda dlg, spath: phone_tags(dlg),
    "playlist_add": lambda dlg, spath: playlist_add(dlg, ACTION_ARGS.get("type", "song"), ACTION_ARGS.get("id", "")),
    "dj_next": lambda dlg, spath: dj_next(dlg, ACTION_ARGS.get("path", "")),
    "dj_crossfade": lambda dlg, spath: dj_crossfade(dlg),
    "dj_forget": lambda dlg, spath: dj_forget(dlg),
    "playlist_convert": lambda dlg, spath: playlist_convert(dlg),
    "settings": lambda dlg, spath: xbmcaddon.Addon().openSettings(),
    "artist_art": lambda dlg, spath: set_artist_art(dlg),
    "music_tags_artist": lambda dlg, spath: fix_music_tags(dlg, ACTION_ARGS.get("artist", "")),
    "yt_video": lambda dlg, spath: yt_video(dlg, ACTION_ARGS.get("path", "")),
    "music_art": lambda dlg, spath: check_music_art(dlg),
    "music_art_set": lambda dlg, spath: set_music_art(dlg),
    "music_tags": lambda dlg, spath: fix_music_tags(dlg),
    "music_tags_undo": lambda dlg, spath: undo_music_tags(dlg),
    "genre_dry_run": lambda dlg, spath: genre_dry_run(dlg),
    "genre_settings": lambda dlg, spath: genre_settings(dlg),
    "music_restore": lambda dlg, spath: restore_music_library(dlg),
    "music_rescan": lambda dlg, spath: rescan_one_album(dlg),
    "missing": lambda dlg, spath: find_missing_episodes(dlg),
    "wherewatch": lambda dlg, spath: where_to_watch_menu(dlg),
    "guide": _ob(lambda ob, dlg: ob.show_guide(dlg, pick=True)), "history": _ob(lambda ob, dlg: ob.show_history(dlg)),
    "kinds": _ob(lambda ob, dlg: ob.choose_kinds(dlg)), "folders": _ob(lambda ob, dlg: ob.choose_folders(dlg)),
    "language": _ob(lambda ob, dlg: ob.choose_language(dlg)), "welcome": _ob(_welcome),
    "update": lambda dlg, spath: check_for_update(dlg, manual=True),
    "nfo": lambda dlg, spath: view_text_file(dlg),
    "free_space": lambda dlg, spath: free_space(dlg),
    "device": _ob(lambda ob, dlg: ob.choose_device(dlg)),
    "sources_help": lambda dlg, spath: dlg.textviewer("%s - adding your folders" % ADDON, sources_help()),
    "reorganize": lambda dlg, spath: _pending_reorganize(dlg, spath),
    "rd_account": lambda dlg, spath: rd_account(dlg),
    "rd_torrents": lambda dlg, spath: rd_torrents(dlg),
    "rd_magnet": lambda dlg, spath: rd_magnet(dlg),
    "torrent_search": lambda dlg, spath: torrent_search(dlg),
    "rd_grab": lambda dlg, spath: rd_grab(dlg),
    "rd_failed": lambda dlg, spath: rd_failed_menu(dlg),
    "phone_torrents": lambda dlg, spath: phone_torrents(dlg, spath),
    "torrent_setup": lambda dlg, spath: torrent_setup(dlg),
    "rd_auto": lambda dlg, spath: rd_auto_toggle(dlg),
    "rd_pick_new": lambda dlg, spath: rd_pick_new(),
    "rd_link": lambda dlg, spath: rd_link(dlg),
    "rd_history": lambda dlg, spath: rd_history(dlg),
    "rd_sort": rd_sort,
    "rd_stop": lambda dlg, spath: home().setProperty(PROP_RD_STOP, "1"),
    "rd_pause": lambda dlg, spath: home().clearProperty(PROP_RD_PAUSE) if home().getProperty(PROP_RD_PAUSE)
    else home().setProperty(PROP_RD_PAUSE, "1"),
    "rd_where": lambda dlg, spath: rd_where_toggle(dlg),
    "problem_report": lambda dlg, spath: send_problem_report(dlg),
    "vault": lambda dlg, spath: vault_menu(dlg),
    "guide_phone": _ob(lambda ob, dlg: ob.show_guide(dlg, topic="use a phone")),
    "rd_releases": lambda dlg, spath: rd_releases(dlg),
    "rd_feed_add": lambda dlg, spath: rd_feed_add(dlg),
    "rd_feed_remove": lambda dlg, spath: rd_feed_remove(dlg),
    "rd_watch": lambda dlg, spath: rd_watch(),
    "rd_resume": lambda dlg, spath: rd_run(None, auto=True),
    "phone_autosort": lambda dlg, spath: phone_autosort(),
}
ACTIONS.update(("yt%d" % i, _youtube(i)) for i in range(10))
if devtools:
    devtools.bind(globals())
    ACTIONS.update(devtools.actions())
STARTS_A_RUN = ("resume", "same", "new", "organise", "yt3", "rd_sort")


def _pending_reorganize(dlg, spath):
    pending = home().getProperty(PROP_REORG)
    home().clearProperty(PROP_REORG)
    if pending:
        kind, folder = json.loads(pending)
        reorganize_folder(dlg, spath, kind, folder)


def phone_music(dlg):
    """Turn on Kodi's web server for the Sortovia phone app, and show what to type there."""
    import phoneplay
    password = (load_cache(data_file("phone.json")).get("dav") or {}).get("pass") or ""
    if not password:
        password = xbmcgui.Dialog().input("A password for the phone to use (at least 6 letters or numbers)")
        if not password or len(password) < 6:
            dlg.ok(ADDON, "No password, so nothing changed.")
            return
    result = phoneplay.turn_on(backup._rpc, password)
    ip = (xbmc.getInfoLabel("Network.IPAddress") or "this device's address").strip()
    dlg.textviewer("Play this music on your phone", phoneplay.instructions(ip, result))


# ---------- DJ tools on this device (Kodi only orders and crossfades; it can't beat-match) ----------
DJ_CACHE = "djkeys.json"


def _dj_details(dlg, songs):
    """songs with their key, tempo and energy, reading tags only for songs not seen before. None if cancelled."""
    import xboxdj
    path = data_file(DJ_CACHE)
    cache = load_cache(path)
    new = sum(1 for s in songs if s["path"] not in cache)
    prog = None
    if new > 20:
        prog = xbmcgui.DialogProgress()
        prog.create(ADDON, "Reading keys and tempos from %d songs. Only new songs are read next time." % new)
    read = [0]

    def step(done, total):
        read[0] += 1
        if prog:
            if prog.iscanceled():
                return False
            if read[0] % 10 == 0:
                prog.update(int(100 * read[0] / max(new, 1)), "Reading keys and tempos: %d of %d" % (read[0], new))
            if read[0] % 200 == 0:
                save_cache(path, cache, verify=False)  # a cancel or crash keeps what's read
        return True
    try:
        xboxdj.dj_details(songs, cache, read_music_tags, step)
        cancelled = bool(prog and prog.iscanceled())
    finally:
        if prog:
            prog.close()
        if new:
            save_cache(path, cache, verify=False)
    return None if cancelled else songs


def _pick_order(dlg, keep=False):
    import xboxdj
    orders = list(xboxdj.ORDERS)
    if keep:
        orders.insert(0, ("", "As it is", "The playlist's own order."))
    items = []
    for _, label, plot in orders:
        it = xbmcgui.ListItem(label, plot)
        items.append(it)
    pick = dlg.select("Which order?", items, useDetails=True)
    return orders[pick][0] if pick >= 0 else None


def _key_note(songs):
    import xboxdj
    n = xboxdj.without_key(songs)
    if not n:
        return ""
    return ("\n\n%d of %d songs have no key in their tags, so they're placed by tempo and energy alone. The Sortovia "
            "phone app can write them: Player > Analyse the Xbox's music, then Send tags to the Xbox, and here Library > "
            "Get tags from the phone. Mixed In Key (or rekordbox, Serato, Traktor) can too; then use Read keys and "
            "tempos again." % (n, len(songs)))


def _save_playlist(name, songs):
    """Write a Kodi music playlist. Returns its name, or "" if it couldn't be written."""
    import playlists
    import xboxdj
    name = xboxdj.file_name(name)
    folder = xboxdj.PLAYLISTS
    xbmcvfs.mkdirs(folder)
    f = xbmcvfs.File(folder + name + xboxdj.OWN, "w")
    try:
        ok = f.write(playlists.write_m3u(name, songs))
    finally:
        f.close()
    return name if ok is not False else ""


def _playlists_kodi_shows():
    """Rename playlists Sortovia saved as .m3u8 (before 1.54) to .m3u, which Kodi's Playlists list shows."""
    import xboxdj
    folder = xboxdj.PLAYLISTS
    try:
        _, files = xbmcvfs.listdir(folder)
    except Exception:
        return
    for name in files:
        if name.lower().endswith(".m3u8"):
            target = folder + name[:-5] + xboxdj.OWN
            if not xbmcvfs.exists(target):
                xbmcvfs.rename(folder + name, target)


def playlist_add(dlg, kind, dbid):
    """Hold down a song or album: add it to a playlist of your own, or a new one."""
    import xboxdj
    rpc = backup._rpc
    _playlists_kodi_shows()
    songs = xboxdj.song_details(rpc, kind, dbid) if dbid else []
    if not songs:
        dlg.ok(ADDON, "Kodi didn't say which songs these are. Try again from Music > Songs or Albums.")
        return
    own = [(n, p) for n, p in xboxdj.saved_playlists(rpc) if p.lower().endswith(xboxdj.OWN)]
    pick = dlg.select("Add %s to which playlist?" % ("this album's %d songs" % len(songs) if kind == "album" else "this song"),
                      ["New playlist..."] + [n for n, _ in own])
    if pick < 0:
        return
    if pick == 0:
        name = xbmcgui.Dialog().input("Name for the new playlist")
        if not name:
            return
        name, text = xboxdj.file_name(name), ""
        path = xboxdj.PLAYLISTS + name + xboxdj.OWN
        if xbmcvfs.exists(path):
            text = _read_text(path)
    else:
        name, path = own[pick - 1]
        text = _read_text(path)
    xbmcvfs.mkdirs(xboxdj.PLAYLISTS)
    f = xbmcvfs.File(path, "w")
    try:
        ok = f.write(xboxdj.added(text, name, songs))
    finally:
        f.close()
    if ok is False:
        dlg.ok(ADDON, "The playlist couldn't be saved.")
    else:
        dlg.notification(ADDON, "Added to %s (Music > Playlists)" % name)


PHONE_TAGS = "phone_tags.json"  # the last phone address used for Get tags from the phone


TAG_PARTS = [("Key", "TKEY", False), ("Tempo (BPM)", "TBPM", False), ("Genre", "TCON", False),
             ("Energy", "EnergyLevel", True)]  # (shown name, frame or TXXX name, a TXXX frame)


def _phone_values(t, djkeys):
    return {"TKEY": djkeys.key_name(t.get("key") or "") or t.get("key") or "",
            "TBPM": str(int(round(float(t["bpm"])))) if t.get("bpm") else "",
            "TCON": t.get("genre") or "",
            "EnergyLevel": str(int(t["energy"])) if t.get("energy") else ""}


def _tag_now(path):
    """{frame: text} of the parts in TAG_PARTS a file's tag has now, reading only the tag, not the music."""
    import id3write
    f = xbmcvfs.File(path)
    try:
        head = bytes(f.readBytes(10))
        size = id3write.tag_size(head)
        tag = head + (bytes(f.readBytes(size - 10)) if size > 10 else b"")
    finally:
        f.close()
    if not size:
        return {}
    version, frames = id3write.parse(tag[:size])
    frames = id3write._upgrade(version, frames)
    return dict((k, " / ".join(id3write.user_values(frames, k) if user else id3write.text_values(frames, k)))
                for _, k, user in TAG_PARTS)


def tag_changes(now, phone, replace):
    """(texts, users, lines): what to write and a line for each change ("Key: 8A -> 9A"). replace: {frame: True to
    replace what the tag has, False to keep it}; frames not in it aren't touched."""
    texts, users, lines = {}, {}, []
    for name, k, user in TAG_PARTS:
        if k not in replace or not phone.get(k):
            continue
        have = (now.get(k) or "").strip()
        if (have and not replace[k]) or have == phone[k]:
            continue
        (users if user else texts)[k] = phone[k]
        lines.append("%s: %s -> %s" % (name, have or "(none)", phone[k]))
    return texts, users, lines


def phone_tags(dlg):
    """Get keys, tempos, energy and genres the Sortovia phone app worked out (it can listen to the music; Kodi
    on this device can't), and write them into this library's MP3s. Old tags are saved, so they can be undone."""
    import djkeys
    import id3write
    saved = load_cache(data_file(PHONE_TAGS))
    dlg.ok(ADDON, "On the phone, open Sortovia > Player > Send tags to the Xbox. It shows an address and a code to type here.")
    address = xbmcgui.Dialog().input("Phone address shown in the app (such as 192.168.1.20:8765)", saved.get("address", ""))
    if not address:
        return 0
    code = xbmcgui.Dialog().input("Code shown in the app")
    if not code:
        return 0
    save_cache(data_file(PHONE_TAGS), {"address": address.strip()})
    try:
        data = json.loads(_fetch_python("http://%s/%s.json" % (address.strip(), code.strip())).decode("utf-8"))
    except Exception as e:
        dlg.ok(ADDON, "Couldn't get the tags from the phone: %s\nCheck the phone still shows Send tags to the Xbox, and both are on the same Wi-Fi." % e)
        return 0
    tracks = [t for t in data.get("tracks") or [] if t.get("file")]
    mp3 = [t for t in tracks if t["file"].lower().endswith(".mp3")]
    if not mp3:
        dlg.ok(ADDON, "The phone sent %d tracks, but none are MP3s, which are the only files Sortovia can write tags into for now." % len(tracks))
        return 0
    names = [n for n, _, _ in TAG_PARTS]
    parts = dlg.multiselect("%d tracks from the phone (%d MP3s). Which parts of the tags to write?" % (len(tracks), len(mp3)),
                            names, preselect=list(range(len(names))))
    if not parts:
        return 0
    replace = {}
    for i in parts:
        how = dlg.select("%s: when a track's tag already has one" % names[i],
                         ["Keep it (only fill in tracks that have none)", "Replace it with the phone's"])
        if how < 0:
            return 0
        replace[TAG_PARTS[i][1]] = how == 1
    root = library_folder("Music", dlg)
    if not root:
        return 0
    plans, changes = [], []
    prog, step = _progress("Comparing with the tags in your files (nothing is written yet)...")
    try:
        for i, t in enumerate(mp3):
            if step(i, len(mp3), base_of(t["file"])):
                return 0
            try:
                now = _tag_now(t["file"])
            except Exception as e:
                log("phone tags: %s: %s" % (base_of(t["file"]), e))
                continue
            texts, users, lines = tag_changes(now, _phone_values(t, djkeys), replace)
            if lines:
                plans.append((t, texts, users))
                changes.append("%s\n%s" % (base_of(t["file"]), "\n".join("    " + x for x in lines)))
    finally:
        _close(prog)
    if not plans:
        dlg.ok(ADDON, "Nothing to change: your files already have these tags.")
        return 0
    dlg.textviewer("%s - what would change in %d files" % (ADDON, len(plans)), "\n".join(changes))
    if not dlg.yesno(ADDON, "Write these changes into %d MP3s?\nTheir old tags are saved first, so File > Undo the "
                     "last music tag fix puts them back." % len(plans), nolabel="Cancel", yeslabel="Write"):
        return 0
    folder = "%s%s/%s/" % (backup.drive_dir(root) or root, TAG_BACKUPS, time.strftime("%Y-%m-%d %H%M"))
    xbmcvfs.mkdirs(folder)
    manifest, failures, written, unchanged = [], [], [], 0
    prog, step = _progress("Writing tags from the phone...")
    try:
        for i, (t, texts, users) in enumerate(plans):
            if step(i, len(plans), base_of(t["file"])):
                break
            try:
                data = backup._read(t["file"])
                new, old = id3write.set_frames(data, texts, users)
                if new == data:
                    unchanged += 1
                    continue
                if new[len(new) - (len(data) - len(old)):] != data[len(old):]:
                    raise id3write.Unsupported("the audio wouldn't have stayed the same")
                kept = "%04d.id3" % i
                if not backup._write(folder + kept, old or b""):
                    raise IOError("couldn't save its old tag")
                manifest.append({"path": t["file"], "tag": kept})
                if not backup._write(folder + "manifest.json", json.dumps(manifest).encode("utf-8")):
                    raise IOError("couldn't save the undo list")
                if not _write_checked(t["file"], new):
                    raise IOError("the new file didn't read back the same")
                written.append(t["file"])
            except Exception as e:
                log("phone tags: %s: %s" % (base_of(t["file"]), e))
                failures.append("%s: %s" % (base_of(t["file"]), e))
    finally:
        _close(prog)
    if not manifest:
        xbmcvfs.rmdir(folder, True)
    _remember_tracks(written)
    cache = load_cache(data_file(DJ_CACHE))
    for path in written:
        cache.pop(path, None)  # the DJ tools read the new keys next time
    save_cache(data_file(DJ_CACHE), cache, verify=False)
    summary = ""
    if written:
        prog, stage = _stages("Updating Kodi's library...")
        try:
            summary = _update_music_library(sorted(set(parent_of(p) for p in written)), stage)
        except Exception as e:
            summary = "Updating the library didn't finish: %s" % e
        _close(prog)
    dlg.ok(ADDON, "Wrote tags into %d files. %d already had them.%s\n%s%s" % (
        len(written), unchanged, " These failed: %s." % "; ".join(failures[:5]) if failures else "", summary,
        "\nFile > Undo the last music tag fix puts the old tags back." if written else ""))
    return len(written)


def _read_text(path):
    f = xbmcvfs.File(path)
    try:
        return bytes(f.readBytes()).decode("utf-8", "replace")
    finally:
        f.close()


def dj_order(dlg):
    """Play a saved playlist, or the queue, in an order that mixes: by key, building up, or winding down."""
    import djkeys
    import xboxdj
    rpc = backup._rpc
    _playlists_kodi_shows()
    saved = xboxdj.saved_playlists(rpc)
    choices = [("What's playing now (the music queue)", "")] + saved
    pick = dlg.select("Put which playlist in mixing order?", [c[0] for c in choices])
    if pick < 0:
        return
    name, path = choices[pick]
    songs = xboxdj.playlist_songs(rpc, path) if path else xboxdj.queue_songs(rpc)
    if len(songs) < 2:
        dlg.ok(ADDON, "That playlist has %s. Pick one with at least two songs." % ("one song" if songs else "no songs"))
        return
    order = _pick_order(dlg)
    if not order or _dj_details(dlg, songs) is None:
        return
    songs = djkeys.reorder(songs, order)
    label = dict((o[0], o[1]) for o in xboxdj.ORDERS)[order]
    what = dlg.select("%s: %d songs, starting with %s" % (label, len(songs), xboxdj.song_name(songs[0])),
                      ["Play it now", "Save it as a new playlist", "Both"])
    if what < 0:
        return
    lines = []
    if what in (1, 2):
        new = _save_playlist("%s (%s)" % (name if path else "Queue", label), songs)
        lines.append("Saved as the playlist \"%s\" (Music > Playlists)." % new if new else "The playlist couldn't be saved.")
    if what in (0, 2):
        xboxdj.play(rpc, songs)
        lines.append("Playing in %s." % label.lower())
        if not xboxdj.crossfade(rpc):
            lines.append("Tip: turn on Crossfade between songs so each one blends into the next.")
    dlg.ok(ADDON, "\n".join(lines) + _key_note(songs))


def dj_next(dlg, path=""):
    """What mixes well after a song (the one held down, or the one playing), by key and tempo."""
    import xboxdj
    rpc = backup._rpc
    if not path:
        now = xboxdj.playing(rpc)
        path = now[2] if now else ""
    if not path:
        dlg.ok(ADDON, "Nothing is playing. Play a song, or hold down a song in the music library and pick What mixes after this.")
        return
    songs = _dj_details(dlg, xboxdj.library_songs(rpc))
    if songs is None:
        return
    current, picks = xboxdj.what_mixes_after(path, songs)
    if not current:
        dlg.ok(ADDON, "That song isn't in Kodi's music library. Scan its folder into the library first.")
        return
    if not current.get("camelot"):
        dlg.ok(ADDON, "%s has no key in its tags. The Sortovia phone app can write it (Player > Analyse the Xbox's "
                      "music, then Send tags to the Xbox, and here Library > Get tags from the phone), or Mixed In Key "
                      "(or rekordbox, Serato, Traktor); then use Read keys and tempos again." % xboxdj.song_name(current))
        return
    if not picks:
        dlg.ok(ADDON, "Nothing in the library mixes well after %s (%s): no song in a key next to it within 6%% of its "
                      "tempo." % (xboxdj.song_name(current), xboxdj.describe(current)))
        return
    items = [xbmcgui.ListItem(xboxdj.song_name(s), "%s  -  %s" % (reason, xboxdj.describe(s))) for s, reason in picks]
    pick = dlg.select("After %s (%s)" % (xboxdj.song_name(current), xboxdj.describe(current)), items, useDetails=True)
    if pick < 0:
        return
    song = picks[pick][0]
    queued = xboxdj.play_next(rpc, song)
    dlg.notification(ADDON, ("Plays next: " if queued else "Playing: ") + xboxdj.song_name(song))


def dj_crossfade(dlg):
    import xboxdj
    rpc = backup._rpc
    now = xboxdj.crossfade(rpc)
    labels = [xboxdj.crossfade_label(s) + (" (now)" if s == now else "") for s in xboxdj.CROSSFADE_CHOICES]
    pick = dlg.select("Crossfade between songs", labels)
    if pick < 0:
        return
    seconds = xboxdj.CROSSFADE_CHOICES[pick]
    try:
        done = xboxdj.set_crossfade(rpc, seconds)
    except IOError:
        done = False
    if done:
        if seconds:
            dlg.ok(ADDON, "Crossfade: %s, also between songs from the same album.\n\nKodi crossfades as a song ends on "
                          "its own, in its music player (not videos). Let one play to the end to hear it." % xboxdj.crossfade_label(seconds))
        else:
            dlg.notification(ADDON, "Crossfade: off")
    else:
        dlg.ok(ADDON, "Kodi didn't take the change. Set it yourself: Settings > Player > Music > Crossfade between songs.")


def dj_forget(dlg):
    if save_cache(data_file(DJ_CACHE), {}, verify=False):
        dlg.ok(ADDON, "Keys and tempos are read from the tags again the next time a DJ tool needs them.")


def playlist_convert(dlg):
    """A playlist from elsewhere (CSV export, M3U, typed list, or a Deezer link) as a Kodi playlist of your own files."""
    import playlists
    import xboxdj
    rpc = backup._rpc
    how = dlg.select("Make a Kodi playlist from", ["A file (.csv, .m3u, .m3u8 or .txt)", "A Deezer playlist link"])
    if how < 0:
        return
    name = ""
    if how == 0:
        path = xbmcgui.Dialog().browse(1, "Pick the playlist file", "files", ".csv|.m3u|.m3u8|.txt")
        if not path or path.endswith(("/", "\\")):
            return
        f = xbmcvfs.File(path)
        try:
            raw = f.readBytes()
        finally:
            f.close()
        text = bytes(raw).decode("utf-8", "replace")
        name = re.sub(r"\.[^.]+$", "", re.split(r"[\\/]", path)[-1])
        entries_text = text
    else:
        link = xbmcgui.Dialog().input("Deezer playlist link (Share > Copy link)")
        kind, pid = playlists.service_of(link)
        if kind != "deezer":
            if link:
                dlg.ok(ADDON, "That isn't a Deezer playlist link. For Spotify, Apple Music or TIDAL, export the playlist "
                              "as a CSV (Exportify or TuneMyMusic) and pick the file instead.")
            return
        try:
            entries = playlists.deezer_playlist(lambda url, headers: _fetch_python(url, headers), pid)
        except (playlists.LinkError, IOError, ValueError) as e:
            dlg.ok(ADDON, "Couldn't read that playlist: %s" % e)
            return
        entries_text = "\n".join("%s - %s" % (e["artist"], e["title"]) if e["artist"] else e["title"] for e in entries)
    songs = xboxdj.library_songs(rpc)
    tracks, missing = xboxdj.convert(entries_text, songs)
    if not tracks:
        dlg.ok(ADDON, "None of the %d songs in it are in Kodi's music library." % len(missing) if missing
               else "No songs found in it. A CSV needs Artist and Track name columns.")
        return
    name = xbmcgui.Dialog().input("Name for the new playlist", name or "New playlist")
    if not name:
        return
    order = _pick_order(dlg, keep=True)
    if order is None:
        return
    note = ""
    if order:
        import djkeys
        if _dj_details(dlg, tracks) is None:
            return
        tracks = djkeys.reorder(tracks, order)
        note = _key_note(tracks)
    saved = _save_playlist(name, tracks)
    if not saved:
        dlg.ok(ADDON, "The playlist couldn't be saved.")
        return
    text = "Saved \"%s\" with %d song%s (Music > Playlists).%s" % (saved, len(tracks), "" if len(tracks) == 1 else "s", note)
    if missing:
        text += "\n\nNot in your library (%d):\n%s" % (len(missing), xboxdj.missing_text(missing))
    dlg.textviewer("Playlist made", text)


def sources_help():
    import devices
    tut = library_folder("Tutorials")
    shown = friendly(tut).rstrip("\\/") if tut else "E:\\Tutorials"
    return devices.add_source_help(my_device(), shown)


def do_action(name):
    dlg = screens.Friendly(xbmcgui.Dialog())
    fn = ACTIONS.get(name)
    if not fn:
        return
    if name not in ("rd_watch", "rd_stop", "rd_pick_new", "rd_resume", "phone_autosort") and not vault_unlock(dlg):
        return
    status = home().getProperty(PROP_RUN)
    if status and name in STARTS_A_RUN:
        running_menu(dlg, status)  # one sort at a time
        return
    set_language()
    try:
        fn(dlg, session_file())
    finally:
        xbmc.executebuiltin("Container.Refresh")  # labels like "last backup" may have changed


def plugin_main(argv):
    try:
        from urllib.parse import parse_qs
    except ImportError:
        from urlparse import parse_qs
    q = dict((k, v[0]) for k, v in parse_qs((argv[2] if len(argv) > 2 else "").lstrip("?")).items())
    if q.get("action"):
        ACTION_ARGS.update(q)
        do_action(q["action"])
        return
    handle = int(argv[1]) if len(argv) > 1 and argv[1].lstrip("-").isdigit() else -1
    name = q.get("menu", "root")
    if name == "root" and startup_due() and not home().getProperty(PROP_RUN):
        if startup_checks(screens.Friendly(xbmcgui.Dialog())):
            import xbmcplugin
            list_menu(handle, name)  # the menu stays on screen, so nothing flashes blank
            xbmc.sleep(500)
            xbmc.executebuiltin("Container.Refresh")  # then read it again with the new version
            return
    list_menu(handle, name)
    if name == "root" and load_cache(data_file(RD_AUTO)).get("on") and not home().getProperty(PROP_RD_WATCH) \
            and rd_client().signed_in():
        xbmc.executebuiltin("RunPlugin(%s?action=rd_pick_new)" % PLUGIN)  # what was added on the phone meanwhile
    elif name == "root" and rd_queue() and not home().getProperty(PROP_RD_WATCH) and rd_client().signed_in():
        xbmc.executebuiltin("RunPlugin(%s?action=rd_watch)" % PLUGIN)  # carries on after Kodi was closed
    if name == "root" and not home().getProperty(PROP_RD) and any(
            j.get("state") in ("queued", "downloading", "paused") for j in rd_jobs().all()):
        xbmc.executebuiltin("RunPlugin(%s?action=rd_resume)" % PLUGIN)  # downloads cut off when Kodi closed carry on
    if name == "root" and autosort_on() and not home().getProperty(PROP_AUTOSORT) and \
            (load_cache(data_file("phone.json")).get("dav") or {}).get("pass"):
        xbmc.executebuiltin("RunPlugin(%s?action=phone_autosort)" % PLUGIN)  # finished downloads go to the Xbox
    if name == "root" and home().getProperty(PROP_REORG):
        xbmc.executebuiltin("RunPlugin(%s?action=reorganize)" % PLUGIN)


def main():
    import sys
    if sys.argv and sys.argv[0].startswith("plugin://"):
        plugin_main(sys.argv)
    else:
        script_main()


main()
