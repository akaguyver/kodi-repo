"""Filename -> Kodi folder/name logic. Pure: no disk access, no Kodi imports.

Shared by the Kodi add-on (default.py) and the command-line kodi_sort.py, so a
naming fix made here applies to both.

  TV:     TV/Show Name (Year)/Season 01/Show Name (Year) S01E02.mkv
  Movies: Movies/Movie Name (Year)/Movie Name (Year).mkv
  Comics: Comics/<original file name>
  Tutorials: Tutorials/<Subject>/<original file name>   (AutoCAD, Revit ...)
"""
import re
from pathlib import PurePath

VIDEO = {".mkv", ".mp4", ".avi", ".m4v", ".mov", ".wmv", ".ts", ".webm"}
SUBS = {".srt", ".ass", ".ssa", ".sub", ".vtt"}
# Separate audio tracks (usually an English dub shipped next to the video):
# moved next to their video with the same name, so Kodi offers them as an extra track.
AUDIO = {".mka", ".ac3", ".eac3", ".dts"}
MUSIC = {".mp3", ".flac", ".m4a", ".ogg", ".oga", ".opus", ".wav", ".wma", ".aac", ".ape", ".alac"}
COMICS = {".cbz", ".cbr", ".cb7", ".cbt"}
# PDFs/EPUBs are usually bills, manuals, receipts: only comics when they sit
# in a folder whose name says so ("Comics", "Manga", "Nightwarden comics" ...).
BOOKS = {".pdf", ".epub"}
COMIC_FOLDER_RE = re.compile(r"comic|manga", re.I)
MIN_VIDEO_BYTES = 50 * 1024 * 1024  # smaller videos are samples/clips

# SxxEyy, optional second episode only with an explicit E / -E (never resolution digits)
TV_RE = re.compile(
    r"^(?P<show>.*?)[ ._\-\[\(]*(?<![a-z])s(?P<s>\d{1,2})[ ._\-]?e(?P<e>\d{1,3})"
    r"(?:-?e(?P<e2>\d{1,3}))?(?!\d)",
    re.I,
)
TV_X_RE = re.compile(r"^(?P<show>.*?)[ ._\-]+(?P<s>\d{1,2})x(?P<e>\d{2,3})(?!\d)", re.I)
# Spelled out (streaming-site downloads): "Show (2026) Season 1 Episode 1- Title", "Show Season 2, Ep. 3".
TV_WORDS_RE = re.compile(r"^(?P<show>.*?)[ ._\-\[\(]*(?<![a-z])season[ ._\-]*(?P<s>\d{1,2})[ ._\-,]*"
                         r"(?:episode|ep\.?)[ ._\-]*(?P<e>\d{1,3})(?!\d)", re.I)
# Fansub style "Show - 03" / "Show_-_03" / "Show -subtitle- 03" (absolute numbering,
# assumed Season 01). The dash needs a space on at least one side, so "Spider-Man"
# or "Apollo-13" never count as an episode number.
ANIME_RE = re.compile(
    r"^(?P<show>.+?)(?:\s+-\s*|\s*-\s+)(?P<e>\d{1,3})(?:v\d)?(?=\s|$|[\[\(])")
# "[Group]_Show_Ep15_(CRC)" and "Show Episode 15": the word in front of the number, no dash
ANIME_EP_RE = re.compile(
    r"(?i)^(?P<show>.+?)\s+ep(?:isode)?\.?\s*(?P<e>\d{1,3})(?:v\d)?(?=\s|$|[\[\(])")
# OVA / OAD / ONA, or "Special" followed by a number -> Season 00 (Kodi's Specials).
# A number right after the word is used; otherwise the number is a guess.
SPECIAL_RE = re.compile(
    r"^(?P<show>.+?)[ ._\-]+(?:(?:ova|oad|ona)(?:[ ._\-]*(?P<n>\d{1,2}))?|specials?[ ._\-]*(?P<n2>\d{1,2}))(?![a-z0-9])",
    re.I)
SPECIAL_GUESS_NOTE = "special with no number - put in Season 00 as the next free episode, check it matches TMDb"
SPECIAL_NOTE = "special - Season 00"
CREDITS_NOTE = "opening/ending credits clip - put in Season 00 as the next free episode (Kodi lists it only if TMDb has that special)"
# Download-site prefixes: "www.ExampleSite.org  -  ", "[TGx]", "www.DownloadSite.com - "
SITE_PREFIX_RE = re.compile(
    r"^\s*(?:www\.)?[a-z0-9\-]+\.(?:org|com|net|to|io|cc|me|tv|xyz|info|ws|se|ag|is|lol)\s*-+\s*", re.I)
# Release-group tags at the start: "[SubTeam] ", "(Group_One)_"
LEADING_TAGS_RE = re.compile(r"^(?:\s*(?:\[[^\]]*\]|\([^)]*\)))+\s*")
YEAR_RE = re.compile(r"[ ._\-\(\[]((?:19|20)\d{2})(?=[ ._\-\)\]]|$)")
# Opening/ending credits videos: "NCOP", "NCED2", "Textless Opening", "Creditless ED"
CREDITS_RE = re.compile(r"(?<![a-z])(?:nc(?:op|ed)\d*|textless|creditless)(?![a-z])", re.I)

RELEASE_TOKENS = {
    "480p", "576p", "720p", "1080p", "1080i", "2160p", "4k", "uhd",
    "web", "webrip", "webdl", "bluray", "brrip", "bdrip", "dvdrip", "hdtv", "hdrip",
    "x264", "x265", "h264", "h265", "hevc", "avc", "xvid", "hdr", "hdr10", "10bit",
    "aac", "ac3", "dts", "ddp5", "dd5", "proper", "repack", "remux", "amzn", "dsnp",
    "hmax", "atvp", "unrated", "internal", "multi",
}

LANGS = {
    "en": "en", "eng": "en", "english": "en",
    "es": "es", "spa": "es", "spanish": "es",
    "fr": "fr", "fre": "fr", "fra": "fr", "french": "fr",
    "de": "de", "ger": "de", "deu": "de", "german": "de",
    "it": "it", "ita": "it", "italian": "it",
    "pt": "pt", "por": "pt", "portuguese": "pt",
    "ru": "ru", "rus": "ru", "russian": "ru",
    "ja": "ja", "jpn": "ja", "japanese": "ja",
    "zh": "zh", "chi": "zh", "zho": "zh", "chinese": "zh",
    "ko": "ko", "kor": "ko", "korean": "ko",
    "nl": "nl", "dut": "nl", "nld": "nl", "dutch": "nl",
    "ar": "ar", "ara": "ar", "arabic": "ar",
    "pl": "pl", "pol": "pl", "polish": "pl",
    "sv": "sv", "swe": "sv", "swedish": "sv",
    "fi": "fi", "fin": "fi", "finnish": "fi", "da": "da", "dan": "da", "danish": "da",
    "no": "no", "nob": "no", "nor": "no", "norwegian": "no", "el": "el", "ell": "el", "gre": "el", "greek": "el",
    "he": "he", "heb": "he", "hebrew": "he", "hu": "hu", "hun": "hu", "hungarian": "hu",
    "cs": "cs", "cze": "cs", "ces": "cs", "czech": "cs", "ro": "ro", "rum": "ro", "ron": "ro", "romanian": "ro",
    "vi": "vi", "vie": "vi", "vietnamese": "vi", "id": "id", "ind": "id", "indonesian": "id",
    "uk": "uk", "ukr": "uk", "ukrainian": "uk", "bg": "bg", "bul": "bg", "bulgarian": "bg",
    "hr": "hr", "hrv": "hr", "croatian": "hr", "sr": "sr", "srp": "sr", "serbian": "sr",
    "sl": "sl", "slv": "sl", "slovenian": "sl", "sk": "sk", "slo": "sk", "slk": "sk", "slovak": "sk",
    "tr": "tr", "tur": "tr", "turkish": "tr", "th": "th", "tha": "th", "thai": "th",
    "hi": "hi", "hin": "hi", "hindi": "hi", "ms": "ms", "may": "ms", "msa": "ms", "malay": "ms",
    "fa": "fa", "per": "fa", "fas": "fa", "persian": "fa", "et": "et", "est": "et", "estonian": "et",
    "lv": "lv", "lav": "lv", "latvian": "lv", "lt": "lt", "lit": "lt", "lithuanian": "lt",
    "is": "is", "ice": "is", "isl": "is", "icelandic": "is", "ca": "ca", "cat": "ca", "catalan": "ca",
    "tl": "tl", "fil": "tl", "filipino": "tl", "ta": "ta", "tam": "ta", "tamil": "ta",
    "te": "te", "tel": "te", "telugu": "te", "bn": "bn", "ben": "bn", "bengali": "bn",
    "gl": "gl", "glg": "gl", "galician": "gl", "eu": "eu", "baq": "eu", "eus": "eu", "basque": "eu",
}

# Tutorials: a name that says so ("AutoCAD 2026 FULL Course For BEGINNERS!",
# "Revit Tutorial - Walls"), or a file inside a "Tutorials"/"Courses" folder.
# Words like "how to", "lesson", "training" are left out: they are film titles too
# ("How to Train Your Dragon", "Training Day").
TUTORIAL_RE = re.compile(
    r"(?<![a-z])(?:tutorials?|full course|crash course|masterclass|master class|course for beginners|"
    r"beginners? course|beginner'?s guide|for beginners|for absolute beginners|step[ ._\-]by[ ._\-]step guide|"
    r"udemy|lynda|linkedin learning|skillshare|pluralsight|coursera|walkthrough|webinar|quick start|getting started)(?![a-z])", re.I)
TUTORIAL_FOLDER_RE = re.compile(r"^(?:tutorials?|courses?|training|lessons|learning)$", re.I)
# YouTube downloader folders (NewPipe, Seal, YTDLnis ...): a video there that names a
# known program is a tutorial even without the word; anything else there is skipped,
# never guessed as a movie ("Some Song 2024.mp4" is not a film).
YOUTUBE_FOLDER_RE = re.compile(r"^(?:youtube|newpipe|seal|ytdlnis|ytdlp|yt-dlp|snaptube|vidmate|tubemate)$", re.I)
# Subject folder from a name: the first match wins, so the specific names come first
# ("AutoCAD Civil 3D" -> Civil 3D, "Autodesk Revit" -> Revit).
TUTORIAL_SUBJECTS = [
    ("Civil 3D", r"civil[ ._\-]?3d"), ("AutoCAD", r"auto[ ._\-]?cad"), ("Revit", r"revit"),
    ("SketchUp", r"sketch[ ._\-]?up"), ("Blender", r"blender"), ("Fusion 360", r"fusion[ ._\-]?360"),
    ("SolidWorks", r"solid[ ._\-]?works"), ("Inventor", r"inventor"), ("3ds Max", r"3ds[ ._\-]?max"),
    ("Maya", r"maya"), ("Rhino", r"rhino(?:ceros)?|grasshopper"), ("ArchiCAD", r"archi[ ._\-]?cad"),
    ("Navisworks", r"navisworks"), ("Lumion", r"lumion"), ("Enscape", r"enscape"), ("V-Ray", r"v[ ._\-]?ray"),
    ("Twinmotion", r"twinmotion"), ("FreeCAD", r"free[ ._\-]?cad"), ("Cinema 4D", r"cinema[ ._\-]?4d|c4d"),
    ("ZBrush", r"z[ ._\-]?brush"), ("Unreal Engine", r"unreal"), ("Unity", r"unity"),
    ("Photoshop", r"photoshop"), ("Illustrator", r"illustrator"), ("InDesign", r"indesign"),
    ("Premiere Pro", r"premiere"), ("After Effects", r"after[ ._\-]?effects"), ("Lightroom", r"lightroom"),
    ("DaVinci Resolve", r"davinci|resolve"), ("Excel", r"excel"), ("PowerPoint", r"power[ ._\-]?point"),
    ("Word", r"ms[ ._\-]?word|microsoft[ ._\-]?word"), ("Python", r"(?<!monty[ ._\\-])python"), ("Kodi", r"kodi"),
    ("Ableton Live", r"ableton|producer[ ._\-]?pal"), ("Closet design", r"closets?|wardrobes?|walk[ ._\-]?in"), ("Claude Code", r"claude[ ._\-]?code"),
    ("Claude", r"claude[ ._\-]?(?:desktop|ai)|claudeai|claude|anthropic|"
               r"(?:fable|opus|sonnet|haiku)[ ._\-]?\d(?:\.\d)?(?![0-9])"),
    # AI song generators: their own folder, ahead of the Music and DJing kinds ("vocals" there).
    ("AI Music", r"suno|udio|sonauto|riffusion|mubert|boomy|ai[ ._\-]?(?:music|songs?|singers?|vocals?)|"
                 r"(?:music|song)[ ._\-]?generators?|songs?[ ._\-]?with[ ._\-]?ai|made[ ._\-]?with[ ._\-]?ai"),
    ("OpenClaw", r"open[ ._\-]?claw|clawdbot|moltbot"),
    # 20/20 (kitchen/bath design). "/" can't be in a file name, so 20-20 / 20 20; a bare
    # "2020" is a year, so that spelling only counts with Design/Fusion/Giza/CAP after it.
    ("2020 Design", r"20[ ._\-]20(?![0-9])|2020[ ._\-]*(?:design|fusion|giza|cap|software)|"
                    r"(?:kitchen|bath|cabinet)s?\b.*\b2020(?![0-9])|\b2020\b.*(?:kitchen|bath|cabinet)"),
]
AI_MUSIC = "AI Music"
TUTORIAL_SUBJECT_RES = [(n, re.compile(r"(?<![a-z0-9])(?:%s)(?![a-z])" % rx, re.I)) for n, rx in TUTORIAL_SUBJECTS]


# Characters YouTube titles bring that the Xbox's font can't show (they appear as boxes):
# the downloader's look-alikes for characters file names can't hold, and emoji.
LOOKALIKES = {u"\u29f8": "-", u"\u2215": "-", u"\uff0f": "-", u"\uff5c": " - ", u"\uff1a": " -", u"\uff02": "'",
              u"\uff1f": "", u"\uff0a": "", u"\uff1c": "", u"\uff1e": "", u"\uff3c": "-"}


def plain_title(text):
    """'AI controls my Project \U0001f92f AbletonMCP' -> 'AI controls my Project AbletonMCP'; 'w\u29f8x' -> 'w-x'."""
    import unicodedata
    out = []
    for ch in text:
        ch = LOOKALIKES.get(ch, ch)
        if len(ch) == 1 and (unicodedata.category(ch) in ("So", "Cs", "Co") or ch in u"\u200d\ufe0f\ufe0e"):
            continue
        out.append(ch)
    text = re.sub(r"\s+", " ", "".join(out)).strip()
    # "Design with me ｜｜ KITCHEN" -> "Design with me - KITCHEN" (not "-- " or "- -")
    return re.sub(r"\s*-(?:\s*-)+\s*", " - ", text)


def tutorial_subject(stem):
    """'Autodesk Revit - Full Beginner Course' -> 'Revit'. None when no known program is named."""
    stem = plain_title(stem).replace("_", " ")
    for name, rx in TUTORIAL_SUBJECT_RES:
        if rx.search(stem):
            return name
    return None


def tutorial_folder(folder):
    """The subject folder the user already put a file in: '.../Tutorials/AutoCAD/x' -> 'AutoCAD'.
    '' when it sits straight in Tutorials, None when it isn't under a Tutorials folder."""
    parts = [p for p in re.split(r"[\\/]", folder or "") if p]
    for i in range(len(parts) - 1, -1, -1):
        if TUTORIAL_FOLDER_RE.match(parts[i].strip()):
            return parts[i + 1].strip() if i + 1 < len(parts) else ""
    return None


def from_youtube(folder):
    return any(YOUTUBE_FOLDER_RE.match(p.strip()) for p in re.split(r"[\\/]", folder or "") if p)


# A YouTube download is a lesson far more often than a film: these words count there (only there).
YT_LEARN_RE = re.compile(
    r"(?<![a-z])(?:how[ ._\-]?to|how i|explained|explaining|guide|tips|tricks|trucos|hacks?|steps?|lessons?|learn(?:ing)?|"
    r"course|class|review|demo|introducing|introduction|intro to|vs|versus|basics|beginners?|ideas|"
    r"understanding|what is|why|fix|setup|set up|install(?:ation)?|tool|features|workflow|secrets?|easiest|"
    r"ultimate|complete|comparison|everything|master(?:ing)?|formula|theory|tutorials?)(?![a-z])", re.I)

# Music and DJing (YouTube only): DJ lessons and gear, making music, and music videos / sets.
MUSIC_DJ = "Music and DJing"
MUSIC_DJ_KINDS = [
    ("DJ sets and mixes", r"dj[ ._\-]?set|boiler[ ._\-]?room|live[ ._\-]?set|(?:mix|mixtape)[ ._\-]?20\d\d|essential[ ._\-]?mix"),
    ("Music videos", r"official[ ._\-]?(?:music[ ._\-]?)?video|official[ ._\-]?audio|lyrics?[ ._\-]?video|visuali[sz]er|"
                     r"\((?:audio|lyrics)\)|music[ ._\-]?video"),
    ("DJing", r"dj|djs|djing|deejay|beat[ ._\-]?match(?:ing)?|beat[ ._\-]?grids?|re[ ._\-]?grid|grid|rekordbox|serato|traktor|"
              r"djuced|virtual[ ._\-]?dj|mixed[ ._\-]?in[ ._\-]?key|mix(?:ing)?[ ._\-]?in[ ._\-]?key|energy[ ._\-]?mixing|"
              r"hot[ ._\-]?cues?|cue[ ._\-]?points?|phrase[ ._\-]?analysis|phrasing|beatsource|pioneer|ddj|cdj|"
              r"turntabl\w*|(?<!from[ ._\-])scratch(?:ing)?|transitions?|mashups?|stems?"),
    ("Making music", r"ableton|fl[ ._\-]?studio|logic[ ._\-]?pro|producer[ ._\-]?pal|producing|music[ ._\-]?production|"
                     r"songwriting|song[ ._\-]?structure|music[ ._\-]?theory|chords?|basslines?|synths?|presets?|"
                     r"samplesound|beat[ ._\-]?making|make (?:a )?beats?|mastering|vocals?|melod\w*|wingman|"
                     r"subdivisions|phrases[ ._\-]?and[ ._\-]?periods|how to rap|building music"),
]
MUSIC_DJ_RES = [(n, re.compile(r"(?<![a-z0-9])(?:%s)(?![a-z])" % rx, re.I)) for n, rx in MUSIC_DJ_KINDS]


# Music videos, concerts and live / DJ sets: their own folder at the top of the drive, from YouTube or anywhere.
MUSIC_VIDEOS = "Music Videos"
YT_OTHER = "YouTube videos"  # a YouTube download that's neither a lesson nor music
MUSIC_VIDEO_RE = re.compile(
    r"(?<![a-z0-9])(?:official[ ._\-]?(?:music[ ._\-]?)?video|official[ ._\-]?audio|lyrics?[ ._\-]?video|visuali[sz]er|"
    r"music[ ._\-]?video|\((?:audio|lyrics|live)\)|\[live\]|dj[ ._\-]?set|live[ ._\-]?set|full[ ._\-]?set|b2b|"
    r"boiler[ ._\-]?room|essential[ ._\-]?mix|(?:mix|mixtape)[ ._\-]?20\d\d|cercle|tiny[ ._\-]?desk|unplugged|"
    r"in[ ._\-]?concert|concert|live[ ._\-]?(?:at|from|in)|live[ ._\-]?performance|"
    r"coachella|tomorrowland|glastonbury|lollapalooza|ultra[ ._\-]?music[ ._\-]?festival|edc|burning[ ._\-]?man|"
    r"festival|world[ ._\-]?tour|live[ ._\-]?stream)(?![a-z])", re.I)
FILM_WORD_RE = re.compile(r"(?<![a-z])concert(?![a-z])", re.I)  # "The Concert (2009)" is a film: only with another sign


def music_video(stem, youtube=True):
    """A music video, concert or live set ('Fred again.. - Live Coachella 2023', 'Song (Official Video)').
    Not when it's a lesson about one ('How to plan a DJ set'), and outside YouTube a bare 'concert' needs
    another sign, so a film called The Concert stays a film."""
    text = plain_title(stem).replace("_", " ").replace(".", " ")
    hits = [m.group(0) for m in MUSIC_VIDEO_RE.finditer(text)]
    if not hits or YT_LEARN_RE.search(text) or TUTORIAL_RE.search(text):
        return False
    if not youtube and all(FILM_WORD_RE.fullmatch(h.strip()) for h in hits):
        return False
    return True


def music_dj_kind(stem):
    """'How To Beatgrid Tracks In Rekordbox' -> 'DJing'; None when it isn't about music."""
    stem = plain_title(stem).replace("_", " ")
    for name, rx in MUSIC_DJ_RES:
        if rx.search(stem):
            return name
    return None


# A YouTube search as a folder name: "how to build a house" -> "House building".
SEARCH_FILLER = set("""how to a an the for of in on with and my your i you do does can best easy easiest quick
quickly simple guide tutorial tutorials course full beginner beginners lesson lessons step by tips tricks learn
2020 2021 2022 2023 2024 2025 2026 2027 complete ultimate way ways start started getting""".split())
SEARCH_VERBS = set("""build make fix cook paint draw design grow play mix produce edit use repair install clean bake
sew knit plant wire weld frame tile plumb remodel renovate sing write record master code program sketch model
render animate shoot film organize organise beatmatch scratch brew carve sand stain cut lay pour drywall""".split())


def _ing(verb):
    if verb.endswith("ie"):
        return verb[:-2] + "ying"
    if verb.endswith("e") and not verb.endswith("ee"):
        return verb[:-1] + "ing"
    if len(verb) <= 4 and re.match(r".*[^aeiou][aeiou][^aeiouwxy]$", verb):
        return verb + verb[-1] + "ing"
    return verb + "ing"


def search_folder(query):
    """The folders a YouTube search's videos go into, inside Tutorials: Music and DJing's kind or the program the
    search names, else words from it ("how to build a house" -> ["House building"]). [] when nothing's left."""
    if music_video(query or ""):
        return [MUSIC_VIDEOS]  # (on its own: it's at the top of the drive, not in Tutorials)
    music = music_dj_kind(query or "")
    if music:
        return [MUSIC_DJ, music]
    subject = tutorial_subject(query or "")
    if subject:
        return [subject]
    words = [w for w in re.findall(r"[a-z0-9']+", (query or "").lower()) if w not in SEARCH_FILLER]
    if not words:
        return []
    if words[0] in SEARCH_VERBS and len(words) > 1:
        words = words[1:] + [_ing(words[0])]
    text = " ".join(words[:4])
    return [safe(text[:1].upper() + text[1:])]


def _folder_words(name):
    return set(w.rstrip("s") for w in re.findall(r"[a-z0-9]+", (name or "").lower()) if w not in SEARCH_FILLER)


def similar_folder(name, existing):
    """An existing folder that means the same as name ("House building" ~ "Building a house"), or None."""
    want = _folder_words(name)
    for e in existing:
        have = _folder_words(e)
        if want and have and (want <= have or have <= want):
            return e
    return None


def plan_youtube(name, stem):
    """A YouTube download: music videos, concerts and sets go to Music Videos, music and DJ lessons to
    Tutorials/Music and DJing/<kind>, other lessons to Tutorials/<program>, anything else to YouTube videos
    (2.0.4: it was left on the phone)."""
    clean = plain_title(stem).replace("_", " ").replace(".", " ")
    file_name = safe(plain_title(PurePath(name).stem)) + PurePath(name).suffix
    if music_video(stem):
        return (MUSIC_VIDEOS, file_name)
    if tutorial_subject(stem) == AI_MUSIC:
        return ("Tutorials", AI_MUSIC, file_name)
    music = music_dj_kind(stem)
    if music in ("DJ sets and mixes", "Music videos"):  # those words alone, with a lesson word: still a lesson
        music = "DJing" if music == "DJ sets and mixes" else "Making music"
    if music:
        return ("Tutorials", MUSIC_DJ, music, file_name)
    subject = tutorial_subject(stem)
    if subject or TUTORIAL_RE.search(clean) or YT_LEARN_RE.search(clean):
        return ("Tutorials", safe(subject or "Other"), file_name)
    return (YT_OTHER, file_name)


def plan_tutorial(name, stem, folder):
    """('Tutorials', subject, name) or None."""
    sub = tutorial_folder(folder)
    if sub is None and from_youtube(folder):
        return plan_youtube(name, stem)
    if sub is None and not TUTORIAL_RE.search(plain_title(stem).replace("_", " ").replace(".", " ")) and \
            not (from_youtube(folder) and tutorial_subject(stem)):
        return None
    subject = sub or tutorial_subject(stem) or "Other"
    return ("Tutorials", safe(subject), safe(plain_title(PurePath(name).stem)) + PurePath(name).suffix)


# A course folder ("Lynda - Programming Beats in Ableton Live 9", "Electronic Music Production in Ableton Live
# (Level I)"): every file in it (lessons, exercise files, loops, project files) goes together to
# Tutorials/<program>/<course>/, keeping its own sub-folders. A folder counts when it says so (Lynda,
# Udemy, full course ...) or names a known program plus a lesson word.
COURSE_WORD_RE = re.compile(
    r"(?<![a-z])(?:level[ ._\-]*(?:[ivx]+|\d+)|lessons?|exercises?|exercise files|production|programming|songwriting|"
    r"mixing|mastering|sound design|courses?|class(?:es)?|training|learn(?:ing)?|essentials|fundamentals|"
    r"beginners?|intermediate|advanced|basics|workshop|bootcamp|academy)(?![a-z])", re.I)
COURSE_JUNK_RE = re.compile(r"(?:downloaded from|follow us|firstuploads|tutsgalaxy|tgx|rarbg|visit|www\.|\.com\.txt$)", re.I)


def _course_part(part):
    text = part.replace("_", " ").replace(".", " ")
    if TUTORIAL_FOLDER_RE.match(part.strip()):
        return False
    return bool(TUTORIAL_RE.search(text) or (tutorial_subject(text) and COURSE_WORD_RE.search(text)))


def course_name(part):
    """'Lynda.com.Songwriting.in.Ableton.Live-QUASAR- [FirstUploads]' -> 'Songwriting in Ableton Live'."""
    text = re.sub(r"\[[^\]]*\]|\{[^}]*\}", " ", part)
    text = re.sub(r"(?i)\.(?:rar|zip|7z)$", "", text)
    text = re.sub(r"(?i)^(?:lynda(?:\.com)?|udemy|linkedin learning|skillshare|pluralsight)[ ._\-]*", "", text.strip())
    text = re.sub(r"[ ._]+", " ", text)
    text = re.sub(r"\s*-[A-Z0-9]{3,}\s*-?\s*$", "", text.strip())  # release group: "-QUASAR-"
    text = re.sub(r"^[\s\-]+|[\s\-]+$", "", text)
    return safe(plain_title(text) or part)


def course_of(folder):
    """(program, course, [sub-folders inside the course]) for a file inside a course folder, else None.
    The outermost course folder wins, so a course's own "Lesson 3" folder stays inside it."""
    parts = [p for p in re.split(r"[\\/]", folder or "") if p]
    for i, part in enumerate(parts):
        if _course_part(part):
            text = part.replace("_", " ").replace(".", " ")
            name = course_name(part)
            # the archive's own name inside the course folder, or the same name again, isn't a sub-folder
            subs = [safe(x) for x in parts[i + 1:] if not _course_part(x) and course_name(x) != name]
            return (tutorial_subject(text) or "Other", name, subs)
    return None


def course_junk(name):
    """A tracker's advert or release note in a course (.nfo, 'Torrent Downloaded from ....txt'): not moved."""
    ext = PurePath(name).suffix.lower()
    return ext in (".nfo", ".url", ".sfv", ".md5", ".exe", ".lnk") or (ext == ".txt" and bool(COURSE_JUNK_RE.search(name)))


SMALL = {"a", "an", "the", "and", "of", "in", "on", "to", "for", "at", "by", "or"}


def clean(name):
    """Dots/underscores to spaces, drop brackets, tidy capitalisation."""
    name = re.sub(r"[._]+", " ", name)
    name = re.sub(r"[\[\(\{].*?[\]\)\}]", " ", name)
    # Stray dashes stuck to one word ("Paragon -the motto-") become spaces;
    # "Spider-Man" and "Show - Subtitle" are left alone.
    name = re.sub(r"(?<=\s)-+(?=\S)|(?<=\S)-+(?=\s|$)", " ", name)
    name = re.sub(r"\s+", " ", name).strip(" -")
    out = []
    for i, w in enumerate(name.split(" ")):
        if w.isupper() and len(w) > 1:
            out.append(w)  # keep acronyms like FBI
        elif i > 0 and w.lower() in SMALL:
            out.append(w.lower())
        else:
            out.append("-".join(p[:1].upper() + p[1:].lower() for p in w.split("-")))
    return " ".join(out)


def safe(part):
    """Make a generated name safe for FAT/exFAT/NTFS drives."""
    part = part.replace(":", " -")
    part = re.sub(r'[<>"/\\|?*]', "", part)
    part = re.sub(r"\s+", " ", part)
    return part.strip().rstrip(". ")


def cut_release(raw):
    """Drop everything from the first release token (1080p, WEB, x264...) on.
    The first word is never cut, so a title like 'Web Therapy' survives."""
    for i, m in enumerate(re.finditer(r"[^ ._\-\[\]\(\)]+", raw)):
        if i > 0 and m.group().lower() in RELEASE_TOKENS:
            return raw[: m.start()]
    return raw


def split_year(raw):
    """'Show.Name.2019' -> ('Show Name', '2019'). Uses the last year that still
    leaves a title in front of it, so '2001.A.Space.Odyssey.1968' -> 1968."""
    padded = " " + cut_release(raw) + " "
    best = None
    for m in YEAR_RE.finditer(padded):
        if clean(padded[: m.start()]):
            best = m
    if best:
        return clean(padded[: best.start()]), best.group(1)
    return clean(cut_release(raw)), None


def sub_lang(stem):
    """'Movie.2019.en' -> ('Movie.2019', '.en'). Only known language codes count."""
    m = re.search(r"\.([a-z]{2,10})$", stem, re.I)
    if m and m.group(1).lower() in LANGS:
        return stem[: m.start()], "." + LANGS[m.group(1).lower()]
    return stem, ""


# Volume / issue / chapter markers: "v01", "Vol. 2", "Volume 3", "#001", "Issue 4",
# "Chapter 5", "c006", "ch.7", "TPB" ... everything from the first one is cut.
# Without one, only a bare number at the very end is the issue ("Saga 054"),
# so "Spider-Man 2099 001" keeps its "2099".
COMIC_MARK_RE = re.compile(
    r"[ ._\-]+(?:v(?:ol(?:ume)?)?\.?\s*\d+|#\s*\d+|issue\s*\d+|chapters?\s*\d+|ch\.?\s*\d+|c\d{2,4}"
    r"|book\s*\d+|part\s*\d+|tpb|omnibus|annual)(?![a-z]).*$", re.I)
COMIC_TRAIL_NUM_RE = re.compile(r"[ ._\-]+\d{1,4}(?:\.\d)?$")


def comic_series(name):
    """'Ironclad v01 (Digital) (Zone).cbz' -> 'Ironclad'; 'Ironclad (2).cbz' -> 'Ironclad';
    'Saga 054 (2018).cbr' -> 'Saga'. Falls back to the cleaned name."""
    stem = name.rsplit(".", 1)[0] if "." in name else name
    stem = LEADING_TAGS_RE.sub("", stem)                    # "[Group] Name" -> "Name"
    stem = re.sub(r"[\[\(\{][^\]\)\}]*[\]\)\}]", " ", stem)   # "(2)", "(Digital)", "[1080p]"
    stem = re.sub(r"[._]+", " ", stem)
    stem = re.sub(r"\s+", " ", stem).strip(" -")
    series = COMIC_MARK_RE.sub("", " " + stem).strip(" -")
    if series == stem:
        series = COMIC_TRAIL_NUM_RE.sub("", " " + stem).strip(" -")
    return safe(clean(series or stem)) or "Unsorted"


def parse_special(stem):
    """'Show OVA - Title' -> (show_raw, number or None, title). None if not a special."""
    spaced = LEADING_TAGS_RE.sub("", re.sub(r"_+", " ", stem))
    m = SPECIAL_RE.match(spaced)
    if not m or not m.group("show").strip(" ._-"):
        return None
    n = m.group("n") or m.group("n2")
    show = re.sub(r"[ ._\-]+\d{1,3}$", "", m.group("show"))  # "Show - 13 OVA" -> "Show"
    rest = re.sub(r"[\[\(\{][^\]\)\}]*[\]\)\}]", " ", spaced[m.end():])  # drop (BD 1080p), [Group]
    title = clean(re.sub(r"[\[\]\(\)\{\}]", " ", cut_release(rest)))
    return show, (int(n) if n else None), title


def parse_credits(stem):
    """'Show (Uncensored Textless Opening) [Group]' -> ('Show', 'Uncensored Textless Opening');
    '[Group] Show - NCOP1 (BD)' -> ('Show', 'NCOP1'). None if no show name is in front."""
    spaced = LEADING_TAGS_RE.sub("", re.sub(r"_+", " ", stem))
    if " " not in spaced.strip():
        spaced = spaced.replace(".", " ")
    m = CREDITS_RE.search(spaced)
    if not m:
        return None
    head = spaced[:m.start()]
    opened = max(head.rfind("("), head.rfind("["))
    if opened > head.rfind(")") and opened > head.rfind("]"):
        close = spaced.find(")" if spaced[opened] == "(" else "]", m.end())
        title = spaced[opened + 1:close if close > 0 else None]
        head = head[:opened]
    else:
        title = re.sub(r"[\[\(\{][^\]\)\}]*[\]\)\}]", " ", spaced[m.start():])
        title = cut_release(title)
    show = re.sub(r"[\[\(].*$", "", head)
    show = re.sub(r"[ ._\-]+\d{1,3}$", "", show.strip(" ._-")).strip(" ._-")
    show = re.sub(r"(?i)[ ._\-]+(?:s\d{1,2}|season[ ._\-]*\d{1,2})$", "", show).strip(" ._-")
    title = clean(re.sub(r"[\[\]\(\)\{\}]", " ", title))
    if not show or not re.search(r"[a-z]", show, re.I):
        return None
    return show, title or m.group(0)


def parse_episode(stem):
    """Return (show_raw, season, episode_tag, absolute) or None.
    absolute is True for fansub numbering, "special" / "special?" for OVAs."""
    m = TV_RE.match(stem) or TV_X_RE.match(stem) or TV_WORDS_RE.match(stem)
    if m and m.group("show").strip(" ._-"):
        ep = "S%02dE%02d" % (int(m.group("s")), int(m.group("e")))
        if m.groupdict().get("e2"):
            ep += "E%02d" % int(m.group("e2"))
        return m.group("show"), int(m.group("s")), ep, False
    sp = parse_special(stem)
    if sp:
        show, n, title = sp
        tag = "S00E%02d" % (n or 1)
        if title:
            tag += " - " + title  # "S00E01 - The Long Road Home": easy to check against TMDb
        return show, 0, tag, ("special" if n else "special?")
    spaced = re.sub(r"_+", " ", stem)
    m = ANIME_RE.match(LEADING_TAGS_RE.sub("", spaced)) or ANIME_EP_RE.match(LEADING_TAGS_RE.sub("", spaced))
    if m and m.group("show").strip(" ._-"):
        return m.group("show"), 1, "S01E%02d" % int(m.group("e")), True
    return None


def episode_tag(name):
    """'S01E05 - Quiet Streets.mka' -> 'S01E05'. Works with no show name in
    front (extras folders often drop it). None when there's no episode number."""
    stem = SITE_PREFIX_RE.sub("", PurePath(name).stem)
    ep = parse_episode("x " + stem)
    return ep[2].split(" ")[0].upper() if ep else None


# Sound that isn't a music album stays where it is.
NOT_MUSIC_FOLDER_RE = re.compile(r"(?i)(?<![a-z])(?:podcasts?|audio ?books?|recordings?|voice ?(?:notes?|recorder|memos?)|"
                                 r"call ?recordings?|whatsapp|telegram|ringtones?|notifications?|alarms?|samples?|"
                                 r"sound ?effects?|sfx)(?![a-z])")
NOT_MUSIC_GENRE_RE = re.compile(r"(?i)podcast|audio ?book|spoken")
GENERIC_FOLDER_RE = re.compile(r"(?i)^(?:music|my music|songs|audio|mp3s?|flacs?|albums?|downloads?|download|complete|completed|"
                               r"incoming|media|new|torrents?|real-debrid|shared?|sdcard|storage|emulated|0|various|misc|"
                               r"[a-z]:|win-lib:|removable|videos?|movies|films|tv|tv shows|1dm|adm|idm)$")
MUSIC_ROOT_RE = re.compile(r"(?i)^(?:music|my music|songs|[a-z]:)$")
DISC_FOLDER_RE = re.compile(r"(?i)^(?:cd|disc|disk)[ ._\-]*(\d{1,2})$")
# "2014.05.06 - Title" and "2013 - Title" are a date and an album, not an artist and an album.
DATED_ALBUM_RE = re.compile(r"^(?:19|20)\d{2}(?:[.\-]\d{1,2}){0,2}\s+-\s+(.+)$")
CATEGORY_FOLDER_RE = re.compile(r"(?i)^(?:albums?|eps?|singles?|lps?|live|compilations?|remix(?:es)?|mixes|mixtapes?|bootlegs?)$")
ARTIST_ALBUM_RE = re.compile(r"^(?P<artist>[^-]+?)\s+-\s+(?:(?:19|20)\d{2}\s+-\s+)?(?P<album>.+)$")
TRACK_PREFIX_RE = re.compile(r"^\d{1,3}(?:[ ._\-]+|$)")
SINGLES = "Singles"
VARIOUS = "Various Artists"


def music_folders(folder):
    """What a file's folders say: (artist, album, disc), each possibly empty."""
    parts = [p for p in re.split(r"[\\/]", folder or "") if p]
    disc = 0
    if parts:
        m = DISC_FOLDER_RE.match(parts[-1])
        if m:
            disc = int(m.group(1))
            parts = parts[:-1]
    parent = parts[-1] if parts else ""
    grand = parts[-2] if len(parts) > 1 else ""
    if len(parts) > 2 and CATEGORY_FOLDER_RE.match(grand):  # Artist\\Singles\\Title
        grand = parts[-3]
    if not parent or GENERIC_FOLDER_RE.match(parent):
        return "", "", disc
    dated = DATED_ALBUM_RE.match(parent)
    if dated:
        parent = dated.group(1)
    else:
        m = ARTIST_ALBUM_RE.match(parent)
        if m:
            return m.group("artist"), m.group("album"), disc
    if not dated and (not grand or MUSIC_ROOT_RE.match(grand)):
        return parent, "", disc  # Music\\Artist or E:\\Artist: straight under the root, so it names the artist
    return ("" if GENERIC_FOLDER_RE.match(grand) else grand), parent, disc


def _names(who, credit):
    """Whether a credit such as "Band & Guest" includes who, as whole words."""
    return bool(who and credit and re.search(r"(?<![^\W_])%s(?![^\W_])" % re.escape(who), credit, re.I))


# Between artists in a credit. "&" and "and" can be inside a band's name, so they only count
# when looking for the artist that a whole album's credits share.
ARTIST_SPLIT_RE = re.compile(r"\s*(?:[/;,]|\s(?:feat\.?|ft\.?|featuring)\s)\s*", re.I)
ALL_ARTISTS_RE = re.compile(r"\s*(?:[/;,&]|\s(?:feat\.?|ft\.?|featuring|and|x|with)\s)\s*", re.I)


def main_artist(credit):
    """The first artist in a credit: "Band/Guest" -> "Band", "Band & Guest" stays as it is."""
    parts = [p for p in ARTIST_SPLIT_RE.split(credit or "") if p.strip()]
    return parts[0].strip() if parts else ""


def shared_artist(credits):
    """The artist named in every credit, for an album with guests on each track, or ""."""
    credits = [c for c in credits if c]
    if not credits:
        return ""
    for name in ALL_ARTISTS_RE.split(credits[0]):
        if name.strip() and all(_names(name.strip(), c) for c in credits):
            return name.strip()
    return ""


def plan_music(name, folder="", tags=None, various=False, album_artist=""):
    """Where a music file belongs: Music/Artist/Album/03 - Title.mp3. Tags come first, then the
    folders and file name. various: this album has several artists, so keep it in one folder.
    album_artist: the artist named on every track of this album.
    Returns (parts or None, "music" or the reason it's left, note)."""
    tags = tags or {}
    stem, ext = PurePath(name).stem, PurePath(name).suffix.lower()
    if name.startswith("."):
        return None, "hidden / still downloading", ""
    if from_youtube(folder):
        return None, "YouTube download that isn't a tutorial - left where it is", ""
    if tags.get("podcast") or NOT_MUSIC_GENRE_RE.search(tags.get("genre", "")) or NOT_MUSIC_FOLDER_RE.search(folder or ""):
        return None, "podcast, audiobook or recording - left where it is", ""
    guessed_artist, guessed_album, guessed_disc = music_folders(folder)
    bare = TRACK_PREFIX_RE.sub("", stem)
    named = ARTIST_ALBUM_RE.match(bare)
    # A folder named after the artist also covers their collaborations: "Band & Guest" in Band's folder.
    credited = tags.get("artist", "")
    if not guessed_artist and guessed_album and _names(guessed_album, credited):
        guessed_artist, guessed_album = guessed_album, ""
    album = tags.get("album") or guessed_album
    if tags.get("albumartist"):
        artist = main_artist(tags["albumartist"])
    elif guessed_artist and _names(guessed_artist, credited):
        artist = guessed_artist
    elif album_artist:
        artist = album_artist
    elif album and (tags.get("compilation") or various):
        artist = VARIOUS
    else:
        artist = main_artist(credited) or guessed_artist or (named.group("artist") if named else "")
    if not artist:
        return None, "music with no artist - add tags or put it in Artist\\Album folders", ""
    title = tags.get("title")
    track, disc = tags.get("track", 0), tags.get("disc", 0) or guessed_disc
    if title and track:
        number = "%d-%02d" % (disc, track) if disc > 1 else "%02d" % track
        file_name = safe("%s - %s" % (number, title)) + ext
    elif title:
        file_name = safe(title) + ext
    else:
        file_name = safe(stem) + ext
    note = "" if tags.get("album") or tags.get("artist") or tags.get("albumartist") else "no tags - named from its folders, check it"
    if album and not tags.get("album") and album.lower() == artist.lower():
        album = ""  # a folder named after the artist isn't an album
    return ("Music", safe(artist), safe(album or SINGLES), file_name), "music", note


ACRONYM_RE = re.compile(r"^[A-Za-z]{3,8}$")


def initials(title):
    """"IASIP" from "It's Always Sunny in Philadelphia": the first letter of every word, upper case."""
    return "".join(w[0] for w in re.findall(r"[A-Za-z0-9]+(?:'[A-Za-z]+)?", title or "")).upper()


def is_acronym(show):
    """A show name that is one short word, like IASIP or HIMYM (a file named by its fans' short name)."""
    return bool(ACRONYM_RE.match(show or "")) and (show.isupper() or len(show) <= 6)


def show_from_folder(show, folder):
    """The full show name for a short one like "IASIP", taken from the download's folder name
    ("It's Always Sunny in Philadelphia Season 1-14 - threesixtyp") when its words start with those letters.
    None when the folder doesn't say."""
    if not is_acronym(show):
        return None
    parent = re.split(r"[\\/]", (folder or "").rstrip("/\\"))[-1]
    name = re.split(r"(?i)\s+(?:season|series|s\d{1,2}\b|complete)|\s*[\[(]|\s+-\s+", parent)[0].strip(" .-_")
    name = re.sub(r"[._]+", " ", name).strip()
    return name if name and " " in name and initials(name) == show.upper() else None


def plan_name(name, folder=""):
    """Where a file called `name` belongs, relative to the destination.
    `folder` is the folder it's in (only used to decide if a PDF is a comic).
    Returns (parts or None, kind, note). kind is 'tv', 'movie', 'comic' or 'tutorial' when
    parts is set, otherwise the reason it was skipped."""
    if re.search(r"%[0-9a-fA-F]{2}", name):
        # URL-encoded name from an early version: "%5bsubcrew%5dtinman" -> "[subcrew]tinman"
        try:
            from urllib.parse import unquote
        except ImportError:
            from urllib import unquote
        name = unquote(name)
    path = PurePath(name)
    ext = path.suffix.lower()
    stem = path.stem

    if name.startswith("."):
        return None, "hidden / still downloading", ""
    if ext in COMICS:
        return ("Comics", comic_series(name), name), "comic", ""
    if ext in BOOKS:
        if COMIC_FOLDER_RE.search(folder or ""):
            return ("Comics", comic_series(name), name), "comic", ""
        return None, "document - PDFs/EPUBs are only moved from a Comics or Manga folder", ""
    if ext not in VIDEO and ext not in SUBS:
        return None, "not video/sub/comic", ""
    if ext in VIDEO and re.search(r"(?<![a-z])sample(?![a-z])", stem.lower()) if from_youtube(folder) else \
            ext in VIDEO and "sample" in stem.lower():
        return None, "sample", ""
    if ext in VIDEO or ext in SUBS:
        tut = plan_tutorial(name, stem, folder)
        if tut and not (TV_RE.search(stem) or TV_X_RE.search(stem)):
            return tut, "tutorial", ""
        if from_youtube(folder):
            return None, "YouTube download that isn't a tutorial - left where it is", ""
        if ext in VIDEO and music_video(stem, youtube=False) and not (TV_RE.search(stem) or TV_X_RE.search(stem)):
            return (MUSIC_VIDEOS, safe(plain_title(stem)) + ext), "tutorial", ""  # a concert or set, not a film
    if ext in VIDEO and CREDITS_RE.search(stem) and not re.search(r"(?i)(?<![a-z0-9])s00e\d{2}(?![0-9])", stem):
        # (an S00Exx name is one already sorted into Specials: treated like any episode below)
        cr = parse_credits(SITE_PREFIX_RE.sub("", stem))
        parent = re.split(r"[\\/]", (folder or "").rstrip("/\\"))[-1]
        if not cr and parent and not GENERIC_FOLDER_RE.match(parent) and not re.match(r"(?i)^(?:extras?|bonus|specials?|nc|credits|op|ed|"
                                              r"openings?|endings?|ncop|nced|creditless|textless|videos?|clips?|"
                                              r"misc|others?|featurettes?|bonus features|extra features)$", parent):
            cr = parse_credits(SITE_PREFIX_RE.sub("", parent) + " " + stem)
        if not cr:
            return None, "opening/ending credits clip (no show name in the file name)", ""
        show, year = split_year(cr[0])
        show_dir = safe("%s (%s)" % (show, year) if year else show)
        new = safe("%s S00E01 - %s" % (show_dir, cr[1])) + ext
        return ("TV", show_dir, "Season 00", new), "tv", CREDITS_NOTE

    stem = SITE_PREFIX_RE.sub("", stem)
    lang = ""
    if ext in SUBS:
        stem, lang = sub_lang(stem)

    ep = parse_episode(stem)
    if ep:
        show_raw, season, tag, absolute = ep
        show, year = split_year(show_raw)
        show = show_from_folder(show, folder) or show  # "IASIP S01E01" in an It's Always Sunny ... folder
        show_dir = safe("%s (%s)" % (show, year) if year else show)
        new = safe("%s %s%s" % (show_dir, tag, lang)) + ext
        note = {True: "absolute episode number - check the season",
                "special": SPECIAL_NOTE, "special?": SPECIAL_GUESS_NOTE}.get(absolute, "")
        return ("TV", show_dir, "Season %02d" % season, new), "tv", note

    title, year = split_year(stem)
    if year:
        movie = safe("%s (%s)" % (title, year))
        return ("Movies", movie, movie + lang + ext), "movie", ""

    return None, "can't tell TV vs movie - rename by hand", ""
