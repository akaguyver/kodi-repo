"""One search for torrents and YouTube (the 2.0 Search page): which torrent category the ticks mean, results from
both in one list, the six sort buttons, and what a pasted link is. Pure: no Kodi imports.

A result is {"kind": "tor" | "yt", "key", "title", "meta", "seeders", "size", "added", "views", "raw"}.
"""
import re

# category ticks -> the torrent category (torrents.GROUPS) to search; Tutorials and Comics search everything
CAT_GROUP = {"tv": "TV", "movies": "Movies", "music": "Music", "tutorials": "Everything", "comics": "Everything"}


def torrent_group(cats, groups):
    """The one torrent category the ticks ask for (a ticked one that exists), else Everything."""
    picked = [CAT_GROUP[c] for c in cats if c in CAT_GROUP]
    named = [g for g in picked if g in groups and g != "Everything"]
    if len(set(named)) == 1 and len(set(picked)) == 1:
        return named[0]
    return "Everything" if "Everything" in groups else (named[0] if named else sorted(groups)[0])


def source_for(cats, current=None):
    """Tutorials starts on Both; otherwise what was picked, else Both."""
    if "tutorials" in cats and current is None:
        return "both"
    return current or "both"


def _views(v):
    try:
        v = int(v)
    except (TypeError, ValueError):
        return ""
    for unit, k in (("B", 1e9), ("M", 1e6), ("K", 1e3)):
        if v >= k:
            return ("%.1f%s views" % (v / k, unit)).replace(".0", "")
    return "%d views" % v


def _mins(sec):
    try:
        sec = int(sec)
    except (TypeError, ValueError):
        return ""
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


def _size(n):
    n = float(n or 0)
    for unit, k in (("TB", 1e12), ("GB", 1e9), ("MB", 1e6), ("KB", 1e3)):
        if n >= k:
            return "%.1f %s" % (n / k, unit)
    return ""


def key_of(title):
    return re.sub(r"[^a-z0-9]+", "", (title or "").lower())


def from_torrent(h, cat_label=""):
    meta = [cat_label, _size(h.get("size")), "%d seeders" % (h.get("seeders") or 0), h.get("source") or ""]
    if h.get("page") and not h.get("magnet") and not h.get("torrent_url"):
        meta = [cat_label, "file-host links", h.get("source") or ""]
    return {"kind": "tor", "key": "t:" + (h.get("hash") or h.get("torrent_url") or h.get("page") or h.get("title", "")),
            "title": h.get("title") or "?", "meta": "  ·  ".join(m for m in meta if m),
            "seeders": h.get("seeders") or 0, "size": h.get("size") or 0, "added": h.get("added") or 0, "views": 0,
            "raw": h}


def from_youtube(x):
    meta = [x.get("channel") or "", _mins(x.get("duration")) or "playlist/live", _views(x.get("views")),
            x.get("published") or ""]
    return {"kind": "yt", "key": "y:" + (x.get("url") or x.get("id") or x.get("title", "")), "title": x.get("title") or "?",
            "meta": "  ·  ".join(m for m in meta if m), "seeders": 0, "size": 0,
            "added": x.get("timestamp") or 0, "views": x.get("views") or 0, "raw": x}


def merged(tor, yt):
    """Best match: the two lists woven together, each keeping its own order (YouTube's relevance, the
    torrents by seeders)."""
    tor = sorted(tor, key=lambda r: -r["seeders"])
    out = []
    for i in range(max(len(tor), len(yt))):
        if i < len(yt):
            out.append(yt[i])
        if i < len(tor):
            out.append(tor[i])
    return out


def sorted_results(results, how):
    if how == "seeders":
        return sorted(results, key=lambda r: (r["kind"] != "tor", -r["seeders"]))
    if how == "newest":
        return sorted(results, key=lambda r: (not r["added"], -(r["added"] or 0)))
    if how == "largest":
        return sorted(results, key=lambda r: (not r["size"], -(r["size"] or 0)))
    if how == "views":
        return sorted(results, key=lambda r: (r["kind"] != "yt", -(r["views"] or 0)))
    if how == "name":
        return sorted(results, key=lambda r: r["title"].lower())
    return list(results)


def summary(results):
    yt = sum(1 for r in results if r["kind"] == "yt")
    tor = len(results) - yt
    bits = ["%d result%s" % (len(results), "" if len(results) == 1 else "s")]
    if yt:
        bits.append("%d YouTube" % yt)
    if tor:
        bits.append("%d torrent%s" % (tor, "" if tor == 1 else "s"))
    return "  ·  ".join(bits) if results else ""


def link_kind(text):
    """What a pasted line is: "youtube", "playlist", "magnet", "web" (a file host or a page of links) or ""."""
    t = (text or "").strip()
    if t.lower().startswith("magnet:"):
        return "magnet"
    if re.match(r"^(https?://)?(www\.|m\.|music\.)?(youtube\.com|youtu\.be)/", t, re.I) or re.match(r"^[\w-]{11}$", t):
        return "playlist" if "list=" in t else "youtube"
    if re.match(r"^(https?://)?[\w-]+(\.[\w-]+)+(/\S*)?$", t, re.I) and " " not in t:
        return "web"
    return ""
