"""Tag Studio (ticket yac2): the engine behind the app's tag studio, and later the add-on's. Pure Python, no Kodi
or Android imports. Everything here plans changes ({uri: {field: new value}}) and shows them first; the caller
writes a plan with musictags.write_fields as one undo batch.

Features (see docs/plans/2026-11-21-tag-studio-plan.md): the song table and its smart views, search with
field:value, several songs edited together (<different>), batch actions (case, replace, regex, trim, remove,
feat., artists, track numbers, key format, BPM), tags from file names and file names from tags, a quality
report and CSV export."""
import csv
import io
import re

FIELDS = ("title", "artist", "album", "albumartist", "genre", "year", "track", "disc", "composer", "comment",
          "bpm", "key", "energy", "label", "isrc", "grouping")
LABELS = {"title": "Title", "artist": "Artist", "album": "Album", "albumartist": "Album artist", "genre": "Genre",
          "year": "Year", "track": "Track", "disc": "Disc", "composer": "Composer", "comment": "Comment",
          "bpm": "BPM", "key": "Key", "energy": "Energy", "label": "Label", "isrc": "ISRC", "grouping": "Grouping"}
DIFFERENT = "<different>"
# What a DJ library needs on every song; the table flags what's missing.
NEEDED = ("title", "artist", "album", "genre", "year", "bpm", "key")


# ---------- table and views ----------

def table_rows(tags_by_uri):
    """[{uri, name, format, <fields>, missing: [...]}], in artist / album / track order."""
    rows = []
    for uri, t in tags_by_uri.items():
        t = t or {}
        row = {"uri": uri, "name": t.get("name") or uri.rsplit("/", 1)[-1], "format": (t.get("format") or "").lower()}
        for f in FIELDS:
            row[f] = ("%s" % t.get(f)).strip() if t.get(f) not in (None, "") else ""
        row["has_art"] = bool(t.get("has_art"))
        row["missing"] = [f for f in NEEDED if not row[f]]
        rows.append(row)
    rows.sort(key=lambda r: (r["albumartist"].lower() or r["artist"].lower(), r["album"].lower(), _num(r["disc"]),
                             _num(r["track"]), r["title"].lower()))
    return rows


def _num(value):
    m = re.match(r"\s*(\d+)", value or "")
    return int(m.group(1)) if m else 0


def album_key(row):
    return ((row.get("albumartist") or row.get("artist") or "").lower(), (row.get("album") or "").lower())


def views(rows):
    """Smart views: {name: [uri, ...]}. 'album_disagrees' = songs of an album whose album artist or year differ."""
    out = {"all": [r["uri"] for r in rows]}
    for f in ("genre", "key", "bpm", "year", "album"):
        out["no_" + f] = [r["uri"] for r in rows if not r[f]]
    out["no_art"] = [r["uri"] for r in rows if not r.get("has_art")]
    albums = {}
    for r in rows:
        if r["album"]:
            albums.setdefault(r["album"].lower(), []).append(r)
    bad = []
    for songs in albums.values():
        if len(set(s["albumartist"] for s in songs)) > 1 or len(set(s["year"][:4] for s in songs)) > 1:
            bad.extend(s["uri"] for s in songs)
    out["album_disagrees"] = bad
    return out


SEARCH_RE = re.compile(r'(\w+):("([^"]*)"|(\S*))|"([^"]*)"|(\S+)')


def search(rows, query):
    """Free words match title, artist, album or file name; field:value matches that field (contains, case-blind);
    field: with nothing after it finds songs where it's empty. All parts must match."""
    parts = []
    for m in SEARCH_RE.finditer(query or ""):
        if m.group(1) and m.group(1).lower() in FIELDS + ("format", "name"):
            parts.append((m.group(1).lower(), (m.group(3) if m.group(3) is not None else m.group(4)).lower()))
        else:
            word = m.group(5) if m.group(5) is not None else (m.group(6) or m.group(0))
            parts.append((None, word.lower()))

    def ok(r):
        for field, value in parts:
            if field:
                have = (r.get(field) or "").lower()
                if (value == "" and have) or (value and value not in have):
                    return False
            elif not any(value in (r.get(f) or "").lower() for f in ("title", "artist", "album", "name")):
                return False
        return True
    return [r for r in rows if ok(r)]


# ---------- several songs at once ----------

def shared(tags_list):
    """{field: value} where every song agrees, else DIFFERENT."""
    out = {}
    for f in FIELDS:
        values = set(("%s" % (t.get(f) or "")).strip() for t in tags_list)
        out[f] = values.pop() if len(values) == 1 else DIFFERENT
    return out


def plan_edit(tags_by_uri, typed):
    """typed: {field: text} from the editor. A field left at <different> isn't touched; an empty one is cleared.
    Returns {uri: {field: new}} with only real changes."""
    plan = {}
    for uri, t in tags_by_uri.items():
        for f, value in typed.items():
            if f not in FIELDS or value == DIFFERENT:
                continue
            value = (value or "").strip()
            if value != ("%s" % (t.get(f) or "")).strip():
                plan.setdefault(uri, {})[f] = value
    return plan


def paste_plan(source_tags, tags_by_uri, fields):
    """Copy the chosen fields of one song onto others."""
    return plan_edit(tags_by_uri, dict((f, ("%s" % (source_tags.get(f) or "")).strip()) for f in fields))


def preview(tags_by_uri, plan):
    """[{uri, field, old, new}] for showing a plan before it's written."""
    out = []
    for uri, changes in plan.items():
        old = tags_by_uri.get(uri) or {}
        for f in FIELDS:
            if f in changes:
                out.append({"uri": uri, "field": f, "old": ("%s" % (old.get(f) or "")).strip(), "new": changes[f]})
    return out


# ---------- actions ----------

SMALL_WORDS = set("a an and as at but by en for from if in into nor of on or per the to vs via with".split())
ROMAN_RE = re.compile(r"^(?=[mdclxvi]+$)m{0,3}(cm|cd|d?c{0,3})(xc|xl|l?x{0,3})(ix|iv|v?i{0,3})$", re.I)
KEEP_RE = re.compile(r"^(?:[A-Z0-9]{2,}|[A-Z](?:\.[A-Z])+\.?|\w*\d\w*|DJ|MC|UK|USA)$")


def _cap(word):
    for i, ch in enumerate(word):
        if ch.isalpha():
            return word[:i] + ch.upper() + word[i + 1:].lower()
    return word


def title_case(text):
    """Title Case: small words lower inside the title, roman numerals and ALLCAPS acronyms kept, the word after
    an opening bracket or a dash capitalised. "dj snake - lean on (feat. mø)" -> "DJ Snake - Lean On (feat. MØ)"."""
    words = re.split(r"(\s+)", text or "")
    out = []
    first = True
    real = [i for i, w in enumerate(words) if w and not w.isspace()]
    # The last word, and the word before a bracket or a dash, is capitalised too ("Lean On (feat. X)").
    ends = set(real[-1:]) | set(a for a, b in zip(real, real[1:]) if words[b][:1] in "([{" or words[b] in ("-", "–", "—"))
    for i, w in enumerate(words):
        if not w or w.isspace():
            out.append(w)
            continue
        core = w.strip("([{\"'")
        lead = w[:len(w) - len(core)]
        bare = re.sub(r"[^\w.]", "", core)
        if lead in ("(", "[", "{"):
            first = True
        if re.match(r"^(?:feat|ft)\.?$", bare, re.I):
            out.append(lead + core.lower())
        elif KEEP_RE.match(bare) and bare.upper() == bare and len(bare) > 1:
            out.append(w)
        elif ROMAN_RE.match(bare) and len(bare) > 1 and bare.lower() not in ("mix", "di", "dim", "mid", "civil"):
            out.append(lead + core.upper())
        elif not first and i not in ends and bare.lower() in SMALL_WORDS:
            out.append(lead + core.lower())
        elif re.match(r"^(?:dj|mc)$", bare, re.I):
            out.append(lead + core.upper())
        else:
            out.append(lead + "-".join(_cap(p) for p in core.split("-")))
        first = core.endswith((":", "-")) or w in ("-", "–", "—")
    return "".join(out)


def sentence_case(text):
    t = (text or "").lower()
    return re.sub(r"^(\W*)(\w)", lambda m: m.group(1) + m.group(2).upper(), t)


CASES = {"title": title_case, "sentence": sentence_case, "upper": lambda s: (s or "").upper(),
         "lower": lambda s: (s or "").lower()}
FEAT_RE = re.compile(r"\s*[(\[]\s*(?:feat\.?|ft\.?|featuring)\s+([^)\]]+)[)\]]|\s+(?:feat\.?|ft\.?|featuring)\s+(.+)$", re.I)
ARTIST_SPLIT = re.compile(r"\s*(?:;|,|/|\s&\s|\s(?:x|vs\.?|and)\s)\s*", re.I)


def split_artists(text):
    return [a for a in (p.strip() for p in ARTIST_SPLIT.split(text or "")) if a]


def _feat_to_artist(t):
    title = t.get("title") or ""
    m = FEAT_RE.search(title)
    if not m:
        return {}
    guests = split_artists(m.group(1) or m.group(2))
    have = split_artists(t.get("artist") or "")
    lower = [a.lower() for a in have]
    artists = have + [g for g in guests if g.lower() not in lower]
    return {"title": (title[:m.start()] + title[m.end():]).strip(), "artist": "; ".join(artists)}


def _feat_to_title(t):
    artists = split_artists(t.get("artist") or "")
    if len(artists) < 2 or FEAT_RE.search(t.get("title") or ""):
        return {}
    return {"artist": artists[0], "title": "%s (feat. %s)" % ((t.get("title") or "").strip(), " & ".join(artists[1:]))}


KEYS_MUSICAL = {"1A": "Abm", "2A": "Ebm", "3A": "Bbm", "4A": "Fm", "5A": "Cm", "6A": "Gm", "7A": "Dm", "8A": "Am",
                "9A": "Em", "10A": "Bm", "11A": "F#m", "12A": "Dbm", "1B": "B", "2B": "F#", "3B": "Db", "4B": "Ab",
                "5B": "Eb", "6B": "Bb", "7B": "F", "8B": "C", "9B": "G", "10B": "D", "11B": "A", "12B": "E"}
ENHARMONIC = {"G#m": "Abm", "D#m": "Ebm", "A#m": "Bbm", "Gbm": "F#m", "C#m": "Dbm", "Cb": "B", "Gb": "F#",
              "C#": "Db", "G#": "Ab", "D#": "Eb", "A#": "Bb", "Fb": "E", "E#": "F", "B#": "C"}
KEYS_CAMELOT = dict((v, k) for k, v in KEYS_MUSICAL.items())


def _parse_key(text):
    """'8A', 'Am', 'A minor', 'A min', '8A - Am' -> '8A' or None."""
    t = (text or "").strip()
    m = re.match(r"^(1[0-2]|[1-9])\s*([ABab])\b", t)
    if m:
        return m.group(1) + m.group(2).upper()
    m = re.match(r"^([A-Ga-g])\s*([#b♯♭]?)\s*(m|min|minor|maj|major)?\b", t)
    if not m:
        return None
    name = m.group(1).upper() + m.group(2).replace("♯", "#").replace("♭", "b") + ("m" if (m.group(3) or "").lower().startswith("m") and (m.group(3) or "").lower() not in ("maj", "major") else "")
    name = ENHARMONIC.get(name, name)
    return KEYS_CAMELOT.get(name)


def key_as(text, style):
    """A key written as 'musical' (Am), 'camelot' (8A) or 'both' (8A - Am); unknown keys are left alone."""
    cam = _parse_key(text)
    if not cam:
        return text
    return {"musical": KEYS_MUSICAL[cam], "camelot": cam, "both": "%s - %s" % (cam, KEYS_MUSICAL[cam])}[style]


def plan_action(tags_by_uri, action, order=None):
    """One batch action over the songs; returns {uri: {field: new}} (only real changes).
    action: {"do": "case", "fields": [...], "style": "title"} | {"do": "replace", "fields", "find", "with",
    "regex": bool, "match_case": bool} | {"do": "trim", "fields"} | {"do": "remove", "fields"} |
    {"do": "feat", "to": "artist"|"title"} | {"do": "artists", "join": "; "} |
    {"do": "number", "zeros": bool, "total": bool, "start": 1} | {"do": "key", "style": "musical"|"camelot"|"both"} |
    {"do": "bpm", "decimals": 0}
    order: the uris in the order to number them (the table's order)."""
    do = action.get("do")
    fields = [f for f in (action.get("fields") or ["title", "artist", "album", "albumartist"]) if f in FIELDS]
    uris = list(order or tags_by_uri.keys())
    plan = {}

    def put(uri, field, value):
        old = ("%s" % (tags_by_uri[uri].get(field) or "")).strip()
        if value is not None and value != old:
            plan.setdefault(uri, {})[field] = value

    if do == "replace" and action.get("regex"):
        try:
            rx = re.compile(action.get("find") or "", 0 if action.get("match_case") else re.I)
        except re.error as e:
            raise ValueError("That pattern doesn't work: %s" % e)
    for n, uri in enumerate(uris):
        t = tags_by_uri[uri]
        if do == "case":
            fn = CASES[action.get("style") or "title"]
            for f in fields:
                if t.get(f):
                    put(uri, f, fn("%s" % t[f]))
        elif do == "replace":
            find, new = action.get("find") or "", action.get("with") or ""
            for f in fields:
                v = "%s" % (t.get(f) or "")
                if not v or not find:
                    continue
                if action.get("regex"):
                    put(uri, f, rx.sub(new.replace("$", "\\"), v).strip())
                elif action.get("match_case"):
                    put(uri, f, v.replace(find, new).strip())
                else:
                    put(uri, f, re.sub(re.escape(find), lambda m: new, v, flags=re.I).strip())
        elif do == "trim":
            for f in fields:
                if t.get(f):
                    put(uri, f, re.sub(r"\s+", " ", "%s" % t[f]).strip())
        elif do == "remove":
            for f in fields:
                if t.get(f):
                    put(uri, f, "")
        elif do == "feat":
            for f, v in (_feat_to_artist(t) if action.get("to", "artist") == "artist" else _feat_to_title(t)).items():
                put(uri, f, v)
        elif do == "artists":
            for f in [x for x in fields if x in ("artist", "albumartist", "composer")] or ["artist"]:
                if t.get(f):
                    put(uri, f, (action.get("join") or "; ").join(split_artists("%s" % t[f])))
        elif do == "number":
            k = (action.get("start") or 1) + n
            width = len(str(len(uris) + (action.get("start") or 1) - 1)) if action.get("zeros") else 1
            put(uri, "track", ("%0*d" % (max(width, 2 if action.get("zeros") else 1), k)) + ("/%d" % len(uris) if action.get("total") else ""))
        elif do == "key":
            if t.get("key"):
                put(uri, "key", key_as("%s" % t["key"], action.get("style") or "musical"))
        elif do == "bpm":
            try:
                v = float("%s" % t.get("bpm"))
            except ValueError:
                continue
            d = int(action.get("decimals") or 0)
            put(uri, "bpm", ("%.*f" % (d, v)) if d else str(int(round(v))))
        else:
            raise ValueError("unknown action %r" % do)
    return plan


# ---------- file names ----------

PATTERN_RE = re.compile(r"%(\w+)%")


def _pattern_regex(pattern):
    """'%artist% - %title%' -> a regex with one named group per field; %dummy% skips a part."""
    out, pos, names = [], 0, []
    for m in PATTERN_RE.finditer(pattern):
        out.append(re.escape(pattern[pos:m.start()]))
        name = m.group(1).lower()
        if name in FIELDS and name not in names:
            names.append(name)
            out.append("(?P<%s>%s)" % (name, r"\d+" if name in ("track", "disc", "year") else ".+?"))
        else:
            out.append(".+?")
        pos = m.end()
    out.append(re.escape(pattern[pos:]))
    return re.compile("^" + "".join(out) + "$"), names


def from_filename(name, pattern):
    """{field: value} read from a file name (without the extension), or {} when it doesn't fit the pattern."""
    stem = re.sub(r"\.[A-Za-z0-9]{2,4}$", "", name)
    rx, _ = _pattern_regex(pattern)
    m = rx.match(stem.replace("_", " ").strip())
    if not m:
        return {}
    return dict((k, v.strip()) for k, v in m.groupdict().items() if v and v.strip())


def plan_from_filenames(tags_by_uri, pattern):
    """(plan, didnt_fit): tags from each song's file name."""
    plan, misses = {}, []
    for uri, t in tags_by_uri.items():
        found = from_filename(t.get("name") or uri.rsplit("/", 1)[-1], pattern)
        if not found:
            misses.append(uri)
            continue
        for f, v in found.items():
            if v != ("%s" % (t.get(f) or "")).strip():
                plan.setdefault(uri, {})[f] = v
    return plan, misses


UNSAFE = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def filename_from(tags, pattern, ext):
    """'%track% %artist% - %title%' -> '03 Artist - Title.mp3'. A missing field leaves its part out; track and disc
    get two digits. Characters a file name can't have are replaced."""
    def val(m):
        f = m.group(1).lower()
        v = ("%s" % (tags.get(f) or "")).strip()
        if f in ("track", "disc") and v:
            v = "%02d" % _num(v)
        return UNSAFE.sub("_" if f != "artist" else ", ", v) if f != "title" else UNSAFE.sub(" ", v)
    name = PATTERN_RE.sub(val, pattern)
    name = re.sub(r"\s+", " ", re.sub(r"(?:\s*-\s*)+$|^(?:\s*-\s*)+", "", name)).strip(" .")
    name = re.sub(r"\s-\s(?:-\s)+", " - ", name)
    return (name or "Untitled") + ext


def plan_renames(tags_by_uri, pattern):
    """[{uri, old, new}] for files whose name would change; a clash inside the folder gets ' (2)'."""
    out, taken = [], set()
    for uri, t in tags_by_uri.items():
        old = t.get("name") or uri.rsplit("/", 1)[-1]
        ext = re.search(r"\.[A-Za-z0-9]{2,4}$", old)
        new = filename_from(t, pattern, ext.group(0) if ext else "")
        base, n = new, 2
        while new.lower() in taken:
            new = re.sub(r"(\.[A-Za-z0-9]{2,4})?$", lambda m: " (%d)%s" % (n, m.group(1) or ""), base, count=1)
            n += 1
        taken.add(new.lower())
        if new != old:
            out.append({"uri": uri, "old": old, "new": new})
    return out


# ---------- quality ----------

def quality_report(rows):
    """{missing: {field: n}, album_disagrees: [{album, field, values}], duplicates: [[uri, ...]], total}."""
    missing = dict((f, sum(1 for r in rows if not r[f])) for f in NEEDED)
    missing["art"] = sum(1 for r in rows if not r.get("has_art"))
    albums = {}
    for r in rows:
        if r["album"]:
            albums.setdefault(r["album"], []).append(r)
    disagree = []
    for album, songs in sorted(albums.items()):
        for f in ("albumartist", "year", "genre"):
            values = sorted(set((s[f][:4] if f == "year" else s[f]) for s in songs))
            if len(values) > 1:
                disagree.append({"album": album, "field": f, "values": values})
    groups = {}
    for r in rows:
        key = ("isrc", r["isrc"].upper()) if r["isrc"] else \
            ("song", re.sub(r"\W+", "", r["artist"].lower()), re.sub(r"\W+", "", re.sub(r"\(.*?\)|\[.*?\]", "", r["title"].lower())))
        if key[-1]:
            groups.setdefault(key, []).append(r["uri"])
    dups = [u for u in groups.values() if len(u) > 1]
    return {"total": len(rows), "missing": missing, "album_disagrees": disagree, "duplicates": dups}


def to_csv(rows, fields=None):
    fields = list(fields or ("artist", "title", "album", "albumartist", "genre", "year", "track", "bpm", "key",
                             "energy", "label", "isrc"))
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["File"] + [LABELS.get(f, f) for f in fields])
    for r in rows:
        w.writerow([r.get("name", "")] + [r.get(f, "") for f in fields])
    return out.getvalue()
