"""Tag Studio online lookups (ticket yac2, phase 2): cover pictures, an album's details from MusicBrainz lined up
with the songs, and lyrics from LRCLIB. Pure Python: every request goes through get(url, headers) -> bytes, which
the app (its fetch) or the add-on supplies, so tests use canned replies. Nothing here writes a file; the results
become a Tag Studio plan or an "art" change for musictags."""
import json
import re
import time
from urllib.parse import quote, urlencode

MB = "https://musicbrainz.org/ws/2"
CAA = "https://coverartarchive.org"
JSON = {"Accept": "application/json"}


def _json(get, url, headers=JSON):
    raw = get(url, headers)
    try:
        return json.loads(raw.decode("utf-8") if isinstance(raw, bytes) else raw)
    except ValueError:
        return {}


SAME_ALBUM_WORDS = re.compile(r"\b(?:deluxe|super|remaster(?:ed)?|expanded|anniversary|bonus|special|edition|version|"
                              r"\d+(?:st|nd|rd|th)|(?:19|20)\d\d)\b")


def _norm(text):
    """An album name to compare: "Random Access Memories (10th Anniversary Edition)" is the same album, but
    "(Drumless Edition)" isn't, so only words that mean another release of the same record are dropped."""
    t = SAME_ALBUM_WORDS.sub(" ", (text or "").lower())
    return re.sub(r"[^a-z0-9]+", "", t)


def _lucene(text):
    return re.sub(r'([+\-!(){}\[\]^"~*?:\\/]|&&|\|\|)', r"\\\1", text or "")


# ---------- covers ----------

def covers(get, artist, album):
    """Front cover choices, best sources first: [{"source", "url", "size", "title"}]. The album name has to agree
    (case, punctuation and "Deluxe"/"Remastered" aside), so a different album's picture isn't offered."""
    want = _norm(album)
    out = []
    it = _json(get, "https://itunes.apple.com/search?" + urlencode({"term": "%s %s" % (artist, album), "entity": "album", "limit": 8}))
    for r in it.get("results") or []:
        art = r.get("artworkUrl100") or ""
        if art and _norm(r.get("collectionName")) == want:
            out.append({"source": "Apple Music", "url": art.replace("100x100bb", "1200x1200bb"), "size": "1200x1200",
                        "title": "%s - %s" % (r.get("artistName", ""), r.get("collectionName", ""))})
    dz = _json(get, "https://api.deezer.com/search/album?" + urlencode({"q": "%s %s" % (artist, album), "limit": 8}))
    for r in dz.get("data") or []:
        if r.get("cover_xl") and _norm(r.get("title")) == want:
            out.append({"source": "Deezer", "url": r["cover_xl"], "size": "1000x1000",
                        "title": "%s - %s" % ((r.get("artist") or {}).get("name", ""), r.get("title", ""))})
    q = 'releasegroup:"%s" AND artist:"%s"' % (_lucene(album), _lucene(artist))
    mb = _json(get, "%s/release-group/?%s" % (MB, urlencode({"query": q, "fmt": "json", "limit": 3})))
    for g in mb.get("release-groups") or []:
        if _norm(g.get("title")) == want and g.get("id"):
            out.append({"source": "Cover Art Archive", "url": "%s/release-group/%s/front-1200" % (CAA, g["id"]),
                        "size": "up to 1200", "title": "%s - %s" % (_credit(g.get("artist-credit")), g.get("title", ""))})
    seen, unique = set(), []
    for c in out:
        if c["url"] not in seen:
            seen.add(c["url"])
            unique.append(c)
    return unique


def download_picture(get, url, max_bytes=8 * 1024 * 1024):
    """The picture's bytes, checked to be a JPEG or PNG (ValueError otherwise, or when it's too big to keep in
    every song's tags)."""
    data = get(url, {"Accept": "image/jpeg, image/png"})
    if isinstance(data, str):
        data = data.encode("latin-1")
    if data[:3] != b"\xff\xd8\xff" and data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("that address didn't give a JPEG or PNG picture")
    if len(data) > max_bytes:
        raise ValueError("the picture is %d MB, too big to put in every song" % (len(data) // (1024 * 1024)))
    return data


# ---------- album details (MusicBrainz) ----------

def _credit(credits):
    return "".join((c.get("name") or (c.get("artist") or {}).get("name", "")) + (c.get("joinphrase") or "")
                   for c in credits or []).strip()


def albums(get, artist, album):
    """MusicBrainz releases that could be this album: [{"id", "title", "artist", "date", "country", "tracks",
    "label", "format"}], the closest names first."""
    q = 'release:"%s" AND artist:"%s"' % (_lucene(album), _lucene(artist))
    r = _json(get, "%s/release/?%s" % (MB, urlencode({"query": q, "fmt": "json", "limit": 10})))
    want = _norm(album)
    out = []
    for rel in r.get("releases") or []:
        media = rel.get("media") or []
        out.append({"id": rel.get("id"), "title": rel.get("title", ""), "artist": _credit(rel.get("artist-credit")),
                    "date": rel.get("date", ""), "country": rel.get("country", ""),
                    "tracks": rel.get("track-count") or sum(m.get("track-count", 0) for m in media),
                    "label": ((rel.get("label-info") or [{}])[0].get("label") or {}).get("name", ""),
                    "format": " + ".join(m.get("format", "") for m in media if m.get("format"))})
    out.sort(key=lambda x: (_norm(x["title"]) != want, x["date"] or "9999"))
    return out


def album_tracks(get, release_id, wait=time.sleep):
    """One release in full: {"album", "albumartist", "year", "label", "discs", "tracks": [{"disc", "track",
    "total", "title", "artist", "length_ms", "isrc"}]}. MusicBrainz allows one request a second, so this waits a
    second first (the search came just before)."""
    wait(1)
    rel = _json(get, "%s/release/%s?inc=recordings+isrcs+artist-credits+labels&fmt=json" % (MB, quote(release_id)))
    media = rel.get("media") or []
    tracks = []
    for m in media:
        total = m.get("track-count") or len(m.get("tracks") or [])
        for t in m.get("tracks") or []:
            rec = t.get("recording") or {}
            tracks.append({"disc": m.get("position", 1), "track": t.get("position") or int(re.sub(r"\D", "", t.get("number") or "0") or 0),
                           "total": total, "title": t.get("title") or rec.get("title", ""),
                           "artist": _credit(t.get("artist-credit") or rec.get("artist-credit")),
                           "length_ms": t.get("length") or rec.get("length"),
                           "isrc": ((rec.get("isrcs") or [""])[0] or "").upper()})
    return {"album": rel.get("title", ""), "albumartist": _credit(rel.get("artist-credit")),
            "year": (rel.get("date") or "")[:4], "label": ((rel.get("label-info") or [{}])[0].get("label") or {}).get("name", ""),
            "discs": len(media), "tracks": tracks}


def _num(value):
    m = re.match(r"\s*(\d+)", value or "")
    return int(m.group(1)) if m else 0


def plan_album(songs, release, fields=("title", "artist", "album", "albumartist", "year", "track", "disc", "label", "isrc")):
    """Line the songs up with the release's tracks and say what each should get.
    songs: [{"uri", "title", "track", "disc", ...}] (the table's rows). A song matches the track with the same
    disc and number when the song has a number, else the track whose title is closest; a track is used once.
    Returns {"plan": {uri: {field: value}}, "pairs": [{"uri", "track"}], "unmatched": [uri]}. Fields already
    right aren't in the plan."""
    tracks = release["tracks"]
    used, pairs, unmatched = set(), [], []
    many_discs = release.get("discs", 1) > 1

    def by_number(s):
        n, d = _num(s.get("track")), _num(s.get("disc")) or 1
        for i, t in enumerate(tracks):
            if i not in used and n and t["track"] == n and (t["disc"] == d or not many_discs):
                return i
        return None

    def by_title(s):
        want = _norm(s.get("title"))
        best = None
        for i, t in enumerate(tracks):
            if i in used or not want:
                continue
            have = _norm(t["title"])
            if have == want or (len(want) > 3 and (have.startswith(want) or want.startswith(have))):
                best = i
                break
        return best

    for s in songs:
        i = by_number(s)
        if i is None:
            i = by_title(s)
        elif _norm(s.get("title")) and _norm(tracks[i]["title"]) != _norm(s.get("title")):
            # the number agrees but the title is a different song: trust the title when one fits better
            j = by_title(s)
            i = j if j is not None else i
        if i is None:
            unmatched.append(s["uri"])
            continue
        used.add(i)
        pairs.append({"uri": s["uri"], "track": tracks[i]})
    plan = {}
    for p in pairs:
        t, song = p["track"], next(s for s in songs if s["uri"] == p["uri"])
        new = {"title": t["title"], "artist": t["artist"], "album": release["album"], "albumartist": release["albumartist"],
               "year": release["year"], "track": "%d/%d" % (t["track"], t["total"]),
               "disc": "%d/%d" % (t["disc"], release["discs"]) if release.get("discs", 1) > 1 else "",
               "label": release["label"], "isrc": t["isrc"]}
        for f in fields:
            v = new.get(f, "")
            if v and v != (song.get(f) or "").strip():
                plan.setdefault(p["uri"], {})[f] = v
    return {"plan": plan, "pairs": pairs, "unmatched": unmatched}


# ---------- lyrics (LRCLIB) ----------

def lyrics(get, artist, title, album="", duration_s=None):
    """{"synced": LRC text or "", "plain": text or "", "instrumental": bool, "found": bool} from lrclib.net.
    The exact lookup first (it needs the length to within 2 seconds), then a search."""
    q = {"artist_name": artist, "track_name": title}
    if album:
        q["album_name"] = album
    if duration_s:
        q["duration"] = int(round(duration_s))
    hit = _json(get, "https://lrclib.net/api/get?" + urlencode(q)) if duration_s else {}
    if not (hit.get("syncedLyrics") or hit.get("plainLyrics") or hit.get("instrumental")):
        found = _json(get, "https://lrclib.net/api/search?" + urlencode({"artist_name": artist, "track_name": title}))
        found = found if isinstance(found, list) else []
        if duration_s:
            found = [f for f in found if not f.get("duration") or abs(f["duration"] - duration_s) <= 5] or found
        hit = next((f for f in found if f.get("syncedLyrics") or f.get("plainLyrics")), found[0] if found else {})
    return {"synced": hit.get("syncedLyrics") or "", "plain": hit.get("plainLyrics") or "",
            "instrumental": bool(hit.get("instrumental")), "found": bool(hit)}
