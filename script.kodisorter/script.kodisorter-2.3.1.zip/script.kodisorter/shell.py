"""Sortovia 2.0's window: a side bar that never goes away (7 places) and one page beside it.

Pages are plain data, a list of widgets (pictures, text, buttons), made by the pure functions below. Window
turns them into Kodi's own controls (1280x720, like screens.py); tools/render_ui.py draws the same widgets to a
PNG to check them against the design. Rounded shapes are pictures made at the exact size they're shown
(tools/make_ui_images.py), so their corners never stretch.

Controller: Left from a page's first column goes to the side bar, Right comes back. Y (Info) opens Search and
X (Context menu) opens Downloads from anywhere; a page can take X for itself (more for this row).
"""
import os
import re
import time

MEDIA = "special://home/addons/script.kodisorter/resources/media/ui/"
W, H = 1280, 720
SIDE_W = 208
X0, X1 = 240, 1248          # the page's left and right edge
CW = X1 - X0                 # 1008

# colours, "AARRGGBB"
BG = "FF0E161E"
SIDE = "FF0A1117"
CARD = "FF141F29"
CARD_FOCUS = "FF2A5266"  # 2.2.3: was FF1B2A37, hard to tell from a card (the cursor "not showing")
LINE = "FF22303C"
TEAL = "FF2EC4B6"
TEAL_FOCUS = "FF0B6E65"       # a chosen button with the cursor on it: darker green, white text (2.0.6: the light
                              # green it was barely showed)
NAVY = "FF0F1A24"            # text on teal
FG = "FFEEF2F5"
MUTE = "FF93A3AF"
DIM = "FF6B7B87"
TAGS = {"REAL-DEBRID": "FF2EC4B6", "YOUTUBE": "FFF2C14E", "PHONE": "FF8AB4F8", "BIGLYBT": "FFB8C2CC",
        "TORRENT": "FF2EC4B6"}
GOOD = "FF4CD07D"
BAD = "FFE5534B"

FONT = {"title": "font32_title", "h": "font14", "body": "font12", "small": "font10", "big": "font13"}
FONT_SIZES = {"normal": dict(FONT), "large": {"title": "font32_title", "h": "font14", "body": "font13",
                                               "small": "font12", "big": "font14"}}
LEFT, RIGHT, CENTER, MIDDLE = 0, 1, 2, 4


def set_text_size(size):
    """Settings > Look: "normal" or "large" (each text a step bigger)."""
    FONT.clear()
    FONT.update(FONT_SIZES.get(size) or FONT_SIZES["normal"])

NAV = [("home", "Home", "home"), ("search", "Search", "search"), ("downloads", "Downloads", "download"),
       ("transfer", "Transfer / sort", "transfer"), ("music", "Music", "music"), ("library", "Library", "library"),
       ("settings", "Settings", "settings")]
NAV_Y, NAV_H, NAV_STEP = 96, 50, 58

# Y and X on a controller, and the keys Kodi gives them (Info is I on a keyboard, Context menu is C)
ACT_LEFT, ACT_RIGHT, ACT_UP, ACT_DOWN, ACT_SELECT = 1, 2, 3, 4, 7
ACT_PAGE_UP, ACT_PAGE_DOWN = 5, 6
ACT_SCROLL_UP, ACT_SCROLL_DOWN = 111, 112  # what some controller keymaps give the triggers
PAGE_UPS, PAGE_DOWNS = (ACT_PAGE_UP, ACT_SCROLL_UP), (ACT_PAGE_DOWN, ACT_SCROLL_DOWN)
ACT_Y = (11, 18)  # Info (I on a keyboard), and FullScreen: what Kodi's controller keymap gives Y
ACT_X = (117,)
ACT_BACK = (9, 10, 13, 92)
ACT_MOUSE_UP, ACT_MOUSE_DOWN = 104, 105

SHAPES = {}  # file name -> (w, h, radius, fill, line, line width), everything the pages ask for


def shape(w, h, r, fill, line=None, lw=0):
    """The picture of a rounded box at exactly w x h (made by tools/make_ui_images.py)."""
    name = "rr_%dx%d_r%d_%s_%s%d.png" % (w, h, r, fill[2:].lower(), (line or "none")[2:].lower() if line else "none", lw)
    SHAPES[name] = (w, h, r, fill, line, lw)
    if HAVE is not None and name not in HAVE:
        return _nearest(name, w) or name
    return name


HAVE = None  # 2.2.9: the pictures shipped (set by Window on Kodi): a size with no picture of its own uses the nearest


def _load_have():
    global HAVE
    try:
        HAVE = set(os.listdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media", "ui")))
    except Exception:
        HAVE = None


def _nearest(name, w):
    """2.2.9 (ticket q81d): the same box (height, corners, colours) at the nearest width that has a picture -
    Kodi stretches it to the size asked for. Without it the button showed no box, and no cursor on it."""
    rest = name.split("x", 1)[1]  # "44_r10_2a5266_2ec4b62.png"
    best = None
    for have in HAVE:
        if have.startswith("rr_") and have.endswith("x" + rest):
            try:
                hw = int(have[3:].split("x", 1)[0])
            except ValueError:
                continue
            if best is None or abs(hw - w) < abs(best[0] - w):
                best = (hw, have)
    return best[1] if best else None


ICONS = ("home", "search", "download", "transfer", "music", "library", "settings", "pencil", "list", "check",
         "phone", "image", "wave", "disc", "undo", "folder", "report", "broom", "space", "tv", "globe", "album",
         "comic", "text", "wrench", "sliders", "cloud", "play", "eye", "help", "refresh", "chevron", "logo",
         "box_on", "box_off", "toggle_on", "toggle_off", "hint_a", "hint_b", "hint_x", "hint_y", "hint_ls", "hint_rs", "dot", "ok_circle",
         "link", "pause", "trash", "backup")


def icon(name):
    return "icon_%s.png" % name


# ---------- widgets ----------
def img(key, x, y, w, h, src, color=None):
    return {"t": "img", "key": key, "x": x, "y": y, "w": w, "h": h, "src": src, "color": color}


def text(key, x, y, w, h, s, font="body", color=FG, align=LEFT | MIDDLE):
    return {"t": "text", "key": key, "x": x, "y": y, "w": w, "h": h, "s": s, "font": font, "color": color,
            "align": align}


def button(key, x, y, w, h, off, on, label="", font="body", color=FG, focus_color=None, align=LEFT | MIDDLE,
           pad=0):
    return {"t": "btn", "key": key, "x": x, "y": y, "w": w, "h": h, "off": off, "on": on, "s": label,
            "font": font, "color": color, "focus_color": focus_color or color, "align": align, "pad": pad}


def bar(key, x, y, w, h, frac, color=TEAL, back=LINE):
    """A progress bar: the track and the filled part (never wider than the track)."""
    frac = max(0.0, min(1.0, frac or 0.0))
    fill = max(h, int(round(w * frac))) if frac > 0 else 0
    out = [img(key + ":track", x, y, w, h, shape(w, h, h // 2, back))]
    # 2.0.6: the whole bar's picture, shown at the filled width (Kodi stretches it): a picture per width.
    # 2.2.7: always there (an empty bar's is 1 pixel, see-through): a bar that started made the page again
    out.append(img(key + ":fill", x, y, fill or 1, h, shape(w, h, h // 2, color), None if fill else "00FFFFFF"))
    return out


def tag(key, x, y, name):
    """A small outlined label: REAL-DEBRID, YOUTUBE, PHONE, BIGLYBT, TORRENT. Returns (widgets, width)."""
    colour = TAGS.get(name, MUTE)
    w = 18 + 9 * len(name)
    return [img(key + ":box", x, y, w, 20, shape(w, 20, 4, BG, colour, 1)),
            text(key + ":s", x, y, w, 20, "[B]%s[/B]" % name, "small", colour, CENTER | MIDDLE)], w


def short(s, n):
    s = re.sub(r"\s+", " ", s or "").strip()
    return s if len(s) <= n else s[:n - 1].rstrip() + "..."


# ---------- the frame: side bar, background, page title, hints ----------
def side_bar(current, status):
    """status: {"downloads": badge count, "drive": "D:\\", "free": "1.2 TB free", "used": 0..1, "version": "2.0"}"""
    out = [img("bg", 0, 0, W, H, shape(W, H, 0, BG)),
           img("side", 0, 0, SIDE_W, H, shape(SIDE_W, H, 0, SIDE)),
           img("side:edge", SIDE_W - 1, 0, 1, H, shape(1, H, 0, LINE)),
           img("logo", 22, 26, 32, 32, icon("logo")),
           text("brand", 66, 26, 140, 32, "[B]Sortovia[/B]", "h", FG)]
    for n, (key, label, ic) in enumerate(NAV):
        y = NAV_Y + n * NAV_STEP
        on = key == current
        out.append(button("nav:" + key, 12, y, 184, NAV_H,
                          shape(184, NAV_H, 10, "FF1A2734") if on else shape(184, NAV_H, 10, SIDE),
                          shape(184, NAV_H, 10, "FF1A2734", TEAL, 2)))
        if on:
            out.append(img("nav:%s:mark" % key, 12, y + 10, 4, NAV_H - 20, shape(4, NAV_H - 20, 2, TEAL)))
        out.append(img("nav:%s:icon" % key, 30, y + 13, 24, 24, icon(ic), TEAL if on else MUTE))
        out.append(text("nav:%s:s" % key, 68, y, 96 if key == "downloads" else 124, NAV_H, "[B]%s[/B]" % label if on else label, "body",
                        FG if on else "FFC9D3DA"))
        if key == "downloads" and status.get("downloads"):
            out.append(img("nav:badge", 170, y + 14, 24, 22, shape(24, 22, 11, TEAL)))
            out.append(text("nav:badge:s", 170, y + 14, 24, 22, "[B]%d[/B]" % status["downloads"], "small", NAVY,
                            CENTER | MIDDLE))
    out.append(img("foot:line", 22, 612, 164, 1, shape(164, 1, 0, LINE)))
    # 2.0.10: no free space or bar (the Xbox never lets an add-on read a drive's free space)
    out.append(text("foot:drive", 22, 622, 164, 24, "Library on %s" % status.get("drive", ""), "small", FG))
    out.append(text("foot:clock", 22, 648, 164, 24, CLOCK, "small", "FFC9D3DA"))  # 2.0.10: the time, kept by Kodi
    out.append(text("foot:ver", 22, 676, 164, 24, "Version %s" % status.get("version", ""), "small", DIM))
    return out


CLOCK = "$INFO[System.Time]"  # Kodi fills in the time itself and keeps it current


def page_title(title, sub="", right=X1):
    """right: where the sub line must stop (2.1.2: on Downloads it ran under the clock and the auto-move line)."""
    out = [text("title", X0, 24, 600, 48, "[B]%s[/B]" % title, "title", FG)]
    if sub:
        x = X0 + 20 + int(len(title) * 21)
        out.append(text("sub", x, 34, right - x, 34, sub, "small", MUTE))
    return out


def hints(pairs, x=X0, y=682):
    """[("a", "Open"), ("b", "Back"), ...] along the bottom."""
    out = []
    pairs = list(pairs)
    if ("b", "Back") in pairs:  # 2.0.8: what Left and Right at the edges do, beside Back
        i = pairs.index(("b", "Back")) + 1
        pairs[i:i] = [("ls", "Top row"), ("rs", "Bottom row")]
    for letter, label in pairs:
        big = 8 if letter in ("ls", "rs") else 0  # 2.2.2: the D-pad pictures are bigger, so the L / R reads
        out.append(img("hint:%s" % letter, x, y + 2 - big // 2, 22 + big, 22 + big, icon("hint_" + letter)))
        out.append(text("hint:%s:s" % letter, x + 27 + big, y, min(160, W - x - 31 - big), 26, label, "small", MUTE))
        x += 27 + big + 8 * len(label) + 24
    return out


DEFAULT_HINTS = [("a", "Open"), ("b", "Back"), ("y", "Search"), ("x", "Downloads")]


# ---------- pages ----------
ARROW_NAMES = {ACT_UP: "Up", ACT_DOWN: "Down", ACT_LEFT: "Left", ACT_RIGHT: "Right", ACT_SELECT: "A",
               ACT_PAGE_UP: "Page up", ACT_PAGE_DOWN: "Page down", ACT_SCROLL_UP: "Trigger up",
               ACT_SCROLL_DOWN: "Trigger down"}


def trace(msg):
    """2.2.8: the cursor's moves in the log (ticket q81d: on the Xbox only), so a press that went wrong shows how."""
    try:
        import xbmc
        xbmc.log("[Sortovia] cursor: %s" % msg, xbmc.LOGINFO)
    except Exception:
        pass


class Page(object):
    """What one page shows. widgets: the list; rows: [[button key]] the D-pad grid (top to bottom, left to right);
    focus: the key to start on; live: seconds between refreshes (0: never); x_own: X is this page's (more for
    a row) instead of Downloads."""

    def __init__(self, name, widgets, rows, focus=None, live=0, x_own=False, scroll=None, place=None):
        self.name, self.widgets, self.rows, self.live, self.x_own = name, widgets, rows, live, x_own
        self.place = place or name  # the side bar place it lights up
        self.focus = focus or (rows[0][0] if rows and rows[0] else "nav:" + name)
        self.jump = {}  # {button key: key that Right goes to} where the grid's own Right would stay put
        self.scroll = scroll or {}  # {"first slot key": ..., "last slot key": ..., "more_up": bool, "more_down": bool}

    def keys(self):
        return [w["key"] for w in self.widgets if w["t"] == "btn"]


def navigation(page):
    """{key: (up, down, left, right)} for every button: the page grid, and the side bar in its own column.
    2.0.8: Left and Right go to the nearest thing that way: Left from a row's first button goes to the side bar
    place level with it, Right from the side bar to the page button level with it. Left in the side bar goes to
    the page's top row, and Right from a row's last button to the bottom row. Up and down in a row of a
    different length go to the nearest column."""
    nav = {}
    side = ["nav:" + k for k, _, _ in NAV]
    rows = [r for r in page.rows if r]
    mid = dict((w["key"], w["y"] + w["h"] / 2.0) for w in page.widgets if w.get("t") == "btn")
    for i, k in enumerate(side):
        mid.setdefault(k, NAV_Y + i * NAV_STEP + NAV_H / 2.0)

    def level(key, choices):
        y = mid.get(key, 0)
        return min(choices, key=lambda o: (abs(mid.get(o, 0) - y), choices.index(o))) if choices else key

    firsts = [r[0] for r in rows]
    top = rows[0][0] if rows else None
    bottom = rows[-1] if rows else []
    for i, k in enumerate(side):
        nav[k] = (side[i - 1], side[(i + 1) % len(side)], top or k, level(k, firsts) if rows else k)

    def col_x(row, n):
        return n / float(max(len(row) - 1, 1))

    for r, row in enumerate(rows):
        for n, k in enumerate(row):
            def nearest(other):
                if not other:
                    return k
                target = col_x(row, n)
                return min(other, key=lambda o: abs(col_x(other, other.index(o)) - target))
            up = nearest(rows[r - 1]) if r > 0 else k
            down = nearest(rows[r + 1]) if r + 1 < len(rows) else k
            sc = page.scroll
            in_row = lambda end: end and (k == end or k.startswith(end + ":"))  # 2.1.1: a row's Search button too
            if sc.get("more_down") and in_row(sc.get("last")):
                down = k  # 2.0.2: the list pages on instead (Kodi moving to the buttons too made the scroll put it back)
            if sc.get("more_up") and in_row(sc.get("first")):
                up = k
            left = row[n - 1] if n > 0 else level(k, side)
            if n + 1 < len(row):
                right = row[n + 1]
            elif k in page.jump:
                right = page.jump[k]
            elif r + 1 < len(rows):
                right = bottom[0]
            else:
                right = k
            nav[k] = (up, down, left, right)
    return nav


CARD_W, CARD_H, CARD_GAP = 496, 130, 16


def cards_page(name, title, sub, items, status, focus=None, current=None, top=84):
    """Two columns of cards, at most 8: items [(key, icon, title, description, opens_more)]."""
    out = side_bar(current or name, status) + page_title(title, sub)
    rows, row = [], []
    rows_n = (len(items) + 1) // 2
    h = CARD_H if rows_n <= 4 else (H - top - 60 - CARD_GAP * (rows_n - 1)) // rows_n
    for i, (key, ic, head, desc, more) in enumerate(items):
        r, c = divmod(i, 2)
        x, y = X0 + c * (CARD_W + CARD_GAP), top + r * (h + CARD_GAP)
        out.append(button(key, x, y, CARD_W, h, shape(CARD_W, h, 12, CARD, LINE, 1),
                          shape(CARD_W, h, 12, CARD_FOCUS, TEAL, 2)))
        mid = y + h // 2
        out.append(img(key + ":iconbox", x + 22, mid - 30, 60, 60, shape(60, 60, 12, "FF17323A")))
        out.append(img(key + ":icon", x + 36, mid - 16, 32, 32, icon(ic), TEAL))
        out.append(text(key + ":h", x + 104, mid - 30, CARD_W - 150, 32, "[B]%s[/B]" % head, "h", FG))
        out.append(text(key + ":d", x + 104, mid + 2, CARD_W - 150, 28, desc, "small", MUTE))
        if more:
            out.append(img(key + ":more", x + CARD_W - 40, mid - 10, 20, 20, icon("chevron"), MUTE))
        row.append(key)
        if c == 1:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    out += hints(DEFAULT_HINTS)
    return Page(name, out, rows, focus if focus in [k for k, _, _, _, _ in items] else None, place=current or name)


def badge_width(count):
    """A count bubble wide enough for its number: round for 1-2 digits, longer for more."""
    return max(22, 10 + 9 * max(2, len(str(count))))  # 2.2.7: 1 and 2 digits the same, so 9 -> 10 isn't a new page


def pill_width(label, per=8.2, pad=36):
    return int(pad + per * len(re_plain(label)))


def re_plain(s):
    return re.sub(r"\[/?[A-Z]+[^\]]*\]", "", s or "")


def chips(items, y=34):
    """Status chips at the top right: [(text, good)] -> widgets, right to left."""
    out, x = [], X1
    for n, (label, good) in enumerate(reversed(items)):
        w = pill_width(label, 8.2, 44)
        x -= w
        out.append(img("chip%d" % n, x, y, w, 26, shape(w, 26, 13, "FF121C25", LINE, 1)))
        out.append(img("chip%d:dot" % n, x + 12, y + 9, 8, 8, icon("dot"), GOOD if good else BAD))
        out.append(text("chip%d:s" % n, x + 26, y, w - 30, 26, label, "small", "FFC9D3DA"))
        x -= 8
    return out


def toggle(key, x, y, on):
    """A switch button 48x24 (the focus ring is the picture's own box)."""
    return [button(key, x - 4, y - 4, 56, 32, shape(56, 32, 16, "00000000"), shape(56, 32, 16, "00000000", TEAL, 2)),
            img(key + ":knob", x, y, 48, 24, icon("toggle_on" if on else "toggle_off"))]


def dl_row(key, x, y, w, h, row, bar_x, bar_w, focus_fill=CARD_FOCUS):
    """One download: name, tag and details under it, the bar, the percent (or state) and speed or a note.
    row: {"name", "tag", "info", "frac" (0..1 or None), "state" (text shown instead of the percent, or ""),
    "state_color", "right"}"""
    out = [button(key, x, y, w, h, shape(w, h, 10, CARD, LINE, 1), shape(w, h, 10, focus_fill, TEAL, 2))]
    out.append(text(key + ":name", x + 18, y + 8, bar_x - x - 40, 28, short(row.get("name"), 60), "body", FG))
    t, tw = tag(key + ":tag", x + 18, y + h - 30, row.get("tag") or "PHONE")
    out += t
    out.append(text(key + ":info", x + 26 + tw, y + h - 33, bar_x - x - tw - 60, 26, row.get("info", ""), "small",
                    MUTE))
    frac = row.get("frac")
    colour = row.get("state_color") or TEAL
    out += bar(key + ":bar", bar_x, y + h // 2 - 3, bar_w, 6, frac or 0, colour if row.get("state") else TEAL)
    state = row.get("state") or ("%d%%" % int(round((frac or 0) * 100)))
    out.append(text(key + ":pct", bar_x + bar_w + 14, y, 80, h, "[B]%s[/B]" % state, "body",
                    row.get("state_color") or FG))
    out.append(text(key + ":right", bar_x + bar_w + 90, y, x + w - (bar_x + bar_w + 90) - 18, h, row.get("right", ""),
                    "small", MUTE, RIGHT | MIDDLE))
    if "ticked" in row:  # 2.0.8: Y ticks it, A then works on every ticked one (hidden, not missing, when unticked)
        out.append(img(key + ":tick", x + w - 30, y + 6, 20, 20, icon("box_on"), None if row["ticked"] else "00FFFFFF"))
    return out


def home_page(status, phone=None, rd="", banner=None, active=0, speed="", rows=(), finished="", new=(), auto=False,
              last="", focus=None):
    """Home: the search box, what's downloading (top 4), what just landed, the auto move switch.
    banner: [(key, text)] shown above the search box only when they apply (resume a sort, moving now)."""
    out = side_bar("home", status) + page_title("Home")
    out += chips(([("Phone connected", True)] if phone else [("Phone not answering", False)] if phone is False else [])
                 + ([(rd, True)] if rd else []))
    grid = []
    y = 84
    for n, (key, label) in enumerate(banner or []):
        out.append(button("banner:" + key, X0, y, CW, 40, shape(CW, 40, 10, "FF15303A", TEAL, 1),
                          shape(CW, 40, 10, "FF1C4450", TEAL, 2), label, "body", FG, pad=18))
        grid.append(["banner:" + key])
        y += 48
    box_w = 848
    out.append(button("home:box", X0, y, box_w, 62, shape(box_w, 62, 12, "FF16222D", LINE, 2),
                      shape(box_w, 62, 12, "FF16222D", TEAL, 2)))
    out.append(img("home:box:icon", X0 + 22, y + 19, 24, 24, icon("search"), TEAL))
    out.append(text("home:box:s", X0 + 64, y, box_w - 90, 62, "Search TV, movies, music, tutorials and comics",
                    "big", MUTE))
    out.append(button("home:go", X0 + box_w + 12, y, CW - box_w - 12, 62, shape(CW - box_w - 12, 62, 12, TEAL),
                      shape(CW - box_w - 12, 62, 12, TEAL_FOCUS, FG, 3), "[B]Search[/B]", "big", NAVY, FG,
                      CENTER | MIDDLE))
    grid.append(["home:box", "home:go"])
    out.append(text("home:boxhint", X0, y + 68, 700, 24,
                    "One search for torrents and YouTube.  A pasted link works here too.", "small", MUTE))
    top = y + 112
    # downloading now
    pw, ph = 624, 664 - top
    out.append(img("dl:panel", X0, top, pw, ph, shape(pw, ph, 14, CARD, LINE, 1)))
    out.append(text("dl:h", X0 + 22, top + 12, 200, 32, "[B]Downloading now[/B]", "h", FG))
    out.append(text("dl:sub", X0 + 232, top + 12, 200, 32, ("%d active  ·  %s" % (active, speed)) if active
                    else "nothing downloading", "small", MUTE))
    out.append(button("dl:all", X0 + pw - 86, top + 14, 70, 28, shape(70, 28, 8, CARD), shape(70, 28, 8, CARD, TEAL, 2),
                      "[B]See all[/B]", "small", TEAL, TEAL, CENTER | MIDDLE))
    grid.append(["dl:all"])
    slot = (ph - 60 - 52) // 4
    for i in range(4):
        ry = top + 52 + i * slot
        if i < len(rows):
            r = rows[i]
            out.append(button("dl:%d" % i, X0 + 10, ry, pw - 20, slot - 4, shape(pw - 20, slot - 4, 8, CARD),
                              shape(pw - 20, slot - 4, 8, CARD_FOCUS, TEAL, 2)))
            out.append(text("dl:%d:name" % i, X0 + 22, ry + 6, pw - 140, 28, short(r.get("name"), 50), "body", FG))
            state = r.get("state") or "%d%%" % int(round((r.get("frac") or 0) * 100))
            out.append(text("dl:%d:pct" % i, X0 + pw - 122, ry + 6, 100, 28, "[B]%s[/B]" % state, "body",
                            r.get("state_color") or (FG if not r.get("state") else MUTE), RIGHT | MIDDLE))
            t, tw = tag("dl:%d:tag" % i, X0 + 22, ry + 40, r.get("tag") or "PHONE")
            out += t
            out.append(text("dl:%d:info" % i, X0 + 30 + tw, ry + 37, 290 - tw, 26, r.get("info", ""), "small", MUTE))
            out += bar("dl:%d:bar" % i, X0 + 320, ry + 47, pw - 342, 6, r.get("frac") or 0)
            grid.append(["dl:%d" % i])
        if i < 3:
            out.append(img("dl:line%d" % i, X0 + 22, ry + slot - 2, pw - 44, 1, shape(pw - 44, 1, 0, LINE)))
    if finished:
        out.append(img("dl:done:icon", X0 + 22, top + ph - 44, 20, 20, icon("ok_circle"), GOOD))
        out.append(text("dl:done", X0 + 52, top + ph - 48, pw - 70, 28, finished, "small", "FFC9D3DA"))
    # new in your library
    rx, rw = X0 + pw + 16, CW - pw - 16
    nh = 324 if top + 324 + 16 + 128 <= 664 else 664 - top - 16 - 128
    out.append(img("new:panel", rx, top, rw, nh, shape(rw, nh, 14, CARD, LINE, 1)))
    out.append(text("new:h", rx + 22, top + 12, rw - 44, 32, "[B]New in your library[/B]", "h", FG))
    step = (nh - 60) // 4
    for i in range(4):
        ny = top + 52 + i * step
        if i < len(new):
            name, sub = new[i]
            out.append(text("new:%d" % i, rx + 22, ny + 4, rw - 44, 26, short(name, 34), "body", FG))
            out.append(text("new:%d:sub" % i, rx + 22, ny + 30, rw - 44, 22, sub, "small", MUTE))
        if i < 3:
            out.append(img("new:line%d" % i, rx + 22, ny + step - 2, rw - 44, 1, shape(rw - 44, 1, 0, LINE)))
    ay = top + nh + 16
    ah = 664 - ay
    out.append(img("auto:panel", rx, ay, rw, ah, shape(rw, ah, 14, CARD, LINE, 1)))
    out.append(text("auto:h", rx + 22, ay + 14, rw - 110, 26, "[B]Move finished downloads[/B]", "body", FG))
    out.append(text("auto:sub", rx + 22, ay + 38, rw - 110, 22, "to the library by themselves", "small", MUTE))
    out += toggle("auto", rx + rw - 70, ay + 24, auto)
    out.append(img("auto:line", rx + 22, ay + ah - 52, rw - 44, 1, shape(rw - 44, 1, 0, LINE)))
    out.append(text("auto:last", rx + 22, ay + ah - 48, 160, 40, "Last transfer / sort", "small", MUTE))
    out.append(text("auto:when", rx + 178, ay + ah - 48, rw - 200, 40, last or "not yet", "small", FG, RIGHT | MIDDLE))
    for g in grid:  # the switch sits right of See all, so Right from See all reaches it
        if g[0] == "dl:all":
            g.append("auto")
            break
    out += hints(DEFAULT_HINTS)
    return Page("home", out, grid, focus or "home:box", live=3)


DL_SLOTS, DL_TOP, DL_H, DL_STEP = 6, 132, 68, 76


def downloads_page(status, active=0, speed="", auto=False, filters=(), shown="all", rows=(), offset=0,
                   buttons=(), focus=None, note="", auto_note="", empty=""):
    """filters: [(key, label, count)]; rows: dl_row dicts (all of them: offset says which are on screen);
    buttons: [(key, label)] along the bottom."""
    out = side_bar("downloads", status) + page_title("Downloads", ("%d active  ·  %s" % (active, speed))
                                                     if active else note, right=X1 - 572)
    out.append(text("clock", X1 - 560, 34, 80, 26, "[B]%s[/B]" % CLOCK, "body", FG, RIGHT | MIDDLE))  # 2.0.10
    out.append(text("auto:s", X1 - 470, 34, 394, 26, auto_note or "Move finished to the library by themselves",
                    "small", MUTE, RIGHT | MIDDLE))  # 2.0.8: when it last moved and when it looks next
    out += toggle("auto", X1 - 52, 35, auto)
    grid = [[], ]
    x = X0
    for key, label, count in filters:
        on = key == shown
        bw = badge_width(count)  # 2.0.6: fits 3 and 4 digits ("1..." was all of 125)
        w = pill_width(label, 9.6, 44) + bw
        out.append(button("f:" + key, x, 78, w, 40, shape(w, 40, 10, TEAL) if on else shape(w, 40, 10, CARD, LINE, 1),
                          shape(w, 40, 10, TEAL_FOCUS, FG, 3) if on else shape(w, 40, 10, CARD_FOCUS, TEAL, 2),
                          "[B]%s[/B]" % label if on else label, "body", NAVY if on else FG, FG, pad=16))
        out.append(img("f:%s:badge" % key, x + w - bw - 12, 87, bw, 22, shape(bw, 22, 11, "FF0F1A24" if on else "FF22303C")))
        out.append(text("f:%s:n" % key, x + w - bw - 12, 87, bw, 22, "[B]%d[/B]" % count, "small", FG, CENTER | MIDDLE))
        grid[0].append("f:" + key)
        x += w + 8
    grid[0].append("auto")
    visible = list(rows)[offset:offset + DL_SLOTS]
    for i in range(DL_SLOTS):
        y = DL_TOP + i * DL_STEP
        if i < len(visible):
            out += dl_row("row:%d" % i, X0, y, CW, DL_H, visible[i], 770, 210)
            grid.append(["row:%d" % i])
    if not rows:
        out.append(text("empty", X0, DL_TOP, CW, 60, empty or "Nothing here.", "body", MUTE, CENTER | MIDDLE))
    if len(rows) > DL_SLOTS:
        out.append(text("more", X1 - 200, 586, 200, 18, "%d-%d of %d" % (offset + 1, offset + len(visible), len(rows)),
                        "small", DIM, RIGHT | MIDDLE))
    gap = 12
    # sized for the longer of a button's two labels, so "Pause all" / "Resume all" doesn't change the pictures
    # 2.2.9: all the same width, whatever their words ("Move to D:\\" made sizes with no picture: no box, no cursor)
    widths = [(CW - gap * (len(buttons) - 1)) // max(len(buttons), 1)] * len(buttons)
    extra = 0
    x, line = X0, []
    for (key, label), w in zip(buttons, widths):
        w += extra
        out.append(button("b:" + key, x, 606, w, 44, shape(w, 44, 10, CARD, LINE, 1),
                          shape(w, 44, 10, CARD_FOCUS, TEAL, 2), label, "body", FG, align=CENTER | MIDDLE))
        line.append("b:" + key)
        x += w + gap
    grid.append(line)
    out += hints([("a", "Options"), ("y", "Tick"), ("b", "Back")])
    scroll = {"first": "row:0", "last": "row:%d" % (len(visible) - 1), "more_up": offset > 0,
              "more_down": offset + DL_SLOTS < len(rows), "page": DL_SLOTS}
    first = "row:0" if visible else (grid[-1][0] if grid[-1] else None)
    page = Page("downloads", out, [g for g in grid if g], focus or first, live=3, x_own=True, scroll=scroll)
    page.jump = dict(("row:%d" % i, line[0]) for i in range(len(visible))) if line else {}  # Right: to the buttons
    return page


SR_SLOTS, SR_TOP, SR_H, SR_STEP = 6, 258, 58, 64
CATS = [("tv", "TV"), ("movies", "Movies"), ("music", "Music"), ("tutorials", "Tutorials"), ("comics", "Comics")]
SOURCES = [("torrents", "Torrents"), ("youtube", "YouTube"), ("both", "Both")]
# 2.2.0: short enough to leave room for Discover and Missing episodes on the same row
SORTS = [("best", "Best match"), ("seeders", "Seeders"), ("newest", "Newest"), ("largest", "Largest"),
         ("views", "Views"), ("name", "A-Z")]


DISC_LISTS = [("popular", "Popular"), ("top", "Top rated"), ("new", "New")]  # 2.2.0: discover.LISTS
MISS_SORTS = [("singles", "Episodes first"), ("show", "A-Z"), ("newest", "Newest"), ("oldest", "Oldest")]


def search_page(status, query="", cats=(), source="both", sort="best", results=(), offset=0, summary="",
                more=False, focus=None, busy="", missing=None, miss_sort="singles", miss_hide=False, discover=None):
    """results: [{"ticked", "tag" (YOUTUBE / TORRENT), "title", "meta", "note", "note_color"}]. missing (2.0.7):
    [{"q", "meta"}] shows the missing episodes instead, each in a search box with its own Search button.
    discover (2.2.0): {"rows": [{"q", "meta", "ticked"}], "list": popular/top/new, "genre": "" or a name} shows
    shows and movies from TMDb the same way."""
    out = side_bar("search", status) + page_title("Search")
    # 2.2.2: while several searches run, "Searching for..." goes up here, not over the results already listed
    busy_top = bool(busy and results and missing is None and discover is None)
    if busy_top:
        out.append(text("summary", X1 - 560, 34, 560, 26, "[B]%s[/B]" % busy, "small", TEAL, RIGHT | MIDDLE))
    elif summary:
        out.append(text("summary", X1 - 500, 34, 500, 26, summary, "small", MUTE, RIGHT | MIDDLE))
    box_w = 848
    out.append(button("box", X0, 78, box_w, 56, shape(box_w, 56, 12, "FF16222D", LINE, 1),
                      shape(box_w, 56, 12, "FF16222D", TEAL, 2)))
    out.append(img("box:icon", X0 + 20, 94, 24, 24, icon("search"), MUTE))
    out.append(text("box:s", X0 + 60, 78, box_w - 80, 56, short(query, 70) or "Type what to look for",
                    "big", FG if query else MUTE))
    out.append(button("go", X0 + box_w + 12, 78, CW - box_w - 12, 56, shape(CW - box_w - 12, 56, 12, TEAL),
                      shape(CW - box_w - 12, 56, 12, TEAL_FOCUS, FG, 3), "[B]Search[/B]", "big", NAVY, FG, CENTER | MIDDLE))
    grid = [["box", "go"], []]
    x = X0
    for key, label in CATS:
        on = key in cats
        out.append(button("cat:" + key, x, 150, 118, 42, shape(118, 42, 10, CARD, TEAL if on else LINE, 1 + on),
                          shape(118, 42, 10, CARD_FOCUS, TEAL, 2)))
        out.append(text("cat:%s:s" % key, x + 44, 150, 70, 42, label, "body", FG))
        out.append(img("cat:%s:box" % key, x + 14, 160, 22, 22, icon("box_on" if on else "box_off")))
        grid[1].append("cat:" + key)
        x += 126
    out.append(img("src:panel", 900, 150, 348, 42, shape(348, 42, 10, CARD, LINE, 1)))
    for n, (key, label) in enumerate(SOURCES):
        on = key == source
        out.append(button("src:" + key, 904 + n * 114, 154, 112, 34,
                          shape(112, 34, 8, TEAL) if on else shape(112, 34, 8, CARD),
                          shape(112, 34, 8, TEAL_FOCUS, FG, 3) if on else shape(112, 34, 8, CARD_FOCUS, TEAL, 2),
                          "[B]%s[/B]" % label if on else label, "body", NAVY if on else FG, FG,
                          CENTER | MIDDLE))
        grid[1].append("src:" + key)
    out.append(text("sort:s", X0, 208, 52, 36, "[B]%s[/B]" % ("List" if discover is not None else "Sort"), "body", MUTE))
    x, line = X0 + 54, []
    if discover is not None:
        missing = None
    pills = [("dl:" + k, l) for k, l in DISC_LISTS] if discover is not None else \
        [("sort:" + k, l) for k, l in (MISS_SORTS if missing is not None else SORTS)]
    current = ("dl:" + (discover.get("list") or "popular")) if discover is not None else \
        "sort:" + (miss_sort if missing is not None else sort)
    # 2.1.0: showing missing episodes, the sorts are the episodes' own (a search sort left the list)
    for key, label in pills:
        on = key == current
        w = pill_width(label, 9.4, 34)
        out.append(button(key, x, 208, w, 36, shape(w, 36, 18, TEAL) if on else shape(w, 36, 18, CARD, LINE, 1),
                          shape(w, 36, 18, TEAL_FOCUS, FG, 3) if on else shape(w, 36, 18, CARD_FOCUS, TEAL, 2),
                          "[B]%s[/B]" % label if on else label, "body", NAVY if on else FG, FG,
                          CENTER | MIDDLE))
        line.append(key)
        x += w + 8
    if missing is not None:  # 2.1.0: on the page, not hidden in a menu
        label = "Hide downloading"  # 2.2.0: on shows as a ticked box (the On/Off words ran into Discover)
        w = pill_width(label, 8.6, 20) + 44
        out.append(button("mhide", x, 208, w, 36, shape(w, 36, 18, CARD, TEAL if miss_hide else LINE, 1 + miss_hide),
                          shape(w, 36, 18, CARD_FOCUS, TEAL, 2), label, "body", FG, FG, LEFT | MIDDLE, pad=16))
        out.append(img("mhide:box", x + w - 32, 215, 22, 22, icon("box_on" if miss_hide else "box_off")))
        line.append("mhide")
    if discover is not None:
        label = "Genre: %s" % (discover.get("genre") or "All")
        w = pill_width(label, 9.4, 34)
        out.append(button("dgenre", x, 208, w, 36, shape(w, 36, 18, CARD, TEAL if discover.get("genre") else LINE,
                                                         1 + bool(discover.get("genre"))),
                          shape(w, 36, 18, CARD_FOCUS, TEAL, 2), label, "body", FG, FG, CENTER | MIDDLE))
        line.append("dgenre")
    on = missing is not None
    w = pill_width("Missing episodes", 9.4, 34)
    dw = pill_width("Discover", 9.4, 34)
    don = discover is not None
    out.append(button("discover", X1 - w - 8 - dw, 208, dw, 36,
                      shape(dw, 36, 18, TEAL) if don else shape(dw, 36, 18, CARD, LINE, 1),
                      shape(dw, 36, 18, TEAL_FOCUS, FG, 3) if don else shape(dw, 36, 18, CARD_FOCUS, TEAL, 2),
                      "[B]Discover[/B]" if don else "Discover", "body", NAVY if don else FG, FG, CENTER | MIDDLE))
    line.append("discover")
    out.append(button("missing", X1 - w, 208, w, 36, shape(w, 36, 18, TEAL) if on else shape(w, 36, 18, CARD, LINE, 1),
                      shape(w, 36, 18, TEAL_FOCUS, FG, 3) if on else shape(w, 36, 18, CARD_FOCUS, TEAL, 2),
                      "[B]Missing episodes[/B]" if on else "Missing episodes", "body", NAVY if on else FG, FG,
                      CENTER | MIDDLE))
    line.append("missing")
    grid.append(line)
    if on:
        return _missing_rows(out, grid, missing, offset, summary, busy, focus)
    if don:
        return _missing_rows(out, grid, discover.get("rows") or [], offset, summary, busy, focus, prefix="disc",
                             buttons=(("dt:search", "Search the ticked"), ("dt:more", "Show more")),
                             empty="Nothing found. Try another genre or list.")
    visible = list(results)[offset:offset + SR_SLOTS]
    for i in range(SR_SLOTS):
        y = SR_TOP + i * SR_STEP
        if i >= len(visible):
            continue
        r, key = visible[i], "res:%d" % i
        out.append(button(key, X0, y, CW, SR_H, shape(CW, SR_H, 10, CARD, LINE, 1),
                          shape(CW, SR_H, 10, CARD_FOCUS, TEAL, 2)))
        out.append(img(key + ":box", X0 + 15, y + 18, 22, 22, icon("box_on" if r.get("ticked") else "box_off")))
        t, tw = tag(key + ":tag", X0 + 52, y + 19, r.get("tag") or "TORRENT")
        out += t
        out.append(text(key + ":title", X0 + 142, y + 6, 640, 26, short(r.get("title"), 72), "body", FG))
        out.append(text(key + ":meta", X0 + 142, y + 30, 640, 22, r.get("meta", ""), "small", MUTE))
        out.append(text(key + ":note", X1 - 260, y, 242, SR_H, "[B]%s[/B]" % r["note"] if r.get("note") else "",
                        "small", r.get("note_color") or TEAL, RIGHT | MIDDLE))
        grid.append([key])
    if (busy and not busy_top) or not results:
        out.append(text("empty", X0, SR_TOP + 40, CW, 60, busy or ("No results. Try fewer words or another category."
                                                                     if summary else "Type what to look for, then Search."),
                        "body", MUTE, CENTER | MIDDLE))
    ticked = sum(1 for r in results if r.get("ticked"))
    line = []
    out.append(button("b:download", X0, 652, 280, 46, shape(280, 46, 10, TEAL), shape(280, 46, 10, TEAL_FOCUS, FG, 3),
                      "[B]Download the %d ticked[/B]" % ticked if ticked else "[B]Download the ticked[/B]", "body",
                      NAVY, FG, CENTER | MIDDLE))
    line.append("b:download")
    out.append(button("b:next", X0 + 292, 652, 150, 46, shape(150, 46, 10, CARD, LINE, 1),
                      shape(150, 46, 10, CARD_FOCUS, TEAL, 2), "Next 100", "body", FG if more else DIM,
                      align=CENTER | MIDDLE))
    line.append("b:next")
    out.append(button("b:paste", X0 + 454, 652, 150, 46, shape(150, 46, 10, CARD, LINE, 1),
                      shape(150, 46, 10, CARD_FOCUS, TEAL, 2), "Paste a link", "body", FG, align=CENTER | MIDDLE))
    line.append("b:paste")
    grid.append(line)
    out += hints([("y", "Tick"), ("b", "Back")], x=X0 + 616, y=662)  # 2.2.0: it was drawn over Paste a link
    scroll = {"first": "res:0", "last": "res:%d" % (len(visible) - 1), "more_up": offset > 0,
              "more_down": offset + SR_SLOTS < len(results), "page": SR_SLOTS}
    page = Page("search", out, [g for g in grid if g], focus or ("res:0" if visible else "box"), x_own=False,
                scroll=scroll)
    page.jump = dict(("res:%d" % i, "b:download") for i in range(len(visible)))  # Right: to the buttons
    return page


def _missing_rows(out, grid, missing, offset, summary, busy, focus, prefix="miss",
                  buttons=(("mt:search", "Search the ticked"), ("mt:scan", "Scan again")),
                  empty="No missing episodes in the last scan."):  # summary: drawn by search_page
    """The search page's lower half while it shows missing episodes (or Discover's shows and movies, 2.2.0): a box
    with the search words (X changes them) and a Search button on each row, paging like the results."""
    visible = list(missing)[offset:offset + SR_SLOTS]
    go_w = 150
    box_w = CW - go_w - 12
    for i, r in enumerate(visible):
        y = SR_TOP + i * SR_STEP
        key = "%s:%d" % (prefix, i)
        out.append(button(key, X0, y, box_w, SR_H, shape(box_w, SR_H, 10, "FF16222D", LINE, 1),
                          shape(box_w, SR_H, 10, "FF16222D", TEAL, 2)))
        out.append(img(key + ":icon", X0 + 16, y + 17, 24, 24, icon("box_on" if r.get("ticked") else "box_off")))
        out.append(text(key + ":q", X0 + 54, y + 4, box_w - 70, 28, short(r.get("q"), 70), "body", FG))
        mx = X0 + 54
        if r.get("downloading"):  # 2.2.2: a green label, easy to see (it was grey words at the start of the line)
            out.append(img(key + ":dl:box", mx, y + 31, 140, 20, shape(140, 20, 5, GOOD)))
            out.append(text(key + ":dl:s", mx, y + 31, 140, 20, "[B]DOWNLOADING[/B]", "small", NAVY, CENTER | MIDDLE))
            mx += 150
        out.append(text(key + ":meta", mx, y + 30, box_w - 16 - mx + X0, 22, short(r.get("meta"), 80 if mx > X0 + 54
                                                                                     else 90), "small", MUTE))
        out.append(button(key + ":go", X1 - go_w, y, go_w, SR_H, shape(go_w, SR_H, 10, TEAL),
                          shape(go_w, SR_H, 10, TEAL_FOCUS, FG, 3), "[B]Search[/B]", "body", NAVY, FG, CENTER | MIDDLE))
        grid.append([key, key + ":go"])
    if busy or not visible:
        out.append(text("empty", X0, SR_TOP + 40, CW, 60, busy or empty, "body",
                        MUTE, CENTER | MIDDLE))
    if len(missing) > SR_SLOTS:
        out.append(text("more", X1 - 200, 652, 200, 46, "%d-%d of %d" % (offset + 1, offset + len(visible),
                                                                      len(missing)), "small", DIM, RIGHT | MIDDLE))
    ticked = sum(1 for r in missing if r.get("ticked"))
    line = []
    (k1, l1), (k2, l2) = buttons
    out.append(button(k1, X0, 652, 300, 46, shape(300, 46, 10, TEAL), shape(300, 46, 10, TEAL_FOCUS, FG, 3),
                      "[B]%s[/B]" % l1.replace("the ticked", "the %d ticked" % ticked) if ticked else "[B]%s[/B]" % l1,
                      "body", NAVY, FG, CENTER | MIDDLE))
    line.append(k1)
    out.append(button(k2, X0 + 312, 652, 200, 46, shape(200, 46, 10, CARD, LINE, 1),
                      shape(200, 46, 10, CARD_FOCUS, TEAL, 2), l2, "body", FG, align=CENTER | MIDDLE))
    line.append(k2)
    grid.append(line)
    # 2.1.1: clear of Scan again (they were drawn over it) and short enough to end before the "1-6 of 80"
    out += hints([("a", "Search"), ("y", "Tick"), ("x", "Change words")], x=X0 + 528, y=662)
    scroll = {"first": prefix + ":0", "last": "%s:%d" % (prefix, len(visible) - 1), "more_up": offset > 0,
              "more_down": offset + SR_SLOTS < len(missing), "page": SR_SLOTS}
    page = Page("search", out, [g for g in grid if g], focus or (prefix + ":0" if visible else
                                                                  "missing" if prefix == "miss" else "discover"),
                x_own=False, scroll=scroll)
    page.jump = dict(("%s:%d:go" % (prefix, i), k1) for i in range(len(visible)))  # Right: to the buttons
    return page


# ---------- dialogs in the new look (2.0.10): what Kodi's own boxes and lists used to show ----------
PX, PW = 160, 960                  # the panel: centred, the side bar's space too
PICK_SLOTS, PICK_TOP, PICK_H, PICK_STEP = 8, 112, 50, 56
DLG_BTN_W, DLG_BTN_H = 220, 46


def _wrap(message, width=78):
    import textwrap
    out = []
    for para in (message or "").split("\n"):
        out += textwrap.wrap(para, width) or [""]
    return out


def message_fits(message):
    return len(_wrap(message)) <= 10


def message_page(heading, message, buttons, focus=None):
    """A message with buttons along the bottom: OK, or No / Yes (the last button is the default)."""
    lines = _wrap(message)[:10]
    ph = 150 + 30 * len(lines) + DLG_BTN_H
    py = max(20, (H - ph) // 2)
    out = [img("bg", 0, 0, W, H, shape(W, H, 0, BG)),
           img("panel", PX, py, PW, ph, shape(PW, ph, 16, CARD, LINE, 1)),
           text("title", PX + 32, py + 20, PW - 64, 40, "[B]%s[/B]" % heading, "h", FG)]
    for i, line in enumerate(lines):
        out.append(text("line%d" % i, PX + 32, py + 72 + 30 * i, PW - 64, 30, line, "body", "FFC9D3DA"))
    keys, x = [], PX + PW - 32 - len(buttons) * (DLG_BTN_W + 12) + 12
    for i, label in enumerate(buttons):
        key = "b:%d" % i
        out.append(button(key, x, py + ph - DLG_BTN_H - 24, DLG_BTN_W, DLG_BTN_H,
                          shape(DLG_BTN_W, DLG_BTN_H, 10, CARD_FOCUS, LINE, 1),
                          shape(DLG_BTN_W, DLG_BTN_H, 10, TEAL), label, "body", FG, NAVY, CENTER | MIDDLE))
        keys.append(key)
        x += DLG_BTN_W + 12
    page = Page("dialog", out, [keys], focus or keys[-1])
    return page


WELCOME_NOTES = 10


def welcome_page(heading, intro, examples, notes, label="Get started"):
    """The first screen after install: logo and title, one intro line, up to 4 example folders in a card, up to
    WELCOME_NOTES lines of notes and one big button. Fixed sizes (nothing depends on the words). 2.0.11."""
    ph, py = 620, 50
    out = [img("bg", 0, 0, W, H, shape(W, H, 0, BG)),
           img("panel", PX, py, PW, ph, shape(PW, ph, 16, CARD, LINE, 1)),
           img("logo", PX + 32, py + 22, 56, 56, icon("logo")),
           text("title", PX + 104, py + 22, PW - 136, 56, "[B]%s[/B]" % heading, "title", FG)]
    out.append(text("intro", PX + 32, py + 96, PW - 64, 30, short(intro, 90), "body", "FFC9D3DA"))
    out.append(img("card", PX + 32, py + 134, PW - 64, 124, shape(PW - 64, 124, 12, BG, LINE, 1)))
    for i in range(4):
        out.append(text("ex%d" % i, PX + 56, py + 142 + 27 * i, PW - 112, 27,
                        examples[i] if i < len(examples) else "", "body", TEAL))
    lines = []
    for para in (notes or "").split("\n\n"):
        lines += _wrap(para.replace("\n", " "), 88) + [""]
    lines = lines[:-1][:WELCOME_NOTES]
    for i in range(WELCOME_NOTES):
        out.append(text("note%d" % i, PX + 32, py + 280 + 25 * i, PW - 64, 25, lines[i] if i < len(lines) else "",
                        "body", "FFC9D3DA"))
    bw, bh = 260, 50
    out.append(button("b:0", PX + PW - 32 - bw, py + ph - bh - 20, bw, bh, shape(bw, bh, 10, CARD_FOCUS, LINE, 1),
                      shape(bw, bh, 10, TEAL), label, "body", FG, NAVY, CENTER | MIDDLE))
    return Page("welcome", out, [["b:0"]], "b:0")


def pick_page(heading, items, offset=0, ticked=None, focus=None):
    """A list to pick from, a page of rows at a time. items: [(label, label2)]. ticked: a set of indexes for a
    list where several can be picked (then Done / Cancel along the bottom); None for pick-one."""
    multi = ticked is not None
    visible = items[offset:offset + PICK_SLOTS]
    rw = PW - 48
    out = [img("bg", 0, 0, W, H, shape(W, H, 0, BG)),
           img("panel", PX, 20, PW, H - 40, shape(PW, H - 40, 16, CARD, LINE, 1)),
           text("title", PX + 32, 36, PW - 260, 44, "[B]%s[/B]" % heading, "h", FG)]
    if len(items) > PICK_SLOTS:
        out.append(text("more", PX + PW - 232, 36, 200, 44, "%d-%d of %d" % (offset + 1, offset + len(visible),
                                                                              len(items)), "small", DIM, RIGHT | MIDDLE))
    grid = []
    for i, (label, label2) in enumerate(visible):
        y = PICK_TOP + i * PICK_STEP
        key = "p:%d" % i
        out.append(button(key, PX + 24, y, rw, PICK_H, shape(rw, PICK_H, 10, BG), shape(rw, PICK_H, 10, CARD_FOCUS,
                                                                                         TEAL, 2)))
        tx = PX + 44
        if multi:
            on = (offset + i) in ticked
            out.append(img(key + ":box", PX + 40, y + 13, 24, 24, icon("box_on" if on else "box_off")))
            tx = PX + 78
        out.append(text(key + ":s", tx, y, rw - (tx - PX) - 230 + 24, PICK_H, short(label, 78), "body", FG))
        out.append(text(key + ":s2", PX + rw - 200, y, 210, PICK_H, short(label2 or "", 30), "small", MUTE,
                        RIGHT | MIDDLE))
        grid.append([key])
    if not visible:
        out.append(text("empty", PX + 24, PICK_TOP, rw, 60, "Nothing to pick.", "body", MUTE, CENTER | MIDDLE))
    line = []
    if multi:
        for j, label in enumerate(("Cancel", "Done (%d)" % len(ticked))):
            key = ("b:cancel", "b:done")[j]
            x = PX + PW - 24 - (2 - j) * (DLG_BTN_W + 12) + 12
            out.append(button(key, x, 600, DLG_BTN_W, DLG_BTN_H, shape(DLG_BTN_W, DLG_BTN_H, 10, CARD_FOCUS, LINE, 1),
                              shape(DLG_BTN_W, DLG_BTN_H, 10, TEAL), label, "body", FG, NAVY, CENTER | MIDDLE))
            line.append(key)
        grid.append(line)
    out += hints([("a", "Tick" if multi else "Pick"), ("b", "Back")], x=PX + 24, y=656)
    scroll = {"first": "p:0", "last": "p:%d" % (len(visible) - 1), "more_up": offset > 0,
              "more_down": offset + PICK_SLOTS < len(items), "page": PICK_SLOTS}
    return Page("pick", out, [g for g in grid if g], focus or ("p:0" if visible else (line[-1] if line else None)),
                scroll=scroll)


def progress_page(heading, message, pct, cancel=True):
    """Work in progress: up to 4 lines, a bar and its percent, and Cancel (B works too). 2.0.10."""
    lines = _wrap(message)[:4]
    ph = 300
    py = (H - ph) // 2
    out = [img("bg", 0, 0, W, H, shape(W, H, 0, BG)),
           img("panel", PX, py, PW, ph, shape(PW, ph, 16, CARD, LINE, 1)),
           text("title", PX + 32, py + 20, PW - 64, 40, "[B]%s[/B]" % heading, "h", FG)]
    for i in range(4):
        out.append(text("line%d" % i, PX + 32, py + 68 + 28 * i, PW - 64, 28, lines[i] if i < len(lines) else "",
                        "body", "FFC9D3DA"))
    pct = max(0, min(100, int(pct or 0)))
    out += bar("bar", PX + 32, py + 196, PW - 160, 10, pct / 100.0)
    out.append(text("pct", PX + PW - 116, py + 186, 84, 30, "[B]%d%%[/B]" % pct, "body", FG, RIGHT | MIDDLE))
    rows = []
    if cancel:
        out.append(button("b:cancel", PX + PW - 32 - DLG_BTN_W, py + ph - DLG_BTN_H - 20, DLG_BTN_W, DLG_BTN_H,
                          shape(DLG_BTN_W, DLG_BTN_H, 10, CARD_FOCUS, LINE, 1), shape(DLG_BTN_W, DLG_BTN_H, 10, TEAL),
                          "Cancel", "body", FG, NAVY, CENTER | MIDDLE))
        rows = [["b:cancel"]]
    return Page("progress", out, rows, "b:cancel" if cancel else None)


GENRE_COLS, GENRE_ROWS = 5, 8
GENRE_W, GENRE_H, GENRE_GAP_X, GENRE_STEP = 176, 40, 8, 46
GENRE_COLOUR = {"discogs": "FFC8590F", "lastfm": "FF0E8A8F", "both": "FF7C5CC4", "none": "FF5A6B7D"}
GENRE_KEY = (("discogs", "Discogs"), ("lastfm", "Last.fm"), ("both", "Both"), ("none", "Outline only"))


def genre_page(title, subtitle, shown, kinds, picks, page, pages, one_track=True):
    """The genre screen in the 2.0 look: a grid of chips (filled and ticked when on, coloured by where the genre
    comes from), then Previous / Next / Change one track / Skip / Save. shown: the names on this page."""
    x0 = PX + 24
    out = [img("bg", 0, 0, W, H, shape(W, H, 0, BG)),
           img("panel", PX, 20, PW, H - 40, shape(PW, H - 40, 16, CARD, LINE, 1)),
           text("title", PX + 32, 30, PW - 330, 40, "[B]%s[/B]" % short(title, 40), "h", FG),
           text("sub", PX + 32, 66, PW - 64, 26, short(subtitle, 100), "small", MUTE),
           text("count", PX + PW - 300, 30, 268, 40, "%d on    Page %d of %d" % (len(picks), page + 1, pages),
                "body", MUTE, RIGHT | MIDDLE)]
    x = x0 + 8
    for kind, label in GENRE_KEY:  # what the colours mean
        out.append(img("key:%s" % kind, x, 98, 16, 16, shape(16, 16, 4, GENRE_COLOUR[kind])))
        out.append(text("key:%s:s" % kind, x + 24, 94, 130, 24, label, "small", MUTE))
        x += 24 + 12 * len(label) // 2 + 36
    rows, row = [], []
    for i, name in enumerate(shown):
        kind = kinds.get(name, "none")
        on = name in picks
        colour = GENRE_COLOUR.get(kind, GENRE_COLOUR["none"])
        key = "c:%d" % i
        cx, cy = x0 + (i % GENRE_COLS) * (GENRE_W + GENRE_GAP_X), 128 + (i // GENRE_COLS) * GENRE_STEP
        off = shape(GENRE_W, GENRE_H, 10, colour if on else BG, colour, 2)
        focus = shape(GENRE_W, GENRE_H, 10, colour if on else CARD_FOCUS, FG, 3)
        out.append(button(key, cx, cy, GENRE_W, GENRE_H, off, focus, short(name, 18), "body", FG, FG,
                          CENTER | MIDDLE))
        if on:
            out.append(img(key + ":tick", cx + 8, cy + 11, 18, 18, icon("check")))
        row.append(key)
        if len(row) == GENRE_COLS:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    labels = [("Previous page", "prev"), ("Next page", "next")]
    if one_track:
        labels.append(("Change one track", "track"))
    labels += [("Skip", "skip"), ("Save", "save")]
    bw = (GENRE_COLS * GENRE_W + (GENRE_COLS - 1) * GENRE_GAP_X - 10 * (len(labels) - 1)) // len(labels)
    line = []
    for n, (label, what) in enumerate(labels):
        key = "b:" + what
        out.append(button(key, x0 + n * (bw + 10), 556, bw, DLG_BTN_H, shape(bw, DLG_BTN_H, 10, CARD_FOCUS, LINE, 1),
                          shape(bw, DLG_BTN_H, 10, TEAL), label, "body", FG, NAVY, CENTER | MIDDLE))
        line.append(key)
    out += hints([("a", "Tick"), ("b", "Back")], x=PX + 24, y=656)
    scroll = {"first": "", "last": "", "more_up": page > 0, "more_down": page + 1 < pages, "page": 1}
    return Page("genres", out, rows + [line], "c:0" if shown else "b:save", scroll=scroll)


TEXT_LINES = 16


def text_lines(body):
    return _wrap(body, 104)


def text_page(heading, lines, offset, buttons, focus=None):
    """Long text (the guide, a report, a long message): TEXT_LINES at a time, Up / Down page through it, the
    buttons along the bottom (Close, or the question's answers). 2.0.10."""
    shown = lines[offset:offset + TEXT_LINES]
    out = [img("bg", 0, 0, W, H, shape(W, H, 0, BG)),
           img("panel", PX - 100, 20, PW + 200, H - 40, shape(PW + 200, H - 40, 16, CARD, LINE, 1)),
           text("title", PX - 68, 34, PW - 100, 44, "[B]%s[/B]" % heading, "h", FG)]
    if len(lines) > TEXT_LINES:
        out.append(text("more", PX + PW - 132, 34, 200, 44, "lines %d-%d of %d" % (
            offset + 1, offset + len(shown), len(lines)), "small", DIM, RIGHT | MIDDLE))
    for i in range(TEXT_LINES):
        out.append(text("line%d" % i, PX - 68, 88 + 29 * i, PW + 136, 29, shown[i] if i < len(shown) else "",
                        "body", "FFC9D3DA"))
    keys, x = [], PX + PW + 68 - len(buttons) * (DLG_BTN_W + 12) + 12
    for i, label in enumerate(buttons):
        key = "b:%d" % i
        out.append(button(key, x, 572, DLG_BTN_W, DLG_BTN_H, shape(DLG_BTN_W, DLG_BTN_H, 10, CARD_FOCUS, LINE, 1),
                          shape(DLG_BTN_W, DLG_BTN_H, 10, TEAL), label, "body", FG, NAVY, CENTER | MIDDLE))
        keys.append(key)
        x += DLG_BTN_W + 12
    out += hints([("a", "Choose"), ("b", "Back")], x=PX - 68, y=650)[:4]  # up/down: the next or last lines
    out.append(text("hint:ud", PX + 120, 650, 300, 26, "Up / Down: more text", "small", MUTE))
    # the buttons are the only row: Up / Down on them page the text
    scroll = {"first": "b", "last": "b", "more_up": offset > 0, "more_down": offset + TEXT_LINES < len(lines),
              "page": TEXT_LINES}
    return Page("text", out, [keys], focus or keys[-1], scroll=scroll)


def _src(name):
    """A picture of ours (resources/media/ui), or a full path such as special://temp/... (a QR code made now)."""
    return name if "://" in name else MEDIA + name


def qr_page(heading, message, qr, status="", button_label="Cancel"):
    """A QR code for the phone's camera on the left, what to do on the right, a status line (Waiting... 9 min
    left) and one button. qr: the picture's full path. 2.0.10."""
    out = [img("bg", 0, 0, W, H, shape(W, H, 0, BG)),
           img("panel", PX - 100, 30, PW + 200, H - 60, shape(PW + 200, H - 60, 16, CARD, LINE, 1)),
           text("title", PX - 68, 50, PW + 136, 44, "[B]%s[/B]" % heading, "h", FG),
           img("qr:back", PX - 68, 116, 440, 440, shape(440, 440, 12, "FFFFFFFF")),
           img("qr", PX - 48, 136, 400, 400, qr)]
    lines = _wrap(message, 46)[:13]
    for i in range(13):
        out.append(text("line%d" % i, PX + 400, 116 + 29 * i, 620, 29, lines[i] if i < len(lines) else "", "body",
                        "FFC9D3DA"))
    out.append(text("status", PX + 400, 506, 620, 30, status, "body", TEAL))
    out.append(button("b:0", PX + PW + 68 - DLG_BTN_W, 584, DLG_BTN_W, DLG_BTN_H,
                      shape(DLG_BTN_W, DLG_BTN_H, 10, CARD_FOCUS, LINE, 1), shape(DLG_BTN_W, DLG_BTN_H, 10, TEAL),
                      button_label, "body", FG, NAVY, CENTER | MIDDLE))
    out += hints([("a", button_label), ("b", "Back")], x=PX - 68, y=596)[:4]
    return Page("qr", out, [["b:0"]], "b:0")


# ---------- the window ----------
SIDE_KEYS = ("bg", "side", "logo", "brand", "nav", "foot")  # the side bar: nothing on a page overlaps it


def _group(key):
    return ":".join(key.split(":")[:2])


def _kept(old, new, made):
    """The side bar's widgets that can stay from the last page: a whole group (a place's button, mark,
    icon and words) when every part of it is the same, so a remade button never covers a kept icon."""
    before = dict((w["key"], w) for w in old)
    groups = {}
    for w in new:
        if w["key"].split(":")[0] in SIDE_KEYS:
            groups.setdefault(_group(w["key"]), []).append(w)
    old_groups = {}
    for w in old:
        old_groups.setdefault(_group(w["key"]), set()).add(w["key"])
    out = set()
    for g, ws in groups.items():
        if old_groups.get(g) == set(w["key"] for w in ws) and \
                all(before.get(w["key"]) == w and w["key"] in made for w in ws):
            out.update(w["key"] for w in ws)
    return out


MAIN = []  # 2.1.0: Sortovia's open window (ui_main's). Dialogs draw on it as a layer instead of their own window


def open_window():
    """The window a dialog page goes on: a layer on top of Sortovia's open window (2.1.0: it used to close
    that window and open a new one, so Kodi's empty list flashed behind and nothing had focus after), or a
    window of its own when Sortovia's isn't open (a context menu, the service)."""
    if MAIN and MAIN[0].shown:
        return Layer(MAIN[0])
    return Window()


class Layer(object):
    """A dialog on top of the open window: its buttons are added over the page, and close() takes just them
    away, so the page underneath is back at once with the cursor where it was."""

    def __init__(self, win):
        self.win = win
        self.open = True
        win.push()

    @property
    def events(self):
        return self.win.events

    @property
    def shown(self):
        return self.open

    def show(self, page, focus=None):
        self.win.show(page, focus)

    def wait(self, seconds=0):
        return self.win.wait(seconds)

    def focused(self):
        return self.win.focused()

    def hide(self):
        del self.win.events[:]

    def close(self):
        if self.open:
            self.open = False
            self.win.pop()


class Window(object):
    """One Kodi window that shows Page after Page. show(page) puts a page up (replacing what's there, or
    updating it in place when it has the same buttons), wait() returns the next event:
    ("click", key), ("x", key), ("y", key), ("back", key) or ("tick",) when a live page is due to refresh.
    push() / pop() put a dialog's page over the current one and take it away again (see Layer)."""

    def __init__(self):
        import sys
        import xbmcgui
        self.gui = xbmcgui
        shell = self
        if "unittest" not in sys.modules:  # on Kodi: see _nearest
            _load_have()

        class Win(xbmcgui.WindowDialog):
            def onAction(self, action):
                shell._action(action.getId())

            def onControl(self, control):
                shell._click(control.getId())

        self.win = Win()
        self.controls = {}   # key -> control
        self.ids = {}        # control id -> key
        self.events = []
        self.page = None
        self.shown = False
        self.nav = {}  # key -> (up, down, left, right) as last set
        self.below = []  # the pages under a dialog layer: (page, controls, ids, nav, focused key)
        self.video = None  # was a video playing when the window opened (None: not looked yet)

    # building
    def _make(self, w):
        g = self.gui
        if w["t"] == "img":
            c = g.ControlImage(w["x"], w["y"], w["w"], w["h"], _src(w["src"]), 0, w["color"] or "0xFFFFFFFF")
        elif w["t"] == "text":
            c = g.ControlLabel(w["x"], w["y"], w["w"], w["h"], w["s"], font=FONT[w["font"]], textColor=w["color"],
                               alignment=w["align"])
        else:
            c = g.ControlButton(w["x"], w["y"], w["w"], w["h"], w["s"], focusTexture=MEDIA + w["on"],
                                noFocusTexture=MEDIA + w["off"], textOffsetX=w["pad"], alignment=w["align"],
                                font=FONT[w["font"]], textColor=w["color"], focusedColor=w["focus_color"])
        return c

    def _same_shape(self, page):
        if not self.page or self.page.name != page.name:
            return False
        old = dict((w["key"], w) for w in self.page.widgets)
        if set(old) != set(w["key"] for w in page.widgets):
            return False
        look = ("x", "y", "w", "h", "off", "on", "color", "focus_color", "font", "align", "pad")
        # 2.0.6: a button whose look changed (a filter chosen) is made again: Kodi can't change a button's
        # pictures or colours once it's made, so the old chosen look stayed and the Finished filter vanished
        return all(old[w["key"]]["t"] == w["t"] and (w["t"] != "btn" or
                   tuple(old[w["key"]].get(k) for k in look) == tuple(w.get(k) for k in look)) for w in page.widgets)

    def show(self, page, focus=None):
        same = self._same_shape(page)
        # 2.2.7: an arrow pressed while a refresh of this page was being made (Downloads: every second) counts:
        # the cursor stays where that press put it. It went back to where it was when the refresh began, so
        # Down from the end of the list or Right from a row to the buttons under it was undone again and again
        cur = self.focused() if self.shown and self.page is not None and self.page.name == page.name else None
        # Kodi moves the cursor before Sortovia hears of the press: one step from where the refresh began counts too
        moved = cur and (getattr(self, "pressed_at", 0) > getattr(self, "returned_at", 0) or
                         cur != focus and cur in (self.nav.get(focus) or ()))
        before = cur if moved else None
        if same:
            self._update(page)
            self._navigate(page)
        else:
            self._build(page)
        if before in self.controls:
            focus = before
        asked, self.asked = getattr(self, "asked", None), (page.name, focus)
        now = self.focused() if same and self.shown else None
        if now in self.controls and asked == (page.name, focus):
            # 2.2.3: a live page's refresh (Downloads, every second) leaves the cursor where the user has it: it put
            # it back on the key saved just before, so a press while the page was being made was undone and
            # the buttons under the list could not be reached
            self.page = page
            return
        self.page = page
        if not self.shown:
            self.win.show()
            self.shown = True
        # 2.1.0: focus after the window is up. Set before, Kodi put it back on a button id from before the
        # page was rebuilt - one that no longer exists - so nothing had focus and only Back worked.
        want = focus if focus in self.controls else page.focus  # a saved key that's gone: the page's own start
        if self.focused() != want:
            trace("page %s %s: cursor set on %s (it was on %s)" % (page.name, "updated" if same else "made",
                                                                    want, self.focused()))
        self._focus(want)
        self.want = (want, time.time())

    def _focus(self, key):
        c = self.controls.get(key)
        if c is None and self.page:
            c = self.controls.get(self.page.focus) or next(
                (self.controls[k] for k in self.page.keys() if k in self.controls), None)
        if c is not None:
            try:
                self.win.setFocus(c)
            except Exception:
                pass

    def _build(self, page):
        """A new page. 2.1.0: the widgets it starts with that are the same as the last page's (the side bar,
        the title) stay as they are - only the rest is made again, which is most of the time a page took."""
        kept = _kept(self.page.widgets if self.page else [], page.widgets, self.controls)
        gone = [c for k, c in self.controls.items() if k not in kept]
        if gone:
            try:
                self.win.removeControls(gone)
            except Exception:
                for c in gone:
                    try:
                        self.win.removeControl(c)
                    except Exception:
                        pass
        self.controls = dict((k, c) for k, c in self.controls.items() if k in kept)
        made = [(w["key"], self._make(w)) for w in page.widgets if w["key"] not in kept]
        if made:
            self.win.addControls([c for _, c in made])
        self.controls.update(made)
        self.ids = dict((c.getId(), k) for k, c in self.controls.items())
        self.nav = {}
        self._navigate(page)

    # dialog layers
    def push(self):
        """A dialog goes on top: the page's controls stay where they are, out of the D-pad's way."""
        self.below.append((self.page, self.controls, self.ids, self.nav, self.focused()))
        # 2.2.2: the page's buttons under the dialog can't take the cursor (with no button on the dialog, a
        # progress screen, the cursor moved round the hidden page and A did nothing there)
        self._enable(self.controls, self.page, False)
        self.page, self.controls, self.ids, self.nav = None, {}, {}, {}
        del self.events[:]

    @staticmethod
    def _enable(controls, page, on):
        for w in (page.widgets if page else []):
            c = controls.get(w["key"])
            if w["t"] == "btn" and c is not None:
                try:
                    c.setEnabled(on)
                except Exception:
                    pass

    def pop(self):
        """The dialog goes: its controls are removed and the page under it is back, focus where it was."""
        if not self.below:
            return
        if self.controls:
            try:
                self.win.removeControls(list(self.controls.values()))
            except Exception:
                for c in self.controls.values():
                    try:
                        self.win.removeControl(c)
                    except Exception:
                        pass
        self.page, self.controls, self.ids, self.nav, was = self.below.pop()
        self._enable(self.controls, self.page, True)
        del self.events[:]
        if self.shown:
            self._focus(was)

    def _navigate(self, page):
        """Sets where each button's arrows go: on a new page, and when an in-place update changes it (2.0.3: a
        list paged to its end kept "Down stays put" from the page before, so the buttons under it were unreachable)."""
        nav = navigation(page)
        for key, (u, d, l, r) in nav.items():
            c = self.controls.get(key)
            if c is None or self.nav.get(key) == (u, d, l, r):
                continue
            try:
                c.setNavigation(self.controls.get(u, c), self.controls.get(d, c), self.controls.get(l, c),
                                self.controls.get(r, c))
                self.nav[key] = (u, d, l, r)
            except Exception:
                pass

    def _update(self, page):
        old = dict((w["key"], w) for w in self.page.widgets)
        # 2.0.8: Kodi ignores a new colour or font on a label that's already made, and a label kept its old width
        # (a row that was REAL-DEBRID showed a teal "YOUT..."). A label or picture that changed in more than its
        # words or picture is made again, with the rest of its group (a tag's box and text) so the text stays on top.
        same = lambda w, o, ks: all(w.get(k) == o.get(k) for k in ks)
        redo = set()
        for w in page.widgets:
            o = old[w["key"]]
            if w["t"] == "text" and not same(w, o, ("h", "color", "font", "align")) or \
                    w["t"] == "img" and not same(w, o, ("h", "color")):
                redo.add(w["key"].rsplit(":", 1)[0])
        again = [w for w in page.widgets if w["t"] != "btn" and w["key"].rsplit(":", 1)[0] in redo]
        if again:
            gone = [self.controls[w["key"]] for w in again]
            try:
                self.win.removeControls(gone)
            except Exception:
                pass
            for c in gone:
                self.ids.pop(c.getId(), None)
            made = [(w["key"], self._make(w)) for w in again]
            self.win.addControls([c for _, c in made])
            for key, c in made:
                self.controls[key] = c
                self.ids[c.getId()] = key
        remade = set(w["key"] for w in again)
        for w in page.widgets:
            c, o = self.controls[w["key"]], old[w["key"]]
            if w == o or w["key"] in remade:
                continue
            try:
                if w["t"] in ("text", "img"):
                    if w["t"] == "text" and w["s"] != o["s"]:
                        c.setLabel(w["s"])
                    if w["t"] == "img" and w["src"] != o["src"]:
                        c.setImage(_src(w["src"]), False)
                    if (w["x"], w["y"]) != (o["x"], o["y"]):
                        c.setPosition(w["x"], w["y"])
                    if w["w"] != o["w"]:
                        c.setWidth(w["w"])
                else:
                    c.setLabel(w["s"])
            except Exception:
                pass

    # events
    def focused(self):
        try:
            return self.ids.get(self.win.getFocusId())
        except Exception:
            return None

    def _action(self, aid):
        self.want = (None, 0)  # a press: the cursor is the user's now
        if aid in (ACT_UP, ACT_DOWN, ACT_LEFT, ACT_RIGHT, ACT_SELECT) + PAGE_UPS + PAGE_DOWNS:
            trace("%s pressed on %s: was on %s, Kodi put it on %s" % (
                ARROW_NAMES.get(aid, aid), self.page.name if self.page else "-", getattr(self, "seen", None),
                self.focused()))
            self.check_at = time.time() + 0.6  # where it ends up is noted in wait()
        if aid in (ACT_UP, ACT_DOWN, ACT_LEFT, ACT_RIGHT):
            self.pressed_at = time.time()  # 2.2.7: see show()
        key = self.focused()
        p = self.page
        arrows = {ACT_UP: 0, ACT_DOWN: 1, ACT_LEFT: 2, ACT_RIGHT: 3}
        # 2.2.3: checked in wait(): see _nudge. 2.2.4: only when the cursor is still where it was before the press -
        # Kodi has mostly moved it already when this is called, and moving it on from there went 2 places
        if key and aid in arrows and key in self.nav and key == getattr(self, "seen", None):
            self.expect = (key, self.nav[key][arrows[aid]], time.time())
        else:
            self.expect = (None, None, 0)
        if aid in ACT_BACK:
            self.events.append(("back", key))
        elif aid in ACT_Y:
            self.events.append(("y", key))
        elif aid in ACT_X:
            self.events.append(("x", key))
        elif p and p.scroll and key:
            sc, n = p.scroll, p.scroll.get("page", 6)
            # 2.0.10: any part of the end row (a missing episode's Search button too) pages the list
            row = lambda k: k and (key == k or key.startswith(k + ":"))
            if aid in PAGE_DOWNS + (ACT_MOUSE_DOWN,) or (aid == ACT_DOWN and row(sc.get("last"))):
                if sc.get("more_down"):  # 2.1.0: Down moves one row (the cursor stays on the bottom row); PageDown a page
                    self.events.append(("scroll", key, n if aid in PAGE_DOWNS else 1))  # 2.1.0: Down: one row
                elif aid in PAGE_DOWNS and sc.get("last") in self.controls:
                    self.win.setFocus(self.controls[sc["last"]])
            elif aid in PAGE_UPS + (ACT_MOUSE_UP,) or (aid == ACT_UP and row(sc.get("first"))):
                if sc.get("more_up"):
                    self.events.append(("scroll", key, -n if aid in PAGE_UPS else -1))
                elif aid in PAGE_UPS and sc.get("first") in self.controls:
                    self.win.setFocus(self.controls[sc["first"]])

    def _click(self, cid):
        key = self.ids.get(cid)
        if key:
            self.events.append(("click", key))

    def wait(self, seconds=0):
        """The next event; ("tick",) after `seconds` with none (0: wait for one). ("quit",) if Kodi is closing,
        or a video starts playing (2.1.0: the window stays open now, so it would cover the video)."""
        try:
            return self._wait(seconds)
        finally:
            self.returned_at = time.time()  # 2.2.7: presses after this are newer than the page being made next

    def _wait(self, seconds=0):
        import xbmc
        monitor = xbmc.Monitor()
        waited, looked = 0.0, -1.0
        self.seen = self.focused()
        while not self.events:
            if monitor.waitForAbort(0.05):
                return ("quit",)
            waited += 0.05
            if waited - looked >= 1.0:
                looked = waited
                if self._video_started(xbmc):
                    return ("quit", "video")
            self._refocus()
            self._nudge()
            if getattr(self, "check_at", 0) and time.time() > self.check_at:
                self.check_at = 0
                trace("... and a moment later it's on %s" % self.focused())
            self.seen = self.focused()  # where the cursor was before the next press
            if seconds and waited >= seconds:
                return ("tick",)
        return self.events.pop(0)

    def _nudge(self):
        """2.2.3: an arrow press that left the cursor where it was, though the page says it goes somewhere else
        (Down from the end of the Downloads list to the buttons under it, which stayed out of reach), moves it
        there."""
        key, target, at = getattr(self, "expect", (None, None, 0))
        if not key or time.time() - at < 0.3:
            return
        self.expect = (None, None, 0)
        if target != key and target in self.controls and self.focused() == key and \
                not any(e[0] == "scroll" for e in self.events):
            trace("Kodi didn't move it off %s: Sortovia moves it to %s" % (key, target))
            self._focus(target)

    def _refocus(self):
        """2.2.2: for half a second after a page goes up, the cursor is put back if Kodi moved it (when the
        button that had it is taken away, Kodi moves it on by itself a moment later: Downloads chosen in the
        side bar lit up Library)."""
        want, at = getattr(self, "want", (None, 0))
        if not want or time.time() - at > 0.5:
            return
        now = self.focused()
        if now in (self.nav.get(want) or ()):  # 2.2.7: one arrow press away: the user moved it, leave it
            self.want = (None, 0)
            return
        if now != want and want in self.controls:
            trace("put back on %s (it was on %s) after the page went up" % (want, now))
            self._focus(want)

    def _video_started(self, xbmc):
        try:
            now = bool(xbmc.getCondVisibility("Player.HasVideo"))
        except Exception:
            return False
        if self.video is None:
            self.video = now
        started = now and not self.video
        self.video = now
        return started

    def hide(self):
        """2.1.0: the window stays up while a dialog or menu runs (they draw on it as a layer, and Kodi's own
        keyboard opens on top), so there's nothing to hide; only the waiting presses are dropped."""
        del self.events[:]

    def close(self):
        if MAIN and MAIN[0] is self:
            del MAIN[:]
        if self.shown:
            try:
                self.win.close()
            except Exception:
                pass
            self.shown = False
        del self.events[:]
        del self.win
