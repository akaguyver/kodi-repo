"""Check which music albums have cover art, and compare with an earlier copy of the library.

Reads Kodi's music database and changes nothing.
"""
import re
import sqlite3

try:
    from urllib.parse import unquote
except ImportError:
    from urllib import unquote

_FILE = re.compile(r"^(.*[\\/])([^\\/]+)$")
IMAGE_RE = re.compile(r"(?i)\.(?:jpe?g|png|webp|gif|bmp)$")
ALBUMS = """SELECT album.idAlbum, album.strAlbum, MIN(path.strPath), MIN(path.strPath || song.strFileName)
            FROM album JOIN song ON song.idAlbum = album.idAlbum JOIN path ON path.idPath = song.idPath
            GROUP BY album.idAlbum"""
ART = "SELECT media_id, url FROM art WHERE media_type = 'album' AND type = 'thumb'"


def read_albums(db_path):
    """{album name in lower case: {"name", "folder", "art": address or ""}}"""
    conn = sqlite3.connect(db_path, timeout=30)
    try:
        art = dict(conn.execute(ART).fetchall())
        return dict((name.lower(), {"name": name, "folder": folder, "art": art.get(album_id, "")})
                    for album_id, name, folder, _ in conn.execute(ALBUMS).fetchall() if name)
    finally:
        conn.close()


def art_file(url):
    """The file an art address points to: the picture itself, or the song holding it. "" for web art."""
    if url.startswith("image://"):
        m = re.match(r"^image://(?:music@)?(.*?)/?$", url)
        url = unquote(m.group(1)) if m else ""
    return url if url.startswith("win-lib://") else ""


def _file_there(path, listdir):
    m = _FILE.match(path)
    return bool(m) and m.group(2) in listdir(m.group(1))[1]


def compare(now, before, listdir):
    """Sort each album into one of: ok, missing_file, lost, cover_unused, none."""
    out = dict((key, []) for key in ("ok", "missing_file", "lost", "cover_unused", "none"))
    for key in sorted(now):
        album = now[key]
        name = album["name"]
        if album["art"]:
            path = art_file(album["art"])
            out["missing_file" if path and not _file_there(path, listdir) else "ok"].append(name)
        elif before and before.get(key, {}).get("art"):
            out["lost"].append(name)
        else:
            images = sorted(f for f in listdir(album["folder"])[1] if IMAGE_RE.search(f))
            if images:
                out["cover_unused"].append("%s (%s)" % (name, images[0]))
            else:
                out["none"].append(name)
    return out


def report(found, had_backup):
    """The report as text for the screen and the phone."""
    total = sum(len(v) for v in found.values())
    lines = ["Music art check: %d albums, %d with art." % (total, len(found["ok"])), ""]
    if not had_backup:
        lines += ["No earlier copy of the music library was found, so nothing could be compared.", ""]
    elif not found["lost"]:
        lines += ["No album lost its art compared with your backup from before the switch.", ""]
    sections = (("lost", "Had art in your backup, but not now"),
                ("missing_file", "Art points to a file that isn't there"),
                ("cover_unused", "No art in Kodi, but an image is in the folder"),
                ("none", "No art in Kodi and no image in the folder"))
    for key, title in sections:
        if found[key]:
            lines += ["%s (%d):" % (title, len(found[key]))] + ["  %s" % n for n in found[key]] + [""]
    lines.append("Artwork can also take a while to appear while Kodi rebuilds its picture cache.")
    return "\n".join(lines)
