"""Torrent search across several indexes at once, grouped into categories you choose.

Each index is a small reader for one site's search. Built in: Knaben (it searches many trackers at once),
The Pirate Bay, Nyaa, Torrents-CSV and YTS. You can add your own: a Torznab address (Jackett or Prowlarr, which
reach almost any tracker, private ones too) or any search page that gives RSS with {q} where the words go.
Each index can be turned off, and categories (Music, Videos ...) say which indexes are searched for what.
Nothing here downloads: a result's magnet link goes to Real-Debrid.
"""
import json
import re
import threading
import xml.etree.ElementTree as ET

try:
    from urllib.parse import quote
    from urllib.request import Request, urlopen
except ImportError:  # Kodi 18 and older
    from urllib import quote
    from urllib2 import Request, urlopen

TRACKERS = ["udp://tracker.opentrackr.org:1337/announce", "udp://open.stealth.si:80/announce",
            "udp://tracker.torrent.eu.org:451/announce", "udp://exodus.desync.com:6969/announce"]

BUILT_IN = [
    {"id": "knaben", "name": "Knaben (searches many trackers at once)", "kind": "knaben"},
    {"id": "tpb", "name": "The Pirate Bay", "kind": "apibay"},
    {"id": "nyaa", "name": "Nyaa (anime and Japanese music)", "kind": "nyaa"},
    {"id": "tcsv", "name": "Torrents-CSV", "kind": "tcsv"},
    {"id": "yts", "name": "YTS (movies)", "kind": "yts"},
]
GROUPS = {  # the categories to start with; each can be changed
    "Everything": ["knaben", "tpb", "nyaa", "tcsv", "yts"],
    "Music": ["knaben", "tpb", "nyaa", "tcsv"],
    "Music videos": ["knaben", "tpb", "tcsv"],
    "Movies": ["knaben", "tpb", "yts", "tcsv"],
    "TV": ["knaben", "tpb", "tcsv"],
    "Anime": ["nyaa", "knaben"],
}
# The Pirate Bay's own category numbers, so a Music search there only finds audio
TPB_CATS = {"Music": "100", "Music videos": "200", "Movies": "200", "TV": "200"}


def _get(url, data=None, headers=None, timeout=20):
    h = {"User-Agent": "Mozilla/5.0 (Sortovia for Kodi)"}
    h.update(headers or {})
    resp = urlopen(Request(url, data=data, headers=h), timeout=timeout)
    try:
        return resp.read()
    finally:
        resp.close()


def magnet(info_hash, name):
    return "magnet:?xt=urn:btih:%s&dn=%s%s" % (info_hash.lower(), quote(name or ""),
                                               "".join("&tr=" + quote(t, "") for t in TRACKERS))


def size_text(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return ("%.0f %s" if unit in ("B", "KB") else "%.1f %s") % (n, unit)
        n /= 1024


def _hit(name, info_hash, size, seeders, source, link=""):
    info_hash = (info_hash or "").strip()
    if not name or not (re.match(r"^[0-9a-fA-F]{40}$", info_hash) or link.startswith("magnet:")):
        return None
    return {"title": name, "hash": info_hash.lower(), "size": int(float(size or 0)), "seeders": int(float(seeders or 0)),
            "source": source, "magnet": link if link.startswith("magnet:") else magnet(info_hash, name)}


# ---------- one reader per kind of index ----------
def search_knaben(q, group, get=_get):
    body = json.dumps({"search_type": "100%", "search_field": "title", "query": q, "size": 50,
                       "order_by": "seeders", "order_direction": "desc", "hide_unsafe": True, "hide_xxx": True}).encode()
    data = json.loads(get("https://api.knaben.org/v1", body, {"Content-Type": "application/json"}).decode("utf-8"))
    return [_hit(h.get("title"), h.get("hash"), h.get("bytes"), h.get("seeders"),
                 "Knaben: %s" % (h.get("cachedOrigin") or h.get("tracker") or "?"), h.get("magnetUrl") or "")
            for h in data.get("hits") or []]


def search_apibay(q, group, get=_get):
    url = "https://apibay.org/q.php?q=%s&cat=%s" % (quote(q), TPB_CATS.get(group, "0"))
    rows = json.loads(get(url).decode("utf-8"))
    return [_hit(r.get("name"), r.get("info_hash"), r.get("size"), r.get("seeders"), "The Pirate Bay")
            for r in rows if r.get("info_hash") and r.get("info_hash") != "0" * 40]


def search_tcsv(q, group, get=_get):
    data = json.loads(get("https://torrents-csv.com/service/search?q=%s&size=50" % quote(q)).decode("utf-8"))
    return [_hit(t.get("name"), t.get("infohash"), t.get("size_bytes"), t.get("seeders"), "Torrents-CSV")
            for t in data.get("torrents") or []]


def search_yts(q, group, get=_get):
    data = json.loads(get("https://yts.mx/api/v2/list_movies.json?limit=20&query_term=%s" % quote(q)).decode("utf-8"))
    out = []
    for m in (data.get("data") or {}).get("movies") or []:
        for t in m.get("torrents") or []:
            out.append(_hit("%s (%s) %s %s" % (m.get("title"), m.get("year"), t.get("quality"), t.get("type", "")),
                            t.get("hash"), t.get("size_bytes"), t.get("seeds"), "YTS"))
    return out


def _rss(xml_bytes, source):
    """Results from RSS: Nyaa's, a Torznab one, or any tracker's search feed."""
    root = ET.fromstring(xml_bytes)
    out = []
    for item in root.iter("item"):
        attrs = {}
        for el in item:
            tag = el.tag.split("}")[-1]
            if tag == "attr":
                attrs[el.get("name")] = el.get("value")
            else:
                attrs.setdefault(tag, (el.text or "").strip())
            if tag == "enclosure" and el.get("url"):
                attrs.setdefault("enclosure", el.get("url"))
        link = next((v for v in (attrs.get("magneturl"), attrs.get("link"), attrs.get("enclosure"), attrs.get("guid"))
                     if v and v.startswith("magnet:")), "")
        info_hash = attrs.get("infoHash") or attrs.get("infohash") or ""
        if not info_hash and link:
            m = re.search(r"btih:([0-9a-fA-F]{40})", link)
            info_hash = m.group(1) if m else ""
        size = attrs.get("size") or attrs.get("contentLength") or 0
        if not str(size).isdigit():
            size = 0
        hit = _hit(attrs.get("title"), info_hash, size, attrs.get("seeders") or attrs.get("seeds") or 0, source, link)
        if hit is None and attrs.get("title") and attrs.get("enclosure", "").startswith("http"):
            hit = {"title": attrs["title"], "hash": "", "size": int(size or 0), "seeders": int(attrs.get("seeders") or 0),
                   "source": source, "torrent_url": attrs["enclosure"]}  # a .torrent file, which Real-Debrid takes too
        out.append(hit)
    return out


def search_nyaa(q, group, get=_get):
    return _rss(get("https://nyaa.si/?page=rss&q=%s" % quote(q)), "Nyaa")


def search_torznab(ix, q, group, get=_get):
    url = ix["url"].rstrip("/")
    if "/api" not in url:
        url += "/api"
    url += ("&" if "?" in url else "?") + "t=search&q=%s" % quote(q)
    if ix.get("key"):
        url += "&apikey=%s" % quote(ix["key"])
    return _rss(get(url), ix.get("name") or "Torznab")


def search_rss(ix, q, group, get=_get):
    return _rss(get(ix["url"].replace("{q}", quote(q))), ix.get("name") or "RSS")


READERS = {"knaben": search_knaben, "apibay": search_apibay, "tcsv": search_tcsv, "yts": search_yts, "nyaa": search_nyaa}


# ---------- settings: which indexes, which categories ----------
def indexes(prefs):
    """Every index, built in and added, with "on" set."""
    off = set(prefs.get("off") or [])
    return [dict(ix, on=ix["id"] not in off) for ix in BUILT_IN + list(prefs.get("custom") or [])]


def groups(prefs):
    g = dict((k, list(v)) for k, v in GROUPS.items())
    g.update(prefs.get("groups") or {})
    for name in prefs.get("removed_groups") or []:
        g.pop(name, None)
    return g


def in_group(prefs, group):
    """The indexes a category searches: those listed in it that are on. Added indexes are in Everything."""
    ids = groups(prefs).get(group)
    every = indexes(prefs)
    if group == "Everything" and ids is not None:
        ids = list(ids) + [ix["id"] for ix in every if ix.get("kind") in ("torznab", "rss") and ix["id"] not in ids]
    return [ix for ix in every if ix["on"] and (ids is None or ix["id"] in ids)]


def search(prefs, group, q, get=_get, timeout_each=25):
    """(results best first, {index name: problem}) from every index in the category, searched at the same time."""
    found, problems, lock = [], {}, threading.Lock()

    def one(ix):
        try:
            if ix["kind"] == "torznab":
                hits = search_torznab(ix, q, group, get)
            elif ix["kind"] == "rss":
                hits = search_rss(ix, q, group, get)
            else:
                hits = READERS[ix["kind"]](q, group, get)
            with lock:
                found.extend(h for h in hits if h)
        except Exception as e:
            with lock:
                problems[ix["name"]] = str(getattr(e, "reason", None) or e)[:120]
    threads = [threading.Thread(target=one, args=(ix,)) for ix in in_group(prefs, group)]
    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(timeout_each)
    best = {}
    for h in found:  # the same torrent from two indexes once, with the most seeders
        key = h["hash"] or h.get("torrent_url") or h["title"]
        if key not in best or h["seeders"] > best[key]["seeders"]:
            best[key] = h
    return sorted(best.values(), key=lambda h: -h["seeders"]), problems


def result_lines(h):
    return h["title"], "%s seeders   %s   %s" % (h["seeders"], size_text(h["size"]) if h["size"] else "size ?", h["source"])
