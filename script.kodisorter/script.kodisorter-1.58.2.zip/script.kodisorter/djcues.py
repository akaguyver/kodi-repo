"""Where a DJ would mix: a track's beat grid, its phrases, and the points to bring it in and take it out.

Two ways in. Cue points already saved by Mixed In Key or Serato (the "Serato Markers2" tag) or rekordbox (its
collection XML), and an analysis of the audio itself. The analysis gets two loudness curves, frames per second
apart: the whole sound and the bass (the app's Java side decodes the audio and makes them). From those it finds
the tempo and the beats, which beat starts each bar, and where the energy changes at phrase starts (every 8 bars),
as a DJ hears it: the intro, the drop, the breakdown, the outro.

Pure Python, so it runs on the phone through Chaquopy and in tests without either.
"""
import base64
import math
import re
import struct
from xml.etree import ElementTree

RATE = 100  # loudness frames per second
BEATS_PER_BAR = 4
PHRASE_BARS = 8
LOWEST_BPM, HIGHEST_BPM = 70.0, 180.0
FLAT = 0.2  # a track whose quietest phrase is within 20% of its loudest, in loudness and in bass, has no real sections to find


# ---------- cue points saved by other software ----------

def _b64(text):
    text = re.sub(r"\s+", "", text or "").rstrip("=")
    if len(text) % 4 == 1:
        text = text[:-1]  # Serato pads its base64 oddly
    return base64.b64decode(text + "=" * (-len(text) % 4))


def serato_cues(encoded):
    """[seconds] from a "Serato Markers2" tag (as base64 text, which is how musictags passes it on), in order.
    Mixed In Key writes its cue points here when it's set to save cues for Serato."""
    try:
        data = _b64(encoded)
        at = data.find(b"Serato Markers2\x00")
        if at >= 0:  # FLAC and MP4 keep the ID3 frame's header, and its body is base64 once more
            data = data[at + len(b"Serato Markers2\x00"):]
            data = _b64(data[2:].decode("ascii", "ignore")) if data[:2] == b"\x01\x01" else data
    except (ValueError, TypeError):
        return []
    cues, pos = [], 2 if data[:2] == b"\x01\x01" else 0  # the entries follow a version number
    try:
        while pos < len(data):
            end = data.find(b"\x00", pos)
            if end <= pos:
                break
            kind = data[pos:end].decode("ascii", "replace")
            size = struct.unpack(">I", data[end + 1:end + 5])[0]
            body = data[end + 5:end + 5 + size]
            pos = end + 5 + size
            if kind == "CUE" and len(body) >= 6:
                cues.append(struct.unpack(">I", body[2:6])[0] / 1000.0)
    except (struct.error, IndexError):
        pass
    return sorted(cues)


def rekordbox_cues(xml_text):
    """{file name in lower case: [seconds]} from a rekordbox collection XML (File > Export Collection in xml
    format). Hot cues and memory cues both count."""
    out = {}
    try:
        root = ElementTree.fromstring(xml_text)
    except ElementTree.ParseError:
        return out
    for track in root.iter("TRACK"):
        location = track.get("Location") or ""
        marks = [m.get("Start") for m in track.findall("POSITION_MARK")]
        times = sorted(set(float(m) for m in marks if m and re.match(r"^\d+(\.\d+)?$", m)))
        if location and times:
            from urllib.parse import unquote
            out[unquote(location.replace("\\", "/")).rsplit("/", 1)[-1].lower()] = times
    return out


# ---------- analysis ----------

def _onsets(values):
    """How sharply the loudness rises at each frame: where drums hit."""
    logs = [math.log(v + 1e-6) for v in values]
    return [0.0] + [max(0.0, logs[i] - logs[i - 1]) for i in range(1, len(logs))]


def _comb(onset, period, offset):
    """The onset strength on a grid of beats `period` frames apart, starting at `offset`."""
    total, at, n = 0.0, offset, len(onset)
    while at < n - 1:
        i = int(at)
        frac = at - i
        total += onset[i] * (1 - frac) + onset[i + 1] * frac
        at += period
    return total


def _best_phase(onset, period):
    steps = max(1, int(period))
    return max((_comb(onset, period, float(p)), p) for p in range(steps))[1]


KICK_CLEAR = 4.0  # the kicks on the best grid must rise this many times more than on an average grid, to be used
KICK_NEAR = 0.025  # seconds: a kick this close to a beat of the grid is that beat's kick
KICK_ON_LINE = 0.012  # seconds: a kick this close to its grid line lines up with it
HALF_TIME_BPM = 80.0  # heard slower than this, a track is taken as half time: its phrases are counted in real bars


def _kick_at(rise, beat, near):
    """The frame near frame `beat` where the kick curve rises most, or None if it doesn't rise there."""
    lo, hi = max(2, int(math.ceil(beat - near))), min(len(rise) - 3, int(math.floor(beat + near)))
    if hi < lo:
        return None
    top = max(range(lo, hi + 1), key=lambda i: rise[i])
    return top if rise[top] > 0 else None


def _kick_start(power, top, fall):
    """Where the kick that rises most at frame `top` starts, in frames with a fraction. Each frame is the
    loudness over its 1/RATE second, so a kick that starts between two frames shows in the first only for the
    part of it after the kick starts. With the kick dying away by `fall` (power, per frame), the share of the
    first frame against the full one after it says how far into the first frame the kick started."""
    first = top - 1 if power[top - 1] - power[top - 2] > 0.05 * (power[top] - power[top - 2]) else top
    before = power[first - 1]
    part, full = power[first] - before, power[first + 1] - before
    if part <= 0 or full <= 0:
        return float(top)
    after = math.log(1 + part / full * (1 - math.exp(-fall))) / fall  # the part of the first frame after the kick
    return first + 1 - min(1.0, max(0.0, after))


def _kick_grid(kick, period, rate):
    """(first beat, frames per beat, share of the kicks on the grid) on the kick drum, or None when the kick curve
    has no clear kick on a beat.
    The phase is searched in tenths of a frame on where the kick curve rises, then the beats are fitted, as one
    steady tempo, through the kicks within KICK_NEAR of the grid (Mixxx moves its grid onto the kicks the same
    way). Rises are in power, not in loudness ratios, so a quiet bass note after silence counts for little."""
    power = [v * v for v in kick]
    rise = [0.0] + [max(0.0, power[i] - power[i - 1]) for i in range(1, len(power))]
    if not any(rise):
        return None
    offsets = [p / 10.0 for p in range(int(period * 10))]
    combs = [_comb(rise, period, p) for p in offsets]
    best = max(range(len(offsets)), key=lambda p: combs[p])
    if combs[best] < KICK_CLEAR * sum(combs) / len(combs):
        return None
    phase, near = offsets[best], KICK_NEAR * rate
    for _ in range(3):  # each fit lets the grid catch the kicks further along
        tops = []
        m = 0
        while phase + m * period < len(kick):
            top = _kick_at(rise, phase + m * period, near)
            if top is not None:
                tops.append((m, top))
            m += 1
        falls = sorted(math.log((power[t + 1] - power[t - 2]) / (power[t + 2] - power[t - 2])) for _, t in tops
                       if power[t + 2] > power[t - 2] and power[t + 1] > power[t + 2])
        fall = min(3.0, max(0.02, falls[len(falls) // 2])) if falls else 0.5
        hits = [(m, _kick_start(power, t, fall), rise[t]) for m, t in tops]
        weight = sum(w for _, _, w in hits)
        if len(hits) < 8 or weight <= 0:
            return None
        mm = sum(m * w for m, _, w in hits) / weight
        mt = sum(t * w for _, t, w in hits) / weight
        spread = sum(w * (m - mm) ** 2 for m, _, w in hits)
        step = sum(w * (m - mm) * (t - mt) for m, t, w in hits) / spread if spread else period
        if abs(step - period) / period > 0.005:  # not one steady tempo near the one heard: leave the tempo be
            step = period
        period, phase = step, mt - step * mm
    # Fitted again through only the kicks that sit on the line (a fill, a swung hit or a bass note pulls a fit
    # through all of them off the rest), then moved onto the start of the kicks: the line sits where the bass
    # impulse starts, the way rekordbox draws it, not in the middle of where the kicks were heard.
    near_line = [(m, t, w) for m, t, w in hits if abs(t - (phase + period * m)) <= KICK_ON_LINE * rate]
    if len(near_line) >= 8:
        weight = sum(w for _, _, w in near_line)
        mm = sum(m * w for m, _, w in near_line) / weight
        mt = sum(t * w for _, t, w in near_line) / weight
        spread = sum(w * (m - mm) ** 2 for m, _, w in near_line)
        step = sum(w * (m - mm) * (t - mt) for m, t, w in near_line) / spread if spread else period
        if abs(step - period) / period <= 0.005:
            period = step
        phase = mt - period * mm
        early = sorted((t - (phase + period * m), w) for m, t, w in near_line)
        total, edge = 0.0, 0.0
        for off, w in early:  # the offset a quarter of the way through the kicks, earliest first
            total += w
            edge = off
            if total >= 0.25 * weight:
                break
        phase += min(0.0, edge)
    on_line = sum(1 for m, t, _ in hits if abs(t - (phase + period * m)) <= KICK_ON_LINE * rate) / max(1, len(hits))
    phase %= period
    if phase > period - 0.5:  # a beat a fraction of a frame before the start is the start
        phase -= period
    return max(0.0, phase), period, round(on_line, 2)


ATTACK_EARLIEST, ATTACK_LATEST = 0.09, 0.03  # seconds before and after the kick line where the attack may be
ATTACK_CLEAR = 1.2  # the attack must rise this many times more than on the kick line itself, to move there


def _on_attack(energy, phase, period, rate):
    """The kick grid moved onto the attack of the whole sound, where a DJ puts the line by eye and ear. The kick
    curve is low-passed, so it rises 15 to 60 ms after the click of the kick; the person's own grid moves (Murda
    Sound, Feel It, VMPR, Wild (Far Too Loud Remix), Break It Down) sat within 6 ms of where the whole sound rises
    most on the beats. Left as it is when the whole sound shows no clearer attack nearby."""
    power = [v * v for v in energy]
    rise = [0.0] + [max(0.0, power[i] - power[i - 1]) for i in range(1, len(power))]

    def comb(offset):
        at = phase + offset
        return _comb(rise, period, at if at >= 0 else at + period)
    steps = range(-int(ATTACK_EARLIEST * rate * 10), int(ATTACK_LATEST * rate * 10) + 1)
    best = max(steps, key=lambda s: comb(s / 10.0))
    if comb(best / 10.0) < ATTACK_CLEAR * comb(0.0):
        return phase
    moved = phase + best / 10.0
    return moved if moved >= 0 else moved + period


def tempo(onset, rate=RATE, hint=0.0):
    """The tempo in BPM. A hint (such as the BPM tag) narrows the search to near it, or half or double."""
    lags = range(int(60.0 * rate / HIGHEST_BPM), int(60.0 * rate / LOWEST_BPM) + 1)
    if hint:
        while hint > HIGHEST_BPM:
            hint /= 2
        while hint < LOWEST_BPM:
            hint *= 2
        lags = [lag for lag in lags if abs(60.0 * rate / lag - hint) / hint < 0.06] or list(lags)
    n = len(onset)
    mean = sum(onset) / max(n, 1)
    centred = [v - mean for v in onset]
    best = max(lags, key=lambda lag: sum(centred[i] * centred[i + lag] for i in range(0, n - lag, 2)))
    coarse = 60.0 * rate / best
    candidates = [coarse * (1 + k / 1000.0) for k in range(-20, 21)]  # refine to about 0.1%
    if hint and abs(hint - round(hint)) > 0.001:
        candidates.append(hint)
    def strength(bpm, step=2):
        return max(_comb(onset, 60.0 * rate / bpm, float(p)) for p in range(0, int(60.0 * rate / bpm), step))
    best = max(candidates, key=strength)
    best = max([best * (1 + k / 10000.0) for k in range(-10, 11)], key=lambda bpm: strength(bpm, 1))
    # Without a hint, a track can read at half its tempo (drum & bass as 87). Its bars and phrases still fall on
    # the right beats, and tempo matching counts half and double time, so the mix points stay right.
    return best


def _mean(values, a, b):
    part = values[max(0, a):max(0, b)]
    return sum(part) / len(part) if part else 0.0


# ---------- key, energy and the waveform ----------

# Krumhansl and Kessler's key profiles: how strongly each note of the scale belongs to a major or minor key.
MAJOR_PROFILE = (6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
MINOR_PROFILE = (6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)
WAVE_POINTS = 400


def _correlation(a, b):
    ma, mb = sum(a) / len(a), sum(b) / len(b)
    top = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    under = math.sqrt(sum((x - ma) ** 2 for x in a) * sum((y - mb) ** 2 for y in b))
    return top / under if under else 0.0


def detect_key(chroma):
    """(Camelot code, strength 0-1) from how much of each note (C first) the track holds; ("", 0) if unclear.
    Analyzer.java adds the notes up over the whole track. Mixed In Key's own key, when tagged, is better."""
    import djkeys
    if not chroma or len(chroma) != 12 or sum(chroma) <= 0:
        return "", 0.0
    best = max((_correlation(chroma, [profile[(note - tonic) % 12] for note in range(12)]), tonic, minor)
               for tonic in range(12) for minor, profile in ((False, MAJOR_PROFILE), (True, MINOR_PROFILE)))
    strength, tonic, minor = best
    if strength < 0.3:
        return "", round(max(strength, 0.0), 2)
    return djkeys.camelot(djkeys.NAMES[tonic] + ("m" if minor else "")), round(strength, 2)


def _clip(v):
    return min(1.0, max(0.0, v))


def pulse(values, first, period):
    """How strongly the sound hits on the beats (frames from `first`, `period` apart) against everywhere else, 0-1:
    near 0 for pads with no drums, near 1 for a kick on every beat."""
    onset = _onsets(values)
    if period <= 0:
        return 0.0

    def strength(shift):  # the sharpest rise near each beat moved shift beats along
        total, count, at = 0.0, 0, first + shift * period
        while at < len(onset) - 1:
            i = int(round(at))
            total += max(onset[max(0, i - 1):i + 2])
            count += 1
            at += period
        return total / max(1, count)
    between = sum(strength(s) for s in (0.25, 0.5, 0.75)) / 3  # the same, measured between the beats
    return _clip((strength(0) / between - 1.3) / 2.0) if between > 0 else 0.0


def estimate_energy(energy, bass, bpm, beats=0.0, drive=0.5):
    """A rough 1-10 energy, the way Mixed In Key's reads: how hard the drums hit on the beat (beats, from pulse),
    how much of the track is at its full level (drive, 0-1), how loud it is, how much of that is bass, and the
    tempo. Loudness counts for less than it did, as every modern master is loud: an intro with no drums or a
    track that stays in its breakdown now reads low. Mixed In Key's energy, when tagged, is better."""
    if not energy:
        return 0
    loud = sorted(energy)[int(len(energy) * 0.8)]
    db = 20 * math.log10(max(loud, 1e-6))
    loudness = _clip((db + 26) / 20.0)  # -26 dB quiet, -6 dB a loud club master
    top = [i for i, v in enumerate(energy) if v >= loud * 0.7] or range(len(energy))
    share = sum(bass[i] for i in top) / max(sum(energy[i] for i in top), 1e-9)
    bassy = _clip((share - 0.2) / 0.5)
    tempo = bpm * 2 if bpm and bpm < 95 else bpm  # 87 for drum & bass is really 174
    fast = _clip(((tempo or 120) - 85) / 90.0)
    score = 0.3 * beats + 0.25 * loudness + 0.2 * _clip(drive) + 0.15 * fast + 0.1 * bassy
    return int(max(1, min(10, round(1 + 9 * score ** 1.3))))


def waveform(energy, bass, points=WAVE_POINTS):
    """([height 0-1], [bass share 0-1]) at `points` places along the track, for drawing it."""
    n = len(energy)
    if not n:
        return [], []
    peak = max(energy) or 1.0
    heights, shares = [], []
    for i in range(points):
        a = int(i * n / points)
        b = max(a + 1, int((i + 1) * n / points))
        part = energy[a:b]
        heights.append(round(max(part) / peak, 3))
        shares.append(round(min(1.0, sum(bass[a:b]) / max(sum(part), 1e-9)), 2))
    return heights, shares


# ---------- where a DJ would mix ----------

def phrase_levels(levels, lows):
    """"low", "mid" or "high" for each phrase, against the track's own phrases rather than a fixed scale (a
    loud modern master is loud throughout). Loudness and bass count half each: a drop brings the kick and bass
    back, a breakdown takes them out. The three groups are found by sorting the phrases into three clusters."""
    if not levels:
        return []
    def flat(values):
        return (max(values) - min(values)) / (max(values) or 1.0) < FLAT
    if flat(levels) and flat(lows):  # a loud master can be flat in loudness while its bass comes and goes
        return ["high"] * len(levels)

    def spread(values):
        low, high = min(values), max(values)
        return [0.5] * len(values) if high - low <= 1e-12 else [(v - low) / (high - low) for v in values]
    scores = [0.5 * e + 0.5 * b for e, b in zip(spread(levels), spread(lows))]
    centres = [0.1, 0.5, 0.9]
    for _ in range(20):
        groups = [[], [], []]
        for v in scores:
            groups[min(range(3), key=lambda c: abs(v - centres[c]))].append(v)
        centres = [sum(g) / len(g) if g else centres[i] for i, g in enumerate(groups)]
    names = ("low", "mid", "high")
    order = sorted(range(3), key=lambda c: centres[c])
    return [names[order.index(min(range(3), key=lambda c: abs(v - centres[c])))] for v in scores]


def _grid(energy, bass, rate, bpm_hint, kick):
    """The beat grid, in frames: (bpm, first beat, frames per beat, downbeat, [start of each bar], the kick fit
    from _kick_grid or None)."""
    n = len(energy)
    if n < rate * 10:
        raise ValueError("too short to analyse")
    onset = [a + b for a, b in zip(_onsets(energy), _onsets(bass))]
    bpm = tempo(onset, rate, bpm_hint)
    period = 60.0 * rate / bpm
    phase = _best_phase(onset, period)
    on_kick = _kick_grid(kick, period, rate) if kick else None
    if on_kick:
        phase, period, fit = on_kick
        phase = _on_attack(energy, phase, period, rate)
        on_kick = (phase, period, fit)
        bpm = 60.0 * rate / period
    loud = sorted(energy)[n // 2] * 0.1
    first = phase
    while first < n and _mean(energy, int(first), int(first + period)) < loud:
        first += period
    bar = period * BEATS_PER_BAR

    # The downbeat is the beat where the energy changes happen: sections start on the first beat of a bar.
    # One beat either side of each bar line, so a change shows sharply at the right beat.
    def change_score(offset):
        score, at = 0.0, first + offset * period + bar
        while at + period < n:
            score += abs(_mean(energy, int(at), int(at + period)) - _mean(energy, int(at - period), int(at)))
            at += bar
        return score
    downbeat = first + max(range(BEATS_PER_BAR), key=change_score) * period
    bars = []
    at = downbeat
    while at < n:
        bars.append(at)
        at += bar
    return bpm, first, period, downbeat, bars, on_kick


def grid(energy, bass, rate=RATE, bpm_hint=0.0, kick=None):
    """The beat grid alone, as analyse finds it: {"bpm", "first_beat", "beat", "bars"} and, with a kick curve,
    "kick_grid" and "kick_fit" (the share of kicks within 12 ms of their line). The phone app redoes an old grid with this without touching the rest of the analysis."""
    bpm, first, period, _, bars, on_kick = _grid(energy, bass, rate, bpm_hint, kick)
    return _grid_found(bpm, first, period, bars, rate, kick, on_kick)


def _grid_found(bpm, first, period, bars, rate, kick, on_kick):
    """The grid as grid() and analyse() both give it, in seconds, so the two never drift apart."""
    found = {"bpm": round(bpm, 2), "first_beat": round(first / rate, 3), "beat": round(period / rate, 5),
             "bars": [round(b / rate, 3) for b in bars]}
    if kick:
        found["kick_grid"] = bool(on_kick)
        if on_kick:
            found["kick_fit"] = on_kick[2]
    return found


DROP_EARLIER, DROP_LATER = 2, 2  # bars a drop's line may move to land where the sound jumps
DROP_CLEAR = 1.5  # the jump there must be this many times the one on the line found
DROP_JUMP = 0.15  # and at least this big (loudness and bass, each against its loudest bar, so 2 at most)


def _jump(bar_s, j):
    """How much the sound (bar_s: loudness and bass, each bar) jumps up from bar j - 1 into bar j."""
    return bar_s[j] - bar_s[j - 1] if 0 < j < len(bar_s) else 0.0


def _onto_drops(sections, bar_s, whole):
    """The song's structure first, then its phrase lines: a drop hits on the bar where the sound jumps up, which can
    be a bar or two off the 8-bar line found. Each drop moves there when that jump is clearly bigger. When every
    drop moves the same way, the phrase lines were off as a whole, so every section moves with them and the
    phrases stay 8 and 16 bars counted from the drops; otherwise only the drops move."""
    drops = [j for j, sec in enumerate(sections) if sec["name"] == "Drop" and j > 0]
    moves = {}
    for j in drops:
        here = sections[j]["bar"]
        lo, hi = sections[j - 1]["bar"] + 1, sections[j]["end"] - 1
        tries = [here + k for k in range(-DROP_EARLIER, DROP_LATER + 1) if lo <= here + k <= hi]
        best = max(tries, key=lambda c: _jump(bar_s, c), default=here)
        if best != here and _jump(bar_s, best) >= DROP_JUMP and _jump(bar_s, best) > DROP_CLEAR * max(_jump(bar_s, here), 0.02):
            moves[j] = best - here
    if not moves:
        return
    shifts = set(moves.values())
    if len(moves) == len(drops) and len(shifts) == 1:
        k = shifts.pop()
        for j in range(1, len(sections)):
            sections[j]["bar"] = min(max(sections[j]["bar"] + k, sections[j - 1]["bar"] + 1), len(whole) - 1)
    else:
        for j, k in moves.items():
            sections[j]["bar"] += k
    for j, sec in enumerate(sections):
        sec["end"] = sections[j + 1]["bar"] if j + 1 < len(sections) else sec["end"]
        sec["at"], sec["bars"] = whole[sec["bar"]], sec["end"] - sec["bar"]


def _bar_one(sections, energy, bass, period, bar, downbeat, n):
    """The structure first, then the grid: the first drop starts bar 1 of a phrase, so the master grid's bars
    count from it. The drop moves a beat either way when the sound clearly jumps there instead (the whole
    structure moves with it), and every bar line is then counted from it, back to the start of the track.
    Returns (downbeat, [start of each bar]); with no drop, the grid stays as found."""
    drop = next((x for x in sections if x["name"] == "Drop"), None)
    if drop is None:
        return downbeat, _bar_lines(downbeat, bar, n)

    def jump(t):
        if t - period < 0 or t + period > n:
            return 0.0
        return (_mean(energy, int(t), int(t + period)) - _mean(energy, int(t - period), int(t))
                + _mean(bass, int(t), int(t + period)) - _mean(bass, int(t - period), int(t)))
    at = drop["at"]
    best = max((at - period, at, at + period), key=jump)
    if best != at and jump(best) > DROP_CLEAR * max(jump(at), 1e-9):
        for x in sections[1:]:
            x["at"] += best - at
        at = best
    lines = _bar_lines(at - int(at // bar) * bar, bar, n)
    # the downbeat (where the track is brought in) is the first of those bars where the music has started
    return next((b for b in lines if b >= downbeat - period / 2), lines[0]), lines


def _bar_lines(start, bar, n):
    lines, at = [], start
    while at < n:
        lines.append(at)
        at += bar
    return lines


def analyse(energy, bass, rate=RATE, bpm_hint=0.0, saved_cues=(), chroma=None, kick=None):
    """The DJ details of one track, from its loudness curves. Times are in seconds. With a kick curve (the phone
    app's Analyzer.java makes one, the add-on doesn't) the beats sit on the kick drum, and "kick_grid" says
    whether the track had a clear enough kick for that; without one the grid is as it always was.

    {"bpm", "first_beat", "beat" (seconds per beat), "bars": [start of each bar], "mix_in", "mix_out",
     "intro_end", "cues": [{"time", "label"}], "from_file": bool}

    mix_in: where to start this track when bringing it in (its first downbeat, or the first saved cue).
    mix_out: where to start bringing the next one in (the outro's first phrase, or a saved cue late on).
    """
    n = len(energy)
    bpm, first, period, downbeat, bars, on_kick = _grid(energy, bass, rate, bpm_hint, kick)
    bar = period * BEATS_PER_BAR
    # A track heard at half time (dubstep at 70 for 140) has two real bars in each bar of its grid: its phrases are
    # counted in real bars, half a grid bar each, so an 8-bar phrase is 8 bars as a DJ counts them, not 16.
    unit = bar / 2 if bpm < HALF_TIME_BPM else bar

    def bar_energy(start):
        return _mean(energy, int(start), int(start + unit))

    # Every phrase gets a level, as rekordbox's phrase analysis does; runs of phrases at one level make a section,
    # and each section is named the way a DJ would: Intro, Verse, Buildup, Drop, Breakdown, Outro.
    whole = []
    at = downbeat
    while at + unit <= n:
        whole.append(at)
        at += unit
    whole = whole or [downbeat]
    peak = max(bar_energy(b) for b in whole) or 1.0
    bar_e = [bar_energy(b) for b in whole]
    bar_b = [_mean(bass, int(b), int(b + bar)) for b in whole]
    top_e, top_b = max(bar_e) or 1.0, max(bar_b) or 1.0
    bar_s = [0.5 * e / top_e + 0.5 * b / top_b for e, b in zip(bar_e, bar_b)]

    def change_at(j, width):
        """How much the sound changes at bar j: the `width` bars after it against the `width` before."""
        if j < width or j + width > len(bar_s):
            return 0.0
        return abs(sum(bar_s[j:j + width]) - sum(bar_s[j - width:j])) / width

    # Phrases are 8 bars, but the first one needn't start on the first bar: a 4-bar intro puts every phrase line
    # half a phrase later. Only that is tried, against the half phrase either side of each line, and it has to
    # be clearly better: phrase lines that straddle the real changes blur every phrase into the next, and the
    # whole track reads as one section.
    def phrase_change(offset):
        lines = range(offset if offset else PHRASE_BARS, len(bar_s), PHRASE_BARS)
        return sum(change_at(j, PHRASE_BARS // 2) for j in lines) / max(1, len(lines))
    half = PHRASE_BARS // 2
    offset = half if phrase_change(half) > 1.5 * phrase_change(0) else 0
    starts = sorted(set(([0] if offset else []) + list(range(offset, len(whole), PHRASE_BARS))))
    ends = starts[1:] + [len(whole)]
    spans = [(a, b) for a, b in zip(starts, ends) if b - a >= PHRASE_BARS // 2 or a == 0] or [(0, len(whole))]
    levels = [sum(bar_e[a:b]) / (b - a) for a, b in spans]
    lows = [sum(bar_b[a:b]) / (b - a) for a, b in spans]

    def rising(a, b):
        """A build-up: the phrase's last two bars much louder than its first two (a riser, a snare roll)."""
        early, late = sum(bar_e[a:a + 2]) / 2, sum(bar_e[b - 2:b]) / 2
        return b - a >= 4 and early > 0 and late / early >= 1.25

    kinds = phrase_levels(levels, lows)
    sections = []
    for i, kind in enumerate(kinds):
        builds = kind != "high" and i + 1 < len(kinds) and kinds[i + 1] == "high" and rising(*spans[i])
        if sections and sections[-1]["kind"] == kind and not builds and not sections[-1]["build"]:
            sections[-1]["end"] = spans[i][1]
        else:
            sections.append({"bar": spans[i][0], "end": spans[i][1], "kind": kind, "build": builds})
    # A section can start half a phrase early or late (a 4-bar extension before a drop): each line between two
    # sections moves 4 bars either way when the sound clearly changes there instead. A buildup's start stays: a
    # riser grows slowly, so the sharpest change inside it isn't where it starts.
    for j in range(1, len(sections)):
        here, lo, hi = sections[j]["bar"], sections[j - 1]["bar"] + 4, sections[j]["end"] - 4
        moves = [c for c in (here - 4, here + 4) if lo <= c <= hi]
        best = max(moves, key=lambda c: change_at(c, 4), default=here)
        if not sections[j]["build"] and change_at(best, 4) > 1.3 * change_at(here, 4):
            sections[j]["bar"] = sections[j - 1]["end"] = best
    # What's left of a section after a line moved can be a 4-bar scrap that sounds like its neighbour: it joins it.
    def loudness(sec):
        return sum(bar_s[sec["bar"]:sec["end"]]) / max(1, sec["end"] - sec["bar"])
    j = 0
    while j < len(sections) and len(sections) > 1:
        sec = sections[j]
        if sec["end"] - sec["bar"] <= PHRASE_BARS // 2:
            near = [k for k in (j + 1, j - 1) if 0 <= k < len(sections)]
            k = min(near, key=lambda k: abs(loudness(sections[k]) - loudness(sec)))
            if abs(loudness(sections[k]) - loudness(sec)) <= 0.15 * max(loudness(sections[k]), 1e-9):
                other = sections.pop(k)
                if k < j:
                    sec["bar"], sec["kind"], sec["build"] = other["bar"], other["kind"], other["build"]
                    j -= 1
                else:
                    sec["end"], sec["kind"], sec["build"] = other["end"], other["kind"], other["build"]
                continue
        j += 1
    for sec in sections:
        sec["at"], sec["bars"] = whole[sec["bar"]], sec["end"] - sec["bar"]
    last_beat = n - period
    for j, sec in enumerate(sections):
        before = sections[j - 1]["kind"] if j else None
        later_high = any(x["kind"] == "high" for x in sections[j + 1:])
        if sec["kind"] == "high":
            sec["name"] = "Drop" if before in ("low", "mid") else "Main"
        elif j == 0:  # rekordbox's first phrase is always the intro, even one that builds
            sec["name"] = "Intro"
        elif sec["build"]:
            sec["name"] = "Buildup"
        elif not later_high and sec["at"] > n * 0.5:
            sec["name"] = "Outro"
        else:
            sec["name"] = "Breakdown" if sec["kind"] == "low" else "Verse"
    for j in range(len(sections) - 1, 0, -1):  # an outro that steps down twice is still one outro
        if sections[j]["name"] == sections[j - 1]["name"] and sections[j]["name"] in ("Outro", "Intro", "Verse", "Breakdown"):
            sections[j - 1]["end"], sections[j - 1]["bars"] = sections[j]["end"], sections[j - 1]["bars"] + sections[j]["bars"]
            del sections[j]
    unit_b = [_mean(bass, int(b), int(b + unit)) for b in whole]  # bar_b is over a grid bar: two units at half time
    top_u = max(unit_b) or 1.0
    _onto_drops(sections, [e / top_e + b / top_u for e, b in zip(bar_e, unit_b)], whole)
    downbeat, bars = _bar_one(sections, energy, bass, period, bar, downbeat, n)
    intro_end = sections[1]["at"] if sections[0]["name"] == "Intro" and len(sections) > 1 else whole[min(16, len(whole) - 1)]
    outros = [x["at"] for x in sections if x["name"] == "Outro" and last_beat - x["at"] >= 8 * unit]
    mix_out = outros[0] if outros else max(downbeat, last_beat - 32 * unit)
    mix_in = downbeat

    from_file = False
    saved = sorted(t * rate for t in saved_cues if 0 <= t * rate < n)
    if saved:
        from_file = True
        snap = lambda t: min(bars, key=lambda b: abs(b - t))  # noqa: E731
        mix_in = snap(saved[0])
        late_saved = [t for t in saved if t > n * 0.6 and last_beat - t >= 8 * unit]
        if late_saved:
            mix_out = snap(late_saved[-1])

    def level(t):
        return max(1, min(10, int(round(10 * _mean(energy, int(t), int(t + PHRASE_BARS * unit)) / peak))))
    cues = [{"time": round(mix_in / rate, 3), "label": "Mix in"}]
    cues += [{"time": round(x["at"] / rate, 3), "label": "%s, energy %d" % (x["name"], level(x["at"]))}
             for x in sections if abs(x["at"] - mix_in) > 1]
    if all(abs(x["at"] - mix_out) > 1 for x in sections):
        cues.append({"time": round(mix_out / rate, 3), "label": "Mix out"})
    parts = [{"time": round(x["at"] / rate, 3), "name": x["name"], "bars": x["bars"], "energy": level(x["at"])}
             for x in sections]
    heights, shares = waveform(energy, bass)
    camelot, strength = detect_key(chroma)
    full = sum(b - a for (a, b), kind in zip(spans, kinds) if kind == "high") / max(1, len(whole))
    drive = 0.5 if all(kind == "high" for kind in kinds) else full  # a flat track says nothing about its drops
    beats = max(pulse(kick or bass, first, period), pulse(energy, first, period))
    energy_level = estimate_energy(energy, bass, bpm, beats, drive)
    found = _grid_found(bpm, first, period, bars, rate, kick, on_kick)
    found.update({"mix_in": round(mix_in / rate, 3),
                  "mix_out": round(mix_out / rate, 3), "intro_end": round(intro_end / rate, 3),
                  "cues": sorted(cues, key=lambda c: c["time"]), "from_file": from_file,
                  "duration": round(n / rate, 2), "waveform": heights, "bass_share": shares,
                  "key": camelot, "key_strength": strength, "energy_estimate": energy_level,
                  "sections": parts})
    return found


def mix_bars(outgoing, incoming, most=32, least=8):
    """How many bars the two tracks play together: what's left of the outgoing track after its mix-out point,
    up to the incoming track's intro, in whole phrases of 8 (at least 8, at most 32)."""
    out_left = (outgoing["bars"][-1] - outgoing["mix_out"]) / (outgoing["beat"] * BEATS_PER_BAR) if outgoing["bars"] else most
    intro = (incoming["intro_end"] - incoming["mix_in"]) / (incoming["beat"] * BEATS_PER_BAR)
    room = min(out_left, intro if intro >= least else most)
    return int(max(least, min(most, room // PHRASE_BARS * PHRASE_BARS)))
