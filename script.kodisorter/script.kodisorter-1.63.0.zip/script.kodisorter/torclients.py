"""Torrent clients Sortovia can hand a torrent to, for what Real-Debrid can't get.

"phone": the phone's own downloader (aria2 in Termux, run by kodi-share's helper on port 8081), which saves into
Download/Torrents for Sortovia to sort. Others on the phone or the network, by their remote-control address:
Transmission (also BiglyBT and Vuze with their Transmission-style remote), qBittorrent's Web UI, and aria2.
"""
import base64
import json

import dlqueue

try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode
    from http.cookiejar import CookieJar
    from urllib.request import build_opener, HTTPCookieProcessor
except ImportError:  # Kodi 18 and older
    from urllib2 import Request, urlopen, build_opener, HTTPCookieProcessor
    from urllib import urlencode
    from cookielib import CookieJar

KINDS = [("transmission", "Transmission (also BiglyBT and Vuze remote)", "http://phone:9091/transmission/rpc"),
         ("qbittorrent", "qBittorrent Web UI", "http://192.168.1.20:8080"),
         ("aria2", "aria2", "http://192.168.1.20:6800/jsonrpc")]
KIND_NAMES = dict((k, n) for k, n, _ in KINDS)


class ClientError(Exception):
    pass


def _open(req, timeout=20, opener=None):
    try:
        resp = (opener.open if opener else urlopen)(req, timeout=timeout)
        try:
            return resp.getcode(), resp.read(), resp.headers
        finally:
            resp.close()
    except Exception as e:
        code = getattr(e, "code", None)
        if code:
            return code, (e.read() if hasattr(e, "read") else b""), getattr(e, "headers", {}) or {}
        raise ClientError("can't reach it (%s)" % (getattr(e, "reason", None) or e))


def _auth(c):
    if not c.get("user"):
        return {}
    return {"Authorization": "Basic " + base64.b64encode(("%s:%s" % (c["user"], c.get("pass", ""))).encode()).decode()}


def add_transmission(c, uri, opener=None):
    body = json.dumps({"method": "torrent-add", "arguments": {"filename": uri}}).encode()
    headers = dict(_auth(c), **{"Content-Type": "application/json"})
    code, data, h = _open(Request(c["url"], data=body, headers=headers), opener=opener)
    if code == 409:  # first call: Transmission hands out its session id
        headers["X-Transmission-Session-Id"] = (h.get("X-Transmission-Session-Id") if h else "") or ""
        code, data, h = _open(Request(c["url"], data=body, headers=headers), opener=opener)
    if code == 401:
        raise ClientError("it refused the user name or password")
    if code != 200:
        raise ClientError("it answered %s" % code)
    out = json.loads(data.decode("utf-8"))
    if out.get("result") != "success":
        raise ClientError(out.get("result") or "it said no")
    return True


def add_qbittorrent(c, uri, opener=None):
    base = c["url"].rstrip("/")
    opener = opener or build_opener(HTTPCookieProcessor(CookieJar()))
    headers = {"Referer": base}
    code, data, _ = _open(Request(base + "/api/v2/auth/login", data=urlencode(
        {"username": c.get("user", ""), "password": c.get("pass", "")}).encode(), headers=headers), opener=opener)
    if code != 200 or data.strip() not in (b"Ok.", b""):
        raise ClientError("it refused the user name or password")
    code, data, _ = _open(Request(base + "/api/v2/torrents/add", data=urlencode({"urls": uri}).encode(),
                                  headers=headers), opener=opener)
    if code != 200:
        raise ClientError("it answered %s" % code)
    return True


def add_aria2(c, uri, opener=None):
    params = (["token:" + c["pass"]] if c.get("pass") else []) + [[uri]]
    body = json.dumps({"jsonrpc": "2.0", "id": "s", "method": "aria2.addUri", "params": params}).encode()
    code, data, _ = _open(Request(c["url"], data=body, headers={"Content-Type": "application/json"}), opener=opener)
    out = json.loads(data.decode("utf-8") or "{}")
    if code != 200 or out.get("error"):
        raise ClientError((out.get("error") or {}).get("message") or "it answered %s" % code)
    return True


def _rpc_transmission(c, method, opener=None, args=None):
    body = json.dumps({"method": method, "arguments": args or {}}).encode()
    headers = dict(_auth(c), **{"Content-Type": "application/json"})
    code, data, h = _open(Request(c["url"], data=body, headers=headers), opener=opener)
    if code == 409:
        headers["X-Transmission-Session-Id"] = (h.get("X-Transmission-Session-Id") if h else "") or ""
        code, data, h = _open(Request(c["url"], data=body, headers=headers), opener=opener)
    if code == 401:
        raise ClientError("it refused the user name or password")
    if code == 404:
        raise ClientError("something answered, but not a Transmission remote (the address should end /transmission/rpc)")
    if code != 200:
        raise ClientError("it answered %s" % code)
    return json.loads(data.decode("utf-8"))


def test(c, opener=None):
    """Ask the client something harmless. Returns what it is (e.g. "Transmission 3.00"); ClientError if not."""
    try:
        if c["kind"] == "transmission":
            a = _rpc_transmission(c, "session-get", opener).get("arguments") or {}
            return "%s %s" % ("Vuze/BiglyBT" if a.get("az-version") or "az" in str(a.get("version", "")).lower()
                              else "Transmission", a.get("version") or "")
        if c["kind"] == "qbittorrent":
            base = c["url"].rstrip("/")
            opener = opener or build_opener(HTTPCookieProcessor(CookieJar()))
            code, data, _ = _open(Request(base + "/api/v2/auth/login", data=urlencode(
                {"username": c.get("user", ""), "password": c.get("pass", "")}).encode(), headers={"Referer": base}),
                opener=opener)
            if code != 200 or data.strip() not in (b"Ok.", b""):
                raise ClientError("it refused the user name or password")
            code, data, _ = _open(Request(base + "/api/v2/app/version", headers={"Referer": base}), opener=opener)
            return "qBittorrent %s" % data.decode("utf-8", "replace").strip()
        params = ["token:" + c["pass"]] if c.get("pass") else []
        body = json.dumps({"jsonrpc": "2.0", "id": "s", "method": "aria2.getVersion", "params": params}).encode()
        code, data, _ = _open(Request(c["url"], data=body, headers={"Content-Type": "application/json"}), opener=opener)
        out = json.loads(data.decode("utf-8") or "{}")
        if code != 200 or out.get("error"):
            raise ClientError((out.get("error") or {}).get("message") or "it answered %s" % code)
        return "aria2 %s" % (out.get("result") or {}).get("version", "")
    except ValueError:
        raise ClientError("something answered, but not a torrent client's remote")


TR_FIELDS = ["id", "name", "status", "percentDone", "rateDownload", "eta", "peersConnected", "peersSendingToUs",
             "error", "errorString", "sizeWhenDone", "magnetLink", "downloadDir", "metadataPercentComplete"]


def tr_state(t):
    """Transmission's status number as the phone's downloader names it (active, waiting, paused, complete, error)."""
    if t.get("percentDone", 0) >= 1 and t.get("sizeWhenDone"):
        return "complete"
    if t.get("error") and t.get("status") == 0:
        return "error"
    return {0: "paused", 3: "waiting", 5: "complete", 6: "complete"}.get(t.get("status"), "active")


def tr_jobs(c, opener=None):
    """A Transmission-style client's torrents (e.g. BiglyBT), shaped like the phone's own downloads."""
    ts = (_rpc_transmission(c, "torrent-get", opener, {"fields": TR_FIELDS}).get("arguments") or {}).get("torrents") or []
    out = []
    for t in ts:
        state, size = tr_state(t), int(t.get("sizeWhenDone") or 0)
        meta = t.get("metadataPercentComplete", 1) < 1
        out.append({"id": "%s:%s" % (c["id"], t["id"]), "client": c["id"], "tid": t["id"],
                    "name": ("[METADATA]" if meta and state == "active" else "") + (t.get("name") or "?"),
                    "kind": "Torrents", "state": state, "size": size, "pct": round(100.0 * (t.get("percentDone") or 0), 1),
                    "speed": int(t.get("rateDownload") or 0), "eta": max(0, int(t.get("eta") or 0)),
                    "seeds": int(t.get("peersSendingToUs") or 0), "peers": int(t.get("peersConnected") or 0),
                    "error": t.get("errorString") or "", "uri": t.get("magnetLink") or "",
                    "dir": t.get("downloadDir") or "", "where": c.get("name") or "BiglyBT"})
    return out


def tr_act(c, tids, what, opener=None):
    """what: "pause", "resume" or "remove" (the files stay)."""
    method = {"pause": "torrent-stop", "resume": "torrent-start", "remove": "torrent-remove"}[what]
    args = {"ids": list(tids)} if tids else {}
    if what == "remove":
        args["delete-local-data"] = False
    _rpc_transmission(c, method, opener, args)


def on_phone(c):
    """True for a client whose address is the phone (http://phone:...)."""
    import re
    return bool(re.match(r"^\w+://phone[:/]", c.get("url") or "", re.I))


def advice(c, err):
    """What to try when test() failed."""
    e = str(err).lower()
    if "refused" in e and "password" not in e:
        tip = "Nothing is listening at that address and port."
        if c["kind"] == "transmission":
            tip += ("\nIn BiglyBT: Options > Remote access > turn on Allow remote access, and keep BiglyBT open. "
                    "Use the port it shows there, e.g. http://phone:9093/transmission/rpc for BiglyBT on the phone "
                    "(Sortovia fills in the phone's address).")
        return tip
    if "timed out" in e or "no route" in e or "unreachable" in e:
        return "That address didn't answer. Check the device is on the same Wi-Fi or hotspot as the Xbox, and its address."
    if "password" in e:
        return "Check the user name and password set in the client's remote-access settings."
    return ""


ADDERS = {"transmission": add_transmission, "qbittorrent": add_qbittorrent, "aria2": add_aria2}


def send(client, uri, phone=None, opener=None):
    """Hand a magnet link or .torrent address to a client. phone: a youtube.Phone, for the phone's own downloader."""
    if client.get("kind") == "phone":
        if phone is None:
            raise ClientError("can't find the phone")
        r = phone.call("/tor/add", {"uri": uri, "name": client.get("label", "")})
        if not r.get("id"):
            raise ClientError(r.get("error") or "the phone didn't take it")
        return True
    return ADDERS[client["kind"]](client, uri, opener)


def job_lines(j):
    """(name, 'Downloading 42% - 1.2 MB/s - 3 min left - 12 peers') for a torrent on the phone.
    The phone's "waiting" is shown as Queued (it downloads eight at a time); a running one nobody is
    sending to is "Waiting for peers"."""
    name = j.get("name") or "?"
    meta = name.startswith("[METADATA]")
    if meta:  # a magnet link's first step: finding peers to get the torrent's details
        name = name[len("[METADATA]"):].replace("+", " ")
    stuck = not meta and j.get("state") == "active" and dlqueue.tor_group(j) == dlqueue.PEERS
    state = {"active": "Finding peers for its details" if meta else "Waiting for peers" if stuck else "Downloading",
             "waiting": "Queued - starts when one ahead of it finishes",
             "paused": "Paused", "complete": "Done - in Download/%s" % (j.get("kind") or "Torrents"),
             "error": "Failed", "removed": "Stopped", "gaveup": "Failed - tried 3x, no peers"}.get(j.get("state"), j.get("state") or "?")
    bits = [state]
    if meta:
        return name, state + (" - %d peers" % j.get("peers", 0) if j.get("state") == "active" else "")
    if j.get("state") in ("active", "waiting", "paused") and j.get("size"):
        bits.append("%d%%" % j.get("pct", 0))
    if j.get("state") == "active" and not stuck:
        if j.get("speed"):
            bits.append("%.1f MB/s" % (j["speed"] / 1e6))
        if j.get("eta"):
            bits.append("%d min left" % max(1, j["eta"] // 60))
        bits.append("%d peers" % j.get("peers", 0))
    if j.get("state") == "error" and j.get("error"):
        bits.append(j["error"][:60])
    return name, " - ".join(bits)
