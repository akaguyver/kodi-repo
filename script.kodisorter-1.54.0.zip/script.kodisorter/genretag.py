"""Find the genres a track belongs under, from Discogs and Last.fm, checked against the person's own list.

Nothing here touches a file or Kodi. fetch(url, headers) returns the reply's bytes, so tests can stand in
for the internet. The sources only suggest: Discogs styles describe a whole release, Last.fm rarely tags
single tracks, and neither knows narrow genres like Riddim. The person chooses, per artist or per track.
"""
import json
import re
import string

import musicfix

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

DISCOGS_SEARCH = "https://api.discogs.com/database/search?"
LASTFM_API = "https://ws.audioscrobbler.com/2.0/?"
ITUNES_SEARCH = "https://itunes.apple.com/search?"
DEEZER_API = "https://api.deezer.com/"
SOUNDCLOUD_TOKEN = "https://secure.soundcloud.com/oauth/token"
SOUNDCLOUD_API = "https://api.soundcloud.com/"
SOURCE_NAMES = {"discogs": "Discogs", "lastfm": "Last.fm", "beatport": "Beatport", "itunes": "Apple Music",
                "deezer": "Deezer", "soundcloud": "SoundCloud", "audius": "Audius",
                "artists": "the featured artists", "tagged": "your tags"}
# Two kinds of source, which the genre screen colours apart: what was filed with a release (by the label,
# distributor or a catalogue), and tags people typed (listeners on Last.fm, artists on SoundCloud).
RELEASE_SOURCES = ("discogs", "itunes", "deezer", "beatport")
TAG_SOURCES = ("lastfm", "soundcloud", "audius")
MIN_RELEASE_SHARE = 1 / 3.0  # a style must be on this share of a track's releases, so one odd album doesn't count
MIN_LASTFM_COUNT = 10  # Last.fm scores a track's tags from 0 to 100; below this they're mostly noise

DEFAULT_GENRES = ["Acid", "Afro House", "Alternative", "Ambient", "Bass House", "Bass Music", "Big Beat", "Blues",
                  "Breakbeat", "Chillout", "Chillstep", "Classical", "Country", "Dancehall", "Deep House", "Disco",
                  "Downtempo", "Drill", "Drum & Bass", "Dub", "Dubstep", "Electro", "Electro Funk", "Electro House",
                  "Electro Swing", "Electronic Jam Band", "Emo", "Experimental", "Folk", "Funk", "Funky House",
                  "Future Bass", "Future House", "Future Jazz", "Gabber", "Gangsta Rap", "Glitch", "Grime", "Grunge",
                  "Happy Hardcore", "Hard Rock", "Hardcore", "Hardstyle", "Hip Hop", "House", "Indie", "Indie Dance",
                  "Instrumental Hip Hop", "Jam Band", "Jazz", "Jungle", "Latin", "Lo-Fi", "Melodic Dubstep", "Metal",
                  "Nu Disco", "Pop", "Pop Punk", "Progressive House", "Psychedelic", "Psytrance", "Punk", "R&B", "Rap",
                  "Reggae", "Riddim", "Rock", "Ska", "Soul", "Soundtrack", "Synthwave", "Tech House", "Trance", "Trap",
                  "Trip Hop", "UK Garage", "World"]

# Other ways people write a genre. A name on the person's own list always wins over these.
SAME_GENRE = (("Dubstep", "dub step", "brostep"),
              ("Drum & Bass", "drum and bass", "drum n bass", "drum 'n' bass", "dnb", "d&b"),
              ("Breakbeat", "breaks", "breakbeats", "break beat"),
              ("Bass House", "basshouse"),
              ("Electro Funk", "electrofunk"),
              ("Electro Swing", "electroswing"),
              ("Happy Hardcore", "happycore"),
              ("Hip Hop", "hiphop", "hip-hop"),
              ("Gangsta Rap", "gangsta"),
              ("Jam Band", "jamband", "jam bands"),
              ("Electronic Jam Band", "electronic jamband", "livetronica", "jamtronica"),
              ("Alternative", "alternative rock", "alt rock"),
              ("Indie", "indie rock"))

# Tags that say nothing about the music, left out of the "not on your list" counts.
JUNK = set(("seen live", "favorites", "favourites", "favorite", "favourite", "awesome", "love", "loved", "cool",
            "amazing", "best", "good", "great", "beautiful", "my music", "spotify", "albums i own", "under 2000 listeners",
            "american", "british", "usa", "uk", "male vocalists", "female vocalists", "instrumental"))

_FEATURE = r"(?:feat\.?|featuring|ft\.?)"
_VERSION = r"(?:original mix|extended mix|radio edit|album version)"
_NOISE = re.compile(r"(?i)\s*[\(\[]\s*(?:%s\s[^\)\]]*|%s)\s*[\)\]]|\s+-\s+%s\s*$|\s+%s\s.*$"
                    % (_FEATURE, _VERSION, _VERSION, _FEATURE))
_SEPARATORS = re.compile(r"(?i)\s*(?:&|,|/|\+|\bfeat\.?|\bfeaturing\b|\bvs\.?|\band\b)\s*")


class SourceError(Exception):
    """A source refused or can't be used, such as a wrong key or too many requests."""


def key(name):
    """The form used to compare names: "Hip-Hop" and "hip hop" are the same."""
    text = (name or "").lower().replace("&", " and ")
    return "".join(c for c in text if c.isalnum())


def parse_list(text):
    """The person's own list, typed with commas or semicolons, without repeats."""
    seen, out = set(), []
    for name in re.split(r"[,;\n]", text or ""):
        name = " ".join(name.split())
        if name and key(name) not in seen:
            seen.add(key(name))
            out.append(name)
    return out


def _index(genres):
    """{compared name: name on the list}. Exact names go in first, so they beat other spellings."""
    index = dict((key(g), g) for g in genres)
    for group in SAME_GENRE:
        chosen = next((index[key(n)] for n in group if key(n) in index), None)
        if chosen:
            for name in group:
                index.setdefault(key(name), chosen)
    return index


def _matches(raw, index):
    """The genres on the list that a raw tag means. "Funk / Soul" can match on either side of the slash."""
    if key(raw) in index:
        return [index[key(raw)]]
    return [index[key(part)] for part in re.split(r"\s*/\s*", raw) if key(part) in index]


def clean_title(title):
    """A title without "feat." credits or words that only describe the standard version. Remix names stay,
    because a remix can belong to a different genre."""
    return " ".join(_NOISE.sub("", title or "").split())


def main_artist(credit):
    names = musicfix.split_artists(credit or "")
    return names[0] if names else (credit or "").strip()


def _plain_artist(name):
    """Discogs writes "Buku (2)" and "Antiserum*" to tell artists apart."""
    return re.sub(r"\s*\(\d+\)", "", name or "").replace("*", "").strip()


def _strip_the(compared):
    return compared[3:] if compared.startswith("the") and len(compared) > 3 else compared


def _is_artist(artist, discogs_title):
    """Whether a Discogs result ("Artist & Other - Release") is by this artist. The whole name must match,
    so "Prof" doesn't match "Professor Green"."""
    head = _plain_artist((discogs_title or "").split(" - ", 1)[0])
    wanted = _strip_the(key(artist))
    return bool(wanted) and (_strip_the(key(head)) == wanted or
                             any(_strip_the(key(part)) == wanted for part in _SEPARATORS.split(head)))


def lookup_discogs(fetch, artist, title, token=""):
    """Styles, then Discogs' broad genres, from the releases holding this track, each most common first.
    Compilations count only when there's nothing else, because their styles describe the other tracks too."""
    query = urlencode({"type": "release", "artist": artist, "track": title, "per_page": 25})
    headers = {"Authorization": "Discogs token=%s" % token} if token else {}
    data = json.loads(fetch(DISCOGS_SEARCH + query, headers).decode("utf-8", "replace"))
    if "results" not in data:
        raise SourceError(str(data.get("message") or "an unexpected reply"))
    mine = [r for r in data["results"] if _is_artist(artist, r.get("title"))]
    releases = [r for r in mine if "Compilation" not in (r.get("format") or [])] or mine
    votes, styles = {}, set()
    for release in releases:
        styles.update(release.get("style") or [])
        for name in set((release.get("style") or []) + (release.get("genre") or [])):
            votes[name] = votes.get(name, 0) + 1
    needed = len(releases) * MIN_RELEASE_SHARE
    return sorted([n for n in votes if votes[n] >= needed], key=lambda n: (n not in styles, -votes[n], n))


def _same_track(artist, title, their_artist, their_title):
    return _is_artist(artist, their_artist) and key(clean_title(their_title)) == key(clean_title(title))


def lookup_itunes(fetch, artist, title):
    """The genre the label or distributor filed with Apple for this track (for self-released music, that's
    the artist's own choice). Apple asks for no more than about 20 searches a minute."""
    query = urlencode({"term": "%s %s" % (artist, clean_title(title)), "media": "music", "entity": "song",
                       "limit": 25})
    data = json.loads(fetch(ITUNES_SEARCH + query, {}).decode("utf-8", "replace"))
    if "results" not in data:
        raise SourceError(str(data.get("errorMessage") or "an unexpected reply"))
    votes = {}
    for result in data["results"]:
        name = result.get("primaryGenreName")
        if name and _same_track(artist, title, result.get("artistName"), result.get("trackName")):
            votes[name] = votes.get(name, 0) + 1
    return sorted(votes, key=lambda n: (-votes[n], n))


def lookup_deezer(fetch, artist, title, most_albums=2):
    """The genres the label or distributor gave the album holding this track on Deezer."""
    query = urlencode({"q": "%s %s" % (artist, clean_title(title)), "limit": 10})  # the strict artist:/track: form misses "feat." titles
    data = json.loads(fetch(DEEZER_API + "search?" + query, {}).decode("utf-8", "replace"))
    if "error" in data:
        raise SourceError(str((data["error"] or {}).get("message") or "an unexpected reply"))
    albums = []
    for result in data.get("data") or []:
        album = (result.get("album") or {}).get("id")
        if album and album not in albums and _same_track(artist, title, (result.get("artist") or {}).get("name"),
                                                         result.get("title")):
            albums.append(album)
    found = []
    for album in albums[:most_albums]:
        info = json.loads(fetch(DEEZER_API + "album/%s" % album, {}).decode("utf-8", "replace"))
        for genre in ((info.get("genres") or {}).get("data") or []):
            if genre.get("name") and genre["name"] not in found:
                found.append(genre["name"])
    return found


def soundcloud_token(post, client_id, client_secret):
    """An access token for SoundCloud's API, from the person's own app keys (client credentials)."""
    import base64
    basic = base64.b64encode(("%s:%s" % (client_id, client_secret)).encode()).decode()
    data = json.loads(post(SOUNDCLOUD_TOKEN, "grant_type=client_credentials",
                           {"Authorization": "Basic " + basic, "Content-Type": "application/x-www-form-urlencoded",
                            "Accept": "application/json"}).decode("utf-8", "replace"))
    if not data.get("access_token"):
        raise SourceError(str(data.get("error_description") or data.get("error") or "SoundCloud refused the keys"))
    return data["access_token"]


def soundcloud_tags(tag_list):
    """SoundCloud's tag_list: words split by spaces, with "quotes" round tags of several words."""
    return [a or b for a, b in re.findall(r'"([^"]+)"|(\S+)', tag_list or "")]


def _soundcloud_title(artist, their_title):
    """Uploaders often title a track "Artist - Title"; the part after the artist is the title."""
    head, _, tail = (their_title or "").partition(" - ")
    return tail if tail and _is_artist(artist, head) else their_title


def soundcloud_tracks(fetch, artist, title, token):
    """SoundCloud's tracks that are this one: the title matches, and the uploader is the artist or the title
    names them ("Artist - Title")."""
    query = urlencode({"q": "%s %s" % (artist, clean_title(title)), "limit": 20, "linked_partitioning": "true"})
    data = json.loads(fetch(SOUNDCLOUD_API + "tracks?" + query,
                            {"Authorization": "OAuth " + token, "Accept": "application/json"}).decode("utf-8", "replace"))
    if isinstance(data, dict) and ("errors" in data or "error" in data or "code" in data):
        raise SourceError(str(data.get("message") or data.get("error") or data.get("errors") or "an unexpected reply"))
    out = []
    for track in (data.get("collection") if isinstance(data, dict) else data) or []:
        uploader = (track.get("user") or {}).get("username")
        named = _soundcloud_title(artist, track.get("title"))
        if key(clean_title(named)) != key(clean_title(title)):
            continue
        if _is_artist(artist, uploader) or _is_artist(artist, (track.get("title") or "").split(" - ")[0]):
            out.append(track)
    return out


def lookup_soundcloud(fetch, artist, title, token):
    """The genre and tags the uploader (usually the artist or label) set on this track, genre first."""
    found = []
    for track in soundcloud_tracks(fetch, artist, title, token):
        for tag in [track.get("genre") or ""] + soundcloud_tags(track.get("tag_list")):
            if tag.strip() and tag not in found:
                found.append(tag.strip())
    return found


def _lastfm_tags(data):
    if data.get("error"):
        if data["error"] == 6:  # Last.fm doesn't know this track or artist
            return []
        raise SourceError(str(data.get("message") or "error %s" % data["error"]))
    tags = (data.get("toptags") or {}).get("tag") or []
    if isinstance(tags, dict):  # a single tag doesn't come as a list
        tags = [tags]
    return [t["name"] for t in tags if t.get("name") and int(t.get("count") or 0) >= MIN_LASTFM_COUNT]


def lookup_lastfm(fetch, artist, title, api_key):
    """The tags Last.fm's listeners gave this track, strongest first."""
    query = urlencode({"method": "track.gettoptags", "artist": artist, "track": title, "autocorrect": 1,
                       "api_key": api_key, "format": "json"})
    return _lastfm_tags(json.loads(fetch(LASTFM_API + query, {}).decode("utf-8", "replace")))


def lookup_lastfm_artist(fetch, artist, api_key):
    """The tags Last.fm's listeners gave this artist, strongest first. Most tracks have no tags of their own."""
    query = urlencode({"method": "artist.gettoptags", "artist": artist, "autocorrect": 1, "api_key": api_key,
                       "format": "json"})
    return _lastfm_tags(json.loads(fetch(LASTFM_API + query, {}).decode("utf-8", "replace")))


def combine(found, genres):
    """found: {source: [raw tags]}. Returns {"keep": [genre], "single": [(genre, source)], "unlisted": [raw tag]}.
    A genre is kept if Beatport gave it or two sources agree, most certain first."""
    index = _index(genres)
    sources, order, unlisted = {}, [], []
    for source in sorted(found):
        for raw in found[source]:
            names = _matches(raw, index)
            for name in names:
                sources.setdefault(name, set()).add(source)
                if name not in order:
                    order.append(name)
            if not names and raw.lower() not in JUNK and raw not in unlisted:
                unlisted.append(raw)
    keep = [g for g in order if "beatport" in sources[g] or len(sources[g]) > 1]
    keep.sort(key=lambda g: ("beatport" not in sources[g], -len(sources[g])))
    return {"keep": keep, "unlisted": unlisted,
            "single": [(g, SOURCE_NAMES.get(s, s)) for g in order if g not in keep for s in sources[g]]}


def format_tag(genres):
    """The text for the genre tag: one text with " / " between genres. Kodi splits it at " / " into separate
    genres (its default), and rekordbox and Serato, which show one genre text, show all of it. First is most
    certain."""
    return " / ".join(genres)


def scan(songs, sources, genres, cache, step, sleep):
    """Look up each song once. sources: [(id, lookup(artist, title), seconds to wait after asking)].
    cache keeps what was found, so a rerun asks only about the rest. A source that fails is left out for
    the rest of the run. Returns (rows, {source: why it failed}, stopped)."""
    rows, failed, seen = [], {}, set()
    wanted = []
    for song in songs:
        where = (song.get("folder", ""), song.get("file", ""))
        if where not in seen:
            seen.add(where)
            wanted.append(song)
    for i, song in enumerate(wanted):
        artist, title = main_artist(song.get("artist")), clean_title(song.get("title"))
        if step(i, len(wanted), "%s - %s" % (artist, title)):
            return rows, failed, True
        found = {}
        for source, lookup, wait in sources:
            if source in failed or not artist or not title:
                continue
            slot = "%s|%s|%s" % (source, key(artist), key(title))
            if slot in cache:
                found[source] = cache[slot]
                continue
            try:
                found[source] = lookup(artist, title)
            except Exception as e:
                failed[source] = str(e)
                continue
            if found[source]:  # an empty answer isn't kept, as the source may learn the track later
                cache[slot] = found[source]
            sleep(wait)
        row = combine(found, genres)
        row.update(artist=song.get("artist", ""), title=song.get("title", ""), current=song.get("genres", ""),
                   album=song.get("album", ""), path=song.get("folder", "") + song.get("file", ""), found=found)
        rows.append(row)
    return rows, failed, False


def sample_songs(songs, most):
    """(songs to look up, the rest). Up to `most` per main artist, spread out so several albums are asked about."""
    groups, order = {}, []
    for song in songs:
        name = key(main_artist(song.get("artist")))
        if name not in groups:
            groups[name] = []
            order.append(name)
        groups[name].append(song)
    chosen, rest = [], []
    for name in order:
        group = groups[name]
        picks = set(i * len(group) // most for i in range(most)) if len(group) > most else set(range(len(group)))
        chosen += [s for i, s in enumerate(group) if i in picks]
        rest += [s for i, s in enumerate(group) if i not in picks]
    return chosen, rest


def group_by_artist(rows):
    """[{"key", "name", "rows"}] by each row's main artist, in the order they first appear."""
    groups, order = {}, []
    for row in rows:
        name = main_artist(row["artist"])
        if key(name) not in groups:
            groups[key(name)] = {"key": key(name), "name": name, "rows": []}
            order.append(key(name))
        groups[key(name)]["rows"].append(row)
    return [groups[k] for k in order]


def suggestions(discogs, lastfm, genres, others=None):
    """{genre on the list: set of sources saying so}, from raw tags. others: {source: [raw tags]}."""
    index = _index(genres)
    out = {}
    for source, tags in [("discogs", discogs), ("lastfm", lastfm)] + sorted((others or {}).items()):
        for raw in tags:
            for name in _matches(raw, index):
                out.setdefault(name, set()).add(source)
    return out


def _others(rows):
    out = {}
    for row in rows:
        for source, tags in row["found"].items():
            if source not in ("discogs", "lastfm"):
                out.setdefault(source, []).extend(tags)
    return out


def artist_suggestions(group, artist_tags, genres):
    """What every looked-up track and the artist's own Last.fm tags say about one artist."""
    discogs = [t for row in group["rows"] for t in row["found"].get("discogs", [])]
    lastfm = list(artist_tags) + [t for row in group["rows"] for t in row["found"].get("lastfm", [])]
    return suggestions(discogs, lastfm, genres, _others(group["rows"]))


def track_suggestions(row, artist_tags, genres):
    return suggestions(row["found"].get("discogs", []), list(artist_tags) + row["found"].get("lastfm", []), genres,
                       _others([row]))


def credited(credit):
    """The keys of every artist credited on a track: "A feat. B & C" -> [a, b, c]."""
    out = []
    for name in _SEPARATORS.split(credit or ""):
        if key(name) and key(name) not in out:
            out.append(key(name))
    return out


def featured_genres(rows, choices):
    """The genres already chosen for the other artists credited on these tracks (featured, collaborating),
    so a crossover track can take its guest's style. The main artist's own choice isn't included."""
    out = []
    for row in rows:
        main = key(main_artist(row["artist"]))
        for other in credited(row["artist"]):
            if other != main:
                for g in (choices.get(other) or {}).get("genres") or []:
                    if g not in out:
                        out.append(g)
    return out


def with_featured(sources, featured):
    """Suggestions plus the featured artists' genres, which show as from "artists"."""
    out = dict((g, set(s)) for g, s in sources.items())
    for g in featured:
        out.setdefault(g, set()).add("artists")
    return out


MOST_NEW = 24  # found genres not on the list shown on one screen, most certain first


def _tidy(raw):
    name = " ".join((raw or "").split())
    return string.capwords(name) if name.islower() else name


def screen_choices(rows, sources, genres):
    """What the genre screen shows for these tracks: (every genre, sources, genres to start ticked).
    Besides the person's list: genres found but not on it (when a release source gave one, or it came up more
    than once), so they can be chosen and added to the list; and the genres already in the tracks' tags,
    which start ticked along with the ones two kinds of source agree on."""
    index = _index(genres)
    out = dict((g, set(s)) for g, s in sources.items())
    names = list(genres)
    counted = {}
    for row in rows:
        for source, raws in (row.get("found") or {}).items():
            for raw in raws:
                if _matches(raw, index) or raw.lower() in JUNK or not key(raw):
                    continue
                c = counted.setdefault(key(raw), {"name": _tidy(raw), "sources": set(), "n": 0})
                c["sources"].add(source)
                c["n"] += 1
    new = [c for c in counted.values() if c["sources"] & set(RELEASE_SOURCES) or c["n"] > 1 or len(c["sources"]) > 1]
    new.sort(key=lambda c: (-len(c["sources"]), -c["n"], c["name"].lower()))
    for c in new[:MOST_NEW]:
        names.append(c["name"])
        out.setdefault(c["name"], set()).update(c["sources"])
    tagged = []
    for row in rows:
        for raw in re.split(r"\s*[/;,]\s*", row.get("current") or ""):
            if not key(raw):
                continue
            found = _matches(raw, index)
            name = found[0] if found else next((n for n in names if key(n) == key(raw)), _tidy(raw))
            if name not in names:
                names.append(name)
            out.setdefault(name, set()).add("tagged")
            if name not in tagged:
                tagged.append(name)
    start = [g for g in order_genres(names, out) if kind_of(out.get(g, ())) == "both"]
    return names, out, start + [g for g in tagged if g not in start]


def new_genres(choices, genres):
    """Genres chosen that aren't on the person's list yet, in the order first chosen."""
    listed = set(key(g) for g in genres)
    out = []
    for choice in choices.values():
        for picked in [choice.get("genres") or []] + list((choice.get("tracks") or {}).values()):
            for g in picked:
                if key(g) not in listed and g not in out:
                    out.append(g)
    return out


def kind_of(sources):
    """Which colour a genre gets: "both" when a release source and a tag source agree, "discogs" for release
    sources only, "lastfm" for tag sources only, or "none". (The names are the original two sources'.)"""
    release = any(s in RELEASE_SOURCES for s in sources)
    tagged = any(s in TAG_SOURCES for s in sources)
    if release and tagged:
        return "both"
    return "discogs" if release else "lastfm" if tagged else "none"


def source_names(sources):
    """"Discogs, SoundCloud": who said so, for the screen."""
    return ", ".join(SOURCE_NAMES.get(s, s) for s in sorted(sources, key=lambda s: SOURCE_NAMES.get(s, s)))


def order_genres(genres, sources):
    """Found on both first, then Discogs, then Last.fm, then the featured artists' genres, then the rest, each
    in A to Z order."""
    rank = {"both": 0, "discogs": 1, "lastfm": 2, "none": 3}
    return sorted(genres, key=lambda g: (rank[kind_of(sources.get(g, ()))], "artists" not in sources.get(g, ()), g.lower()))


def default_picks(ordered, sources):
    return [g for g in ordered if kind_of(sources.get(g, ())) == "both"]


def apply_choices(rows, choices):
    """Set each row's genres from what the person chose: a track's own choice, or else its artist's.
    Only the person's choices become genres. A track whose artist wasn't reviewed gets none."""
    for row in rows:
        chosen = choices.get(key(main_artist(row["artist"])))
        row["reviewed"] = chosen is not None
        if not chosen:
            row["keep"] = []
            continue
        row["keep"] = list(chosen.get("tracks", {}).get(key(clean_title(row["title"])), chosen.get("genres", [])))
        row["single"] = [pair for pair in row["single"] if pair[0] not in row["keep"]]
    return rows


def report(rows, source_status, stopped=False):
    """The dry run's plain text. source_status: lines saying what each source did."""
    with_genres = [r for r in rows if r["keep"]]
    only_one = [r for r in rows if r["single"] and not r["keep"]]
    lines = ["Dry run: no files were changed.", ""] + source_status + [
        "", "%d tracks%s: %d would get genres, %d have a genre from one source only, %d have nothing." % (
            len(rows), " before you stopped it" if stopped else "", len(with_genres), len(only_one),
            len(rows) - len(with_genres) - len(only_one)), ""]
    tally = {}
    for row in rows:
        lines.append("%s - %s" % (row["artist"], row["title"]))
        if row["current"]:
            lines.append("   Now: %s" % row["current"])
        if row["keep"]:
            lines.append("   Would write: %s" % format_tag(row["keep"]))
        elif row.get("reviewed") is False:
            lines.append("   Artist not reviewed, so nothing would be written.")
        if row["single"]:
            lines.append("   One source only: %s" % ", ".join("%s (%s)" % pair for pair in row["single"]))
        if row["unlisted"]:
            lines.append("   Not on your list: %s" % ", ".join(row["unlisted"]))
        if not (row["keep"] or row["single"] or row["unlisted"]):
            lines.append("   Nothing found.")
        for raw in row["unlisted"]:
            tally[raw] = tally.get(raw, 0) + 1
    if tally:
        top = sorted(tally, key=lambda n: (-tally[n], n.lower()))[:25]
        lines += ["", "Most common tags not on your list:"] + ["   %s (%d)" % (n, tally[n]) for n in top]
    return "\n".join(lines)
