"""Torrent clients Sortovia can hand a torrent to, for what Real-Debrid can't get.

"phone": the phone's own downloader (aria2 in Termux, run by kodi-share's helper on port 8081), which saves into
Download/Torrents for Sortovia to sort. Others on the phone or the network, by their remote-control address:
Transmission (also BiglyBT and Vuze with their Transmission-style remote), qBittorrent's Web UI, and aria2.
"""
import base64
import json
import re

import dlqueue

try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode
    from http.cookiejar import CookieJar
    from urllib.request import build_opener, HTTPCookieProcessor
except ImportError:  # Kodi 18 and older
    from urllib2 import Request, urlopen, build_opener, HTTPCookieProcessor
    from urllib import urlencode
    from cookielib import CookieJar

KINDS = [("transmission", "Transmission (also BiglyBT and Vuze remote)", "http://phone:9091/transmission/rpc"),
         ("qbittorrent", "qBittorrent Web UI", "http://192.168.1.20:8080"),
         ("aria2", "aria2", "http://192.168.1.20:6800/jsonrpc")]
KIND_NAMES = dict((k, n) for k, n, _ in KINDS)


class ClientError(Exception):
    pass


def _open(req, timeout=20, opener=None):
    try:
        resp = (opener.open if opener else urlopen)(req, timeout=timeout)
        try:
            return resp.getcode(), resp.read(), resp.headers
        finally:
            resp.close()
    except Exception as e:
        code = getattr(e, "code", None)
        if code:
            return code, (e.read() if hasattr(e, "read") else b""), getattr(e, "headers", {}) or {}
        if type(e).__name__ in ("BadStatusLine", "RemoteDisconnected", "LineTooLong"):
            raise ClientError("something answered, but not a web remote - is that the port torrents use, "
                              "rather than the remote-control one?")
        why = "".join(ch for ch in str(getattr(e, "reason", None) or e) if ch.isprintable())[:120]
        raise ClientError("can't reach it (%s)" % why)


def _auth(c):
    if not c.get("user"):
        return {}
    return {"Authorization": "Basic " + base64.b64encode(("%s:%s" % (c["user"], c.get("pass", ""))).encode()).decode()}


def add_transmission(c, uri, opener=None):
    body = json.dumps({"method": "torrent-add", "arguments": {"filename": uri}}).encode()
    headers = dict(_auth(c), **{"Content-Type": "application/json"})
    code, data, h = _open(Request(c["url"], data=body, headers=headers), opener=opener)
    if code == 409:  # first call: Transmission hands out its session id
        headers["X-Transmission-Session-Id"] = (h.get("X-Transmission-Session-Id") if h else "") or ""
        code, data, h = _open(Request(c["url"], data=body, headers=headers), opener=opener)
    if code == 401:
        raise ClientError("it refused the user name or password")
    if code != 200:
        raise ClientError("it answered %s" % code)
    out = json.loads(data.decode("utf-8"))
    if out.get("result") != "success":
        raise ClientError(out.get("result") or "it said no")
    return True


def add_qbittorrent(c, uri, opener=None):
    base = c["url"].rstrip("/")
    opener = opener or build_opener(HTTPCookieProcessor(CookieJar()))
    headers = {"Referer": base}
    code, data, _ = _open(Request(base + "/api/v2/auth/login", data=urlencode(
        {"username": c.get("user", ""), "password": c.get("pass", "")}).encode(), headers=headers), opener=opener)
    if code != 200 or data.strip() not in (b"Ok.", b""):
        raise ClientError("it refused the user name or password")
    code, data, _ = _open(Request(base + "/api/v2/torrents/add", data=urlencode({"urls": uri}).encode(),
                                  headers=headers), opener=opener)
    if code != 200:
        raise ClientError("it answered %s" % code)
    return True


def add_aria2(c, uri, opener=None):
    params = (["token:" + c["pass"]] if c.get("pass") else []) + [[uri]]
    body = json.dumps({"jsonrpc": "2.0", "id": "s", "method": "aria2.addUri", "params": params}).encode()
    code, data, _ = _open(Request(c["url"], data=body, headers={"Content-Type": "application/json"}), opener=opener)
    out = json.loads(data.decode("utf-8") or "{}")
    if code != 200 or out.get("error"):
        raise ClientError((out.get("error") or {}).get("message") or "it answered %s" % code)
    return True


def _rpc_transmission(c, method, opener=None, args=None):
    body = json.dumps({"method": method, "arguments": args or {}}).encode()
    headers = dict(_auth(c), **{"Content-Type": "application/json"})
    code, data, h = _open(Request(c["url"], data=body, headers=headers), opener=opener)
    if code == 409:
        headers["X-Transmission-Session-Id"] = (h.get("X-Transmission-Session-Id") if h else "") or ""
        code, data, h = _open(Request(c["url"], data=body, headers=headers), opener=opener)
    if code == 401:
        raise ClientError("it refused the user name or password")
    if code == 404:
        raise ClientError("something answered, but not a Transmission remote (the address should end /transmission/rpc)")
    if code != 200:
        raise ClientError("it answered %s" % code)
    out = json.loads(data.decode("utf-8"))
    if isinstance(out, dict) and out.get("result") not in (None, "success"):  # 2.1.0: e.g. a method BiglyBT lacks
        raise ClientError(str(out["result"])[:120])
    return out


def test(c, opener=None):
    """Ask the client something harmless. Returns what it is (e.g. "Transmission 3.00"); ClientError if not."""
    try:
        if c["kind"] == "transmission":
            a = _rpc_transmission(c, "session-get", opener).get("arguments") or {}
            return "%s %s" % ("Vuze/BiglyBT" if a.get("az-version") or "az" in str(a.get("version", "")).lower()
                              else "Transmission", a.get("version") or "")
        if c["kind"] == "qbittorrent":
            base = c["url"].rstrip("/")
            opener = opener or build_opener(HTTPCookieProcessor(CookieJar()))
            code, data, _ = _open(Request(base + "/api/v2/auth/login", data=urlencode(
                {"username": c.get("user", ""), "password": c.get("pass", "")}).encode(), headers={"Referer": base}),
                opener=opener)
            if code != 200 or data.strip() not in (b"Ok.", b""):
                raise ClientError("it refused the user name or password")
            code, data, _ = _open(Request(base + "/api/v2/app/version", headers={"Referer": base}), opener=opener)
            return "qBittorrent %s" % data.decode("utf-8", "replace").strip()
        params = ["token:" + c["pass"]] if c.get("pass") else []
        body = json.dumps({"jsonrpc": "2.0", "id": "s", "method": "aria2.getVersion", "params": params}).encode()
        code, data, _ = _open(Request(c["url"], data=body, headers={"Content-Type": "application/json"}), opener=opener)
        out = json.loads(data.decode("utf-8") or "{}")
        if code != 200 or out.get("error"):
            raise ClientError((out.get("error") or {}).get("message") or "it answered %s" % code)
        return "aria2 %s" % (out.get("result") or {}).get("version", "")
    except ValueError:
        raise ClientError("something answered, but not a torrent client's remote")


TR_FIELDS = ["id", "name", "status", "percentDone", "rateDownload", "eta", "peersConnected", "peersSendingToUs",
             "error", "errorString", "sizeWhenDone", "magnetLink", "downloadDir", "metadataPercentComplete",
             "hashString"]


def magnet_of(h, name=None):
    """A magnet link made from a torrent's info hash, when the client gives no link of its own."""
    from urllib.parse import quote
    if not h or not re.match(r"^[0-9a-fA-F]{40}$", h):
        return ""
    return "magnet:?xt=urn:btih:%s" % h.lower() + ("&dn=%s" % quote(name) if name else "")


def tr_state(t):
    """Transmission's status number as the phone's downloader names it (active, waiting, paused, complete, error)."""
    if t.get("percentDone", 0) >= 1 and t.get("sizeWhenDone"):
        return "complete"
    if t.get("error") and t.get("status") == 0:
        return "error"
    return {0: "paused", 3: "waiting", 5: "complete", 6: "complete"}.get(t.get("status"), "active")


def tr_jobs(c, opener=None):
    """A Transmission-style client's torrents (e.g. BiglyBT), shaped like the phone's own downloads."""
    ts = (_rpc_transmission(c, "torrent-get", opener, {"fields": TR_FIELDS}).get("arguments") or {}).get("torrents") or []
    out = []
    for t in ts:
        state, size = tr_state(t), int(t.get("sizeWhenDone") or 0)
        meta = t.get("metadataPercentComplete", 1) < 1
        out.append({"id": "%s:%s" % (c["id"], t["id"]), "client": c["id"], "tid": t["id"],
                    "name": ("[METADATA]" if meta and state == "active" else "") + (t.get("name") or "?"),
                    "kind": "Torrents", "state": state, "size": size, "pct": round(100.0 * (t.get("percentDone") or 0), 1),
                    "speed": int(t.get("rateDownload") or 0), "eta": max(0, int(t.get("eta") or 0)),
                    "seeds": int(t.get("peersSendingToUs") or 0), "peers": int(t.get("peersConnected") or 0),
                    "error": t.get("errorString") or "", "uri": t.get("magnetLink") or magnet_of(t.get("hashString"), t.get("name")),
                    "hash": (t.get("hashString") or "").lower(),
                    "dir": t.get("downloadDir") or "", "where": c.get("name") or "BiglyBT"})
    return out


def tr_files(c, tid, opener=None):
    """The files in one torrent: [{"index", "name" (its path inside the torrent), "length", "done", "wanted"}]."""
    ts = (_rpc_transmission(c, "torrent-get", opener, {"ids": [tid], "fields": ["id", "files", "fileStats"]})
          .get("arguments") or {}).get("torrents") or []
    if not ts:
        return []
    stats = ts[0].get("fileStats") or []
    out = []
    for i, f in enumerate(ts[0].get("files") or []):
        st = stats[i] if i < len(stats) else {}
        out.append({"index": i, "name": f.get("name") or "", "length": int(f.get("length") or 0),
                    "done": int(f.get("bytesCompleted") or 0), "wanted": st.get("wanted", True) not in (False, 0)})
    return out


# The phone's own downloader (tools/yt_helper.py TRACKERS) uses these too; a test keeps the two lists the same.
TRACKERS = [
    "udp://tracker.opentrackr.org:1337/announce", "udp://open.stealth.si:80/announce",
    "udp://tracker.torrent.eu.org:451/announce", "udp://open.tracker.cl:1337/announce",
    "udp://open.demonii.com:1337/announce", "udp://exodus.desync.com:6969/announce",
    "udp://tracker.qu.ax:6969/announce", "udp://tracker.ducks.party:1984/announce",
    "udp://tracker.bittor.pw:1337/announce", "udp://tracker-udp.gbitt.info:80/announce",
    "udp://tracker.corpscorp.online:80/announce", "udp://tracker.nyaa.vc:6969/announce",
    "udp://tracker2.dler.org:80/announce", "http://tracker.dler.org:6969/announce",
    "http://tracker.dler.com:6969/announce", "udp://explodie.org:6969/announce",
    "udp://tracker.gmi.gd:6969/announce", "http://tracker.renfei.net:8080/announce",
    "udp://tracker.peerfect.org:6969/announce",
]


def tr_add_trackers(c, tid, opener=None):
    """Add the extra public trackers a torrent doesn't have yet (BiglyBT also lists DHT and peer counts among its
    trackers; only real addresses count). A few at a time: BiglyBT took over 20 seconds for six at once.
    Returns how many were added."""
    t = (_rpc_transmission(c, "torrent-get", opener, {"ids": [tid], "fields": ["trackers"]}).get("arguments")
         or {}).get("torrents") or []
    if not t:
        return 0
    have = set(x.get("announce", "") for x in t[0].get("trackers") or [])
    have |= set(h.replace("http://", "udp://", 1) for h in have) | set(h.replace("udp://", "http://", 1) for h in have)
    missing = [u for u in TRACKERS if u not in have]
    for i in range(0, len(missing), 3):
        _rpc_transmission(c, "torrent-set", opener, {"ids": [tid], "trackerAdd": missing[i:i + 3]})
    return len(missing)


def tr_want(c, tid, indices, wanted, opener=None):
    """Mark files of a torrent to download (wanted) or "Do not download"."""
    _rpc_transmission(c, "torrent-set", opener, {"ids": [tid], ("files-wanted" if wanted else "files-unwanted"):
                                                 list(indices)})


def finished_episodes(files, video_exts):
    """The files of a torrent still downloading that are finished episodes: fully downloaded, still wanted,
    a video, with an episode number in the name, and in a torrent of several files."""
    from sortlib import episode_tag
    if len(files) < 2:
        return []
    return [f for f in files if f["wanted"] and f["length"] > 0 and f["done"] >= f["length"]
            and ("." + f["name"].rsplit(".", 1)[-1].lower()) in video_exts and episode_tag(f["name"].split("/")[-1])]


def tr_act(c, tids, what, opener=None):
    """what: "pause", "resume", "remove" (the files stay) or "delete" (the files and part files go too)."""
    method = {"pause": "torrent-stop", "resume": "torrent-start", "remove": "torrent-remove",
              "delete": "torrent-remove"}[what]
    args = {"ids": list(tids)} if tids else {}
    if what in ("remove", "delete"):
        args["delete-local-data"] = what == "delete"
    _rpc_transmission(c, method, opener, args)


def on_phone(c):
    """True for a client whose address is the phone (http://phone:...)."""
    import re
    return bool(re.match(r"^\w+://phone[:/]", c.get("url") or "", re.I))


def advice(c, err):
    """What to try when test() failed."""
    e = str(err).lower()
    if "refused" in e and "password" not in e:
        tip = "Nothing is listening at that address and port."
        if c["kind"] == "transmission":
            tip += ("\nIn BiglyBT: Options > Remote access > turn on Allow remote access, and keep BiglyBT open. "
                    "Use the port it shows there, e.g. http://phone:9093/transmission/rpc for BiglyBT on the phone "
                    "(Sortovia fills in the phone's address).")
        return tip
    if "timed out" in e or "no route" in e or "unreachable" in e:
        return "That address didn't answer. Check the device is on the same Wi-Fi or hotspot as the Xbox, and its address."
    if "password" in e:
        return "Check the user name and password set in the client's remote-access settings."
    return ""


ADDERS = {"transmission": add_transmission, "qbittorrent": add_qbittorrent, "aria2": add_aria2}


def send(client, uri, phone=None, opener=None):
    """Hand a magnet link or .torrent address to a client. phone: a youtube.Phone, for the phone's own downloader."""
    if client.get("kind") == "phone":
        if phone is None:
            raise ClientError("can't find the phone")
        r = phone.call("/tor/add", {"uri": uri, "name": client.get("label", "")})
        if not r.get("id"):
            raise ClientError(r.get("error") or "the phone didn't take it")
        return True
    return ADDERS[client["kind"]](client, uri, opener)


def job_lines(j):
    """(name, 'Downloading 42% - 1.2 MB/s - 3 min left - 12 peers') for a torrent on the phone.
    The phone's "waiting" is shown as Queued (it downloads twelve at a time); a running one nobody is
    sending to is "Waiting for peers"."""
    name = j.get("name") or "?"
    meta = name.startswith("[METADATA]")
    if meta:  # a magnet link's first step: finding peers to get the torrent's details
        name = name[len("[METADATA]"):].replace("+", " ")
    stuck = not meta and j.get("state") == "active" and dlqueue.tor_group(j) == dlqueue.PEERS
    state = {"active": "Finding peers for its details" if meta else "Waiting for peers" if stuck else "Downloading",
             "waiting": "Queued - starts when one ahead of it finishes",
             "paused": "Paused", "complete": "Done - in Download/%s" % (j.get("kind") or "Torrents"),
             "error": "Failed", "removed": "Stopped", "gaveup": "Failed - no peers, " + dlqueue.gaveup_note(j)}.get(j.get("state"), j.get("state") or "?")
    bits = [state]
    if meta:
        return name, state + (" - %d peers" % j.get("peers", 0) if j.get("state") == "active" else "")
    if (j.get("state") == "active" and not stuck) or \
            (j.get("state") in ("active", "waiting", "paused") and j.get("size")):  # always says its percentage
        bits.append("%d%%" % j.get("pct", 0))
    if j.get("state") == "active" and not stuck:
        if j.get("speed"):
            bits.append("%.1f MB/s" % (j["speed"] / 1e6))
        if j.get("eta"):
            bits.append("%d min left" % max(1, j["eta"] // 60))
        bits.append("%d peers" % j.get("peers", 0))
    if j.get("state") == "error" and j.get("error"):
        bits.append(j["error"][:60])
    return name, " - ".join(bits)


# ---------- 2.1.0: one control layer for every client (the phone's helper and BiglyBT's Transmission remote) ----------
# What each client can do; dlview.TORRENT_CAPS keeps the menus to these.
CAPS = {
    "helper": {"pause", "resume", "start_now", "queue_top", "queue_up", "queue_down", "queue_bottom",
               "limit_item", "limit_all", "files", "peers", "remove_keep", "remove_delete"},
    "transmission": {"pause", "resume", "start_now", "queue_top", "queue_up", "queue_down", "queue_bottom",
                     "recheck", "reannounce", "limit_item", "limit_all", "files", "peers", "trackers",
                     "remove_keep", "remove_delete"},
}


def _is_helper(c):
    return (c or {}).get("kind") in ("helper", "phone")


def _helper(phone, path, body):
    if phone is None:
        raise ClientError("can't find the phone")
    r = phone.call(path, body) or {}
    if r.get("error"):
        if r["error"] == "not found":
            raise ClientError("the phone helper is too old for this; in Termux: kodi-share restart")
        raise ClientError(r["error"])
    return r


def _kb(n):
    return max(0, int(n or 0))


def act(c, tids, what, phone=None, opener=None, down=None, up=None, indices=None, wanted=True):
    """Do one thing to downloads in a client. tids: its ids ([] for limit_all). what: one of CAPS.
    down/up: KB/s (0 = no limit) for limit_item / limit_all. indices/wanted: for files."""
    tids = [t for t in (tids or []) if t is not None]
    if _is_helper(c):
        for tid in tids or [None]:
            if what in ("pause", "resume"):
                _helper(phone, "/tor/" + what, {"id": tid})
            elif what == "start_now":
                _helper(phone, "/tor/position", {"id": tid, "to": "top"})
                _helper(phone, "/tor/resume", {"id": tid})
            elif what.startswith("queue_"):
                _helper(phone, "/tor/position", {"id": tid, "to": what[len("queue_"):]})
            elif what in ("remove_keep", "remove_delete"):
                _helper(phone, "/tor/remove", {"id": tid, "keep": what == "remove_keep"})
            elif what == "limit_item":
                _helper(phone, "/tor/option", {"id": tid, "down": _kb(down), "up": _kb(up)})
            elif what == "limit_all":
                body = dict((k, _kb(v)) for k, v in (("down", down), ("up", up)) if v is not None)
                _helper(phone, "/tor/global", body)
                return True
            elif what == "files":
                _helper(phone, "/tor/files", {"id": tid, "indices": list(indices or []), "wanted": bool(wanted)})
            else:
                raise ClientError("the phone's downloader can't do that")
        return True
    if c.get("kind", "transmission") != "transmission":
        raise ClientError("%s can't be controlled from here yet" % KIND_NAMES.get(c.get("kind"), c.get("kind")))
    ids = {"ids": tids} if tids else {}
    simple = {"pause": "torrent-stop", "resume": "torrent-start", "start_now": "torrent-start-now",
              "queue_top": "queue-move-top", "queue_up": "queue-move-up", "queue_down": "queue-move-down",
              "queue_bottom": "queue-move-bottom", "recheck": "torrent-verify", "reannounce": "torrent-reannounce"}
    if what in simple:
        _rpc_transmission(c, simple[what], opener, ids)
    elif what in ("remove_keep", "remove_delete"):
        _rpc_transmission(c, "torrent-remove", opener, dict(ids, **{"delete-local-data": what == "remove_delete"}))
    elif what == "limit_item":
        _rpc_transmission(c, "torrent-set", opener, dict(ids, downloadLimit=_kb(down), downloadLimited=bool(down),
                                                         uploadLimit=_kb(up), uploadLimited=bool(up)))
    elif what == "limit_all":
        args = {}
        if down is not None:
            args.update({"speed-limit-down": _kb(down), "speed-limit-down-enabled": bool(down)})
        if up is not None:
            args.update({"speed-limit-up": _kb(up), "speed-limit-up-enabled": bool(up)})
        _rpc_transmission(c, "session-set", opener, args)
    elif what == "files":
        for tid in tids:
            tr_want(c, tid, indices or [], wanted, opener)
    else:
        raise ClientError("that can't be done in %s" % (c.get("name") or "this client"))
    return True


def details(c, tid, phone=None, opener=None):
    """{"files": [...like tr_files], "peers": [{"ip", "client", "down"}], "trackers": [{"url", "status"}],
    "ratio", "added", "down_limit", "up_limit"} for one download; what a client doesn't know is left out."""
    if _is_helper(c):
        return _helper(phone, "/tor/details", {"id": tid})
    ts = (_rpc_transmission(c, "torrent-get", opener, {"ids": [tid], "fields": [
        "id", "files", "fileStats", "peers", "trackerStats", "uploadRatio", "addedDate", "downloadLimit",
        "downloadLimited", "uploadLimit", "uploadLimited"]}).get("arguments") or {}).get("torrents") or []
    if not ts:
        return {}
    t = ts[0]
    stats = t.get("fileStats") or []
    files = []
    for i, f in enumerate(t.get("files") or []):
        st = stats[i] if i < len(stats) else {}
        files.append({"index": i, "name": f.get("name") or "", "length": int(f.get("length") or 0),
                      "done": int(f.get("bytesCompleted") or 0), "wanted": st.get("wanted", True) not in (False, 0)})
    import time
    out = {"files": files,
           "peers": [{"ip": p.get("address", "?"), "client": p.get("clientName", ""), "down": int(p.get("rateToClient") or 0)}
                     for p in t.get("peers") or []],
           "trackers": [{"url": s.get("announce", ""), "status": s.get("lastAnnounceResult", "")}
                        for s in t.get("trackerStats") or []]}
    if t.get("uploadRatio") is not None and t["uploadRatio"] >= 0:
        out["ratio"] = round(t["uploadRatio"], 2)
    if t.get("addedDate"):
        out["added"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(t["addedDate"]))
    out["down_limit"] = t.get("downloadLimit") if t.get("downloadLimited") else "none"
    out["up_limit"] = t.get("uploadLimit") if t.get("uploadLimited") else "none"
    return out
