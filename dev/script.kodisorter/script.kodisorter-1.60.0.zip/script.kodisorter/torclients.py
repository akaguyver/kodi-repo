"""Torrent clients Sortovia can hand a torrent to, for what Real-Debrid can't get.

"phone": the phone's own downloader (aria2 in Termux, run by kodi-share's helper on port 8081), which saves into
Download/Torrents for Sortovia to sort. Others on the phone or the network, by their remote-control address:
Transmission (also BiglyBT and Vuze with their Transmission-style remote), qBittorrent's Web UI, and aria2.
"""
import base64
import json

import dlqueue

try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode
    from http.cookiejar import CookieJar
    from urllib.request import build_opener, HTTPCookieProcessor
except ImportError:  # Kodi 18 and older
    from urllib2 import Request, urlopen, build_opener, HTTPCookieProcessor
    from urllib import urlencode
    from cookielib import CookieJar

KINDS = [("transmission", "Transmission (also BiglyBT and Vuze remote)", "http://192.168.1.20:9091/transmission/rpc"),
         ("qbittorrent", "qBittorrent Web UI", "http://192.168.1.20:8080"),
         ("aria2", "aria2", "http://192.168.1.20:6800/jsonrpc")]
KIND_NAMES = dict((k, n) for k, n, _ in KINDS)


class ClientError(Exception):
    pass


def _open(req, timeout=20, opener=None):
    try:
        resp = (opener.open if opener else urlopen)(req, timeout=timeout)
        try:
            return resp.getcode(), resp.read(), resp.headers
        finally:
            resp.close()
    except Exception as e:
        code = getattr(e, "code", None)
        if code:
            return code, (e.read() if hasattr(e, "read") else b""), getattr(e, "headers", {}) or {}
        raise ClientError("can't reach it (%s)" % (getattr(e, "reason", None) or e))


def _auth(c):
    if not c.get("user"):
        return {}
    return {"Authorization": "Basic " + base64.b64encode(("%s:%s" % (c["user"], c.get("pass", ""))).encode()).decode()}


def add_transmission(c, uri, opener=None):
    body = json.dumps({"method": "torrent-add", "arguments": {"filename": uri}}).encode()
    headers = dict(_auth(c), **{"Content-Type": "application/json"})
    code, data, h = _open(Request(c["url"], data=body, headers=headers), opener=opener)
    if code == 409:  # first call: Transmission hands out its session id
        headers["X-Transmission-Session-Id"] = (h.get("X-Transmission-Session-Id") if h else "") or ""
        code, data, h = _open(Request(c["url"], data=body, headers=headers), opener=opener)
    if code == 401:
        raise ClientError("it refused the user name or password")
    if code != 200:
        raise ClientError("it answered %s" % code)
    out = json.loads(data.decode("utf-8"))
    if out.get("result") != "success":
        raise ClientError(out.get("result") or "it said no")
    return True


def add_qbittorrent(c, uri, opener=None):
    base = c["url"].rstrip("/")
    opener = opener or build_opener(HTTPCookieProcessor(CookieJar()))
    headers = {"Referer": base}
    code, data, _ = _open(Request(base + "/api/v2/auth/login", data=urlencode(
        {"username": c.get("user", ""), "password": c.get("pass", "")}).encode(), headers=headers), opener=opener)
    if code != 200 or data.strip() not in (b"Ok.", b""):
        raise ClientError("it refused the user name or password")
    code, data, _ = _open(Request(base + "/api/v2/torrents/add", data=urlencode({"urls": uri}).encode(),
                                  headers=headers), opener=opener)
    if code != 200:
        raise ClientError("it answered %s" % code)
    return True


def add_aria2(c, uri, opener=None):
    params = (["token:" + c["pass"]] if c.get("pass") else []) + [[uri]]
    body = json.dumps({"jsonrpc": "2.0", "id": "s", "method": "aria2.addUri", "params": params}).encode()
    code, data, _ = _open(Request(c["url"], data=body, headers={"Content-Type": "application/json"}), opener=opener)
    out = json.loads(data.decode("utf-8") or "{}")
    if code != 200 or out.get("error"):
        raise ClientError((out.get("error") or {}).get("message") or "it answered %s" % code)
    return True


ADDERS = {"transmission": add_transmission, "qbittorrent": add_qbittorrent, "aria2": add_aria2}


def send(client, uri, phone=None, opener=None):
    """Hand a magnet link or .torrent address to a client. phone: a youtube.Phone, for the phone's own downloader."""
    if client.get("kind") == "phone":
        if phone is None:
            raise ClientError("can't find the phone")
        r = phone.call("/tor/add", {"uri": uri, "name": client.get("label", "")})
        if not r.get("id"):
            raise ClientError(r.get("error") or "the phone didn't take it")
        return True
    return ADDERS[client["kind"]](client, uri, opener)


def job_lines(j):
    """(name, 'Downloading 42% - 1.2 MB/s - 3 min left - 12 peers') for a torrent on the phone.
    The phone's "waiting" is shown as Queued (it downloads eight at a time); a running one nobody is
    sending to is "Waiting for peers"."""
    name = j.get("name") or "?"
    meta = name.startswith("[METADATA]")
    if meta:  # a magnet link's first step: finding peers to get the torrent's details
        name = name[len("[METADATA]"):].replace("+", " ")
    stuck = not meta and j.get("state") == "active" and dlqueue.tor_group(j) == dlqueue.PEERS
    state = {"active": "Finding peers for its details" if meta else "Waiting for peers" if stuck else "Downloading",
             "waiting": "Queued - starts when one ahead of it finishes",
             "paused": "Paused", "complete": "Done - in Download/%s" % (j.get("kind") or "Torrents"),
             "error": "Failed", "removed": "Stopped", "gaveup": "Failed - tried 3x, no peers"}.get(j.get("state"), j.get("state") or "?")
    bits = [state]
    if meta:
        return name, state + (" - %d peers" % j.get("peers", 0) if j.get("state") == "active" else "")
    if j.get("state") in ("active", "waiting", "paused") and j.get("size"):
        bits.append("%d%%" % j.get("pct", 0))
    if j.get("state") == "active" and not stuck:
        if j.get("speed"):
            bits.append("%.1f MB/s" % (j["speed"] / 1e6))
        if j.get("eta"):
            bits.append("%d min left" % max(1, j["eta"] // 60))
        bits.append("%d peers" % j.get("peers", 0))
    if j.get("state") == "error" and j.get("error"):
        bits.append(j["error"][:60])
    return name, " - ".join(bits)
