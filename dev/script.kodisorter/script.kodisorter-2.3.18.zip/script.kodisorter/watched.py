"""Watched marks that follow a video (2.3.18).

Kodi keeps a video's watched mark and resume point under the exact folder path it was played from. Outside the
library that breaks two ways: Sortovia moves a file (Tidy YouTube folders), so the mark stays at the old folder;
and Kodi spells one folder more than one way ('D:/Tutorials/Claude/' and 'D:\\\\Tutorials\\Claude\\'), so a mark
saved one way doesn't show when the folder is opened the other way. This finds the marks in Kodi's video
database and copies each onto every spelling of wherever that file is now.
"""
import re

PREFIX = "win-lib://removable/"


def parse(path):
    """'win-lib://removable/D:\\\\a\\b/c.mp4' -> ('D', ('a', 'b'), 'c.mp4'); None for other kinds of path."""
    if not path.lower().startswith(PREFIX):
        return None
    rest = path[len(PREFIX):]
    m = re.match(r"^([A-Za-z]):(.*)$", rest)
    if not m:
        return None
    parts = [p for p in re.split(r"[\\/]+", m.group(2)) if p]
    if not parts:
        return None
    return m.group(1).upper(), tuple(parts[:-1]), parts[-1]


def spellings(drive, parts):
    """Every way Kodi has been seen to write this folder."""
    slash = "/".join(parts)
    back = "\\".join(parts)
    tail_s = slash + "/" if parts else ""
    tail_b = back + "\\" if parts else ""
    return [PREFIX + drive + ":/" + tail_s, PREFIX + drive + ":\\" + tail_b, PREFIX + drive + ":\\\\" + tail_b]


RECORDS_SQL = ("SELECT p.strPath, f.strFilename, f.playCount, f.lastPlayed, b.timeInSeconds, b.totalTimeInSeconds "
               "FROM files f JOIN path p ON p.idPath = f.idPath "
               "LEFT JOIN bookmark b ON b.idFile = f.idFile AND b.type = 1 "
               "WHERE f.playCount > 0 OR b.idBookmark IS NOT NULL")


def records(conn):
    """[(folder, file, playcount, lastplayed, resume seconds, total seconds)] of every played or half-played file."""
    return [tuple(r) for r in conn.execute(RECORDS_SQL).fetchall()]


def _better(a, b):
    """The record to keep for one file name: watched beats half-watched, then the latest."""
    return a if (bool(a[2]), a[3] or "") >= (bool(b[2]), b[3] or "") else b


def plan(recs, current):
    """[(full path to set, record)] for the files now on the drive (`current`, full paths) whose name has a watched
    mark or resume point somewhere, under each spelling of their folder that doesn't have it yet."""
    by_name = {}
    exact = set((r[0] or "", r[1] or "") for r in recs)
    for r in recs:
        p = parse((r[0] or "") + (r[1] or ""))
        if not p:
            continue
        k = p[2].lower()
        by_name[k] = _better(r, by_name[k]) if k in by_name else r
    out, seen = [], set()
    for path in current:
        p = parse(path)
        if not p:
            continue
        drive, parts, name = p
        rec = by_name.get(name.lower())
        if not rec:
            continue
        for folder in spellings(drive, parts):
            full = folder + name
            if full.lower() in seen:
                continue
            seen.add(full.lower())
            if (folder, name) in exact:
                continue
            out.append((full, rec))
    return out


def details(full, rec):
    """Files.SetFileDetails params for one file."""
    params = {"file": full, "media": "video"}
    if rec[2]:
        params["playcount"] = int(rec[2])
    if rec[3]:
        params["lastplayed"] = rec[3]
    if rec[4] and rec[5]:
        params["resume"] = {"position": float(rec[4]), "total": float(rec[5])}
    return params
