"""Discover (2.2.0, ticket wwhe): popular, top rated and new shows and movies from TMDb, by genre, each row
ready to search for. Uses the same free TMDb key as Where to watch (whereto.TMDb)."""
import time

LISTS = [("popular", "Popular"), ("top", "Top rated"), ("new", "New")]

# one list of genres for both: TMDb numbers movie and TV genres differently, and some exist for only one
GENRES = [  # (name, movie genre id, TV genre id)
    ("Action", 28, 10759), ("Adventure", 12, 10759), ("Animation", 16, 16), ("Comedy", 35, 35), ("Crime", 80, 80),
    ("Documentary", 99, 99), ("Drama", 18, 18), ("Family", 10751, 10751), ("Fantasy", 14, 10765),
    ("History", 36, None), ("Horror", 27, None), ("Kids", None, 10762), ("Music", 10402, None),
    ("Mystery", 9648, 9648), ("Reality", None, 10764), ("Romance", 10749, None), ("Science Fiction", 878, 10765),
    ("Talk", None, 10767), ("Thriller", 53, None), ("War", 10752, 10768), ("Western", 37, 37),
]
NAMES = {}
for _name, _m, _t in GENRES:
    if _m:
        NAMES.setdefault(("movie", _m), _name)
    if _t:
        NAMES.setdefault(("tv", _t), _name)
NAMES[("tv", 10759)] = "Action & Adventure"
NAMES[("tv", 10765)] = "Sci-Fi & Fantasy"
NAMES[("tv", 10768)] = "War & Politics"
NEW_DAYS = {"movie": 90, "tv": 120}  # "new": first shown in the last this many days
MIN_VOTES = {"movie": 1000, "tv": 300}  # "top rated" needs enough votes to mean something


def genre_id(genre, kind):
    """The TMDb id of the genre for "movie" or "tv"; None when that kind has no such genre (or genre is "")."""
    for name, m, t in GENRES:
        if name == genre:
            return m if kind == "movie" else t
    return None


def kinds_for(cats, genre=""):
    """Which of "tv" and "movie" to list: from the ticked categories (both when neither is ticked), leaving out
    a kind that doesn't have the genre (Horror: movies only)."""
    out = [k for c, k in (("tv", "tv"), ("movies", "movie")) if c in (cats or ())] or ["tv", "movie"]
    if genre:
        out = [k for k in out if genre_id(genre, k)]
    return out


def params(kind, which, genre="", page=1, today=None):
    """(path, query) for TMDb's discover call."""
    p = {"page": page, "include_adult": "false", "language": "en-US"}
    if genre:
        p["with_genres"] = genre_id(genre, kind)
    date = "primary_release_date" if kind == "movie" else "first_air_date"
    if which == "top":
        p.update(sort_by="vote_average.desc")
        p["vote_count.gte"] = MIN_VOTES[kind]
    else:
        p["sort_by"] = "popularity.desc"
    if which == "new":
        now = today or time.time()
        p[date + ".gte"] = time.strftime("%Y-%m-%d", time.localtime(now - NEW_DAYS[kind] * 86400))
        p[date + ".lte"] = time.strftime("%Y-%m-%d", time.localtime(now))
        p["vote_count.gte"] = 5  # leaves out the many entries nobody has seen
    if kind == "tv":
        p["with_original_language"] = "en"  # the torrent sites list English titles; others rarely match
    return "/discover/%s" % kind, p


def row(item, kind, have=()):
    """{"q": what to search for, "meta", "kind", "id", "have"} from one TMDb result."""
    title = item.get("title") or item.get("name") or "?"
    date = item.get("release_date") or item.get("first_air_date") or ""
    year = date[:4]
    q = "%s %s" % (title, year) if kind == "movie" and year else title
    genres = [NAMES.get((kind, g)) for g in item.get("genre_ids") or []]
    vote = item.get("vote_average")
    meta = ["Movie" if kind == "movie" else "Show", year or "", "%.1f/10" % vote if vote else "",
            ", ".join(g for g in genres if g)[:40], (item.get("overview") or "")[:120]]
    key = _key(title)
    return {"q": q, "kind": kind, "id": item.get("id"), "have": key in have,
            "meta": ("In your library  ·  " if key in have else "") + "  ·  ".join(m for m in meta if m)}


def _key(title):
    import re
    return re.sub(r"[^a-z0-9]+", "", (title or "").lower())


def fetch(tmdb, cats, which, genre="", page=1, have=()):
    """The rows for one page of each kind asked for, shows and movies alternating (by their own order)."""
    lists = []
    for kind in kinds_for(cats, genre):
        path, p = params(kind, which, genre, page)
        res = (tmdb.get(path, **p) or {}).get("results") or []
        lists.append([row(x, kind, have) for x in res])
    out = []
    for i in range(max([len(x) for x in lists] or [0])):
        out += [x[i] for x in lists if i < len(x)]
    return out


def merge(old, new):
    """old rows, then the new ones not already listed (TMDb pages overlap when the order shifts)."""
    seen = set((r["kind"], r["id"]) for r in old)
    return list(old) + [r for r in new if (r["kind"], r["id"]) not in seen]
