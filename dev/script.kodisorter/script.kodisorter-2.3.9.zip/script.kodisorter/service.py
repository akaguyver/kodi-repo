"""Runs while Kodi is open: every ten minutes, starts the watcher that moves finished phone downloads onto the
Xbox (default.phone_autosort), unless it's already running. The watcher itself checks whether it's turned on
(Auto move, on the Downloads screen) and whether a phone is set up."""
import xbmc
import xbmcgui

PROP_AUTOSORT = "kodisorter.autosort"  # same as default.py: set while the watcher runs
PROP_RD_WATCH = "kodisorter.rd.watch"  # same as default.py: set while the Real-Debrid watcher runs
FIRST_WAIT, EVERY = 90, 600  # seconds: let Kodi finish starting, then look every ten minutes

if __name__ == "__main__":
    monitor = xbmc.Monitor()
    if not monitor.waitForAbort(FIRST_WAIT):
        while True:
            if not xbmcgui.Window(10000).getProperty(PROP_AUTOSORT):
                xbmc.executebuiltin("RunPlugin(plugin://script.kodisorter/?action=phone_autosort)")
            if not xbmcgui.Window(10000).getProperty(PROP_RD_WATCH):  # it returns at once if nothing is waiting
                xbmc.executebuiltin("RunPlugin(plugin://script.kodisorter/?action=rd_watch)")
            if monitor.waitForAbort(EVERY):
                break
