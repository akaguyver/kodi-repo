"""Full-window pages and a guide reader that scrolls slowly, one line at a time.

Kodi's own dialogs are small and page through text. These windows are built from Kodi's
standard controls, and anything that goes wrong falls back to Kodi's own dialog.
"""
import re

MEDIA = "special://home/addons/script.kodisorter/resources/media/"
LONG = 110          # messages longer than this get the full window
BACK = (9, 10, 13, 92)
LEFT, RIGHT, UP, DOWN, PAGE_UP, PAGE_DOWN = 1, 2, 3, 4, 5, 6
SELECT, PAUSE, PLAY = 7, 12, 79
CHARS_PER_LINE = 100
ROWS = 19


def line_count(text, width=CHARS_PER_LINE):
    """How many lines the text fills on screen (an estimate: Kodi does the real wrapping)."""
    plain = re.sub(r"\[/?[A-Z]+[^\]]*\]", "", text or "")
    return sum(max(1, (len(l) + width - 1) // width) for l in plain.split("\n"))


class Scroller(object):
    """Where the reader is, one line at a time, so no line is skipped between pages."""
    SLOWEST, FASTEST, STEP = 8.0, 1.0, 0.5

    def __init__(self, lines, rows=ROWS, delay=3.5, hold=5.0, now=0.0):
        self.last = max(0, lines - rows)
        self.pos = 0
        self.delay = delay
        self.playing = self.last > 0
        self.due = now + hold

    def tick(self, now):
        """True if it moved on a line."""
        if not self.playing or now < self.due:
            return False
        if self.pos >= self.last:
            self.playing = False
            return False
        self.pos += 1
        self.due = now + self.delay
        return True

    def move(self, lines, now):
        """Arrow keys: go by hand. Moving by hand pauses the scrolling."""
        self.playing = False
        self.pos = min(self.last, max(0, self.pos + lines))

    def toggle(self, now):
        self.playing = not self.playing and self.pos < self.last
        self.due = now + 1.0

    def slower(self):
        self.delay = min(self.SLOWEST, self.delay + self.STEP)

    def faster(self):
        self.delay = max(self.FASTEST, self.delay - self.STEP)

    def hint(self):
        state = "Scrolling" if self.playing else "Paused"
        return "%s, %.1f s per line.   OK: pause or play    Up/Down: move    Left/Right: slower/faster    Back: close" % (
            state, self.delay)


def show_page(title, body, buttons):
    """A full-window message. Returns the button pressed, or -1 for Back."""
    import xbmcgui

    class Page(xbmcgui.WindowDialog):
        choice = -1
        ids = []

        def onAction(self, action):
            if action.getId() in BACK:
                self.close()

        def onControl(self, control):
            cid = control.getId()
            if cid in self.ids:
                self.choice = self.ids.index(cid)
                self.close()

    win = Page()
    win.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, MEDIA + "panel.png"))
    win.addControl(xbmcgui.ControlImage(1140, 24, 80, 80, MEDIA + "logo.png"))
    win.addControl(xbmcgui.ControlLabel(60, 40, 1060, 44, "[B]%s[/B]" % title, font="font13", textColor="FF2EC4B6"))
    box = xbmcgui.ControlTextBox(60, 116, 1160, 484, font="font13", textColor="FFFFFFFF")
    win.addControl(box)
    box.setText(body)
    width = 300
    x = 60
    made = []
    for label in buttons:
        b = xbmcgui.ControlButton(x, 620, width, 60, label, focusTexture=MEDIA + "focus.png",
                                  noFocusTexture=MEDIA + "button.png", alignment=6, font="font13",
                                  textColor="FFFFFFFF", focusedColor="FF0F1A24")
        win.addControl(b)
        made.append(b)
        x += width + 30
    for i, b in enumerate(made):
        b.setNavigation(b, b, made[i - 1], made[(i + 1) % len(made)])
    win.ids = [b.getId() for b in made]
    win.setFocus(made[-1])
    win.doModal()
    choice = win.choice
    del win
    return choice


CHIP_COLUMNS, CHIP_ROWS = 5, 8
CHIP_W, CHIP_H, CHIP_GAP_X, CHIP_GAP_Y = 228, 50, 6, 8


class GenreGrid(object):
    """Which genres are on and which page shows. names: in display order. kinds: {name: "both", "discogs",
    "lastfm" or "none"}. picks stay in the order they were turned on, because the first genre leads the tag."""

    def __init__(self, names, kinds, picks, per_page=CHIP_COLUMNS * CHIP_ROWS):
        self.names = list(names)
        self.kinds = kinds
        self.picks = [p for p in picks if p in self.names]
        self.per_page = per_page
        self.page = 0

    @property
    def pages(self):
        return max(1, (len(self.names) + self.per_page - 1) // self.per_page)

    def shown(self):
        start = self.page * self.per_page
        return self.names[start:start + self.per_page]

    def toggle(self, name):
        if name in self.picks:
            self.picks.remove(name)
        else:
            self.picks.append(name)

    def turn(self, by):
        self.page = max(0, min(self.pages - 1, self.page + by))

    def image(self, name):
        return "chip_%s_%s.png" % (self.kinds.get(name, "none"), "on" if name in self.picks else "off")


def pick_genres(title, subtitle, names, kinds, picks, one_track=True):
    """The genre screen in Sortovia's look (2.0.11), the old window if it can't be built.
    Returns (what happened, genres on): "save", "skip", "track" or "stop" (Back)."""
    try:
        import shell
        grid = GenreGrid(names, kinds, picks)

        def build():
            page = shell.genre_page(title, subtitle, grid.shown(), kinds, grid.picks, grid.page, grid.pages, one_track)
            page.want, st["focus"] = st["focus"], None
            return page

        def react(ev, page):
            kind, key = ev[0], ev[1] if len(ev) > 1 else None
            if kind == "back":
                return ("done", "stop")
            if kind == "scroll":
                grid.turn(1 if ev[2] > 0 else -1)
                return None
            if kind == "click" and key and key.startswith("c:"):
                shown = grid.shown()
                if int(key[2:]) < len(shown):
                    grid.toggle(shown[int(key[2:])])
                    st["focus"] = key
            elif kind == "click" and key in ("b:prev", "b:next"):
                grid.turn(-1 if key == "b:prev" else 1)
                st["focus"] = key
            elif kind == "click" and key in ("b:track", "b:skip", "b:save"):
                return ("done", key[2:])
            return None
        st = {"focus": None}
        outcome = _run(build, react)
        return (outcome or "stop"), list(grid.picks)
    except Exception:
        return _pick_genres_classic(title, subtitle, names, kinds, picks, one_track)


def _pick_genres_classic(title, subtitle, names, kinds, picks, one_track=True):
    """The old genre window (the fallback)."""
    import xbmcgui

    grid = GenreGrid(names, kinds, picks)

    class Screen(xbmcgui.WindowDialog):
        outcome = "stop"
        slots = {}
        actions = {}

        def onAction(self, action):
            a = action.getId()
            if a in BACK:
                self.close()
            elif a in (PAGE_UP, PAGE_DOWN):
                self.flip(-1 if a == PAGE_UP else 1)

        def onControl(self, control):
            cid = control.getId()
            if cid in self.slots:
                shown = grid.shown()
                if self.slots[cid] < len(shown):
                    grid.toggle(shown[self.slots[cid]])
                    self.draw()
            elif cid in self.actions:
                what = self.actions[cid]
                if what in ("prev", "next"):
                    self.flip(-1 if what == "prev" else 1)
                else:
                    self.outcome = what
                    self.close()

        def flip(self, by):
            grid.turn(by)
            self.draw()

        def draw(self):
            shown = grid.shown()
            for i, (image, button) in enumerate(self.chips):
                visible = i < len(shown)
                image.setVisible(visible)
                button.setVisible(visible)
                if visible:
                    image.setImage(MEDIA + grid.image(shown[i]), False)
                    button.setLabel(shown[i])
            self.counter.setLabel("%d on    Page %d of %d" % (len(grid.picks), grid.page + 1, grid.pages))

    win = Screen()
    win.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, MEDIA + "panel.png"))
    win.addControl(xbmcgui.ControlLabel(58, 18, 900, 40, "[B]%s[/B]" % title, font="font13", textColor="FF2EC4B6"))
    win.addControl(xbmcgui.ControlLabel(58, 54, 900, 30, subtitle, font="font12", textColor="FFD0D6DE"))
    win.counter = xbmcgui.ControlLabel(960, 18, 262, 40, "", font="font12", textColor="FFFFFFFF", alignment=1)
    win.addControl(win.counter)
    x = 58
    for image, label, width in (("chip_discogs_on.png", "Releases: Discogs, Apple Music, Deezer", 330),
                                ("chip_lastfm_on.png", "Tags: Last.fm, Audius", 200),
                                ("chip_both_on.png", "Both", 70), ("chip_none_off.png", "Not found: off", 150)):
        win.addControl(xbmcgui.ControlImage(x, 94, 34, 20, MEDIA + image))
        win.addControl(xbmcgui.ControlLabel(x + 42, 88, width, 30, label, font="font12", textColor="FFFFFFFF"))
        x += 42 + width
    win.chips = []
    buttons = []
    for i in range(CHIP_COLUMNS * CHIP_ROWS):
        cx = 58 + (i % CHIP_COLUMNS) * (CHIP_W + CHIP_GAP_X)
        cy = 124 + (i // CHIP_COLUMNS) * (CHIP_H + CHIP_GAP_Y)
        image = xbmcgui.ControlImage(cx, cy, CHIP_W, CHIP_H, MEDIA + "chip_none_off.png")
        button = xbmcgui.ControlButton(cx, cy, CHIP_W, CHIP_H, "", focusTexture=MEDIA + "chip_focus.png",
                                       noFocusTexture=MEDIA + "chip_clear.png", alignment=6, font="font12",
                                       textColor="FFFFFFFF", focusedColor="FFFFFFFF")
        win.addControl(image)
        win.addControl(button)
        win.chips.append((image, button))
        buttons.append(button)
    labels = [("Previous page", "prev"), ("Next page", "next")]
    if one_track:
        labels.append(("Change one track", "track"))
    labels += [("Skip", "skip"), ("Save", "save")]
    width = (1164 - 10 * (len(labels) - 1)) // len(labels)
    bar = []
    for n, (label, what) in enumerate(labels):
        b = xbmcgui.ControlButton(58 + n * (width + 10), 648, width, 52, label, focusTexture=MEDIA + "focus.png",
                                  noFocusTexture=MEDIA + "button.png", alignment=6, font="font12",
                                  textColor="FFFFFFFF", focusedColor="FF0F1A24")
        win.addControl(b)
        bar.append((b, what))
    bar_buttons = [b for b, _ in bar]
    for i, b in enumerate(buttons):
        column, row = i % CHIP_COLUMNS, i // CHIP_COLUMNS
        up = buttons[i - CHIP_COLUMNS] if row else bar_buttons[-1]
        down = buttons[i + CHIP_COLUMNS] if row < CHIP_ROWS - 1 else bar_buttons[-1]
        left = buttons[i - 1] if column else buttons[i + CHIP_COLUMNS - 1]
        right = buttons[i + 1] if column < CHIP_COLUMNS - 1 else buttons[i - CHIP_COLUMNS + 1]
        b.setNavigation(up, down, left, right)
    for n, b in enumerate(bar_buttons):
        b.setNavigation(buttons[0], buttons[0], bar_buttons[n - 1], bar_buttons[(n + 1) % len(bar_buttons)])
    win.slots = dict((b.getId(), i) for i, b in enumerate(buttons))
    win.actions = dict((b.getId(), what) for b, what in bar)
    win.draw()
    win.setFocus(buttons[0])
    win.doModal()
    outcome = win.outcome
    del win
    return outcome, list(grid.picks)


def read_text(title, text):
    """Show text in the reader until Back is pressed."""
    import time
    import xbmc
    import xbmcgui

    state = Scroller(line_count(text), now=time.time())

    class Reader(xbmcgui.WindowDialog):
        closed = False

        def onAction(self, action):
            a, now = action.getId(), time.time()
            if a in BACK:
                self.closed = True
            elif a in (SELECT, PAUSE, PLAY):
                state.toggle(now)
            elif a == UP:
                state.move(-1, now)
            elif a == DOWN:
                state.move(1, now)
            elif a == PAGE_UP:
                state.move(-(ROWS - 2), now)
            elif a == PAGE_DOWN:
                state.move(ROWS - 2, now)
            elif a == LEFT:
                state.slower()
            elif a == RIGHT:
                state.faster()

    win = Reader()
    win.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, MEDIA + "panel.png"))
    win.addControl(xbmcgui.ControlLabel(40, 18, 1200, 40, "[B]%s[/B]" % title, font="font13", textColor="FF2EC4B6"))
    box = xbmcgui.ControlTextBox(40, 66, 1200, 600, font="font13", textColor="FFFFFFFF")
    win.addControl(box)
    box.setText(text)
    hint = xbmcgui.ControlLabel(40, 676, 1200, 34, state.hint(), font="font12", textColor="FFA9BAC0")
    win.addControl(hint)
    monitor = xbmc.Monitor()
    win.show()
    try:
        shown_pos, shown_hint = 0, state.hint()
        while not win.closed and not monitor.abortRequested():
            state.tick(time.time())
            if state.pos != shown_pos:
                shown_pos = state.pos
                box.scroll(shown_pos)
            if state.hint() != shown_hint:
                shown_hint = state.hint()
                hint.setLabel(shown_hint)
            if monitor.waitForAbort(0.1):
                break
    finally:
        win.close()
        del win


def text_window(title, body, buttons):
    """Long text in Sortovia's look: returns the button chosen, or -1 for Back. 2.0.10."""
    import shell
    lines = shell.text_lines(body)
    st = {"offset": 0}

    def react(ev, page):
        if ev[0] == "back":
            return ("done", -1)
        if ev[0] == "scroll":
            n = shell.TEXT_LINES
            st["offset"] = max(0, min(st["offset"] + (n if ev[2] > 0 else -n), max(0, len(lines) - n)))
            return None
        if ev[0] == "click" and (ev[1] or "").startswith("b:"):
            return ("done", int(ev[1][2:]))
        return None
    return _run(lambda: shell.text_page(title, lines, st["offset"], buttons), react)


def _labels(item):
    """(label, label2) of a select() entry: a string or a ListItem."""
    if isinstance(item, (list, tuple)):
        return item[0], item[1] if len(item) > 1 else ""
    if hasattr(item, "getLabel"):
        try:
            return item.getLabel(), item.getLabel2()
        except Exception:
            return item.getLabel(), ""
    return "%s" % item, ""


def _run(build, react):
    """Shows shell pages until react(event) returns ("done", value). build() makes the page each time."""
    import shell
    win = shell.open_window()
    try:
        while True:
            page = build()
            win.show(page, getattr(page, "want", None))
            ev = win.wait()
            if ev[0] == "quit":
                # 2.1.0: a video started (or Kodi is closing) while this was up: answered like Back, and the
                # main window gets the quit too, so it closes off the video
                try:
                    if shell.MAIN and win is not shell.MAIN[0]:
                        shell.MAIN[0].events.append(ev)
                except Exception:
                    pass
                done = react(("back", None), page)
                return done[1] if done is not None else None
            done = react(ev, page)
            if done is not None:
                return done[1]
    finally:
        win.close()


def _fell_back(what):
    """2.1.0: a page that failed falls back to Kodi's own box; the log says why (it was silent)."""
    try:
        import traceback
        import xbmc
        xbmc.log("[Sortovia] %s in the new look failed, Kodi's own box instead: %s" % (what, traceback.format_exc()),
                 xbmc.LOGWARNING)
    except Exception:
        pass


class Friendly(object):
    """Kodi's dialog in Sortovia's look (2.0.10): OK and yes/no boxes, pick lists (one or several) are pages
    like the rest of the window. Kodi's own box is the fallback, and the keyboard stays Kodi's."""
    def __init__(self, dlg):
        self.dlg = dlg

    def __getattr__(self, name):
        return getattr(self.dlg, name)

    def _box(self, heading, message, buttons):
        import shell
        if not shell.message_fits(message):
            try:
                return text_window(heading, message, buttons)
            except Exception:
                return show_page(heading, message, buttons)
        return _run(lambda: shell.message_page(heading, message, buttons),
                    lambda ev, page: ("done", int(ev[1][2:])) if ev[0] == "click" and (ev[1] or "").startswith("b:")
                    else ("done", -1) if ev[0] == "back" else None)

    def ok(self, heading, message):
        try:
            self._box(heading, message, ["OK"])
            return True
        except Exception:
            _fell_back('ok')
            return self.dlg.ok(heading, message)

    def yesno(self, heading, message, nolabel="No", yeslabel="Yes", **kw):
        try:
            return self._box(heading, message, [nolabel, yeslabel]) == 1
        except Exception:
            _fell_back('yesno')
            return self.dlg.yesno(heading, message, nolabel=nolabel, yeslabel=yeslabel, **kw)

    def _pick(self, heading, items, multi, preselect):
        import shell
        rows = [_labels(x) for x in items]
        st = {"offset": 0, "ticked": set(preselect or []) if multi else None, "focus": None}
        if not multi and isinstance(preselect, int) and preselect > 0:
            st["offset"] = preselect // shell.PICK_SLOTS * shell.PICK_SLOTS
            st["focus"] = "p:%d" % (preselect % shell.PICK_SLOTS)

        def build():
            page = shell.pick_page(heading, rows, st["offset"], st["ticked"])
            page.want, st["focus"] = st["focus"], None
            return page

        def react(ev, page):
            kind, key = ev[0], ev[1] if len(ev) > 1 else None
            if kind == "back" or key == "b:cancel" and kind == "click":
                return ("done", None if multi else -1)
            if kind == "scroll":
                n = shell.PICK_SLOTS
                st["offset"] = max(0, min(st["offset"] + ev[2], len(rows) - n))
                st["focus"] = ev[1] if abs(ev[2]) == 1 else "p:0" if ev[2] > 0 else "p:%d" % (n - 1)
                return None
            if kind == "click" and key == "b:done":
                return ("done", sorted(st["ticked"]))
            if kind == "click" and key and key.startswith("p:"):
                i = st["offset"] + int(key.split(":")[1])
                if not multi:
                    return ("done", i)
                st["ticked"].symmetric_difference_update([i])
                st["focus"] = key
            return None
        return _run(build, react)

    def select(self, heading, items, *a, **kw):
        try:
            return self._pick(heading, list(items), False, kw.get("preselect", -1))
        except Exception:
            _fell_back('select')
            return self.dlg.select(heading, items, *a, **kw)

    def multiselect(self, heading, items, *a, **kw):
        try:
            return self._pick(heading, list(items), True, kw.get("preselect") or [])
        except Exception:
            _fell_back('multiselect')
            return self.dlg.multiselect(heading, items, *a, **kw)

    def welcome(self, heading, intro, examples, notes, button="Get started"):
        """The welcome page (logo, title, example folders, a big button). Returns True when it was shown."""
        try:
            import shell
            _run(lambda: shell.welcome_page(heading, intro, examples, notes, button),
                 lambda ev, page: ("done", 0) if ev[0] in ("click", "back") else None)
            return True
        except Exception:
            return False

    def textviewer(self, heading, text, *a, **k):
        try:
            text_window(heading, text, ["Close"])
            return
        except Exception:
            pass
        try:
            return read_text(heading, text)
        except Exception:
            _fell_back('textviewer')
            return self.dlg.textviewer(heading, text, *a, **k)


class Progress(object):
    """Kodi's DialogProgress (create / update / iscanceled / close) in Sortovia's look (2.0.10). Cancel or B
    cancels. If the page can't be made, Kodi's own box does the job."""
    EVERY = 0.25  # seconds between redraws: a copy updates many times a second

    def __init__(self):
        self.win, self.kodi, self.cancelled = None, None, False
        self.state, self.drawn = {"heading": "", "message": "", "pct": 0}, 0.0

    def create(self, heading, message=""):
        self.state.update(heading=heading, message=message or "")
        try:
            import shell
            self.win = shell.open_window()
            self._draw(force=True)
        except Exception:
            import xbmcgui
            self.win = None
            self.kodi = xbmcgui.DialogProgress()
            self.kodi.create(heading, message or "")

    def _draw(self, force=False):
        import time
        import shell
        now = time.time()
        if not force and now - self.drawn < self.EVERY:
            return
        self.drawn = now
        st = self.state
        self.win.show(shell.progress_page(st["heading"], st["message"], st["pct"]))

    def update(self, percent, message=None, *a):
        if self.kodi:
            return self.kodi.update(percent, message) if message is not None else self.kodi.update(percent)
        self.state["pct"] = percent
        if message is not None:
            self.state["message"] = message
        try:
            self._draw()
        except Exception:
            pass

    def iscanceled(self):
        if self.kodi:
            return self.kodi.iscanceled()
        if self.win is not None and not self.cancelled:
            try:
                import xbmc
                xbmc.Monitor().waitForAbort(0.001)  # lets the button presses arrive
            except Exception:
                pass
            for ev in self.win.events:
                if ev[0] == "back" or ev[0] == "click" and ev[1] == "b:cancel":
                    self.cancelled = True
            del self.win.events[:]
        return self.cancelled

    def close(self):
        if self.kodi:
            return self.kodi.close()
        if self.win is not None:
            try:
                self.win.close()
            except Exception:
                pass
            self.win = None
