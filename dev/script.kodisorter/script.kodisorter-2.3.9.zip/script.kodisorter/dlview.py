"""Every download as one row of the 2.0 Downloads list and Home's "Downloading now": torrents on the phone (aria2),
BiglyBT, Real-Debrid files (on the phone or here) and YouTube videos on the phone. Pure: no Kodi imports.

An entry is (src, job): src is "phone", "bt", "box" (Real-Debrid on this device) or "yt".
"""
import re

import dlqueue

FILTERS = [("all", "All"), ("active", "Downloading"), ("waiting", "Waiting"), ("done", "Finished"),
           ("failed", "Failed")]
FIVE = {dlqueue.ACTIVE: "active", dlqueue.PEERS: "waiting", dlqueue.QUEUED: "waiting", dlqueue.PAUSED: "waiting",
        dlqueue.DONE: "done", dlqueue.FAILED: "failed", dlqueue.GAVE_UP: "failed"}
GOOD, BAD, MUTE = "FF4CD07D", "FFE5534B", "FF93A3AF"


def group_of(e):
    """The detailed group (dlqueue's). src "lib" (2.1.0): something moved to the library lately, listed under
    Finished as In your library."""
    src, j = e
    if src == "lib":
        return dlqueue.DONE
    if src in ("phone", "bt"):
        return dlqueue.tor_group(j)
    if src == "yt":
        return dlqueue.yt_group(j)
    return dlqueue.box_group(j)


def filter_of(e):
    """all / active / waiting / done / failed: the five buttons."""
    return FIVE.get(group_of(e), "waiting")


def counts(entries):
    out = dict((k, 0) for k, _ in FILTERS)
    out["all"] = len(entries)
    for e in entries:
        out[filter_of(e)] += 1
    return out


def ordered(entries, shown="all"):
    """Downloading first, then waiting, failed, finished."""
    rank = {"active": 0, "waiting": 1, "failed": 2, "done": 3}
    keep = [e for e in entries if shown == "all" or filter_of(e) == shown]
    return sorted(keep, key=lambda e: rank.get(filter_of(e), 1))


def size_text(n):
    n = float(n or 0)
    if n <= 0:
        return ""
    for unit, k in (("GB", 1e9), ("MB", 1e6), ("KB", 1e3)):
        if n >= k:
            return ("%.1f %s" % (n / k, unit)).replace(".0 ", " ")
    return "%d B" % n


def speed_bytes(e):
    """Bytes a second, from whichever form the source gives (a number, or yt-dlp's "1.2MiB/s")."""
    src, j = e
    v = j.get("speed")
    if isinstance(v, (int, float)):
        return float(v)
    m = re.match(r"\s*([\d.]+)\s*([KMG]?)i?B/s", v or "")
    if not m:
        return 0.0
    return float(m.group(1)) * {"": 1, "K": 1024, "M": 1024 ** 2, "G": 1024 ** 3}[m.group(2)]


def speed_text(bps):
    return "%.1f MB/s" % (bps / 1e6) if bps >= 1e5 else ("%d KB/s" % (bps / 1e3) if bps else "")


def eta_text(e):
    src, j = e
    eta = j.get("eta")
    if isinstance(eta, (int, float)) and eta > 0:
        return "%d min" % max(1, int(eta) // 60) if eta < 3600 else "%d h %d min" % (eta // 3600, eta % 3600 // 60)
    return eta if isinstance(eta, str) else ""


def name_of(e):
    src, j = e
    name = j.get("title") if src == "yt" else j.get("name")
    if not name and src == "yt" and j.get("file"):  # 2.2.3: the file's name before the link
        name = re.sub(r"\.\w{2,4}$", "", str(j["file"]).replace("\\", "/").rsplit("/", 1)[-1])
    name = (name or j.get("url") or "?")
    if name.startswith("[METADATA]"):
        name = name[len("[METADATA]"):].replace("+", " ")
    return name


def tag_of(e):
    src, j = e
    if src == "yt":
        return "YOUTUBE"
    if src == "bt":
        return "BIGLYBT"
    if src == "lib":
        return "MOVED"
    if src == "box" or j.get("kind") == "Real-Debrid":
        return "REAL-DEBRID"
    return "PHONE"


def frac_of(e):
    src, j = e
    if src == "box":
        size, got = j.get("size") or 0, j.get("got") or 0
        return float(got) / size if size else 0.0
    if group_of(e) == dlqueue.DONE:
        return 1.0
    return float(j.get("pct") or 0) / 100.0


def where_of(e):
    src, j = e
    return {"phone": "phone torrent" if tag_of(e) == "PHONE" else "on the phone", "bt": "BiglyBT",
            "box": "on this device", "yt": "on the phone", "lib": j.get("kind") or "library"}[src]


def row(e, moved=False):
    """{"name", "tag", "info", "frac", "state", "state_color", "right"} for shell.dl_row."""
    src, j = e
    g, five = group_of(e), filter_of(e)
    size = size_text(j.get("size") or j.get("total"))
    first = j.get("quality") if src == "yt" and j.get("quality") else size
    info = "  ·  ".join(x for x in (first, where_of(e)) if x)
    out = {"name": name_of(e), "tag": tag_of(e), "frac": frac_of(e), "state": "", "state_color": None, "right": ""}
    if five == "active":
        out["right"] = "  ·  ".join(x for x in (speed_text(speed_bytes(e)), eta_text(e)) if x)
    elif five == "done":
        moved = moved or src == "lib" or j.get("gone")
        out.update(state="Done", state_color=GOOD, right="In your library" if moved else "Not moved yet")
        if moved and src != "yt":
            info = "  ·  ".join(x for x in (size, "moved to your library") if x)
    elif five == "failed":
        why = (j.get("error") or ("no peers" if g == dlqueue.GAVE_UP else "")).strip()
        out.update(state="Failed", state_color=BAD, right="Select to retry")
        if why:
            info = "  ·  ".join(x for x in (size, why[:48]) if x)
    else:
        if g == dlqueue.PAUSED:
            out.update(state="Paused", state_color=MUTE, right="Select to resume")
        elif g == dlqueue.PEERS:
            out.update(state="Waiting", state_color=MUTE, right="No peers yet")
        else:
            out.update(state="Queued", state_color=MUTE, right="Waits its turn")
    if j.get("stale"):  # 2.0.8: BiglyBT stopped answering; this is its last list
        out["right"] = "BiglyBT not answering"
    out["info"] = info
    return out


def summary(entries):
    """(how many downloading, "4.1 MB/s")"""
    active = [e for e in entries if filter_of(e) == "active"]
    return len(active), speed_text(sum(speed_bytes(e) for e in active))


def badge(entries):
    """2.2.3: the side bar's Downloads number: downloading or waiting their turn (one just added waits first, so
    the number didn't change when a download was added)."""
    return sum(1 for e in entries if filter_of(e) in ("active", "waiting"))


def home_entries(entries, n=4):
    """The downloads on Home's top rows: downloading first, then waiting (finished and failed ones stay on
    Downloads)."""
    return [e for e in ordered(entries) if filter_of(e) in ("active", "waiting")][:n]


def home_rows(entries, n=4):
    return [row(e) for e in home_entries(entries, n)]


# ---------- 2.1.0: what can be done to a download, the same words for every kind ----------
TORRENT_CAPS = {  # what each place can do (torclients.CAPS has the full table for each client)
    "phone": {"pause", "resume", "start_now", "queue_top", "queue_up", "queue_down", "queue_bottom",
              "limit_item", "files", "peers", "remove_keep", "remove_delete"},
    "bt": {"pause", "resume", "start_now", "queue_top", "queue_up", "queue_down", "queue_bottom", "recheck", "in_order",
           "limit_item", "files", "peers", "trackers", "reannounce", "remove_keep", "remove_delete"},
    "yt": {"pause", "resume", "remove_keep", "remove_delete"},  # (no Start now: the helper has no queue order)
}
LABELS = {
    "move": "Move it to the library now",
    "pause": "Pause",
    "resume": "Resume",
    "start_now": "Start now (ahead of the queue)",
    "retry": "Try again",
    "queue_top": "Move to the top of the queue",
    "queue_up": "Move up one",
    "queue_down": "Move down one",
    "queue_bottom": "Move to the bottom of the queue",
    "limit_item": "Speed limit for this one",
    "files": "Choose which files to download",
    "details": "Show details",
    "recheck": "Check the files again",
    "in_order": "Download in order (episode 1 first)",
    "reannounce": "Look for more sources",
    "error": "Show the whole error",
    "remove_keep": "Remove from the list (keep the files)",
    "remove_delete": "Remove from the list and delete the files",
}


def is_torrent(e):
    src, j = e
    return src == "bt" or src == "phone" and j.get("kind") != "Real-Debrid"


def actions(e, moved=False, caps=None):
    """[(action, label)] for one download, in the order a menu shows them. Every state has both ways off the
    list; nothing offers Stop or Pause to a download that isn't running, or Pause to one that's only queued."""
    src, j = e
    if src == "lib":
        return [("details", LABELS["details"]), ("remove_keep", "Take it off this list (it stays in your library)")]
    caps = TORRENT_CAPS.get(src, set()) if caps is None else caps
    g, f = group_of(e), filter_of(e)
    out = ["details"]  # 2.1.2: first on every download's menu: everything known about it

    def add(a):
        if a in ("move", "retry", "error", "details") or a in caps:
            out.append(a)
    if f == "done":
        if not moved and not j.get("gone"):
            add("move")
    elif f == "failed":
        if not j.get("damaged"):  # an archive that can't be opened: only off the list (and download it again)
            add("retry")
        if j.get("error"):
            add("error")
    elif f == "active":
        add("pause")
        if is_torrent(e):
            for a in ("limit_item", "files", "recheck", "reannounce"):
                add(a)
    elif g == dlqueue.PEERS:  # running, but nobody to download from yet: it can be paused, not started
        add("pause")
        for a in ("queue_top", "queue_bottom"):  # 2.3.3 (ticket mujr): it can still be moved in the queue
            add(a)
        if is_torrent(e):
            for a in ("reannounce", "files"):
                add(a)
    else:  # waiting: queued or paused
        add("resume" if g == dlqueue.PAUSED else "start_now")
        if src == "yt" and g != dlqueue.PAUSED:
            add("pause")
        for a in ("queue_top", "queue_up", "queue_down", "queue_bottom"):
            add(a)
        if is_torrent(e):
            for a in ("files",):
                add(a)
    if f not in ("done", "failed") and src == "bt":
        add("in_order")
    out += ["remove_keep", "remove_delete"]
    paused = f not in ("done", "failed", "active") and g == dlqueue.PAUSED
    def label(a):
        if a == "queue_top" and paused:
            return "Resume, at the top of the queue"
        if a == "in_order":
            return "Download in order (episode 1 first): %s" % ("on - turn off" if j.get("in_order") else "off - turn on")
        return LABELS[a]
    return [(a, label(a)) for a in out]


def common_actions(entries, moved_of=lambda e: False):
    """What a menu for several ticked downloads offers: what fits each of them (in order), with Move for the
    finished ones and both ways off the list for all."""
    if not entries:
        return []
    each = [[a for a, _ in actions(e, moved_of(e))] for e in entries]
    out = []
    for a in ("move", "resume", "start_now", "pause", "retry", "queue_top", "queue_bottom"):
        if any(a in x for x in each):
            out.append(a)
    return out + ["remove_keep", "remove_delete"]


def failed(entries):
    return [e for e in entries if filter_of(e) == "failed"]
