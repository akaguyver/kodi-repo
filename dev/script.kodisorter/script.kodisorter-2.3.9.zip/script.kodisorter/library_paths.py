"""2.3.9 (ticket xgkc): one spelling per folder in Kodi's video library, and Movies set to the Movies folder only.

Kodi on the Xbox saved many folders twice: win-lib://removable/D:/TV/Show/ and win-lib://removable/D:\\\\TV\\Show\\.
The second spelling came from the Movies source being the whole drive (win-lib://removable/): Kodi's movie scan went
through every folder on it, TV and Music Videos too, and left file entries with no movie or episode on them. The
movies and episodes Kodi shows use the / spelling (newer scans) or, for a few old movies, the \\ one.

tidy(conn, movies_folder) on an open MyVideos database:
- every folder spelled with \\ (not a library source itself) is merged into its / spelling: movies, episodes and music
  videos are moved over (their file path and path id columns too), watched marks and resume points on a leftover
  copy are kept on the real one, leftover file entries go (Kodi's delete_file trigger takes their stream details,
  bookmarks and settings), and the \\ folder entry goes once nothing uses it;
- the Movies setting moves from the whole drive to the Movies folder, spelled like the TV source (D:/TV\\ ->
  D:/Movies\\), so Kodi stops filing TV, Music Videos and Tutorials as movies.
Returns a dict of counts. Never touches files on the drive.
"""
import re

ROOT = "win-lib://removable/"
MEDIA = (("movie", "idMovie", "c22", "c23"), ("episode", "idEpisode", "c18", "c19"),
         ("musicvideo", "idMVideo", "c13", "c14"))


def forward(path):
    """win-lib://removable/D:\\\\TV\\Show\\ -> win-lib://removable/D:/TV/Show/ (None for other paths)."""
    if not path or not path.startswith(ROOT):
        return None
    rest = re.sub(r"[\\/]+", "/", path[len(ROOT):])
    return ROOT + rest.rstrip("/") + "/" if rest.strip("/") else ROOT


def _parent(path):
    p = path.rstrip("/")
    return p[:p.rfind("/") + 1] if "/" in p[len(ROOT):] else ROOT


def _media_of(conn, id_file):
    """[(table, idcol, filecol, pathcol, id)] of library items on a file entry."""
    out = []
    for table, idcol, fcol, pcol in MEDIA:
        for (i,) in conn.execute("SELECT %s FROM %s WHERE idFile=?" % (idcol, table), (id_file,)):
            out.append((table, idcol, fcol, pcol, i))
    return out


def _path_id(conn, path, like_row=None, made=None):
    row = conn.execute("SELECT idPath FROM path WHERE strPath=?", (path,)).fetchone()
    if row:
        return row[0]
    parent = conn.execute("SELECT idPath FROM path WHERE strPath=?", (_parent(path),)).fetchone()
    hash_, added = (like_row or (None, None))
    cur = conn.execute("INSERT INTO path (strPath, strContent, strScraper, strHash, scanRecursive, useFolderNames, "
                       "strSettings, noUpdate, exclude, allAudio, dateAdded, idParentPath) "
                       "VALUES (?, '', '', ?, 0, 0, '', 0, 0, 0, ?, ?)",
                       (path, hash_, added, parent[0] if parent else None))
    if made is not None:
        made.append(path)
    return cur.lastrowid


def _keep_marks(conn, src, dst):
    """Watched mark, last played and resume point of file entry src kept on dst (when dst has none)."""
    a = conn.execute("SELECT playCount, lastPlayed FROM files WHERE idFile=?", (src,)).fetchone()
    b = conn.execute("SELECT playCount, lastPlayed FROM files WHERE idFile=?", (dst,)).fetchone()
    if a and b and (a[0] or 0) > (b[0] or 0):
        conn.execute("UPDATE files SET playCount=?, lastPlayed=COALESCE(?, lastPlayed) WHERE idFile=?",
                     (a[0], a[1], dst))
    if not conn.execute("SELECT 1 FROM bookmark WHERE idFile=? AND type=1", (dst,)).fetchone():
        conn.execute("UPDATE bookmark SET idFile=? WHERE idFile=? AND type=1", (dst, src))


def merge_spellings(conn):
    """Folders spelled with \\ merged into their / spelling (see the module doc). Returns counts."""
    n = {"folders": 0, "moved": 0, "leftovers": 0, "kept_marks": 0, "skipped": 0}
    rows = conn.execute("SELECT idPath, strPath, strHash, dateAdded FROM path WHERE strPath LIKE ? "
                        "AND (strContent IS NULL OR strContent='') AND COALESCE(exclude, 0)=0", (ROOT + "%",)).fetchall()
    for id_b, path_b, hash_b, added_b in sorted(rows, key=lambda r: -len(r[1])):  # deepest first
        if "\\" not in path_b[len(ROOT):]:
            continue
        canon = forward(path_b)
        id_f = None
        for id_file, name in conn.execute("SELECT idFile, strFilename FROM files WHERE idPath=?", (id_b,)).fetchall():
            media = _media_of(conn, id_file)
            if id_f is None:
                id_f = conn.execute("SELECT idPath FROM path WHERE strPath=?", (canon,)).fetchone()
                id_f = id_f[0] if id_f else None
            twin = conn.execute("SELECT idFile FROM files WHERE idPath=? AND strFilename=?",
                                (id_f, name)).fetchone() if id_f else None
            twin_media = _media_of(conn, twin[0]) if twin else []
            if not media:  # a leftover: its marks go to the real entry, then it goes
                if twin:
                    _keep_marks(conn, id_file, twin[0])
                    n["kept_marks"] += 1
                conn.execute("DELETE FROM files WHERE idFile=?", (id_file,))
                n["leftovers"] += 1
                continue
            if twin and twin_media:  # both spellings have a library item: leave it for Kodi's own clean-up
                n["skipped"] += 1
                continue
            if id_f is None:
                id_f = _path_id(conn, canon, (hash_b, added_b))
            if twin:  # the / copy is a leftover: the real entry keeps its marks and takes its place
                _keep_marks(conn, twin[0], id_file)
                conn.execute("DELETE FROM files WHERE idFile=?", (twin[0],))
            conn.execute("UPDATE files SET idPath=? WHERE idFile=?", (id_f, id_file))
            for table, idcol, fcol, pcol, i in media:
                conn.execute("UPDATE %s SET %s=?, %s=? WHERE %s=?" % (table, fcol, pcol, idcol),
                             (canon + name, str(id_f), i))
            n["moved"] += 1
        for (id_show,) in conn.execute("SELECT idShow FROM tvshowlinkpath WHERE idPath=?", (id_b,)).fetchall():
            id_f = id_f or _path_id(conn, canon, (hash_b, added_b))
            if conn.execute("SELECT 1 FROM tvshowlinkpath WHERE idShow=? AND idPath=?", (id_show, id_f)).fetchone():
                conn.execute("DELETE FROM tvshowlinkpath WHERE idShow=? AND idPath=?", (id_show, id_b))
            else:
                conn.execute("UPDATE tvshowlinkpath SET idPath=? WHERE idShow=? AND idPath=?", (id_f, id_show, id_b))
        in_use = conn.execute("SELECT 1 FROM files WHERE idPath=? UNION ALL SELECT 1 FROM tvshowlinkpath "
                              "WHERE idPath=? LIMIT 1", (id_b, id_b)).fetchone()
        if not in_use:
            conn.execute("UPDATE path SET idParentPath=NULL WHERE idParentPath=?", (id_b,))
            conn.execute("DELETE FROM path WHERE idPath=?", (id_b,))
            n["folders"] += 1
    return n


def movies_source_spelling(conn, movies_folder):
    """The Movies folder spelled like Kodi's TV source (win-lib://removable/D:/TV\\ -> .../D:/Movies\\), else the /
    spelling. movies_folder: 'D:/Movies' (drive letter, any slashes). None when it isn't on a drive letter."""
    rest = re.sub(r"[\\/]+", "/", movies_folder or "").strip("/")
    if not re.match(r"^[A-Za-z]:/.+", rest):
        return None
    drive, name = rest.split("/", 1)
    tv = conn.execute("SELECT strPath FROM path WHERE strContent='tvshows' AND strPath LIKE ?", (ROOT + "%",)).fetchone()
    m = re.match(r"^(%s[A-Za-z]:)([\\/]+)[^\\/].*?([\\/]+)$" % re.escape(ROOT), tv[0]) if tv else None
    if m:
        return ROOT + drive + m.group(2) + name.replace("/", m.group(2)[0]) + m.group(3)
    return ROOT + drive + "/" + name + "/"


def move_movies_source(conn, movies_folder):
    """The whole-drive Movies setting moved to the Movies folder. Returns the new spelling, or None when there was
    nothing to move (no whole-drive Movies setting, or the folder isn't on a drive letter)."""
    root = conn.execute("SELECT idPath, strContent, strScraper, scanRecursive, useFolderNames, strSettings, noUpdate "
                        "FROM path WHERE strPath=? AND strContent='movies'", (ROOT,)).fetchone()
    new = movies_source_spelling(conn, movies_folder) if root else None
    if not new:
        return None
    id_root, content, scraper, recursive, folder_names, settings, no_update = root
    row = conn.execute("SELECT idPath FROM path WHERE strPath=?", (new,)).fetchone()
    if row:
        conn.execute("UPDATE path SET strContent=?, strScraper=?, scanRecursive=?, useFolderNames=?, strSettings=?, "
                     "noUpdate=?, exclude=0 WHERE idPath=?",
                     (content, scraper, recursive, folder_names, settings, no_update, row[0]))
    else:
        conn.execute("INSERT INTO path (strPath, strContent, strScraper, scanRecursive, useFolderNames, strSettings, "
                     "noUpdate, exclude, allAudio) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0)",
                     (new, content, scraper, recursive, folder_names, settings, no_update))
    conn.execute("UPDATE path SET strContent='', strScraper='', strSettings='', scanRecursive=0 WHERE idPath=?",
                 (id_root,))
    return new


def sources_xml_move(text, old, new):
    """sources.xml with the video source at old pointed at new (and named Movies when it was named after the drive).
    Unchanged text when there's no such source."""
    m = re.search(r"<video>.*?</video>", text or "", re.S)
    if not m:
        return text
    block = m.group(0)

    def one(src):
        s = src.group(0)
        if not re.search(r"<path[^>]*>%s</path>" % re.escape(old), s):
            return s
        s = re.sub(r"(<path[^>]*>)%s(</path>)" % re.escape(old), lambda x: x.group(1) + new + x.group(2), s)
        return re.sub(r"<name>\s*(?:removable|[A-Za-z]:?|)\s*</name>", "<name>Movies</name>", s, flags=re.I)
    fixed = re.sub(r"<source>.*?</source>", one, block, flags=re.S)
    return text.replace(block, fixed)


def tidy(conn, movies_folder):
    """Both steps in one transaction. Returns counts (and 'movies' = the new Movies spelling or None)."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        n = merge_spellings(conn)
        n["movies"] = move_movies_source(conn, movies_folder)
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
    return n
