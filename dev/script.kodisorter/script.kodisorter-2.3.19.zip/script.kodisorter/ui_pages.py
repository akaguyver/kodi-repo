"""What's on each group page of the 2.0 window (Transfer / sort, Music, Library, Settings and the pages inside
them), as data. Pure: ctx (a dict the add-on fills in) decides labels and what's shown only sometimes.

An item is (key, icon, title, one-line description, target). target is "page:<name>" (a page of cards inside
this one) or "act:<action>" (an action of default.do_action).
"""

PARENT = {}  # sub page -> the side bar place it belongs to


def _page(name, parent):
    PARENT[name] = parent
    return name


def menu(name, ctx):
    """(title, subtitle, [items]) for a group page, or None."""
    c = ctx.get
    if name == "transfer":
        items = []
        if c("resume"):
            items.append(("resume", "refresh", "Resume the sort that didn't finish", c("resume"), "act:resume"))
        if c("last"):
            items.append(("same", "transfer", "Same as last time", c("last"), "act:same"))
        items += [
            ("new", "folder", "Choose folders and choices", "Pick where downloads are and where they go.", "act:new"),
            ("organise", "sliders", "Organise my folders", "TV, Movies, Music or Comics: tidy what's there.",
             "act:organise"),
            ("report", "report", "Report from the last move", "Every file moved or skipped, and why.", "act:report"),
            ("free", "space", "Free up space", "See what's using this device and clear leftovers.", "act:free_space")]
        return "Transfer / sort", "Move downloads into your library", items
    if name == "music":
        return "Music", "Tags, art and DJ tools", [
            ("tag_edit", "pencil", "Edit tags", "Title, artists, genre, key, tempo. MP3, FLAC, M4A.", "act:tag_edit"),
            ("genres", "list", "Find genres", "Looks up genres on Discogs, Last.fm and more.", "act:genre_dry_run"),
            ("fix", "check", "Fix music tags", "Joins split albums, links collaborations.", "act:music_tags"),
            ("phone_tags", "phone", "Get tags from the phone", "Keys, tempos, energy and genres from the app.",
             "act:phone_tags"),
            ("art", "image", "Cover and artist art", "Albums with no cover; use pictures from folders.",
             "page:" + _page("music_art", "music")),
            ("sound", "wave", "Save the sound of a video", "Makes a tagged music file from a video.",
             "act:audio_pick"),
            ("dj", "disc", "DJ and playlists", "Mixing order, what mixes next, crossfade.",
             "page:" + _page("dj", "music")),
            ("undo", "undo", "Undo the last change", "Puts back tags from before the last edit or fix.",
             "page:" + _page("music_undo", "music"))]
    if name == "music_art":
        return "Cover and artist art", "Music", [
            ("check_art", "image", "Check music art", "Albums with no cover art.", "act:music_art"),
            ("album_art", "album", "Set album art from folders", "Uses the picture in an album's folder.",
             "act:music_art_set"),
            ("artist_art", "music", "Set artist art from folders", "artist.jpg and fanart.jpg in the artist's folder.",
             "act:artist_art")]
    if name == "dj":
        return "DJ and playlists", ("Music  -  the mixing tools work best in the phone app" if c("xbox") else
                                    "Music"), [
            ("playlist", "list", "Playlist from another app", "Spotify CSV, M3U, a typed list or a Deezer link.",
             "act:playlist_convert"),
            ("order", "disc", "Play in mixing order", "Key order, build up or wind down.", "act:dj_order"),
            ("next", "music", "What mixes next", "Songs in a nearby key and a close tempo.", "act:dj_next"),
            ("crossfade", "wave", "Crossfade", "Kodi's own crossfade between songs.", "act:dj_crossfade"),
            ("keys", "refresh", "Read keys and tempos again", "After retagging with Mixed In Key.", "act:dj_forget"),
            ("phone_music", "phone", "Play this music on your phone", "The phone app plays and mixes this library.",
             "act:phone_music")]
    if name == "music_undo":
        return "Undo the last change", "Music", [
            ("undo_edit", "undo", "Undo the last tag edit", "Tags from before the last Edit tags save.",
             "act:tag_edit_undo"),
            ("undo_fix", "undo", "Undo the last music tag fix", "Old tags saved by Fix music tags.",
             "act:music_tags_undo")]
    if name == "library":
        return "Library", "What Kodi shows", [
            ("clean", "broom", "Clean the library", "Removes entries whose files are gone. Never deletes files.",
             "act:clean_library"),
            ("missing", "tv", "Find missing episodes", "Aired episodes you don't have. Saved as missing-episodes.txt.",
             "act:missing"),
            ("miss_finished", "refresh", "Missing episodes: finished shows: %s" % (
                "checked" if c("miss_finished") else "skipped"),
             "Shows that ended and you have every episode of.", "act:miss_finished"),
            ("watch", "globe", "Where to watch a show", "Your services, free, or buy and rent.", "act:wherewatch"),
            ("rescan", "album", "Rescan one album", "One album's changes, without a full scan.", "act:music_rescan"),
            ("comics", "comic", "Comics", "Convert .cbr to .cbz, turn pages for a monitor.",
             "page:" + _page("comics", "library")),
            ("nfo", "text", "View a text / NFO file", "Reads old DOS-style NFO art correctly.", "act:nfo"),
            ("maint", "wrench", "Maintenance", "Backups%s." % (", restore and the drive letter fix" if c("xbox")
                                                                else " and restore"),
             "page:" + _page("maintenance", "library"))]
    if name == "comics":
        return "Comics", "Library", [
            ("convert", "comic", "Convert .cbr to .cbz" + (" (%d left)" % c("comics_left") if c("comics_left") else ""),
             "A .cbz opens much faster in Kodi.", "act:comics_convert"),
            ("turn", "refresh", "Turn pages for a monitor on its side", "Now: %s. Try one comic first." %
             (c("turn") or "upright"), "act:comics_turn")]
    if name == "maintenance":
        items = [
            ("backup", "backup", "Back up now", "Last: %s. Also runs once a day." % (c("backup_line") or "never"),
             "act:backup"),
            ("restore", "refresh", "Restore the video library", "Pick a date; Kodi's Import puts it back.",
             "act:restore"),
            ("music_restore", "music", "Restore the music library", "A saved copy, if it looks wrong or empty.",
             "act:music_restore"),
            ("backups", "list", "List the backups", "When each was made and what was in it.", "act:backups"),
            ("remove_backups", "trash", "Remove old backups", "Frees space. The newest is always kept.",
             "act:remove_backups"),
            ("add_sources", "folder", "Add Sortovia's folders to Kodi", "Music Videos and YouTube videos, as video sources.",
             "act:add_sources")]
        if c("xbox"):
            items.append(("drive_letter", "wrench", "Drive letter changed? Fix the library",
                          "When E: became D:, so Kodi finds your files.", "act:drive_letter"))
        return "Maintenance", "Library", items
    if name == "settings":
        items = [
            ("general", "sliders", "General settings", "Updates, sorting, music, phone, privacy, movie data.",
             "page:" + _page("general", "settings")),
            ("sources", "search", "Search sources", "Indexes and categories: Jackett, Prowlarr, RSS.",
             "act:torrent_setup"),
            ("rd", "cloud", "Real-Debrid", c("rd_who") or "Account, where it downloads, new torrents.",
             "page:" + _page("rd_settings", "settings")),
            ("youtube", "play", "YouTube", "Quality, where videos go, cookies.",
             "page:" + _page("yt_settings", "settings")),
            ("look", "eye", "Look", "Text size: %s." % (c("text_size") or "normal"), "act:ui_look"),
            ("help", "help", "Help", "The guide, setup steps, version history, reports.",
             "page:" + _page("help", "settings")),
            ("update", "refresh", "Check for updates now", "Sortovia also checks every time it opens.",
             "act:update")]
        if c("dev"):
            items.append(("dev", "wrench", "Dev", "Testing tools. Not in public builds.", "act:dev_menu"))
        return "Settings", "Switches and help", items
    # 2.0.8: the add-on's own settings as pages like the rest (Kodi's settings screen is the old look).
    # A switch is "toggle:<setting id>"; ctx["set"] holds their values.
    def sw(key, ic, title, desc, sid, default=True):
        on = (c("set") or {}).get(sid, default)
        return (key, ic, "%s: %s" % (title, "on" if on else "off"), desc, "toggle:" + sid)
    if name == "general":
        return "General settings", "Settings", [
            ("g_updates", "refresh", "Updates and backup", "Update checks, daily library backup, language, device.",
             "page:" + _page("g_updates", "settings")),
            ("g_sorting", "transfer", "Sorting", "What to sort, your folders, samples, titles, comics.",
             "page:" + _page("g_sorting", "settings")),
            ("g_phone", "phone", "Phone and privacy", "Downloads from the phone, its logs, a passcode for keys.",
             "page:" + _page("g_phone", "settings")),
            ("g_data", "music", "Music and movie data", "Tag fixing, genre lists, TMDb key and services.",
             "page:" + _page("g_data", "settings")),
            ("g_search", "search", "Search and missing episodes", "0-seed results, where to watch, season packs.",
             "page:" + _page("g_search", "settings"))]
    if name == "g_search":  # 2.2.2
        return "Search and missing episodes", "General settings", [
            sw("s_dead", "search", "Hide results with 0 seeds", "Torrents nobody shares can't download.",
               "hide_dead"),
            sw("s_whereto", "tv", "Where to watch", "After the missing episodes check: which ones stream where.",
               "miss_whereto", default=False),
            sw("s_seq", "download", "Season packs in episode order", "BiglyBT, qBittorrent, Transmission: first "
               "episodes first.", "seq_packs")]  # 2.2.3
    if name == "g_updates":
        return "Updates and backup", "General settings", [
            sw("s_updates", "refresh", "Check for updates", "Every time Sortovia opens.", "check_updates"),
            sw("s_autoupd", "download", "Install updates by themselves", "No question: the new version opens "
               "next time.", "auto_update"),  # 2.2.5
            sw("s_backup", "backup", "Daily library backup", "Backs up Kodi's library once a day by itself.",
               "auto_backup"),
            ("s_language", "globe", "Your language", "For movie titles and audio checks.", "act:language"),
            ("s_device", "tv", "Your device", "Xbox, PC, phone or TV box.", "act:device")]
    if name == "g_sorting":
        return "Sorting", "General settings", [
            ("s_kinds", "check", "What to sort", "TV, movies, music, tutorials, comics.", "act:kinds"),
            ("s_folders", "folder", "My library folders", "Where each kind goes on your drive.", "act:folders"),
            sw("s_small", "space", "Skip samples", "Videos under 50 MB are left out.", "skip_small"),
            sw("s_rename", "text", "Translate titles", "Movie titles in your language.", "rename_foreign"),
            sw("s_comics", "comic", "Convert comics", "New .cbr comics become .cbz when sorted.", "convert_comics")]
    if name == "g_phone":
        return "Phone and privacy", "General settings", [
            sw("s_phone", "phone", "Phone downloads", "Sorts what the phone downloaded.", "use_phone"),
            sw("s_rdonly", "cloud", "Phone downloader: Real-Debrid only", "Torrents go to BiglyBT, so Termux can stay "
               "out of your VPN.", "phone_rd_only"),  # 2.3.0
            sw("s_logs", "report", "Logs to the phone", "Kodi's logs, into Download/SortoviaLogs.", "send_logs"),
            ("s_vault", "settings", "Passcode for saved keys", "Protects saved passwords and keys.", "act:vault")]
    if name == "g_data":
        return "Music and movie data", "General settings", [
            sw("s_context", "music", "Quick tag fixing", "Holding down an artist fixes its tags, no question.",
               "context_auto", False),
            ("s_genres", "list", "Music genres", "Discogs token, Last.fm key and your genre list.",
             "act:genre_settings"),
            ("s_tmdb", "globe", "Movie data (TMDb)", "Your TMDb key, country and streaming services.",
             "act:tmdb_settings")]
    if name == "rd_settings":
        return "Real-Debrid", "Settings", [
            ("rd_account", "cloud", c("rd_who") or "Sign in to Real-Debrid", "With a code on your phone, or a token.",
             "act:rd_account"),
            ("rd_where", "download", "Download on: %s" % (c("rd_where") or "the phone"),
             "Which device downloads what Real-Debrid unlocks.", "act:rd_where"),
            ("rd_auto", "refresh", "Download new torrents by themselves: %s" % ("on" if c("rd_auto") else "off"),
             "Anything added to your account downloads when ready.", "act:rd_auto")]
    if name == "yt_settings":
        return "YouTube", "Settings", [
            ("yt_quality", "play", "Download quality", "Up to 4K, 1080p, 720p, 480p or sound only.", "act:yt6"),
            ("yt_where", "folder", "Where sorted videos go", "The drive or folder for YouTube downloads.", "act:yt8"),
            ("yt_cookies", "help", "Cookies: how to set them up", "YouTube needs a signed-in browser's cookies.",
             "act:yt4"),
            ("yt_import", "refresh", "Import cookies now", "A new cookies.txt from the phone's Download folder.",
             "act:yt5"),
            ("yt_meta", "search", "Look up channel and upload date", "For videos already downloaded.", "act:yt9"),
            ("yt_tidy", "folder", "Tidy YouTube folders", "Lessons into Tutorials, folders with near the same name "
             "merged.", "act:yt_tidy"),
            ("yt_dates", "refresh", "Put upload dates in names", "2024-12-22 - Title.mp4, so Sort by: Name in "
             "Files goes in upload order.", "act:yt_dates"),
            ("yt_watched", "check", "Bring back watched marks", "For videos that lost their tick after being moved.",
             "act:yt_watched")]
    if name == "help":
        return "Help", "Settings", [
            ("guide", "text", "Read the guide", "Every step and feature, by topic.", "act:guide"),
            ("welcome", "home", "Welcome screen", "The first-run steps again.", "act:welcome"),
            ("sources_help", "folder", "Add your folders to Kodi", "TV, Movies, Tutorials and Comics as sources.",
             "act:sources_help"),
            ("guide_phone", "phone", "Set up your phone", "Android and iPhone: files over Wi-Fi.", "act:guide_phone"),
            ("history", "list", "Version history", "What each update added.", "act:history"),
            ("problem", "report", "Send a problem report", "Cleans Kodi's log, shows it, sends it if you agree.",
             "act:problem_report")]
    if name == "rd_lists":
        return "Real-Debrid lists", "Downloads", [
            ("rd_torrents", "cloud", "My torrents", "What's in your account. Tick files to download.",
             "act:rd_torrents"),
            ("rd_releases", "list", "My releases (feeds)", "Releases from the feeds you added.", "act:rd_releases"),
            ("rd_feeds", "link", "Add or remove a feed", "The RSS address of your uploads on a site.",
             "act:rd_feeds"),
            ("rd_history", "refresh", "Recent downloads", "Files you unlocked before, on any device.",
             "act:rd_history"),
            ("rd_failed", "trash", "Couldn't get on Real-Debrid (%d)" % (c("rd_failed") or 0),
             "Download these on the phone or another client.", "act:rd_failed")]
    return None


for _n in ("rd_lists",):
    PARENT[_n] = "downloads"
menu("music", {})
menu("library", {})
menu("settings", {})


def side_place(name):
    """The side bar place a page lights up."""
    return PARENT.get(name, name)


def cards(name, ctx):
    """[(key, icon, title, description, opens_more)] and the targets, for shell.cards_page."""
    got = menu(name, ctx)
    if not got:
        return None
    title, sub, items = got
    return title, sub, [(k, ic, t, d, tg.startswith("page:")) for k, ic, t, d, tg in items], \
        dict((k, tg) for k, ic, t, d, tg in items)
