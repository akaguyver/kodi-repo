"""Full-window pages and a guide reader that scrolls slowly, one line at a time.

Kodi's own dialogs are small and page through text. These windows are built from Kodi's
standard controls, and anything that goes wrong falls back to Kodi's own dialog.
"""
import re

MEDIA = "special://home/addons/script.kodisorter/resources/media/"
LONG = 110          # messages longer than this get the full window
BACK = (9, 10, 13, 92)
LEFT, RIGHT, UP, DOWN, PAGE_UP, PAGE_DOWN = 1, 2, 3, 4, 5, 6
SELECT, PAUSE, PLAY = 7, 12, 79
CHARS_PER_LINE = 100
ROWS = 19


def line_count(text, width=CHARS_PER_LINE):
    """How many lines the text fills on screen (an estimate: Kodi does the real wrapping)."""
    plain = re.sub(r"\[/?[A-Z]+[^\]]*\]", "", text or "")
    return sum(max(1, (len(l) + width - 1) // width) for l in plain.split("\n"))


class Scroller(object):
    """Where the reader is, one line at a time, so no line is skipped between pages."""
    SLOWEST, FASTEST, STEP = 8.0, 1.0, 0.5

    def __init__(self, lines, rows=ROWS, delay=3.5, hold=5.0, now=0.0):
        self.last = max(0, lines - rows)
        self.pos = 0
        self.delay = delay
        self.playing = self.last > 0
        self.due = now + hold

    def tick(self, now):
        """True if it moved on a line."""
        if not self.playing or now < self.due:
            return False
        if self.pos >= self.last:
            self.playing = False
            return False
        self.pos += 1
        self.due = now + self.delay
        return True

    def move(self, lines, now):
        """Arrow keys: go by hand. Moving by hand pauses the scrolling."""
        self.playing = False
        self.pos = min(self.last, max(0, self.pos + lines))

    def toggle(self, now):
        self.playing = not self.playing and self.pos < self.last
        self.due = now + 1.0

    def slower(self):
        self.delay = min(self.SLOWEST, self.delay + self.STEP)

    def faster(self):
        self.delay = max(self.FASTEST, self.delay - self.STEP)

    def hint(self):
        state = "Scrolling" if self.playing else "Paused"
        return "%s, %.1f s per line.   OK: pause or play    Up/Down: move    Left/Right: slower/faster    Back: close" % (
            state, self.delay)


def show_page(title, body, buttons):
    """A full-window message. Returns the button pressed, or -1 for Back."""
    import xbmcgui

    class Page(xbmcgui.WindowDialog):
        choice = -1
        ids = []

        def onAction(self, action):
            if action.getId() in BACK:
                self.close()

        def onControl(self, control):
            cid = control.getId()
            if cid in self.ids:
                self.choice = self.ids.index(cid)
                self.close()

    win = Page()
    win.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, MEDIA + "panel.png"))
    win.addControl(xbmcgui.ControlImage(1140, 24, 80, 80, MEDIA + "logo.png"))
    win.addControl(xbmcgui.ControlLabel(60, 40, 1060, 44, "[B]%s[/B]" % title, font="font13", textColor="FF2EC4B6"))
    box = xbmcgui.ControlTextBox(60, 116, 1160, 484, font="font13", textColor="FFFFFFFF")
    win.addControl(box)
    box.setText(body)
    width = 300
    x = 60
    made = []
    for label in buttons:
        b = xbmcgui.ControlButton(x, 620, width, 60, label, focusTexture=MEDIA + "focus.png",
                                  noFocusTexture=MEDIA + "button.png", alignment=6, font="font13",
                                  textColor="FFFFFFFF", focusedColor="FF0F1A24")
        win.addControl(b)
        made.append(b)
        x += width + 30
    for i, b in enumerate(made):
        b.setNavigation(b, b, made[i - 1], made[(i + 1) % len(made)])
    win.ids = [b.getId() for b in made]
    win.setFocus(made[-1])
    win.doModal()
    choice = win.choice
    del win
    return choice


CHIP_COLUMNS, CHIP_ROWS = 5, 8
CHIP_W, CHIP_H, CHIP_GAP_X, CHIP_GAP_Y = 228, 50, 6, 8


class GenreGrid(object):
    """Which genres are on and which page shows. names: in display order. kinds: {name: "both", "discogs",
    "lastfm" or "none"}. picks stay in the order they were turned on, because the first genre leads the tag."""

    def __init__(self, names, kinds, picks, per_page=CHIP_COLUMNS * CHIP_ROWS):
        self.names = list(names)
        self.kinds = kinds
        self.picks = [p for p in picks if p in self.names]
        self.per_page = per_page
        self.page = 0

    @property
    def pages(self):
        return max(1, (len(self.names) + self.per_page - 1) // self.per_page)

    def shown(self):
        start = self.page * self.per_page
        return self.names[start:start + self.per_page]

    def toggle(self, name):
        if name in self.picks:
            self.picks.remove(name)
        else:
            self.picks.append(name)

    def turn(self, by):
        self.page = max(0, min(self.pages - 1, self.page + by))

    def image(self, name):
        return "chip_%s_%s.png" % (self.kinds.get(name, "none"), "on" if name in self.picks else "off")


def pick_genres(title, subtitle, names, kinds, picks, one_track=True):
    """The genre screen. Returns (what happened, genres on): "save", "skip", "track" or "stop" (Back)."""
    import xbmcgui

    grid = GenreGrid(names, kinds, picks)

    class Screen(xbmcgui.WindowDialog):
        outcome = "stop"
        slots = {}
        actions = {}

        def onAction(self, action):
            a = action.getId()
            if a in BACK:
                self.close()
            elif a in (PAGE_UP, PAGE_DOWN):
                self.flip(-1 if a == PAGE_UP else 1)

        def onControl(self, control):
            cid = control.getId()
            if cid in self.slots:
                shown = grid.shown()
                if self.slots[cid] < len(shown):
                    grid.toggle(shown[self.slots[cid]])
                    self.draw()
            elif cid in self.actions:
                what = self.actions[cid]
                if what in ("prev", "next"):
                    self.flip(-1 if what == "prev" else 1)
                else:
                    self.outcome = what
                    self.close()

        def flip(self, by):
            grid.turn(by)
            self.draw()

        def draw(self):
            shown = grid.shown()
            for i, (image, button) in enumerate(self.chips):
                visible = i < len(shown)
                image.setVisible(visible)
                button.setVisible(visible)
                if visible:
                    image.setImage(MEDIA + grid.image(shown[i]), False)
                    button.setLabel(shown[i])
            self.counter.setLabel("%d on    Page %d of %d" % (len(grid.picks), grid.page + 1, grid.pages))

    win = Screen()
    win.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, MEDIA + "panel.png"))
    win.addControl(xbmcgui.ControlLabel(58, 18, 900, 40, "[B]%s[/B]" % title, font="font13", textColor="FF2EC4B6"))
    win.addControl(xbmcgui.ControlLabel(58, 54, 900, 30, subtitle, font="font12", textColor="FFD0D6DE"))
    win.counter = xbmcgui.ControlLabel(960, 18, 262, 40, "", font="font12", textColor="FFFFFFFF", alignment=1)
    win.addControl(win.counter)
    x = 58
    for image, label, width in (("chip_discogs_on.png", "Releases: Discogs, Apple Music, Deezer", 330),
                                ("chip_lastfm_on.png", "Tags: Last.fm, Audius", 200),
                                ("chip_both_on.png", "Both", 70), ("chip_none_off.png", "Not found: off", 150)):
        win.addControl(xbmcgui.ControlImage(x, 94, 34, 20, MEDIA + image))
        win.addControl(xbmcgui.ControlLabel(x + 42, 88, width, 30, label, font="font12", textColor="FFFFFFFF"))
        x += 42 + width
    win.chips = []
    buttons = []
    for i in range(CHIP_COLUMNS * CHIP_ROWS):
        cx = 58 + (i % CHIP_COLUMNS) * (CHIP_W + CHIP_GAP_X)
        cy = 124 + (i // CHIP_COLUMNS) * (CHIP_H + CHIP_GAP_Y)
        image = xbmcgui.ControlImage(cx, cy, CHIP_W, CHIP_H, MEDIA + "chip_none_off.png")
        button = xbmcgui.ControlButton(cx, cy, CHIP_W, CHIP_H, "", focusTexture=MEDIA + "chip_focus.png",
                                       noFocusTexture=MEDIA + "chip_clear.png", alignment=6, font="font12",
                                       textColor="FFFFFFFF", focusedColor="FFFFFFFF")
        win.addControl(image)
        win.addControl(button)
        win.chips.append((image, button))
        buttons.append(button)
    labels = [("Previous page", "prev"), ("Next page", "next")]
    if one_track:
        labels.append(("Change one track", "track"))
    labels += [("Skip", "skip"), ("Save", "save")]
    width = (1164 - 10 * (len(labels) - 1)) // len(labels)
    bar = []
    for n, (label, what) in enumerate(labels):
        b = xbmcgui.ControlButton(58 + n * (width + 10), 648, width, 52, label, focusTexture=MEDIA + "focus.png",
                                  noFocusTexture=MEDIA + "button.png", alignment=6, font="font12",
                                  textColor="FFFFFFFF", focusedColor="FF0F1A24")
        win.addControl(b)
        bar.append((b, what))
    bar_buttons = [b for b, _ in bar]
    for i, b in enumerate(buttons):
        column, row = i % CHIP_COLUMNS, i // CHIP_COLUMNS
        up = buttons[i - CHIP_COLUMNS] if row else bar_buttons[-1]
        down = buttons[i + CHIP_COLUMNS] if row < CHIP_ROWS - 1 else bar_buttons[-1]
        left = buttons[i - 1] if column else buttons[i + CHIP_COLUMNS - 1]
        right = buttons[i + 1] if column < CHIP_COLUMNS - 1 else buttons[i - CHIP_COLUMNS + 1]
        b.setNavigation(up, down, left, right)
    for n, b in enumerate(bar_buttons):
        b.setNavigation(buttons[0], buttons[0], bar_buttons[n - 1], bar_buttons[(n + 1) % len(bar_buttons)])
    win.slots = dict((b.getId(), i) for i, b in enumerate(buttons))
    win.actions = dict((b.getId(), what) for b, what in bar)
    win.draw()
    win.setFocus(buttons[0])
    win.doModal()
    outcome = win.outcome
    del win
    return outcome, list(grid.picks)


def read_text(title, text):
    """Show text in the reader until Back is pressed."""
    import time
    import xbmc
    import xbmcgui

    state = Scroller(line_count(text), now=time.time())

    class Reader(xbmcgui.WindowDialog):
        closed = False

        def onAction(self, action):
            a, now = action.getId(), time.time()
            if a in BACK:
                self.closed = True
            elif a in (SELECT, PAUSE, PLAY):
                state.toggle(now)
            elif a == UP:
                state.move(-1, now)
            elif a == DOWN:
                state.move(1, now)
            elif a == PAGE_UP:
                state.move(-(ROWS - 2), now)
            elif a == PAGE_DOWN:
                state.move(ROWS - 2, now)
            elif a == LEFT:
                state.slower()
            elif a == RIGHT:
                state.faster()

    win = Reader()
    win.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, MEDIA + "panel.png"))
    win.addControl(xbmcgui.ControlLabel(40, 18, 1200, 40, "[B]%s[/B]" % title, font="font13", textColor="FF2EC4B6"))
    box = xbmcgui.ControlTextBox(40, 66, 1200, 600, font="font13", textColor="FFFFFFFF")
    win.addControl(box)
    box.setText(text)
    hint = xbmcgui.ControlLabel(40, 676, 1200, 34, state.hint(), font="font12", textColor="FFA9BAC0")
    win.addControl(hint)
    monitor = xbmc.Monitor()
    win.show()
    try:
        shown_pos, shown_hint = 0, state.hint()
        while not win.closed and not monitor.abortRequested():
            state.tick(time.time())
            if state.pos != shown_pos:
                shown_pos = state.pos
                box.scroll(shown_pos)
            if state.hint() != shown_hint:
                shown_hint = state.hint()
                hint.setLabel(shown_hint)
            if monitor.waitForAbort(0.1):
                break
    finally:
        win.close()
        del win


class Friendly(object):
    """Kodi's dialog, with long messages in a full window and text in the reader."""
    def __init__(self, dlg):
        self.dlg = dlg

    def __getattr__(self, name):
        return getattr(self.dlg, name)

    def ok(self, heading, message):
        if len(message) > LONG:
            try:
                show_page(heading, message, ["OK"])
                return True
            except Exception:
                pass
        return self.dlg.ok(heading, message)

    def yesno(self, heading, message, nolabel="No", yeslabel="Yes", **kw):
        if len(message) > LONG:
            try:
                return show_page(heading, message, [nolabel, yeslabel]) == 1
            except Exception:
                pass
        return self.dlg.yesno(heading, message, nolabel=nolabel, yeslabel=yeslabel, **kw)

    def textviewer(self, heading, text, *a, **k):
        try:
            return read_text(heading, text)
        except Exception:
            return self.dlg.textviewer(heading, text, *a, **k)


def downloads_window(title, top, filters, rows, bottom, focus=None):
    """The downloads screen: a row of extra buttons (top), the filter buttons right above the list, the list of
    downloads in the middle (scrolls), and the main buttons along the bottom. top, filters, bottom: [label];
    rows: [(name, status)]. Returns (part, index) for what was pressed - part is "top", "filter", "row" or
    "bottom" - or None for Back. focus: (part, index) to start on. Raises if Kodi can't build it, so the caller
    can fall back to a plain list."""
    import xbmcgui

    class Win(xbmcgui.WindowDialog):
        picked = None
        ids = {}

        def onAction(self, action):
            if action.getId() in BACK:
                self.close()

        def onControl(self, control):
            cid = control.getId()
            if cid == self.list_id:
                self.picked = ("row", self.lst.getSelectedPosition())
                self.close()
            elif cid in self.ids:
                self.picked = self.ids[cid]
                self.close()

    win = Win()
    win.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, MEDIA + "panel.png"))
    win.addControl(xbmcgui.ControlLabel(40, 14, 1100, 40, "[B]%s[/B]" % title, font="font13", textColor="FF2EC4B6"))

    def bar(labels, y, height, part, font="font12"):
        made = []
        if not labels:
            return made
        width = (1200 - 8 * (len(labels) - 1)) // len(labels)
        for n, label in enumerate(labels):
            b = xbmcgui.ControlButton(40 + n * (width + 8), y, width, height, label, focusTexture=MEDIA + "focus.png",
                                      noFocusTexture=MEDIA + "button.png", alignment=6, font=font,
                                      textColor="FFFFFFFF", focusedColor="FF0F1A24")
            win.addControl(b)
            win.ids[b.getId()] = (part, n)
            made.append(b)
        return made

    win.ids = {}
    tops = bar(top, 58, 44, "top", "font10")
    list_y = 166 if tops else 116
    fil = bar(filters, list_y - 54, 46, "filter")
    lst = xbmcgui.ControlList(40, list_y, 1200, 628 - list_y, font="font12", textColor="FFFFFFFF",
                              selectedColor="FF0F1A24", buttonFocusTexture=MEDIA + "focus.png",
                              buttonTexture=MEDIA + "button.png", _itemHeight=44, _space=4, _itemTextXOffset=12,
                              _alignmentY=4)  # underscored: the plain names raise
    win.addControl(lst)
    for name, status in rows:
        lst.addItem(xbmcgui.ListItem(name, status))
    if not rows:
        lst.addItem(xbmcgui.ListItem("Nothing here", ""))
    win.lst, win.list_id = lst, lst.getId()
    bot = bar(bottom, 642, 56, "bottom", "font13")
    lines = [l for l in (tops, fil, [lst], bot) if l]
    for i, line in enumerate(lines):
        up, down = lines[i - 1][0] if i else lines[-1][0], lines[(i + 1) % len(lines)][0]
        for n, c in enumerate(line):
            if c is lst:
                c.controlUp(up)
                c.controlDown(down)
            else:
                c.setNavigation(up, down, line[n - 1], line[(n + 1) % len(line)])
    part, idx = focus or ("row", 0)
    pool = {"top": tops, "filter": fil, "bottom": bot}.get(part)
    if pool:
        win.setFocus(pool[min(idx, len(pool) - 1)])
    else:
        win.setFocus(lst)
        if rows:
            lst.selectItem(min(idx, len(rows) - 1))
    win.doModal()
    picked = win.picked
    del win
    if picked and picked[0] == "row" and not rows:
        return None
    return picked
