"""The add-on's own colours, one palette per skin, the same five the phone app's decks use (Theme.java).

Every new window takes its colours from current(), so a skin is a change of palette, not of code. Kodi colours are
"AARRGGBB" text. The skin selector comes in a later batch; until then it is always Pro.
"""

# bg, panel, line, fg, mute, knob, wave, a (accent), b (second accent), metal, led: as in Theme.set()
SLOTS = ("bg", "panel", "line", "fg", "mute", "knob", "wave", "a", "b", "metal", "led")
PALETTES = {
    "pro": (0xFF1C1E22, 0xFF25282D, 0xFF3C4148, 0xFFEEF0F2, 0xFF9BA3AC, 0xFF17181B, 0xFF05070A, 0xFFFF7A1A,
            0xFF2FB7FF, 0xFFC9CED6, 0xFFF2F6FA),
    "holo": (0xFF050916, 0xFF0B1430, 0xFF2A4A8A, 0xFFE2F2FF, 0xFF8AA5D6, 0xFF071028, 0xFF02040B, 0xFF19E6FF,
             0xFFC6FF4D, 0xFF7FB4FF, 0xFFFF4FD8),
    "walnut": (0xFFE4D9BF, 0xFFD8CBAA, 0xFF9A8A6A, 0xFF2B2118, 0xFF655644, 0xFF2A211B, 0xFF14100C, 0xFFB93A0A,
               0xFF0E6470, 0xFF7A4A22, 0xFFFFB000),
    "booth": (0xFF0E0E0F, 0xFF171819, 0xFF2C2E31, 0xFFF1F1EF, 0xFF8F9398, 0xFF1D1E20, 0xFF020202, 0xFF37E29A,
              0xFFB88CFF, 0xFFF1F1EF, 0xFFFF9F0A),
    "silver": (0xFFD5D9DE, 0xFFE3E6EA, 0xFFA9AFB7, 0xFF1B1F24, 0xFF58606A, 0xFFC3C8CF, 0xFF0A0D11, 0xFFC2410C,
               0xFF0B6477, 0xFFE9EDF2, 0xFF12B886),
}
NAMES = {"pro": "Pro", "holo": "Hologram", "walnut": "Walnut 74", "booth": "Booth", "silver": "Silver"}


def kodi(argb):
    return "%08X" % (argb & 0xFFFFFFFF)


FOCUS_TEXT = "FF0F1A24"  # text on the focus texture (resources/media/focus.png), as the Downloads screen uses


def palette(name="pro"):
    """{slot: "AARRGGBB"} for a skin, plus "focus_text": the text colour on a focused button. Focus is drawn with
    the add-on's focus texture, the same in every skin until each skin gets its own textures."""
    values = PALETTES.get(name) or PALETTES["pro"]
    out = dict((slot, kodi(v)) for slot, v in zip(SLOTS, values))
    out["focus_text"] = FOCUS_TEXT
    return out


def current():
    """The palette in use. Always Pro until the skin selector arrives."""
    return palette("pro")
