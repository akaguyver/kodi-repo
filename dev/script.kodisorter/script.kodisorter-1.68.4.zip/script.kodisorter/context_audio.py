"""Hold down a video: save its sound as a tagged music file, copied out as it is."""
import sys

import xbmc

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

if __name__ == "__main__":
    path = sys.listitem.getPath() or xbmc.getInfoLabel("ListItem.FileNameAndPath")
    xbmc.executebuiltin("RunPlugin(plugin://script.kodisorter/?action=audio_out&path=%s)" % quote(path.encode("utf-8"), ""))
