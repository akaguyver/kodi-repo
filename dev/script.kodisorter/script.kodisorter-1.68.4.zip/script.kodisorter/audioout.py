"""Copy the sound out of a video with no change to it, and no ffmpeg: Kodi on the Xbox has none.

An MP4/M4V/MOV with AAC or ALAC sound gives an .m4a (its audio track copied as it is, in a new file); an MP3 track
gives an .mp3. A Matroska/WebM video (.mkv, .webm) with AAC gives an .m4a, with MP3 an .mp3, with FLAC a .flac.
Anything else (Opus, Vorbis, AC-3, DTS ...) has to be converted, which needs the phone app: probe says so.
Nothing but Python, so it runs in Kodi and in the tests; the file is read through read_at(position, count)."""
import re
import struct
import zlib

COPY = {"aac": ".m4a", "alac": ".m4a", "mp3": ".mp3", "flac": ".flac"}
NAMES = {"aac": "AAC", "alac": "ALAC", "mp3": "MP3", "flac": "FLAC", "opus": "Opus", "vorbis": "Vorbis",
         "ac3": "Dolby Digital (AC-3)", "eac3": "Dolby Digital Plus", "dts": "DTS", "truehd": "Dolby TrueHD",
         "pcm": "PCM"}
RATES = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350]
MAX_MOOV = 64 << 20


class Unsupported(Exception):
    """A file this can't read: the reason in plain words."""


def name_of(codec):
    return NAMES.get(codec, codec or "unknown")


class Buffered(object):
    """read_at over a slow one (a file on the phone): reads ahead in big pieces, as the file is read in order."""
    def __init__(self, read_at, size, piece=2 << 20):
        self.raw, self.size, self.piece = read_at, size, piece
        self.at, self.buf = 0, b""

    def __call__(self, pos, n):
        if not (self.at <= pos and pos + n <= self.at + len(self.buf)):
            self.at = pos
            self.buf = self.raw(pos, max(n, self.piece))
        return self.buf[pos - self.at:pos - self.at + n]


def probe(read_at, size):
    """{"container": "mp4"|"mkv", "codec", "ext" (None when it can't be copied out as it is)}."""
    head = read_at(0, 12)
    if head[4:8] == b"ftyp":
        codec = _mp4_audio(_mp4_moov(read_at, size))[1]
        return {"container": "mp4", "codec": codec, "ext": COPY.get(codec)}
    if head[:4] == b"\x1a\x45\xdf\xa3":
        codec = _mkv_track(_mkv_tracks(read_at, size))["codec"]
        return {"container": "mkv", "codec": codec, "ext": COPY.get(codec)}
    raise Unsupported("not an MP4 or MKV video")


def extract(read_at, size, out, progress=None):
    """Write the video's sound into out (a file open for writing that can seek). progress(done, total) is told
    how far it has got; return False from it to stop (raises Unsupported("stopped")). Returns probe's dict."""
    read_at = Buffered(read_at, size)
    info = probe(read_at, size)
    if not info["ext"]:
        raise Unsupported("%s sound has to be converted" % name_of(info["codec"]))
    (_mp4_extract if info["container"] == "mp4" else _mkv_extract)(read_at, size, out, info, progress or
                                                                    (lambda d, t: True))
    return info


def _go(progress, done, total):
    if progress(done, total) is False:
        raise Unsupported("stopped")


# --- MP4 ----------------------------------------------------------------------------------------------------

def _box(kind, body):
    return struct.pack(">I", len(body) + 8) + kind + body


def _boxes(data, start, end):
    pos = start
    while pos + 8 <= end:
        size, kind = struct.unpack(">I4s", data[pos:pos + 8])
        head = 8
        if size == 1:
            size, head = struct.unpack(">Q", data[pos + 8:pos + 16])[0], 16
        elif size == 0:
            size = end - pos
        if size < head or pos + size > end:
            raise Unsupported("damaged video file")
        yield kind, pos, pos + head, pos + size
        pos += size


def _find(data, start, end, *path):
    for kind, _, a, b in _boxes(data, start, end):
        if kind == path[0]:
            return (a, b) if len(path) == 1 else _find(data, a, b, *path[1:])
    return None


def _mp4_moov(read_at, size):
    pos = 0
    while pos + 8 <= size:
        h = read_at(pos, 16)
        n, kind = struct.unpack(">I4s", h[:8])
        if n == 1:
            n = struct.unpack(">Q", h[8:16])[0]
        elif n == 0:
            n = size - pos
        if n < 8:
            raise Unsupported("damaged video file")
        if kind == b"moov":
            if n > MAX_MOOV:
                raise Unsupported("the video's index is too large")
            return read_at(pos, n)
        if kind == b"moof":
            raise Unsupported("a video in pieces (fragmented MP4)")
        pos += n
    raise Unsupported("damaged video file (no index)")


def _descriptors(data, pos, end):
    """MPEG-4 descriptors: (tag, body start, body end)."""
    while pos + 2 <= end:
        tag, length, pos = data[pos], 0, pos + 1
        for _ in range(4):
            b = data[pos]
            pos += 1
            length = (length << 7) | (b & 0x7f)
            if not b & 0x80:
                break
        yield tag, pos, min(pos + length, end)
        pos += length


def _esds_type(esds):
    """The object type in an esds box body: 0x40 (and 0x66-0x68) AAC, 0x69/0x6B MP3."""
    for tag, a, b in _descriptors(esds, 4, len(esds)):
        if tag == 3:
            flags = esds[a + 2]
            a += 3 + (2 if flags & 0x80 else 0) + (2 if flags & 0x20 else 0)
            if flags & 0x40:
                a += 1 + esds[a]
            for tag2, c, _ in _descriptors(esds, a, b):
                if tag2 == 4:
                    return esds[c]
    return None


def _mp4_audio(moov):
    """(trak (start, end) in moov, codec) of the first sound track."""
    first = None
    for kind, s, a, b in _boxes(moov, 8, len(moov)):
        if kind != b"trak":
            continue
        hdlr = _find(moov, a, b, b"mdia", b"hdlr")
        if not hdlr or moov[hdlr[0] + 8:hdlr[0] + 12] != b"soun":
            continue
        stsd = _find(moov, a, b, b"mdia", b"minf", b"stbl", b"stsd")
        if not stsd:
            continue
        e = stsd[0] + 8  # version, flags, entry count
        fourcc = moov[e + 4:e + 8]
        codec = {b"alac": "alac", b"ac-3": "ac3", b"ec-3": "eac3", b"Opus": "opus", b"fLaC": "flac",
                 b".mp3": "mp3", b"lpcm": "pcm", b"sowt": "pcm", b"twos": "pcm"}.get(fourcc, fourcc.decode("latin-1"))
        if fourcc == b"mp4a":
            entry_end = e + struct.unpack(">I", moov[e:e + 4])[0]
            try:  # 8 + 28 bytes of sound details, then its boxes (a QuickTime version 1 entry has 16 more)
                esds = _find(moov, e + 36, entry_end, b"esds") or _find(moov, e + 52, entry_end, b"esds")
            except Unsupported:
                esds = _find(moov, e + 52, entry_end, b"esds")
            t = _esds_type(moov[esds[0]:esds[1]]) if esds else 0x40
            codec = "mp3" if t in (0x69, 0x6B) else "aac" if t in (0x40, 0x66, 0x67, 0x68) else "mp4a-%02x" % (t or 0)
        if codec == "flac":
            codec = "flac-mp4"  # FLAC in MP4 would need its own file layout: leave it to the app
        if first is None or (COPY.get(codec) and not COPY.get(first[1])):
            first = ((s, b), codec)
    if not first:
        raise Unsupported("the video has no sound")
    return first


def _mp4_chunks(moov, stbl):
    """[(position, length)] of every piece of sound in the file, in order."""
    def table(kind):
        span = _find(moov, stbl[0], stbl[1], kind)
        return moov[span[0]:span[1]] if span else None
    stsz, stsc = table(b"stsz"), table(b"stsc")
    stco, co64 = table(b"stco"), table(b"co64")
    if not stsz or not stsc or not (stco or co64):
        raise Unsupported("damaged video file")
    fixed, count = struct.unpack(">II", stsz[4:12])
    sizes = [fixed] * count if fixed else list(struct.unpack(">%dI" % count, stsz[12:12 + 4 * count]))
    if co64:
        n = struct.unpack(">I", co64[4:8])[0]
        offsets = struct.unpack(">%dQ" % n, co64[8:8 + 8 * n])
    else:
        n = struct.unpack(">I", stco[4:8])[0]
        offsets = struct.unpack(">%dI" % n, stco[8:8 + 4 * n])
    runs = [struct.unpack(">III", stsc[8 + 12 * i:20 + 12 * i]) for i in range(struct.unpack(">I", stsc[4:8])[0])]
    out, sample = [], 0
    for i, (first, per, _) in enumerate(runs):
        last = runs[i + 1][0] - 1 if i + 1 < len(runs) else n
        for chunk in range(first, last + 1):
            if chunk > n:
                break
            length = sum(sizes[sample:sample + per])
            sample += per
            out.append((offsets[chunk - 1], length))
    return out


def _rewrite(moov, a, b, swap):
    """The boxes between a and b again, with stco/co64 swapped for swap and everything holding one resized."""
    out = b""
    for kind, s, x, y in _boxes(moov, a, b):
        if kind in (b"mdia", b"minf", b"stbl"):
            out += _box(kind, _rewrite(moov, x, y, swap))
        elif kind in (b"stco", b"co64"):
            out += swap
        else:
            out += moov[s:y]
    return out


def _mp4_extract(read_at, size, out, info, progress):
    moov = _mp4_moov(read_at, size)
    (ts, te), codec = _mp4_audio(moov)
    stbl = _find(moov, ts + 8, te, b"mdia", b"minf", b"stbl")
    chunks = _mp4_chunks(moov, stbl)
    total = sum(n for _, n in chunks) or 1
    if codec == "mp3":
        done = 0
        for pos, n in chunks:
            out.write(read_at(pos, n))
            done += n
            _go(progress, done, total)
        return
    out.write(_box(b"ftyp", b"M4A " + bytes(4) + b"M4A mp42isom"))
    mdat = out.tell()
    out.write(struct.pack(">I4sQ", 1, b"mdat", 0))
    places, done = [], 0
    for pos, n in chunks:
        places.append(out.tell())
        out.write(read_at(pos, n))
        done += n
        _go(progress, done, total)
    end = out.tell()
    out.seek(mdat + 8)
    out.write(struct.pack(">Q", end - mdat))
    out.seek(end)
    wide = places and places[-1] >= 1 << 32
    swap = (_box(b"co64", struct.pack(">II", 0, len(places)) + struct.pack(">%dQ" % len(places), *places)) if wide
            else _box(b"stco", struct.pack(">II", 0, len(places)) + struct.pack(">%dI" % len(places), *places)))
    mvhd = _find(moov, 8, len(moov), b"mvhd")
    trak = _rewrite(moov, ts + 8, te, swap)
    out.write(_box(b"moov", moov[mvhd[0] - 8:mvhd[1]] + _box(b"trak", trak)))


# --- Matroska / WebM ----------------------------------------------------------------------------------------

SEGMENT, CLUSTER, BLOCKGROUP = 0x18538067, 0x1F43B675, 0xA0
TRACKS, SIMPLEBLOCK, BLOCK = 0x1654AE6B, 0xA3, 0xA1
OPEN = (SEGMENT, CLUSTER, BLOCKGROUP)  # gone into, not skipped: their size can be "unknown"


def _vint(data, pos, keep_marker=False):
    first = data[pos]
    width = 1
    while width <= 8 and not first & (0x80 >> (width - 1)):
        width += 1
    if width > 8:
        raise Unsupported("damaged video file")
    value = first if keep_marker else first & (0xff >> width)
    for b in data[pos + 1:pos + width]:
        value = (value << 8) | b
    unknown = not keep_marker and value == (1 << (7 * width)) - 1
    return value, pos + width, width, unknown


def _elements(data, pos, end):
    while pos < end:
        eid, pos, _, _ = _vint(data, pos, keep_marker=True)
        size, pos, _, _ = _vint(data, pos)
        yield eid, pos, min(pos + size, end)
        pos += size


def _uint(data):
    return int.from_bytes(bytes(data), "big") if data else 0


def _walk(read_at, size, wanted):
    """(element id, position, size) of each element in wanted, reading through segments, clusters and block
    groups (which may not say their size) and skipping everything else."""
    pos = 0
    while pos + 2 <= size:
        h = read_at(pos, 16)
        if len(h) < 2:
            return
        eid, p, _, _ = _vint(h, 0, keep_marker=True)
        n, p, _, unknown = _vint(h, p)
        if eid in OPEN:
            pos += p
            continue
        if unknown:
            raise Unsupported("damaged video file")
        if eid in wanted:
            yield eid, pos + p, n
        pos += p + n


def _mkv_tracks(read_at, size):
    for eid, pos, n in _walk(read_at, size, (TRACKS, SIMPLEBLOCK, BLOCK)):
        if eid == TRACKS:
            return read_at(pos, n)
        raise Unsupported("damaged video file (sound found before the track list)")
    raise Unsupported("damaged video file (no track list)")


def _mkv_track(tracks):
    """The first sound track: {"number", "codec", "private", "rate", "channels", "strip", "zlib"}."""
    best = None
    for eid, a, b in _elements(tracks, 0, len(tracks)):
        if eid != 0xAE:
            continue
        t = {"number": 0, "type": 0, "id": "", "private": b"", "rate": 8000.0, "channels": 1, "strip": b"",
             "zlib": False}
        for e, x, y in _elements(tracks, a, b):
            if e == 0xD7:
                t["number"] = _uint(tracks[x:y])
            elif e == 0x83:
                t["type"] = _uint(tracks[x:y])
            elif e == 0x86:
                t["id"] = bytes(tracks[x:y]).decode("latin-1")
            elif e == 0x63A2:
                t["private"] = bytes(tracks[x:y])
            elif e == 0xE1:
                for e2, x2, y2 in _elements(tracks, x, y):
                    if e2 == 0xB5:
                        t["rate"] = struct.unpack(">f" if y2 - x2 == 4 else ">d", tracks[x2:y2])[0]
                    elif e2 == 0x9F:
                        t["channels"] = _uint(tracks[x2:y2])
            elif e == 0x6D80:  # content encodings: header stripping or zlib
                for _, x2, y2 in _elements(tracks, x, y):  # ContentEncoding
                    for e3, x3, y3 in _elements(tracks, x2, y2):
                        if e3 == 0x5034:  # ContentCompression
                            algo, setting = 0, b""
                            for e4, x4, y4 in _elements(tracks, x3, y3):
                                if e4 == 0x4254:
                                    algo = _uint(tracks[x4:y4])
                                elif e4 == 0x4255:
                                    setting = bytes(tracks[x4:y4])
                            if algo == 3:
                                t["strip"] = setting
                            elif algo == 0:
                                t["zlib"] = True
                            else:
                                t["id"] = "compressed"
        if t["type"] != 2:
            continue
        cid = t["id"]
        t["codec"] = ("aac" if cid.startswith("A_AAC") else "mp3" if cid in ("A_MPEG/L3",) else
                      "flac" if cid == "A_FLAC" else "opus" if cid == "A_OPUS" else "vorbis" if cid == "A_VORBIS" else
                      "ac3" if cid == "A_AC3" else "eac3" if cid == "A_EAC3" else "dts" if cid.startswith("A_DTS") else
                      "truehd" if cid == "A_TRUEHD" else "pcm" if cid.startswith("A_PCM") else cid)
        if best is None or (COPY.get(t["codec"]) and not COPY.get(best["codec"])):
            best = t
    if not best:
        raise Unsupported("the video has no sound")
    return best


def _laced(data, start, flags):
    """The frames in one block, from start (just after the flags byte)."""
    lacing = (flags >> 1) & 3
    if not lacing:
        return [data[start:]]
    count, pos = data[start] + 1, start + 1
    sizes = []
    if lacing == 1:  # Xiph
        for _ in range(count - 1):
            n = 0
            while True:
                b = data[pos]
                pos += 1
                n += b
                if b != 255:
                    break
            sizes.append(n)
    elif lacing == 3:  # EBML
        n, pos, _, _ = _vint(data, pos)
        sizes.append(n)
        for _ in range(count - 2):
            raw, pos, width, _ = _vint(data, pos)
            n += raw - ((1 << (7 * width - 1)) - 1)
            sizes.append(n)
    else:  # all the same size
        each = (len(data) - pos) // count
        sizes = [each] * (count - 1)
    frames = []
    for n in sizes:
        frames.append(data[pos:pos + n])
        pos += n
    frames.append(data[pos:])
    return frames


def _mkv_frames(read_at, size, track, progress):
    for eid, pos, n in _walk(read_at, size, (SIMPLEBLOCK, BLOCK)):
        head = read_at(pos, 8)
        number, p, _, _ = _vint(head, 0)
        if number != track["number"]:
            continue
        block = read_at(pos, n)
        for f in _laced(block, p + 3, block[p + 2]):
            f = bytes(f)
            if track["zlib"]:
                f = zlib.decompress(f)
            yield track["strip"] + f
        _go(progress, pos + n, size)


def _asc(track, first):
    """The AAC AudioSpecificConfig: the track's own, else made from an ADTS frame header or the track's details.
    Also says how many header bytes each frame starts with (ADTS headers are dropped)."""
    if track["private"] and not track["id"].startswith("A_AAC/"):
        return track["private"], 0
    if len(first) > 7 and first[0] == 0xFF and first[1] & 0xF6 == 0xF0:
        kind = (first[2] >> 6) + 1
        rate = (first[2] >> 2) & 15
        ch = ((first[2] & 1) << 2) | (first[3] >> 6)
        return struct.pack(">H", (kind << 11) | (rate << 7) | (ch << 3)), 9 if not first[1] & 1 else 7
    if track["private"]:
        return track["private"], 0
    kind = 1 if "MAIN" in track["id"] else 3 if "SSR" in track["id"] else 2
    rate = min(range(len(RATES)), key=lambda i: abs(RATES[i] - track["rate"]))
    if "SBR" in track["id"]:
        rate = min(range(len(RATES)), key=lambda i: abs(RATES[i] - track["rate"] / 2))
    return struct.pack(">H", (kind << 11) | (rate << 7) | ((track["channels"] & 15) << 3)), 0


def _asc_rate(asc):
    index = ((asc[0] & 7) << 1) | (asc[1] >> 7)
    if (asc[0] >> 3) == 31:
        index = ((asc[1] & 1) << 3) | (asc[2] >> 5)
    if index == 15:
        raise Unsupported("unusual AAC sound")
    return RATES[index] if index < len(RATES) else 44100


def _desc(tag, body):
    n = len(body)
    return bytes([tag, 0x80 | (n >> 21 & 0x7f), 0x80 | (n >> 14 & 0x7f), 0x80 | (n >> 7 & 0x7f), n & 0x7f]) + body


MATRIX = struct.pack(">9I", 0x10000, 0, 0, 0, 0x10000, 0, 0, 0, 0x40000000)


def _m4a_moov(asc, channels, rate, sizes, place):
    n = len(sizes)
    duration = n * 1024
    ms = duration * 1000 // rate
    esds = _box(b"esds", bytes(4) + _desc(3, struct.pack(">HB", 1, 0) + _desc(
        4, struct.pack(">BB3sII", 0x40, 0x15, bytes(3), 0, 0) + _desc(5, asc)) + _desc(6, b"\x02")))
    mp4a = _box(b"mp4a", bytes(6) + struct.pack(">H", 1) + bytes(8) + struct.pack(
        ">HHHHI", min(channels, 2) or 2, 16, 0, 0, (rate << 16) if rate < 65536 else 0) + esds)
    stbl = _box(b"stbl",
                _box(b"stsd", struct.pack(">II", 0, 1) + mp4a) +
                _box(b"stts", struct.pack(">IIII", 0, 1, n, 1024)) +
                _box(b"stsc", struct.pack(">IIIII", 0, 1, 1, n, 1)) +
                _box(b"stsz", struct.pack(">III", 0, 0, n) + struct.pack(">%dI" % n, *sizes)) +
                (_box(b"co64", struct.pack(">IIQ", 0, 1, place)) if place >= 1 << 32 else
                 _box(b"stco", struct.pack(">III", 0, 1, place))))
    minf = _box(b"minf", _box(b"smhd", bytes(8)) +
                _box(b"dinf", _box(b"dref", struct.pack(">II", 0, 1) + _box(b"url ", struct.pack(">I", 1)))) + stbl)
    mdia = _box(b"mdia", _box(b"mdhd", struct.pack(">IIIIIHH", 0, 0, 0, rate, duration, 0x55C4, 0)) +
                _box(b"hdlr", bytes(8) + b"soun" + bytes(12) + b"SoundHandler\0") + minf)
    tkhd = _box(b"tkhd", struct.pack(">IIIIII", 7, 0, 0, 1, 0, ms) + bytes(8) + struct.pack(">HHHH", 0, 0, 0x100, 0) +
                MATRIX + bytes(8))
    mvhd = _box(b"mvhd", struct.pack(">IIIII", 0, 0, 0, 1000, ms) + struct.pack(">IH", 0x10000, 0x100) + bytes(10) +
                MATRIX + bytes(24) + struct.pack(">I", 2))
    return _box(b"moov", mvhd + _box(b"trak", tkhd + mdia))


def _mkv_extract(read_at, size, out, info, progress):
    track = _mkv_track(_mkv_tracks(read_at, size))
    frames = _mkv_frames(read_at, size, track, progress)
    if track["codec"] == "mp3":
        for f in frames:
            out.write(f)
        return
    if track["codec"] == "flac":
        if not track["private"].startswith(b"fLaC"):
            raise Unsupported("damaged FLAC sound")
        out.write(track["private"])
        for f in frames:
            out.write(f)
        return
    out.write(_box(b"ftyp", b"M4A " + bytes(4) + b"M4A mp42isom"))
    mdat = out.tell()
    out.write(struct.pack(">I4sQ", 1, b"mdat", 0))
    sizes, asc, skip = [], None, 0
    for f in frames:
        if asc is None:
            asc, skip = _asc(track, f)
        f = f[skip:]
        out.write(f)
        sizes.append(len(f))
    if not sizes:
        raise Unsupported("the sound track is empty")
    end = out.tell()
    out.seek(mdat + 8)
    out.write(struct.pack(">Q", end - mdat))
    out.seek(end)
    out.write(_m4a_moov(asc, track["channels"], _asc_rate(asc), sizes, mdat + 16))


# --- Names --------------------------------------------------------------------------------------------------

_NOISE = re.compile(r"\s*[\(\[][^\)\]]*\b(official|video|audio|lyrics?|visuali[sz]er|hd|hq|4k|1080p|720p|"
                    r"music video|full)\b[^\)\]]*[\)\]]", re.I)


def guess(name):
    """(artist, title) from a video's file name: "Artist - Title (Official Video).mp4" gives ("Artist", "Title")."""
    stem = re.sub(r"\.[A-Za-z0-9]{2,4}$", "", name or "")
    stem = re.sub(r"\s*\[[A-Za-z0-9_-]{11}\]$", "", stem)  # a YouTube id
    stem = _NOISE.sub("", stem).strip()
    artist, sep, title = stem.partition(" - ")
    return (artist.strip(), title.strip()) if sep else ("", stem)
