"""Hold down a video in Tutorials or Music and DJing: its YouTube channel, upload date, more from the channel,
the rest of its series."""
import sys

import xbmc

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

if __name__ == "__main__":
    path = sys.listitem.getPath() or xbmc.getInfoLabel("ListItem.FileNameAndPath")
    xbmc.executebuiltin("RunPlugin(plugin://script.kodisorter/?action=yt_video&path=%s)" % quote(path.encode("utf-8"), ""))
