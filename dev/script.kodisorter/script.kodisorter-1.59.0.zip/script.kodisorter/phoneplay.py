"""Let the Sortovia phone app play this device's music library, over Kodi's own web server.

The phone's share (kodi-share or the companion app) only lets Kodi read the phone. For the phone to play the
music on this device, Kodi's web server has to be on, with a password; this turns it on, using the share's
password so there's only one to remember. If the web server is already on (for the Kore remote, say), its
user name, port and password stay as they are.
"""

WEB = "services.webserver"
PORT, USER, PASSWORD = "services.webserverport", "services.webserverusername", "services.webserverpassword"
AUTH = "services.webserverauthentication"  # Kodi 18 and earlier only; later ones always ask for the password


def _get(rpc, name, default=None):
    try:
        return rpc("Settings.GetSettingValue", {"setting": name}).get("value", default)
    except Exception:
        return default


def _set(rpc, name, value):
    try:
        rpc("Settings.SetSettingValue", {"setting": name, "value": value})
        return True
    except Exception:
        return False


def turn_on(rpc, password, user="kodi", port=8080):
    """Turn on Kodi's web server for the phone. Returns {"on", "already", "user", "port", "password"}: password is
    "" when the web server was already on with its own password, which Kodi doesn't hand out."""
    if _get(rpc, WEB):
        return {"on": True, "already": True, "user": _get(rpc, USER, "kodi") or "kodi",
                "port": int(_get(rpc, PORT, port) or port), "password": ""}
    _set(rpc, USER, user)
    _set(rpc, PASSWORD, password)
    _set(rpc, PORT, port)
    _set(rpc, AUTH, True)
    on = _set(rpc, WEB, True) and bool(_get(rpc, WEB))
    return {"on": on, "already": False, "user": user, "port": port, "password": password}


def instructions(ip, result):
    """What to type in the phone app, or how to turn the web server on by hand if Kodi refused."""
    if not result["on"]:
        return ("Kodi didn't let Sortovia turn its web server on. Turn it on yourself: Settings > Services > Control > "
                "Allow remote control via HTTP, with a user name and password. Then, in the Sortovia phone app, open "
                "Settings > Xbox or Kodi and type this device's address (%s), the port, user name and password." % ip)
    password = result["password"] or "the web server's password (Settings > Services > Control)"
    return ("In the Sortovia phone app, open Settings > Xbox or Kodi and type:\n\n"
            "Address: %s\nPort: %s\nUser name: %s\nPassword: %s\n\n"
            "Keep this device and the phone on the same Wi-Fi or hotspot. The phone plays the songs in Kodi's music "
            "library, so scan your music into the library first." % (ip, result["port"], result["user"], password))
