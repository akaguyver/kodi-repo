"""Read the artist, album and track tags from music files, using nothing but Python.

Handles ID3 (MP3, some AAC), FLAC, Ogg (Vorbis and Opus) and MP4 (M4A). read_at(offset, count)
returns bytes from the file, so only the small parts holding the tags are read. A damaged or
unusual file just gives fewer tags.

The second half is the tag editor (read_all, write_fields, undo_last, analysis_fields, compare) for MP3, FLAC
and M4A. It also uses nothing but Python, so it runs the same in Kodi and in the app.
"""
import json
import os
import re
import struct
import time
import zlib

import djkeys
import id3write
from id3write import Unsupported

MAX_TAG = 2 * 1024 * 1024
ID3_FRAMES = {"TPE1": "artist", "TP1": "artist", "TPE2": "albumartist", "TP2": "albumartist", "TALB": "album",
              "TAL": "album", "TIT2": "title", "TT2": "title", "TRCK": "track", "TRK": "track", "TPOS": "disc",
              "TPA": "disc", "TCON": "genre", "TCO": "genre", "TCMP": "compilation", "TCP": "compilation",
              "PCST": "podcast", "TKEY": "key", "TKE": "key", "TBPM": "bpm", "TBP": "bpm"}
USER_TEXT = {"energylevel": "energy", "energy": "energy", "initialkey": "key", "key": "key",
             "markersv2": "serato_markers"}  # Serato's cue points, which Mixed In Key can write
VORBIS = {"ARTIST": "artist", "ALBUMARTIST": "albumartist", "ALBUM ARTIST": "albumartist", "ALBUM": "album",
          "TITLE": "title", "TRACKNUMBER": "track", "DISCNUMBER": "disc", "GENRE": "genre",
          "COMPILATION": "compilation", "INITIALKEY": "key", "KEY": "key", "BPM": "bpm", "TEMPO": "bpm",
          "COMMENT": "comment", "DESCRIPTION": "comment", "ENERGYLEVEL": "energy", "ENERGY": "energy",
          "SERATO_MARKERS_V2": "serato_markers"}
MP4_ITEMS = {b"\xa9ART": "artist", b"aART": "albumartist", b"\xa9alb": "album", b"\xa9nam": "title",
             b"\xa9gen": "genre", b"trkn": "track", b"disk": "disc", b"cpil": "compilation", b"pcst": "podcast",
             b"\xa9cmt": "comment", b"tmpo": "bpm"}


def _number(value):
    """"3/12" -> 3, anything else -> 0."""
    digits = str(value or "").split("/")[0].strip()
    return int(digits) if digits.isdigit() else 0


def _tidy(tags):
    out = {}
    for key, value in tags.items():
        if key in ("track", "disc"):
            value = _number(value)
        elif key in ("compilation", "podcast"):
            value = str(value).strip() not in ("", "0", "False", "false")
        else:
            value = " ".join(str(value).replace("\x00", " ").split())
        if value:
            out[key] = value
    return out


def _synchsafe(b):
    return (b[0] << 21) | (b[1] << 14) | (b[2] << 7) | b[3]


def _id3_text(data):
    if not data:
        return ""
    encoding = {0: "latin-1", 1: "utf-16", 2: "utf-16-be", 3: "utf-8"}.get(data[0])
    text = data[1:].decode(encoding, "replace") if encoding else data.decode("latin-1")
    return text.split("\x00")[0]  # the first of several values


def _id3_all(data):
    """Every value in a text frame, as "Dubstep / Trap" (Kodi's way of showing several)."""
    if not data:
        return ""
    encoding = {0: "latin-1", 1: "utf-16", 2: "utf-16-be", 3: "utf-8"}.get(data[0])
    text = data[1:].decode(encoding, "replace") if encoding else data.decode("latin-1")
    parts = [x.lstrip("\ufeff").strip() for x in text.split("\x00")]
    return " / ".join(x for x in parts if x)


def _id3_parts(data):
    """A COMM or TXXX frame's text after its encoding byte, split at the separator: [description, value]."""
    encoding = {0: "latin-1", 1: "utf-16", 2: "utf-16-be", 3: "utf-8"}.get(data[0]) if data else None
    if not encoding:
        return ["", ""]
    parts = [x.lstrip("\ufeff") for x in data[1:].decode(encoding, "replace").split("\x00")]
    return (parts + ["", ""])[:2]


def _id3(read_at):
    head = read_at(0, 10)
    if len(head) < 10 or head[:3] != b"ID3":
        return {}
    version, flags = head[3], head[5]
    data = read_at(10, min(_synchsafe(head[6:10]), MAX_TAG))
    pos = 0
    if flags & 0x40 and version >= 3 and len(data) > 4:  # an extended header comes first
        pos = _synchsafe(data[:4]) if version == 4 else struct.unpack(">I", data[:4])[0] + 4
    head_len, id_len = (6, 3) if version == 2 else (10, 4)
    tags = {}
    while pos + head_len <= len(data):
        frame = data[pos:pos + id_len]
        if not frame.strip(b"\x00"):
            break
        raw = data[pos + id_len:pos + head_len]
        if version == 2:
            size = (raw[0] << 16) | (raw[1] << 8) | raw[2]
        elif version == 4:
            size = _synchsafe(raw[:4])
        else:
            size = struct.unpack(">I", raw[:4])[0]
        name = frame.decode("latin-1")
        body = data[pos + head_len:pos + head_len + size]
        key = ID3_FRAMES.get(name)
        if name in ("COMM", "COM") and len(body) > 4:
            describe, text = _id3_parts(body[:1] + body[4:])  # 3 bytes of language follow the encoding
            if not describe.startswith("iTun") and text.strip():
                tags.setdefault("comment", text)
        elif name == "GEOB" and body[:1] == b"\x00":
            parts = body[1:].split(b"\x00", 3)  # type, file name, description, then the data
            if len(parts) == 4 and parts[2] == b"Serato Markers2" and parts[3][:2] == b"\x01\x01":
                tags.setdefault("serato_markers", parts[3][2:].decode("ascii", "ignore"))
        elif name in ("TXXX", "TXX") and body:
            describe, text = _id3_parts(body)
            user_key = USER_TEXT.get(describe.strip().lower())
            if user_key and text.strip():
                tags.setdefault(user_key, text)
        if key == "genre":  # ID3v2.4 keeps several genres in one frame, between zero bytes
            tags.setdefault(key, _id3_all(body))
        elif key:
            tags.setdefault(key, "1" if key == "podcast" else _id3_text(data[pos + head_len:pos + head_len + size]))
        pos += head_len + size
    return tags


def _id3v1(read_at, size):
    if size < 128:
        return {}
    tail = read_at(size - 128, 128)
    if tail[:3] != b"TAG":
        return {}

    def text(a, b):
        return tail[a:b].split(b"\x00")[0].decode("latin-1").strip()
    tags = {"title": text(3, 33), "artist": text(33, 63), "album": text(63, 93)}
    if tail[125] == 0 and tail[126]:
        tags["track"] = str(tail[126])
    return tags


def _vorbis_comments(data):
    pos = struct.unpack("<I", data[:4])[0] + 4
    count = struct.unpack("<I", data[pos:pos + 4])[0]
    pos += 4
    tags = {}
    for _ in range(min(count, 1000)):
        size = struct.unpack("<I", data[pos:pos + 4])[0]
        entry = data[pos + 4:pos + 4 + size].decode("utf-8", "replace")
        pos += 4 + size
        name, _, value = entry.partition("=")
        key = VORBIS.get(name.upper())
        if key == "genre" and tags.get(key) and value.strip():
            tags[key] += " / " + value.strip()  # one GENRE comment per genre
        elif key:
            tags.setdefault(key, value)
    return tags


def _flac(read_at):
    pos = 4
    while True:
        head = read_at(pos, 4)
        if len(head) < 4:
            return {}
        size = (head[1] << 16) | (head[2] << 8) | head[3]
        if head[0] & 0x7f == 4:
            return _vorbis_comments(read_at(pos + 4, min(size, MAX_TAG)))
        if head[0] & 0x80:
            return {}
        pos += 4 + size


def _ogg(read_at):
    data = read_at(0, 256 * 1024)
    for mark in (b"\x03vorbis", b"OpusTags"):
        at = data.find(mark)
        if at >= 0:
            return _vorbis_comments(data[at + len(mark):])
    return {}


def _atoms(data, start=0, end=None):
    pos, end = start, len(data) if end is None else end
    while pos + 8 <= end:
        size = struct.unpack(">I", data[pos:pos + 4])[0]
        if size < 8 or pos + size > end:
            return
        yield data[pos + 4:pos + 8], pos + 8, pos + size
        pos += size


def _child(data, name, start, end):
    for kind, a, b in _atoms(data, start, end):
        if kind == name:
            return a, b
    return None


def _mp4(read_at, size):
    pos = 0
    while pos + 8 <= size:
        head = read_at(pos, 8)
        if len(head) < 8:
            return {}
        length = struct.unpack(">I", head[:4])[0]
        if head[4:8] == b"moov":
            data = read_at(pos, min(length, 8 * MAX_TAG))
            break
        if length < 8:
            return {}  # a form this reader doesn't handle
        pos += length
    else:
        return {}
    span = (8, len(data))
    for name in (b"udta", b"meta"):
        span = _child(data, name, *span)
        if not span:
            return {}
    ilst = _child(data, b"ilst", span[0] + 4, span[1])  # meta starts with 4 bytes of version
    if not ilst:
        return {}
    tags = {}
    for kind, a, b in _atoms(data, *ilst):
        key = MP4_ITEMS.get(kind)
        if kind == b"----":  # iTunes' free-form items, where Mixed In Key keeps the key and energy
            named = _child(data, b"name", a, b)
            key = USER_TEXT.get(data[named[0] + 4:named[1]].decode("utf-8", "replace").lower()) if named else None
        value = _child(data, b"data", a, b) if key else None
        if not value:
            continue
        body = data[value[0] + 8:value[1]]
        if key in ("track", "disc"):
            tags[key] = str(struct.unpack(">H", body[2:4])[0]) if len(body) >= 4 else ""
        elif key in ("compilation", "podcast"):
            tags[key] = str(body[0]) if body else ""
        elif key == "bpm":
            tags[key] = str(struct.unpack(">H", body[:2])[0]) if len(body) >= 2 else ""
        else:
            tags[key] = body.decode("utf-8", "replace")
    return tags


def read_tags(read_at, size):
    """{artist, albumartist, album, title, track, disc, genre, compilation, podcast, key, bpm, comment, energy,
    serato_markers (base64 text for djcues.serato_cues)}, with what was found."""
    try:
        start = read_at(0, 12)
        if start[:4] == b"fLaC":
            tags = _flac(read_at)
        elif start[:4] == b"OggS":
            tags = _ogg(read_at)
        elif start[4:8] == b"ftyp":
            tags = _mp4(read_at, size)
        else:
            tags = _id3(read_at) or _id3v1(read_at, size)
    except (IndexError, ValueError, struct.error, TypeError):
        tags = {}
    return _tidy(tags)


# ---------------------------------------------------------------------------------------------------------------
# The tag editor: every common field of an MP3, FLAC or M4A in one plain form, changed a field at a time.
#
# Where each field lives. The first name is the one written; the names in brackets are also read, and are taken
# out when the field is written so an old value can't linger beside the new one.
#
#   field        MP3 (ID3v2.3 or 2.4)               FLAC (Vorbis comment)               M4A (MP4 item)
#   title        TIT2                               TITLE                               ©nam
#   artist       TPE1                               ARTIST                              ©ART
#   album        TALB                               ALBUM                               ©alb
#   albumartist  TPE2                               ALBUMARTIST (ALBUM ARTIST)          aART
#   genre        TCON, a value per genre            GENRE, a comment per genre          ©gen
#   year         TDRC (TYER and TDAT in v2.3)       DATE (YEAR)                         ©day
#   track        TRCK "3/12"                        TRACKNUMBER + TRACKTOTAL            trkn
#                                                   (TOTALTRACKS)
#   disc         TPOS "1/2"                         DISCNUMBER + DISCTOTAL (TOTALDISCS) disk
#   composer     TCOM                               COMPOSER                            ©wrt
#   comment      COMM (the first that isn't         COMMENT (DESCRIPTION)               ©cmt
#                iTunes' own)
#   bpm          TBPM                               BPM (TEMPO)                         tmpo, whole numbers only, and
#                                                                                       ----:com.apple.iTunes:BPM
#                                                                                       when there are decimals
#   key          TKEY (TXXX:INITIALKEY, TXXX:KEY)   INITIALKEY (KEY)                    ----:com.apple.iTunes:initialkey
#                                                                                       (KEY)
#   energy       TXXX:EnergyLevel (TXXX:Energy)     ENERGYLEVEL (ENERGY)                ----:com.apple.iTunes:EnergyLevel
#                                                                                       (Energy)
#   label        TPUB                               LABEL (ORGANIZATION, PUBLISHER)     ----:com.apple.iTunes:LABEL
#                                                                                       (PUBLISHER)
#   isrc         TSRC                               ISRC                                ----:com.apple.iTunes:ISRC
#   grouping     TIT1 (GRP1, kept in step if the    GROUPING (CONTENTGROUP)             ©grp
#                file has one)
#
# Every value is text. "year" is the date as stored ("2020" or "2020-03-15"). "track" and "disc" are "3" or
# "3/12". Several genres are "Dubstep / Trap". An empty value takes the field out of the file.
# An MP3 is written as ID3v2.4 (as Fix music tags does); pictures and every frame not listed stay as they are.
# ---------------------------------------------------------------------------------------------------------------

FIELDS = ("title", "artist", "album", "albumartist", "genre", "year", "track", "disc", "composer", "comment",
          "bpm", "key", "energy", "label", "isrc", "grouping")
PADDING = 1024  # spare room left after a tag that had to grow, so the next change needn't move the audio
MAX_REGION = 64 * 1024 * 1024
MANIFEST = "manifest.json"

ID3_FIELD = {"title": "TIT2", "artist": "TPE1", "album": "TALB", "albumartist": "TPE2", "genre": "TCON",
             "year": "TDRC", "track": "TRCK", "disc": "TPOS", "composer": "TCOM", "bpm": "TBPM", "key": "TKEY",
             "label": "TPUB", "isrc": "TSRC", "grouping": "TIT1"}
ID3_USER = {"energy": ("energylevel", "energy"), "key": ("initialkey", "key")}  # TXXX descriptions, lower case
VORBIS_FIELD = {"title": ("TITLE",), "artist": ("ARTIST",), "album": ("ALBUM",),
                "albumartist": ("ALBUMARTIST", "ALBUM ARTIST"), "genre": ("GENRE",), "year": ("DATE", "YEAR"),
                "track": ("TRACKNUMBER",), "disc": ("DISCNUMBER",), "composer": ("COMPOSER",),
                "comment": ("COMMENT", "DESCRIPTION"), "bpm": ("BPM", "TEMPO"), "key": ("INITIALKEY", "KEY"),
                "energy": ("ENERGYLEVEL", "ENERGY"), "label": ("LABEL", "ORGANIZATION", "PUBLISHER"),
                "isrc": ("ISRC",), "grouping": ("GROUPING", "CONTENTGROUP")}
VORBIS_TOTAL = {"track": ("TRACKTOTAL", "TOTALTRACKS"), "disc": ("DISCTOTAL", "TOTALDISCS")}
MP4_FIELD = {"title": b"\xa9nam", "artist": b"\xa9ART", "album": b"\xa9alb", "albumartist": b"aART",
             "genre": b"\xa9gen", "year": b"\xa9day", "track": b"trkn", "disc": b"disk", "composer": b"\xa9wrt",
             "comment": b"\xa9cmt", "bpm": b"tmpo", "grouping": b"\xa9grp"}
MP4_FREE = {"bpm": ("BPM",), "key": ("initialkey", "KEY"), "energy": ("EnergyLevel", "Energy"),
            "label": ("LABEL", "PUBLISHER"), "isrc": ("ISRC",)}  # ----:com.apple.iTunes:<name>, any case
MP4_MEAN = b"com.apple.iTunes"
_COUNT = re.compile(r"^(\d+)(?:\s*/\s*(\d+))?$")


def _bpm_text(value):
    """127.98 -> "127.98", 128.0 -> "128": two decimals at most, and none when the tempo is a whole number."""
    return ("%.2f" % float(value)).rstrip("0").rstrip(".")


def _clean(kind, field, value):
    """A field's new value as the text that gets stored, so it reads back exactly as written."""
    if value is None:
        return ""
    if field == "bpm" and isinstance(value, (int, float)):
        return _bpm_text(value) if value > 0 else ""
    text = str(value).replace("\x00", "").strip()
    if field == "bpm" and text:
        try:
            text = _bpm_text(float(text.replace(",", "."))) if float(text.replace(",", ".")) > 0 else ""
        except ValueError:
            if kind == "m4a":
                raise ValueError("the tempo must be a number")
        if kind == "m4a" and text and float(text) >= 65535.5:
            raise ValueError("the tempo is too high")
    elif field in ("track", "disc") and text:
        found = _COUNT.match(text)
        if found:
            text = str(int(found.group(1))) + ("/%d" % int(found.group(2)) if found.group(2) else "")
        elif kind == "m4a":
            raise ValueError("the %s number must look like 3 or 3/12" % field)
        if kind == "m4a" and any(int(x) > 65535 for x in text.split("/")):
            raise ValueError("the %s number is too high" % field)
    elif field == "genre":
        text = " / ".join(x.strip() for x in text.split(" / ") if x.strip())
    return text


# --- MP3 -----------------------------------------------------------------------------------------------------

def _id3_frames(tag):
    if not tag:
        return []
    version, frames = id3write.parse(tag)
    return id3write._upgrade(version, frames)


def _id3_is(field, name, body, comment_at=None, at=None):
    """True when this frame holds this field."""
    if field == "comment":
        return at is not None and at == comment_at
    if name == "TXXX":
        return _id3_parts(body)[0].strip().lower() in ID3_USER.get(field, ())
    return name == ID3_FIELD.get(field) or (field == "grouping" and name == "GRP1")


def _id3_comment_at(frames):
    """Which frame is the comment: the first COMM with text that isn't one of iTunes' own (iTunNORM and so on)."""
    for i, (name, body) in enumerate(frames):
        if name == "COMM" and len(body) > 4:
            describe, text = _id3_parts(body[:1] + body[4:])
            if not describe.startswith("iTun") and text.strip():
                return i
    return None


def _id3_fields(tag):
    frames = _id3_frames(tag)
    fields, other, spare = {}, [], {}
    names = dict((frame, field) for field, frame in ID3_FIELD.items())
    comment_at = _id3_comment_at(frames)
    for i, (name, body) in enumerate(frames):
        if i == comment_at:
            fields["comment"] = _id3_parts(body[:1] + body[4:])[1].strip()
        elif name == "COMM" and len(body) > 4:
            describe, text = _id3_parts(body[:1] + body[4:])
            other.append({"name": "COMM:" + describe, "value": text.strip()})
        elif name == "TXXX":
            describe, text = _id3_parts(body)
            field = next((f for f, known in ID3_USER.items() if describe.strip().lower() in known), None)
            if field and text.strip():
                spare.setdefault(field, text.strip())
            elif len(text) > 200:
                other.append({"name": "TXXX:" + describe, "value": "", "bytes": len(body)})
            else:
                other.append({"name": "TXXX:" + describe, "value": text.strip()})
        elif name in names or name == "GRP1":
            value = " / ".join(id3write._text(body))
            if value:
                (spare if name == "GRP1" else fields).setdefault(names.get(name, "grouping"), value)
        elif name[:1] == "T":
            other.append({"name": name, "value": " / ".join(id3write._text(body))})
        else:
            other.append({"name": name, "value": "", "bytes": len(body)})
    for field, value in spare.items():
        fields.setdefault(field, value)
    return fields, other


def _id3_edit(tag, changes):
    frames = _id3_frames(tag)
    for field, value in changes.items():
        comment_at = _id3_comment_at(frames)
        found = [i for i, (name, body) in enumerate(frames) if _id3_is(field, name, body, comment_at, i)]
        new = []
        while field == "comment" and not value and comment_at is not None:  # or the next one would show instead
            frames = frames[:comment_at] + frames[comment_at + 1:]
            comment_at, found = _id3_comment_at(frames), []
        if value and field == "comment":
            head = frames[found[0]][1] if found else b"\x03eng\x00"
            describe = _id3_parts(head[:1] + head[4:])[0]
            new = [("COMM", b"\x03" + head[1:4] + (describe + "\x00" + value).encode("utf-8"))]
        elif value and field == "energy":
            new = [("TXXX", id3write.user_frame("EnergyLevel", [value]))]
        elif value:
            new = [(ID3_FIELD[field], id3write.text_frame(value.split(" / ") if field == "genre" else [value]))]
            if field == "grouping" and any(frames[i][0] == "GRP1" for i in found):
                new.append(("GRP1", id3write.text_frame([value])))
        at = found[0] if found else len(frames)
        frames = [f for i, f in enumerate(frames[:at]) if i not in found] + new + \
                 [f for i, f in enumerate(frames[at:], at) if i not in found]
    body = b"".join(name.encode("latin-1") + id3write.synchsafe(len(data)) + b"\x00\x00" + data
                    for name, data in frames)
    size = len(tag) if len(body) + 10 <= len(tag) else len(body) + 10 + PADDING  # the same size when it fits
    return b"ID3\x04\x00\x00" + id3write.synchsafe(size - 10) + body + bytes(size - 10 - len(body))


# --- FLAC ----------------------------------------------------------------------------------------------------

def _flac_blocks(region):
    """[(block type, block data)] from a FLAC file's metadata blocks."""
    blocks, pos = [], 0
    while pos + 4 <= len(region):
        size = (region[pos + 1] << 16) | (region[pos + 2] << 8) | region[pos + 3]
        blocks.append((region[pos] & 0x7f, region[pos + 4:pos + 4 + size]))
        pos += 4 + size
    if pos != len(region):
        raise Unsupported("damaged FLAC file")
    return blocks


def _vorbis_list(data):
    """(vendor bytes, [(name, value)]) from a Vorbis comment block."""
    size = struct.unpack("<I", data[:4])[0]
    vendor, pos = data[4:4 + size], 4 + size
    count = struct.unpack("<I", data[pos:pos + 4])[0]
    pos += 4
    comments = []
    for _ in range(count):
        size = struct.unpack("<I", data[pos:pos + 4])[0]
        if pos + 4 + size > len(data):
            raise Unsupported("damaged FLAC comments")
        name, _, value = data[pos + 4:pos + 4 + size].decode("utf-8", "replace").partition("=")
        comments.append((name, value))
        pos += 4 + size
    return vendor, comments


def _flac_fields(region):
    blocks = _flac_blocks(region)
    comments = next((_vorbis_list(data)[1] for kind, data in blocks if kind == 4), [])
    have = {}
    for name, value in comments:
        if value.strip():
            have.setdefault(name.upper(), []).append(value.strip())
    fields = {}
    for field, names in VORBIS_FIELD.items():
        values = next((have[n] for n in names if n in have), [])
        if values:
            fields[field] = " / ".join(values) if field == "genre" else values[0]
    for field, names in VORBIS_TOTAL.items():
        total = next((have[n][0] for n in names if n in have), "")
        if fields.get(field) and total and "/" not in fields[field]:
            fields[field] += "/" + total
    known = set(n for names in list(VORBIS_FIELD.values()) + list(VORBIS_TOTAL.values()) for n in names)
    other = [{"name": name, "value": value} if len(value) <= 200 else {"name": name, "value": "", "bytes": len(value)}
             for name, value in comments if name.upper() not in known]
    other += [{"name": "PICTURE", "value": "", "bytes": len(data)} for kind, data in blocks if kind == 6]
    return fields, other


def _flac_edit(region, changes):
    blocks = [(kind, data) for kind, data in _flac_blocks(region) if kind != 1]  # the padding is worked out again
    at = next((i for i, (kind, _) in enumerate(blocks) if kind == 4), None)
    vendor, comments = _vorbis_list(blocks[at][1]) if at is not None else (b"Sortovia", [])
    for field, value in changes.items():
        gone = set(VORBIS_FIELD[field] + VORBIS_TOTAL.get(field, ()))
        new = []
        if value and field in VORBIS_TOTAL:
            number, _, total = value.partition("/")
            new = [(VORBIS_FIELD[field][0], number)] + ([(VORBIS_TOTAL[field][0], total)] if total else [])
        elif value:
            new = [(VORBIS_FIELD[field][0], x) for x in (value.split(" / ") if field == "genre" else [value])]
        first = next((i for i, (name, _) in enumerate(comments) if name.upper() in gone), len(comments))
        comments = [c for c in comments[:first] if c[0].upper() not in gone] + new + \
                   [c for c in comments[first:] if c[0].upper() not in gone]
    data = struct.pack("<I", len(vendor)) + vendor + struct.pack("<I", len(comments))
    for name, value in comments:
        entry = ("%s=%s" % (name, value)).encode("utf-8")
        data += struct.pack("<I", len(entry)) + entry
    if at is None:
        blocks.insert(1 if blocks else 0, (4, data))  # after the stream's own block, which must come first
    else:
        blocks[at] = (4, data)
    used = sum(4 + len(data) for _, data in blocks)
    if used != len(region):
        room = len(region) - used - 4
        blocks.append((1, bytes(room if 0 <= room < 1 << 24 else PADDING)))  # the same size when it fits
    out = b""
    for i, (kind, data) in enumerate(blocks):
        if len(data) >= 1 << 24:
            raise Unsupported("the tags are too large for a FLAC file")
        out += bytes([kind | (0x80 if i == len(blocks) - 1 else 0)]) + struct.pack(">I", len(data))[1:] + data
    return out


# --- M4A -----------------------------------------------------------------------------------------------------

def _atom(kind, body):
    return struct.pack(">I", len(body) + 8) + kind + body


def _mp4_data(kind, payload):
    return _atom(b"data", struct.pack(">II", kind, 0) + payload)  # kind 1 is text, 21 a number, 0 a number pair


def _mp4_free(name, value):
    return _atom(b"----", _atom(b"mean", bytes(4) + MP4_MEAN) + _atom(b"name", bytes(4) + name.encode("utf-8")) +
                 _mp4_data(1, value.encode("utf-8")))


def _mp4_ilst(moov):
    """(udta span, meta span, ilst span) inside a moov atom; None for each that isn't there."""
    kids = list(_atoms(moov, 8))
    if (kids[-1][2] if kids else 8) != len(moov):
        raise Unsupported("damaged M4A file")
    udta = _child(moov, b"udta", 8, len(moov))
    meta = _child(moov, b"meta", *udta) if udta else None
    ilst = _child(moov, b"ilst", meta[0] + 4, meta[1]) if meta else None  # meta starts with 4 bytes of version
    return udta, meta, ilst


def _mp4_items(moov, ilst):
    """[(name, kind of data, payload, whole item's bytes)]: name is the 4 letters, or for a free-form item
    "----:com.apple.iTunes:initialkey". The payload is the first value's."""
    items = []
    for kind, a, b in _atoms(moov, *ilst) if ilst else ():
        name = kind.decode("latin-1")
        if kind == b"----":
            mean, named = _child(moov, b"mean", a, b), _child(moov, b"name", a, b)
            name = "----:%s:%s" % (moov[mean[0] + 4:mean[1]].decode("utf-8", "replace") if mean else "",
                                   moov[named[0] + 4:named[1]].decode("utf-8", "replace") if named else "")
        value = _child(moov, b"data", a, b)
        body = moov[value[0]:value[1]] if value else b""
        items.append((name, struct.unpack(">I", body[:4])[0] & 0xffffff if len(body) >= 8 else -1, body[8:],
                      moov[a - 8:b]))
    return items


def _mp4_is(field, name):
    if name.startswith("----:"):
        return name.rsplit(":", 1)[-1].lower() in [x.lower() for x in MP4_FREE.get(field, ())]
    return name.encode("latin-1") == MP4_FIELD.get(field)


def _mp4_fields(moov):
    fields, other, exact = {}, [], ""
    for name, kind, payload, _ in _mp4_items(moov, _mp4_ilst(moov)[2]):
        field = next((f for f in FIELDS if _mp4_is(f, name)), None)
        if field in ("track", "disc") and len(payload) >= 4:
            number, total = struct.unpack(">H", payload[2:4])[0], struct.unpack(">H", payload[4:6] or b"\0\0")[0]
            value = ("%d/%d" % (number, total) if total else str(number)) if number or total else ""
        elif field == "bpm" and not name.startswith("----:"):
            value = str(struct.unpack(">H", payload[:2])[0] or "") if len(payload) >= 2 else ""
        elif kind == 1:
            value = payload.decode("utf-8", "replace").replace("\x00", "").strip()
        else:
            field, value = None, ""
        if field == "bpm" and name.startswith("----:"):
            exact = value
        elif field and value:
            fields.setdefault(field, value)
        elif not field:
            shown = name.replace("\xa9", "©")
            other.append({"name": shown, "value": value} if kind == 1 and len(value) <= 200
                         else {"name": shown, "value": "", "bytes": len(payload)})
    try:  # the tempo with its decimals, when it agrees with the whole number every app reads
        if exact and fields.get("bpm", str(int(round(float(exact))))) == str(int(round(float(exact)))):
            fields["bpm"] = _bpm_text(float(exact))
    except ValueError:
        pass
    return fields, other


def _mp4_shift(moov, start, by):
    """Move every chunk position past the moov atom by this much, as the audio after it has moved."""
    def walk(a, b):
        for kind, x, y in _atoms(moov, a, b):
            if kind in (b"trak", b"mdia", b"minf", b"stbl"):
                walk(x, y)
            elif kind in (b"stco", b"co64"):
                form, width = (">I", 4) if kind == b"stco" else (">Q", 8)
                count = struct.unpack(">I", moov[x + 4:x + 8])[0]
                if x + 8 + count * width > y:
                    raise Unsupported("damaged M4A file")
                for at in range(x + 8, x + 8 + count * width, width):
                    position = struct.unpack(form, moov[at:at + width])[0]
                    if position > start:
                        if position + by >= 1 << (8 * width):
                            raise Unsupported("the file is too large to make room for the tags")
                        moov[at:at + width] = struct.pack(form, position + by)
    walk(8, len(moov))


def _mp4_edit(moov, start, changes):
    udta, meta, ilst = _mp4_ilst(moov)
    items = [(name, raw) for name, _, _, raw in _mp4_items(moov, ilst)]
    for field, value in changes.items():
        new = []
        if value and field in ("track", "disc"):
            number, _, total = value.partition("/")
            pair = struct.pack(">HHH", 0, int(number), int(total or 0)) + (bytes(2) if field == "track" else b"")
            new = [("", _atom(MP4_FIELD[field], _mp4_data(0, pair)))]
        elif value and field == "bpm":
            new = [("", _atom(b"tmpo", _mp4_data(21, struct.pack(">H", int(round(float(value)))))))]
            if "." in value:
                new.append(("", _mp4_free(MP4_FREE["bpm"][0], value)))
        elif value and field in MP4_FIELD:
            new = [("", _atom(MP4_FIELD[field], _mp4_data(1, value.encode("utf-8"))))]
        elif value:
            new = [("", _mp4_free(MP4_FREE[field][0], value))]
        first = next((i for i, (name, _) in enumerate(items) if _mp4_is(field, name)), len(items))
        items = [x for x in items[:first] if not _mp4_is(field, x[0])] + new + \
                [x for x in items[first:] if not _mp4_is(field, x[0])]
    new_ilst = _atom(b"ilst", b"".join(raw for _, raw in items))
    spare = _atom(b"free", bytes(PADDING))
    if ilst:
        begin, end = ilst[0] - 8, ilst[1]
        while end + 8 <= meta[1] and moov[end + 4:end + 8] == b"free":  # spare room right after the tags
            size = struct.unpack(">I", moov[end:end + 4])[0]
            if size < 8 or end + size > meta[1]:
                break
            end += size
        room = end - begin - len(new_ilst)
        if room == 0:
            spare = b""
        elif room >= 8:
            spare = _atom(b"free", bytes(room - 8))  # the same size, so nothing else in the file moves
        meta_body = moov[meta[0]:begin] + new_ilst + spare + moov[end:meta[1]]
    elif meta:
        meta_body = moov[meta[0]:meta[1]] + new_ilst + spare
    else:
        meta_body = bytes(4) + _atom(b"hdlr", bytes(8) + b"mdirappl" + bytes(9)) + new_ilst + spare
    new_meta = _atom(b"meta", meta_body)
    if meta:
        udta_body = moov[udta[0]:meta[0] - 8] + new_meta + moov[meta[1]:udta[1]]
    else:
        udta_body = (moov[udta[0]:udta[1]] if udta else b"") + new_meta
    if udta:
        body = moov[8:udta[0] - 8] + _atom(b"udta", udta_body) + moov[udta[1]:]
    else:
        body = moov[8:] + _atom(b"udta", udta_body)
    out = bytearray(_atom(b"moov", body))
    if len(out) != len(moov):
        _mp4_shift(out, start, len(out) - len(moov))
    return bytes(out)


# --- Any of the three ----------------------------------------------------------------------------------------

def _locate(read_at, size):
    """(kind, start, length, fixed) for the part of the file that holds the tags: an MP3's ID3v2 tag, a FLAC's
    metadata blocks, an M4A's moov atom. fixed: the part can't change size (a fragmented M4A)."""
    head = read_at(0, 12)
    front = id3write.tag_size(head[:10])
    if head[:4] == b"fLaC" or (front and read_at(front, 4) == b"fLaC"):
        pos = begin = (0 if head[:4] == b"fLaC" else front) + 4
        while True:
            block = read_at(pos, 4)
            if len(block) < 4:
                raise Unsupported("damaged FLAC file")
            pos += 4 + ((block[1] << 16) | (block[2] << 8) | block[3])
            if block[0] & 0x80:
                break
        if pos > size or pos - begin > MAX_REGION:
            raise Unsupported("damaged FLAC file")
        return "flac", begin, pos - begin, False
    if head[4:8] == b"ftyp":
        pos, moov, pieces = 0, None, False
        while pos + 8 <= size:
            atom = read_at(pos, 16)
            length = struct.unpack(">I", atom[:4])[0] if len(atom) >= 8 else -1
            if length == 1 and len(atom) == 16:
                length = struct.unpack(">Q", atom[8:16])[0]
            elif length == 0:
                length = size - pos
            if length < 8 or pos + length > size:
                raise Unsupported("damaged M4A file")
            if atom[4:8] == b"moov" and not moov:
                moov = (pos, length)
            pieces = pieces or atom[4:8] == b"moof"
            pos += length
        if not moov or moov[1] > MAX_REGION or struct.unpack(">I", read_at(moov[0], 4))[0] == 1:
            raise Unsupported("this M4A file's tags can't be found")
        return "m4a", moov[0], moov[1], pieces
    if head[:4] == b"OggS":
        raise Unsupported("Ogg files can be read but not changed")
    if front > MAX_REGION:
        raise Unsupported("the tag is too large")
    if not front and not (len(head) > 1 and head[0] == 0xff and head[1] & 0xe0 == 0xe0):
        raise Unsupported("not an MP3, FLAC or M4A file")
    return "mp3", 0, front, False


def _fields(kind, region):
    return {"mp3": _id3_fields, "flac": _flac_fields, "m4a": _mp4_fields}[kind](region)


def _plan(read_at, size, changes):
    """What a change comes to: None when the file already says all of it, else (kind, start, old part, new
    part, {field: {"old", "new"}})."""
    unknown = [k for k in changes if k not in FIELDS]
    if unknown:
        raise ValueError("not a field that can be changed: %s" % ", ".join(sorted(unknown)))
    try:
        kind, start, length, fixed = _locate(read_at, size)
        old = read_at(start, length)
        if len(old) != length:
            raise Unsupported("the file is shorter than it says")
        now = _fields(kind, old)[0]
        wanted = dict((field, _clean(kind, field, value)) for field, value in changes.items())
        wanted = dict((field, value) for field, value in wanted.items() if value != now.get(field, ""))
        if not wanted:
            return None
        if kind == "mp3":
            new = _id3_edit(old, wanted)
        elif kind == "flac":
            new = _flac_edit(old, wanted)
        else:
            new = _mp4_edit(old, start, wanted)
        after = _fields(kind, new)[0]
    except (IndexError, struct.error, TypeError) as e:
        raise Unsupported("damaged tags (%s)" % e)
    if fixed and len(new) != len(old):
        raise Unsupported("this M4A file is in pieces, which leaves no room for longer tags")
    wrong = [field for field, value in wanted.items() if after.get(field, "") != value]
    if wrong or any(after.get(f, "") != now.get(f, "") for f in FIELDS if f not in wanted):
        raise Unsupported("the new tags didn't read back as written (%s)" % ", ".join(wrong or ["another field"]))
    return kind, start, old, new, dict((f, {"old": now.get(f, ""), "new": v}) for f, v in wanted.items())


def _open(path, mode):
    """path: a file's path, or an open file descriptor (a number), which is left open."""
    return open(path, mode, closefd=not isinstance(path, int))


def _reader(f):
    def read_at(offset, count):
        f.seek(offset)
        return f.read(count)
    return read_at, os.fstat(f.fileno()).st_size


def read_all_at(read_at, size):
    """read_all for a file reached through read_at(offset, count), as read_tags is."""
    out = dict((field, "") for field in FIELDS)
    out.update(format="", other=[], can_edit=False, why="")
    try:
        kind, start, length, _ = _locate(read_at, size)
        fields, other = _fields(kind, read_at(start, length))
        out.update(fields, format=kind, other=other, can_edit=True)
        if kind == "mp3" and not length:  # only the old kind of tag at the end of the file: shown, not kept up
            out.update((k, str(v)) for k, v in _tidy(_id3v1(read_at, size)).items() if k in FIELDS)
    except (Unsupported, IndexError, ValueError, struct.error, TypeError) as e:
        out.update((k, str(v)) for k, v in read_tags(read_at, size).items() if k in FIELDS)
        out["why"] = str(e) if isinstance(e, Unsupported) else "damaged tags"
    out["camelot"] = _key_code(out["key"])
    return out


def read_all(path):
    """Every common field of an MP3, FLAC or M4A as text ("" when the file doesn't have it): title, artist,
    album, albumartist, genre, year, track, disc, composer, comment, bpm, key, energy, label, isrc, grouping
    (the table above says where each one lives). As well: "format" ("mp3", "flac", "m4a"); "camelot", the key as
    a Camelot code when it's understood; "other", everything else in the tag to show but not change:
    [{"name": "TXXX:Rating" or "ENCODER" or "©too", "value": text}], with "bytes" in place of text for pictures
    and long data; "can_edit", and "why" not when it's False (an Ogg file, an unusual or damaged tag: what could
    be read is still given). path: a path, or an open file descriptor."""
    with _open(path, "rb") as f:
        return read_all_at(*_reader(f))


def _put(path, start, length, new):
    """Replace length bytes at start with new. The same size is written in place. Otherwise a whole new file
    is made beside this one and swapped in, so a stop half way leaves the old file; an open descriptor has no
    place for one, so the rest of the file is moved along inside it."""
    if len(new) != length and not isinstance(path, int) and not str(path).startswith("/proc/"):
        path = os.path.realpath(path)  # the file itself, not a link to it
        temp = "%s.sortovia-new" % path
        try:
            out = open(temp, "wb")
        except OSError:
            out = None  # nowhere to put a new file: change this one
        if out:
            try:
                with out, open(path, "rb") as f:
                    for begin, count, piece in ((0, start, b""), (start + length, -1, new)):
                        out.write(piece)
                        f.seek(begin)
                        while count:
                            block = f.read(min(1 << 20, count) if count > 0 else 1 << 20)
                            if not block:
                                break
                            out.write(block)
                            count -= len(block) if count > 0 else 0
                    out.flush()
                    os.fsync(out.fileno())
                try:
                    os.chmod(temp, os.stat(path).st_mode & 0o7777)
                except OSError:
                    pass
                os.replace(temp, path)
            except Exception:
                try:
                    os.remove(temp)
                except OSError:
                    pass
                raise
            return
    with _open(path, "r+b") as f:
        rest = b""
        if len(new) != length:
            f.seek(start + length)
            rest = f.read()
        f.seek(start)
        f.write(new + rest)
        if len(new) != length:
            f.truncate()
        f.flush()
        os.fsync(f.fileno())


def _save_json(path, value):
    with open(path + ".new", "w", encoding="utf-8") as f:
        json.dump(value, f)
    os.replace(path + ".new", path)


def _load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def write_fields(path, changes, manifest_dir, batch=None, ref=None):
    """Write the fields in changes ({field: text}; "" or None takes a field out) that differ from what the file
    says, leaving everything else in the tag as it is. Before the file is touched its old tag is saved under
    manifest_dir, the way Fix music tags saves one: a folder named for the time, the old tag as a file in it
    and a manifest.json listing {"path", "ref", "tag", "format", "start", "length", "crc", "fields": {field:
    {"old", "new"}}}. undo_last puts it back.

    Returns {"changed": {field: {"old", "new"}}, "batch": the folder's name}; "changed" is empty, and nothing is
    written or saved, when the file already says all of it. Pass a call's "batch" to the next to keep several
    files (Save analysis to tags for a whole folder) in one undo. ref: anything to find the file by later, kept
    in the manifest (the app's document URI, when path is an open file descriptor).
    Raises Unsupported with a plain reason for a file that can't be changed, ValueError for a value that can't
    be stored (an M4A's tempo and track number must be numbers), OSError when writing fails."""
    with _open(path, "rb") as f:
        plan = _plan(*_reader(f), changes=changes)
    if not plan:
        return {"changed": {}, "batch": batch or ""}
    kind, start, old, new, changed = plan
    if not batch:
        batch = stamp = time.strftime("%Y%m%d-%H%M%S")
        count = 1
        while os.path.exists(os.path.join(manifest_dir, batch)):
            count += 1
            batch = "%s-%d" % (stamp, count)
    folder = os.path.join(manifest_dir, batch)
    os.makedirs(folder, exist_ok=True)
    manifest = _load_json(os.path.join(folder, MANIFEST))
    number = len(manifest)
    while os.path.exists(os.path.join(folder, "%05d.tag" % number)):
        number += 1
    with open(os.path.join(folder, "%05d.tag" % number), "wb") as f:
        f.write(old)
    manifest.append({"path": str(path), "ref": ref, "tag": "%05d.tag" % number, "format": kind, "start": start,
                     "length": len(new), "crc": zlib.crc32(new) & 0xffffffff, "fields": changed})
    _save_json(os.path.join(folder, MANIFEST), manifest)
    _put(path, start, len(old), new)
    return {"changed": changed, "batch": batch}


def _last_batch(manifest_dir):
    names = sorted(n for n in (os.listdir(manifest_dir) if os.path.isdir(manifest_dir) else [])
                   if os.path.isfile(os.path.join(manifest_dir, n, MANIFEST)))
    return names[-1] if names else ""


def can_undo(manifest_dir):
    return bool(_last_batch(manifest_dir))


def undo_last(manifest_dir, path_for=None):
    """Put back the tags from the last write_fields batch, newest change first. A file whose tag isn't the one
    that was written (changed again since, moved, gone) is reported and left alone. path_for(entry) gives the
    path or open file descriptor for a manifest entry when its saved "path" won't do (the app looks it up by
    "ref"). Returns {"changed": how many, "failed": [{"name", "why"}], "batch"}. A batch that's all put back has
    its manifest.json renamed undone.json, so the next undo goes to the batch before; entries that failed stay
    for another try."""
    batch = _last_batch(manifest_dir)
    if not batch:
        return {"changed": 0, "failed": [], "batch": ""}
    folder = os.path.join(manifest_dir, batch)
    manifest = _load_json(os.path.join(folder, MANIFEST))
    changed, failed, remaining, stuck = 0, [], [], set()
    for entry in reversed(manifest):
        try:
            if (entry.get("ref") or entry["path"]) in stuck:  # an earlier change to it can't go back before a later one has
                raise Unsupported("a later change to it couldn't be put back")
            path = path_for(entry) if path_for else entry["path"]
            with open(os.path.join(folder, entry["tag"]), "rb") as f:
                old = f.read()
            with _open(path, "rb") as f:
                f.seek(entry["start"])
                now = f.read(entry["length"])
            if len(now) != entry["length"] or zlib.crc32(now) & 0xffffffff != entry["crc"]:
                raise Unsupported("its tags have changed since")
            _put(path, entry["start"], entry["length"], old)
            changed += 1
        except Exception as e:
            stuck.add(entry.get("ref") or entry.get("path"))
            remaining.insert(0, entry)
            failed.append({"name": os.path.basename(str(entry.get("path") or "")), "why": str(e)})
    if remaining:
        _save_json(os.path.join(folder, MANIFEST), remaining)
    else:
        os.replace(os.path.join(folder, MANIFEST), os.path.join(folder, "undone.json"))
    return {"changed": changed, "failed": failed, "batch": batch}


# --- Analysis to tags ----------------------------------------------------------------------------------------

def _key_code(text):
    """The Camelot code for a key however it's written, including "8A - Am" and "8A/Am"; "" if it isn't one."""
    text = str(text or "").strip()
    for part in [text] + re.split(r"\s+-\s+|/", text):
        code = djkeys.camelot(part)
        if code:
            return code
    return ""


def _energy(value):
    try:
        return max(0, min(10, int(round(float(value or 0)))))
    except (TypeError, ValueError):
        return 0


def analysis_fields(analysis, key_style="musical"):
    """The fields Save analysis to tags writes, from a Sortovia analysis: {"bpm", "key", "energy"}, each only
    when the analysis found it. Give the result to write_fields.

    bpm: the tempo shown and mixed by ("shown_bpm", else "bpm") with two decimals at most and none for a whole
    number: "128", "127.98". The ID3 standard asks for a whole number in TBPM, but rekordbox, Serato, Traktor
    and Mixed In Key all write decimals there and read them, and a rounded 127.98 would drift against the grid.
    An M4A's tmpo can only hold a whole number, so the decimals go beside it (see the table).
    key: one notation per file, as DJ software reads one tag. "musical" (the default) is what the standard and
    every DJ program understand: "Am", "F#m", "Bb". "camelot" is "8A", Mixed In Key's own default for the key
    tag. "both" is "8A - Am", for reading on a screen; software may not take it as a key.
    energy: 1 to 10, in Mixed In Key's EnergyLevel tag."""
    analysis = analysis or {}
    out = {}
    try:
        tempo = float(analysis.get("shown_bpm") or analysis.get("bpm") or 0)
    except (TypeError, ValueError):
        tempo = 0
    if tempo > 0:
        out["bpm"] = _bpm_text(tempo)
    code = _key_code(analysis.get("key"))
    if code:
        name = djkeys.key_name(code)
        out["key"] = {"camelot": code, "both": "%s - %s" % (code, name)}.get(key_style, name)
    if _energy(analysis.get("energy_estimate")):
        out["energy"] = str(_energy(analysis.get("energy_estimate")))
    return out


def _cue_names(analysis):
    """The names of an analysis's cue points, in order (its sections when it has no cues)."""
    marks = (analysis or {}).get("cues") or (analysis or {}).get("sections") or []
    return [str(m.get("label") or m.get("name") or "Cue") if isinstance(m, dict) else "Cue" for m in marks]


def compare_at(read_at, size, last_analysis, this_analysis):
    """compare for a file reached through read_at(offset, count)."""
    in_file = read_all_at(read_at, size)
    try:
        import djcues
        file_cues = len(djcues.serato_cues(read_tags(read_at, size).get("serato_markers") or ""))
    except Exception:
        file_cues = 0
    rows = []
    for field, label in (("bpm", "BPM"), ("key", "Key"), ("energy", "Energy")):
        texts, same = [], []
        for i, value in enumerate((in_file[field], (analysis_fields(last_analysis, "camelot")).get(field, ""),
                                   (analysis_fields(this_analysis, "camelot")).get(field, ""))):
            if field == "bpm":
                number = djkeys.bpm(value)
                value, match = (_bpm_text(number) if number else value), (round(number, 2) if number else value)
            elif field == "key":
                code = _key_code(value)
                value, match = ("%s (%s)" % (code, djkeys.key_name(code)) if code else value), code or value.lower()
            else:
                match = _energy(value) or value
            texts.append(value)
            same.append(match)
        rows.append({"field": field, "label": label, "in_file": texts[0], "last": texts[1], "this": texts[2],
                     "differs": len(set(x for x in same if x)) > 1})
    last, this = _cue_names(last_analysis), _cue_names(this_analysis)
    rows.append({"field": "cues", "label": "Cue points", "in_file": str(file_cues) if file_cues else "",
                 "last": str(len(last)) if last else "", "this": str(len(this)) if this else "",
                 "last_names": last, "this_names": this,
                 "differs": bool(last and this and last != this) or
                 len(set(x for x in (file_cues, len(last), len(this)) if x)) > 1})
    return rows


def compare(path, last_analysis, this_analysis):
    """Rows for a three-column screen: what the file's tags say, what the analysis before this one found, and
    what this one found. [{"field": "bpm" | "key" | "energy" | "cues", "label", "in_file", "last", "this",
    "differs"}], every value text ready to show and "" where there's nothing. The tempo is shown with two
    decimals at most; a key as "8A (Am)" however the file wrote it; cues as how many (in the file: Serato's cue
    points, the only ones a file's tags hold), with the names in "last_names" and "this_names". differs: the
    values that are there don't all agree (for cues: a different count, or different names between the two
    analyses). Either analysis may be None. path: a path, or an open file descriptor."""
    with _open(path, "rb") as f:
        return compare_at(*_reader(f), last_analysis=last_analysis, this_analysis=this_analysis)
