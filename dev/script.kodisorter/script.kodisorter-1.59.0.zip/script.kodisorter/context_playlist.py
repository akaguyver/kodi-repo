"""Hold down a song or album in Kodi's music library: add it to a playlist."""
import xbmc

if __name__ == "__main__":
    kind = xbmc.getInfoLabel("ListItem.DBTYPE") or "song"
    dbid = xbmc.getInfoLabel("ListItem.DBID")
    xbmc.executebuiltin("RunPlugin(plugin://script.kodisorter/?action=playlist_add&type=%s&id=%s)" % (kind, dbid))
