"""DJ tools on the Xbox, through Kodi's JSON-RPC: play a playlist in mixing order (by key, building up or winding
down), what mixes after a song, Kodi's crossfade, and a playlist from elsewhere made into a Kodi playlist.

Kodi can't beat-match, so these only choose the order and let Kodi crossfade. Keys, tempos and energy come from
the files' tags (Mixed In Key, rekordbox, Serato, Traktor), read once and kept in a cache. Nothing here touches
Kodi's modules, so it runs in tests: rpc(method, params) and read_tags(path) are passed in.
"""
import re

import djkeys
import playlists

PLAYLISTS = "special://profile/playlists/music/"
PLAYLIST_TYPES = (".m3u", ".m3u8", ".xsp", ".pls")
OWN = ".m3u"  # what Sortovia saves: Kodi's Playlists list shows .m3u (it can miss .m3u8)
QUEUE = 0  # Kodi's music play queue
CROSSFADE = "musicplayer.crossfade"
CROSSFADE_ALBUM = "musicplayer.crossfadealbumtracks"
CROSSFADE_CHOICES = (0, 2, 4, 6, 8, 10, 15)
ORDERS = (("keys", "Key order", "Each song mixes into the next. The first song stays first."),
          ("harder", "Build up", "Starts with the softest song and builds energy and tempo."),
          ("softer", "Wind down", "Starts with the hardest song and winds down."),
          ("live", "Live set", "Warms up, builds to a peak about three quarters in, then cools down."),
          ("waves", "Peaks and valleys", "Harder, then softer, again and again through the set."))
PAGE = 500


def library_songs(rpc):
    """[{path, artist, title, genre, bpm}] for every song in Kodi's music library."""
    out, start = [], 0
    fields = ["file", "artist", "title", "genre", "bpm"]
    while True:
        try:
            reply = rpc("AudioLibrary.GetSongs", {"properties": fields, "limits": {"start": start, "end": start + PAGE}})
        except IOError:
            if "bpm" not in fields:
                raise
            fields.remove("bpm")  # Kodi before 19 has no bpm field
            continue
        songs = reply.get("songs") or []
        out += [_song(s) for s in songs]
        start += len(songs)
        if not songs or start >= int((reply.get("limits") or {}).get("total", 0)):
            return out


def _song(item):
    def joined(value):
        return ", ".join(value) if isinstance(value, list) else (value or "")
    return {"path": item.get("file") or "", "artist": joined(item.get("artist")),
            "title": item.get("title") or item.get("label") or "", "genre": joined(item.get("genre")),
            "bpm": djkeys.bpm(item.get("bpm"))}


def saved_playlists(rpc):
    """[(name, path)] of the music playlists Kodi has saved."""
    try:
        files = rpc("Files.GetDirectory", {"directory": PLAYLISTS, "media": "files"}).get("files") or []
    except IOError:
        return []
    out = [(re.sub(r"\.[^.]+$", "", f.get("label") or ""), f.get("file") or "") for f in files
           if (f.get("file") or "").lower().endswith(PLAYLIST_TYPES)]
    return sorted(out, key=lambda p: p[0].lower())


def playlist_songs(rpc, path):
    """The songs in a saved playlist (plain or smart), in its order."""
    reply = rpc("Files.GetDirectory", {"directory": path, "media": "music", "properties": ["file", "artist", "title", "genre"]})
    return [_song(f) for f in reply.get("files") or [] if f.get("filetype") != "directory" and f.get("file")]


def queue_songs(rpc):
    reply = rpc("Playlist.GetItems", {"playlistid": QUEUE, "properties": ["file", "artist", "title", "genre"]})
    return [_song(i) for i in reply.get("items") or [] if i.get("file")]


def dj_details(songs, cache, read_tags, step=None):
    """Adds camelot, bpm and energy to each song, from the cache or the file's tags (and Kodi's bpm if the tags
    have none). Fills the cache as it goes. step(done, total) returning False stops early. Returns the songs."""
    for done, song in enumerate(songs):
        found = cache.get(song["path"])
        if found is None:
            if step and step(done, len(songs)) is False:
                break
            try:
                info = djkeys.dj_info(read_tags(song["path"]) or {})
            except Exception:
                info = {"camelot": "", "bpm": 0.0, "energy": 0}
            found = cache[song["path"]] = [info["camelot"], info["bpm"], info["energy"]]
        song["camelot"], song["energy"] = found[0], found[2]
        song["bpm"] = found[1] or song.get("bpm") or 0.0
    return songs


def describe(song):
    """"8A  124 BPM  energy 6" with only the parts known."""
    parts = [song.get("camelot") or ""]
    if song.get("bpm"):
        parts.append("%d BPM" % round(song["bpm"]))
    if song.get("energy"):
        parts.append("energy %d" % song["energy"])
    return "  ".join(p for p in parts if p)


def song_name(song):
    return " - ".join(p for p in (song.get("artist"), song.get("title")) if p) or song.get("path", "").split("/")[-1]


def what_mixes_after(path, songs, limit=25):
    """(the song, [(song, reason)]) for the song at path, or (None, []) if it isn't in the library."""
    current = next((s for s in songs if s["path"] == path), None)
    if not current or not current.get("camelot"):
        return current, []
    return current, djkeys.suggest(current, [s for s in songs if s.get("camelot")], limit=limit)


def without_key(songs):
    return sum(1 for s in songs if not s.get("camelot"))


def play(rpc, songs):
    """Replace the music queue with these songs and start the first."""
    rpc("Playlist.Clear", {"playlistid": QUEUE})
    rpc("Playlist.Add", {"playlistid": QUEUE, "item": [{"file": s["path"]} for s in songs]})
    rpc("Player.Open", {"item": {"playlistid": QUEUE, "position": 0}})


def playing(rpc):
    """(player id, position in the queue, file) of the music playing now, or None."""
    players = rpc("Player.GetActivePlayers", {}) or []
    audio = next((p for p in players if p.get("type") == "audio"), None)
    if not audio:
        return None
    pid = audio.get("playerid", QUEUE)
    position = rpc("Player.GetProperties", {"playerid": pid, "properties": ["position"]}).get("position", -1)
    item = rpc("Player.GetItem", {"playerid": pid, "properties": ["file"]}).get("item") or {}
    return pid, position, item.get("file") or ""


def play_next(rpc, song):
    """Put the song straight after the one playing, or play it now if nothing is. True if it went in the queue."""
    now = playing(rpc)
    if not now or now[1] < 0:
        play(rpc, [song])
        return False
    rpc("Playlist.Insert", {"playlistid": QUEUE, "position": now[1] + 1, "item": {"file": song["path"]}})
    return True


def crossfade(rpc):
    """Kodi's crossfade between songs, in seconds (0 is off), or None if Kodi wouldn't say."""
    try:
        return int(rpc("Settings.GetSettingValue", {"setting": CROSSFADE}).get("value") or 0)
    except (IOError, ValueError, TypeError):
        return None


def set_crossfade(rpc, seconds):
    """Turn Kodi's crossfade on (or off, 0). Turning it on also turns on crossfading songs from the same album, in
    case it was off: then Kodi plays them gapless, which sounds like no crossfade at all in one album's folder."""
    rpc("Settings.SetSettingValue", {"setting": CROSSFADE, "value": int(seconds)})
    if seconds:
        try:
            rpc("Settings.SetSettingValue", {"setting": CROSSFADE_ALBUM, "value": True})
        except (IOError, ValueError, TypeError):
            pass  # an older Kodi without the setting
    return crossfade(rpc) == int(seconds)


def crossfade_label(seconds):
    if seconds is None:
        return "unknown"
    return "off" if not seconds else "%d seconds" % seconds


def song_details(rpc, kind, dbid):
    """The songs to add for a held-down song or album: [{path, artist, title}]."""
    fields = ["file", "artist", "title", "genre"]
    if kind == "album":
        reply = rpc("AudioLibrary.GetSongs", {"properties": fields, "filter": {"albumid": int(dbid)},
                                               "sort": {"method": "track"}})
        return [_song(s) for s in reply.get("songs") or []]
    reply = rpc("AudioLibrary.GetSongDetails", {"songid": int(dbid), "properties": fields})
    return [_song(reply["songdetails"])] if reply.get("songdetails") else []


def added(text, name, songs):
    """A playlist's text with songs added at the end (a new playlist when text is empty). Songs already in it
    aren't added twice."""
    import playlists
    if not (text or "").strip():
        return playlists.write_m3u(name, songs)
    have = set(line.strip() for line in text.splitlines() if line.strip() and not line.startswith("#"))
    lines = [text.rstrip("\n")]
    for song in songs:
        if song["path"] not in have:
            lines.append("#EXTINF:-1,%s - %s" % (song.get("artist") or "", song.get("title") or ""))
            lines.append(song["path"])
            have.add(song["path"])
    return "\n".join(lines) + "\n"


def file_name(name):
    """A playlist name made safe as a file name."""
    name = re.sub(r'[\\/:*?"<>|]+', " ", name or "").strip(" .")
    return " ".join(name.split())[:80] or "Playlist"


def convert(text, songs):
    """(tracks found in the library, entries missing) for a playlist file's text: M3U, CSV or typed list."""
    found, missing = playlists.match(playlists.parse(text), songs)
    seen, tracks = set(), []
    for _, track in found:
        if track["path"] not in seen:  # the same song twice in a playlist only plays twice by choice
            seen.add(track["path"])
            tracks.append(track)
    return tracks, missing


def missing_text(missing, most=200):
    lines = ["%s - %s" % (e["artist"], e["title"]) if e["artist"] else e["title"] for e in missing[:most]]
    if len(missing) > most:
        lines.append("... and %d more" % (len(missing) - most))
    return "\n".join(lines)
