"""Downloads, wherever they run, sorted into the same few groups - and Real-Debrid downloads on this device
that carry on from where they stopped.

Groups: every download is "Waiting for peers", "Downloading", "Queued", "Paused", "Failed" or "Done", whether it's
a torrent on the phone (aria2), a YouTube video on the phone (yt-dlp) or a Real-Debrid file downloading here.

Carrying on: a download here is written to "<name>.part" beside where it will end up. If the connection drops it
asks the server for the rest (a Range request) a few times by itself; if it still fails, or Kodi closes, the part
stays on the drive and the saved list (Jobs) remembers it, so it can be tried again later from the same place.
Kodi's own files can't be added to, so where Python can't either, a later try writes "<name>.part2", ".part3" ...
and the pieces are put together at the end. No Kodi imports here: default.py hands in the file functions.
"""
import re
import time

try:
    from http.client import HTTPException
except ImportError:  # Kodi 18 and older
    from httplib import HTTPException

ALL, PEERS, ACTIVE, QUEUED, PAUSED, FAILED, DONE = "all", "peers", "downloading", "queued", "paused", "failed", "done"
GROUPS = [(ALL, "All"), (PEERS, "Waiting for peers"), (ACTIVE, "Downloading"), (QUEUED, "Queued"),
          (PAUSED, "Paused"), (FAILED, "Failed"), (DONE, "Done")]
GROUP_NAMES = dict(GROUPS)
OTHER = "other"  # stopped by hand: only under All


def tor_group(j):
    """A download on the phone (aria2). "waiting" there means queued: the phone does two at a time, so the rest
    wait their turn. One that's running but has nobody to download from is waiting for peers."""
    s = j.get("state")
    if s == "active":
        if (j.get("name") or "").startswith("[METADATA]"):
            return PEERS  # a magnet link still finding its details
        if j.get("kind") == "Real-Debrid":
            return ACTIVE  # a plain file from a server: no peers to wait for
        if not j.get("peers") or (not j.get("speed") and not j.get("seeds")):
            return PEERS
        return ACTIVE
    return {"waiting": QUEUED, "paused": PAUSED, "complete": DONE, "error": FAILED}.get(s, OTHER)


def yt_group(j):
    """A YouTube download on the phone: one at a time, the rest queued."""
    return {"downloading": ACTIVE, "copying": ACTIVE, "queued": QUEUED, "paused": PAUSED, "failed": FAILED,
            "done": DONE}.get(j.get("state"), OTHER)


def box_group(j):
    """A Real-Debrid download on this device (see Jobs)."""
    return {"downloading": ACTIVE, "queued": QUEUED, "paused": PAUSED, "failed": FAILED,
            "done": DONE}.get(j.get("state"), OTHER)


def counts(jobs, group_of):
    out = dict((k, 0) for k, _ in GROUPS)
    out[ALL] = len(jobs)
    for j in jobs:
        g = group_of(j)
        if g in out:
            out[g] += 1
    return out


def buttons(jobs, group_of, shown=ALL):
    """The buttons at the top of a downloads list: [(group, "Failed (3)", note)], All first, then each group
    that has something in it. The one being shown says so."""
    n = counts(jobs, group_of)
    out = []
    for key, name in GROUPS:
        if key != ALL and not n[key]:
            continue
        out.append((key, "%s: %s (%d)" % ("Showing" if key == shown else "Show", name, n[key]),
                    "" if key == shown else "select to list only these" if key != ALL else "select to list everything"))
    return out


def shown_group(jobs, group_of, shown):
    """The group to show: the one picked, or All once the picked one has emptied."""
    return shown if shown == ALL or counts(jobs, group_of).get(shown) else ALL


def only(jobs, group_of, shown):
    return list(jobs) if shown == ALL else [j for j in jobs if group_of(j) == shown]


def box_lines(j):
    """(name, 'Failed at 40% - the connection dropped') for a Real-Debrid download on this device."""
    size, got = j.get("size") or 0, j.get("got") or 0
    pct = (" at %d%%" % (got * 100 // size)) if size and got else ""
    s = j.get("state")
    if s == "failed":
        status = "Failed%s - %s" % (pct, j.get("error") or "?")
    elif s == "downloading":
        status = "Downloading%s" % (pct.replace(" at", " -") if pct else "")
    elif s == "paused":
        status = "Paused%s" % pct
    elif s == "done":
        status = "Done"
    else:
        status = "Queued - %s" % ("carries on from %s" % pct[4:] if pct else "waiting its turn")
    return j.get("name") or "?", "On this device - " + status


# ---------- Real-Debrid files the phone downloads ----------
def _mb(n):
    return "%.1f MB" % (n / 1e6) if n < 1e9 else "%.2f GB" % (n / 1e9)


def mark_short(jobs, expected):
    """Real-Debrid says how big each file is when it's handed to the phone (expected: {download id: {"size"}}).
    A finished download smaller than that is cut short, not done: it comes back as failed, marked "short",
    so it's listed under Failed and can be tried again."""
    out = []
    for j in jobs:
        want = (expected.get(j.get("id")) or {}).get("size") or 0
        if j.get("state") == "complete" and want and j.get("size") and j["size"] < want:
            j = dict(j, state="error", short=True,
                     error="it's short: %s of the %s Real-Debrid said" % (_mb(j["size"]), _mb(want)))
        out.append(j)
    return out


def unpack_plan(urls, folder, music):
    """Where each file inside a packed album goes: [(its address inside the archive, the place in folder)], or
    [] when there's no music in it (videos in archives are the sorter's job). A folder every file shares is
    dropped, so the songs land in the album's own folder; names can't climb out of it."""
    urls = [u for u in urls if not u.endswith("/")]
    if not any(u.lower().endswith(tuple(music)) for u in urls):
        return []
    top = urls[0][:urls[0].rfind("/") + 1]
    for u in urls:
        while not u.startswith(top):
            top = top[:top.rstrip("/").rfind("/") + 1]
    out = []
    for u in urls:
        parts = [x for x in re.split(r"[\\/]", u[len(top):]) if x and x not in (".", "..")]
        if parts:
            out.append((u, folder + "/".join(parts)))
    return out


# ---------- the saved list of Real-Debrid downloads on this device ----------
KEEP_DONE = 30  # finished ones kept on the list


class Jobs(object):
    """The list of Real-Debrid downloads on this device, saved after every change so it's still there when Kodi
    opens again. load() returns the saved dict, save(dict) keeps it. A job: {"id", "url", "name", "size",
    "folder", "group", "state": queued | downloading | paused | failed | done, "got", "error"}."""

    def __init__(self, load, save, now=time.time):
        self.load, self.save, self.now = load, save, now

    def all(self):
        return list((self.load() or {}).get("jobs") or [])

    def _keep(self, jobs):
        done = [j for j in jobs if j.get("state") == "done"]
        drop = set(j["id"] for j in done[:-KEEP_DONE]) if len(done) > KEEP_DONE else ()
        self.save({"jobs": [j for j in jobs if j["id"] not in drop]})

    def get(self, jid):
        return next((j for j in self.all() if j["id"] == jid), None)

    def add(self, url, name, size, folder, group=""):
        """Queue a file. One already on the list for the same place is queued again with the new address
        (the part already downloaded is kept)."""
        jobs = self.all()
        for j in jobs:
            if j.get("folder") == folder and j.get("name") == name and j.get("state") != "done":
                j.update(url=url, size=size or j.get("size") or 0, error="")
                if j.get("state") != "downloading":
                    j["state"] = "queued"
                self._keep(jobs)
                return j
        job = {"id": "%d-%d" % (int(self.now() * 1000), len(jobs)), "url": url, "name": name, "size": size or 0,
               "folder": folder, "group": group, "state": "queued", "got": 0, "error": ""}
        self._keep(jobs + [job])
        return job

    def set(self, jid, **changes):
        jobs = self.all()
        for j in jobs:
            if j["id"] == jid:
                j.update(changes)
        self._keep(jobs)

    def remove(self, jid=None, states=None):
        """Take one job off the list, or every job in the given states."""
        self._keep([j for j in self.all() if not (j["id"] == jid or (states and j.get("state") in states))])

    def next(self):
        return next((j for j in self.all() if j.get("state") == "queued"), None)

    def retry(self, jid=None):
        """Queue a failed download again (all of them without an id). Returns how many."""
        jobs, n = self.all(), 0
        for j in jobs:
            if j.get("state") == "failed" and jid in (None, j["id"]):
                j["state"], j["error"] = "queued", ""
                n += 1
        if n:
            self._keep(jobs)
        return n

    def interrupted(self):
        """Call when nothing is downloading: jobs left "downloading" or "paused" were cut off (Kodi closed, the
        power went) and are queued again. Returns how many are queued now."""
        jobs, changed = self.all(), False
        for j in jobs:
            if j.get("state") in ("downloading", "paused"):
                j["state"], changed = "queued", True
        if changed:
            self._keep(jobs)
        return sum(1 for j in jobs if j.get("state") == "queued")


# ---------- one download that can carry on ----------
PART = ".part"
CHUNK = 1024 * 1024
WAITS = (5, 15, 30, 60, 60)  # seconds before each try after the connection drops


class DownloadError(Exception):
    """The download failed; what's on the drive so far is kept for another try."""


def piece_paths(dst, exists):
    """The half-done pieces of dst that are on the drive, in order: name.part, name.part2, name.part3 ..."""
    out, n = [], 1
    while exists(dst + PART + (str(n) if n > 1 else "")):
        out.append(dst + PART + (str(n) if n > 1 else ""))
        n += 1
    return out


def drop_pieces(dst, io):
    for p in piece_paths(dst, io.exists):
        io.delete(p)


def have_bytes(dst, io):
    return sum(max(io.size(p), 0) for p in piece_paths(dst, io.exists))


def _total(resp, start):
    """The whole file's size from a reply's headers, or 0."""
    h = getattr(resp, "headers", None) or {}
    m = re.search(r"/(\d+)\s*$", h.get("Content-Range") or "")
    if m:
        return int(m.group(1))
    try:
        return start + int(h.get("Content-Length") or 0) if h.get("Content-Length") else 0
    except ValueError:
        return 0


def _why(e):
    code = getattr(e, "code", None)
    if code in (401, 403, 404, 410):
        return "the link has run out (%s): get it again from Real-Debrid" % code
    if code:
        return "the server answered %s" % code
    return "the connection dropped (%s)" % (getattr(e, "reason", None) or e or type(e).__name__)


def fetch(url, dst, size, io, open_url, tick=None, sleep=time.sleep, waits=WAITS, joining=None):
    """Download url to dst, carrying on from whatever is already on the drive. Returns the bytes in the file.

    io: exists(path), size(path), delete(path), rename(a, b) -> bool, writer(path) and reader(path) (objects with
    write/read(n) and close), appender(path) -> a writer that adds to the file, or None where that can't be done.
    open_url(url, start) -> a reply with getcode(), headers, read(n), close(); start > 0 asks for the rest only.
    tick(got, total) runs after every chunk: raise to stop, return True after a long wait (a pause) to ask the
    server again. sleep(seconds) waits between tries; joining(done, total) runs while pieces are put together.
    Raises DownloadError when it gives up; the pieces stay."""
    have = have_bytes(dst, io)
    if size and have > size:  # not this file's: start again
        drop_pieces(dst, io)
        have = 0
    out, resp, fails, last = None, None, 0, ""

    def writer():
        pieces = piece_paths(dst, io.exists)
        if not pieces:
            return io.writer(dst + PART)
        return io.appender(pieces[-1]) or io.writer(dst + PART + str(len(pieces) + 1))

    try:
        while not (size and have == size):
            before = have
            try:
                resp = open_url(url, have)
                code = resp.getcode()
                if have and code != 206:  # the server sent the whole file again
                    if out:
                        out.close()
                        out = None
                    drop_pieces(dst, io)
                    have = before = 0
                size = size or _total(resp, have)
                out = out or writer()
                again = False
                while not (size and have >= size):
                    chunk = resp.read(CHUNK)
                    if not chunk:
                        break
                    try:
                        out.write(chunk)
                    except (IOError, OSError) as e:
                        raise DownloadError("couldn't write to the drive (is it full?): %s" % e)
                    have += len(chunk)
                    if tick and tick(have, size):
                        again = True
                        break
                resp.close()
                resp = None
                if again:
                    continue
                if not size or have == size:
                    break
                raise IOError("it stopped at %d of %d bytes" % (have, size))
            except (IOError, OSError, HTTPException) as e:
                if resp:
                    try:
                        resp.close()
                    except Exception:
                        pass
                    resp = None
                code = getattr(e, "code", None)
                if code == 416 and have:  # the part on the drive isn't a part of this file
                    if out:
                        out.close()
                        out = None
                    drop_pieces(dst, io)
                    have = 0
                    continue
                last = _why(e)
                if code and code < 500 and code != 408 and code != 429:
                    raise DownloadError(last)
                fails = 0 if have > before else fails + 1  # it got somewhere: the count starts again
                if fails > len(waits):
                    raise DownloadError(last)
                sleep(waits[max(fails, 1) - 1])
    finally:
        if out:
            out.close()
        if resp:
            try:
                resp.close()
            except Exception:
                pass
    return join(dst, size, io, joining)


def join(dst, size, io, tick=None):
    """Turn the finished pieces into dst: one piece is renamed, and where that can't be done (the Xbox's
    drives) or there are several, they're copied into dst one after another. Checks the size at each step."""
    pieces = piece_paths(dst, io.exists)
    sizes = [max(io.size(p), 0) for p in pieces]
    if not pieces or (size and sum(sizes) != size):
        got = sum(sizes)
        drop = size and got > size
        if drop:
            drop_pieces(dst, io)
        raise DownloadError("the drive has %d of %d bytes%s" % (got, size, " - starting again next time" if drop else ""))
    total = sum(sizes)
    if io.exists(dst):
        io.delete(dst)
    if len(pieces) == 1 and io.rename(pieces[0], dst) and io.exists(dst):
        return total
    out, done = io.writer(dst), 0
    try:
        for p, n in zip(pieces, sizes):
            src, left = io.reader(p), n
            try:
                while left > 0:  # stops at the known size: a read past the end may never return on the Xbox
                    chunk = src.read(min(CHUNK, left))
                    if not chunk:
                        raise DownloadError("couldn't read back %s" % p)
                    out.write(chunk)
                    left -= len(chunk)
                    done += len(chunk)
                    if tick:
                        tick(done, total)
            finally:
                src.close()
    except Exception:
        out.close()
        io.delete(dst)  # the pieces are still there for another go
        raise
    out.close()
    if io.size(dst) != total:
        io.delete(dst)
        raise DownloadError("putting the pieces together gave %d of %d bytes" % (max(io.size(dst), 0), total))
    for p in pieces:
        io.delete(p)
    return total
