"""Turn a playlist from anywhere into one that points at the person's own files.

In: an M3U or M3U8, a typed list ("Artist - Title" per line), or a CSV export of a streaming playlist
(Exportify, TuneMyMusic, Soundiiz and most others give Artist and Title columns). Out: an M3U8, or a
rekordbox XML that rekordbox can import (File > Import > Playlist or the Bridge view).

Nothing here reads files or the internet. A library track is a dict with path, artist and title, plus
camelot, bpm and energy from djkeys.dj_info when they're known.
"""
import csv
import io
import os
import re
from xml.sax.saxutils import quoteattr

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

import djkeys
from genretag import _SEPARATORS, clean_title, key, main_artist

ARTIST_COLUMNS = ("artist name(s)", "artist name", "artist names", "artists", "artist")
TITLE_COLUMNS = ("track name", "track title", "song name", "title", "track", "name", "song")


def _entry(artist, title, path=""):
    return {"artist": " ".join((artist or "").split()), "title": " ".join((title or "").split()), "path": path}


def _split_line(text):
    """"Artist - Title" (or a dash or en dash between) -> (artist, title)."""
    parts = re.split(r"\s+[-\u2013\u2014]\s+", text.strip(), maxsplit=1)
    return (parts[0], parts[1]) if len(parts) == 2 else ("", text.strip())


def parse_m3u(text):
    entries, info = [], None
    for line in (text or "").splitlines():
        line = line.strip().lstrip("\ufeff")
        if line.upper().startswith("#EXTINF:"):
            info = _split_line(line.split(",", 1)[1] if "," in line else "")
        elif line and not line.startswith("#"):
            artist, title = info or ("", "")
            if not title:
                artist, title = _split_line(os.path.splitext(re.split(r"[\\/]", line)[-1])[0])
            entries.append(_entry(artist, title, line))
            info = None
    return entries


def _column(header, names):
    lowered = [h.strip().lower() for h in header]
    for name in names:
        if name in lowered:
            return lowered.index(name)
    return -1


def parse_csv(text):
    rows = list(csv.reader(io.StringIO((text or "").lstrip("\ufeff"))))
    if not rows:
        return []
    artist_at, title_at = _column(rows[0], ARTIST_COLUMNS), _column(rows[0], TITLE_COLUMNS)
    if title_at < 0:
        return []
    out = []
    for row in rows[1:]:
        if len(row) > title_at and row[title_at].strip():
            artist = row[artist_at] if 0 <= artist_at < len(row) else ""
            out.append(_entry(artist, row[title_at]))  # all the artists: matching needs only one of them
    return out


def parse(text):
    """Any of the three forms, told apart by their content."""
    text = text or ""
    if text.lstrip("\ufeff").lstrip().upper().startswith("#EXTM3U") or re.search(r"(?im)^[^#\n]+\.(mp3|flac|m4a|wav|aiff?|ogg|opus)\s*$", text):
        return parse_m3u(text)
    first = text.lstrip("\ufeff").splitlines()[0] if text.strip() else ""
    if "," in first and _column(next(csv.reader([first])), TITLE_COLUMNS) >= 0:
        return parse_csv(text)
    return [_entry(*_split_line(line)) for line in text.splitlines() if line.strip() and not line.startswith("#")]


# ---------- playlists from streaming services, by their share link ----------

DEEZER_API = "https://api.deezer.com/"
TIDAL_TOKEN = "https://auth.tidal.com/v1/oauth2/token"
TIDAL_API = "https://openapi.tidal.com/v2/"
MOST_PAGES = 100  # 100 pages of tracks is far more than any playlist; it stops a reply that loops


class LinkError(Exception):
    """The link isn't a playlist this app can read, or the service refused."""


def service_of(link):
    """("deezer", id), ("tidal", id) or ("", "") for a playlist's share link."""
    link = (link or "").strip()
    found = re.search(r"deezer\.com/(?:[a-z]{2}/)?playlist/(\d+)", link)
    if found:
        return "deezer", found.group(1)
    found = re.search(r"tidal\.com/(?:browse/)?playlist/([0-9a-fA-F-]{36})", link)
    if found:
        return "tidal", found.group(1)
    found = re.search(r"youtube\.com/(?:playlist|watch)\?(?:.*&)?list=([A-Za-z0-9_-]+)", link)
    if found:
        return "youtube", found.group(1)
    return "", ""


def _json(raw):
    import json
    return json.loads(raw.decode("utf-8", "replace"))


def deezer_playlist(fetch, playlist_id):
    """[entry] from a public Deezer playlist. Deezer needs no key for these."""
    url, out = DEEZER_API + "playlist/%s/tracks?limit=100" % playlist_id, []
    for _ in range(MOST_PAGES):
        data = _json(fetch(url, {}))
        if "error" in data:
            raise LinkError("Deezer: %s" % ((data["error"] or {}).get("message") or "refused"))
        for track in data.get("data") or []:
            out.append(_entry((track.get("artist") or {}).get("name"), track.get("title_short") or track.get("title")))  # without "(Remastered 2015)"
        url = data.get("next")
        if not url:
            break
    return out


def tidal_token(post, client_id, client_secret):
    """An access token for TIDAL's API, from the person's own developer keys (client credentials)."""
    import base64
    basic = base64.b64encode(("%s:%s" % (client_id, client_secret)).encode()).decode()
    data = _json(post(TIDAL_TOKEN, "grant_type=client_credentials",
                      {"Authorization": "Basic " + basic, "Content-Type": "application/x-www-form-urlencoded"}))
    if not data.get("access_token"):
        raise LinkError("TIDAL refused the keys: %s" % (data.get("error_description") or data.get("error") or "no token"))
    return data["access_token"]


def tidal_playlist(fetch, playlist_id, token, country="US"):
    """[entry] from a public TIDAL playlist: its track ids page by page, then the tracks with their artists."""
    headers = {"Authorization": "Bearer " + token, "Accept": "application/vnd.api+json"}
    url = TIDAL_API + "playlists/%s/relationships/items?countryCode=%s" % (playlist_id, country)
    ids = []
    for _ in range(MOST_PAGES):
        data = _json(fetch(url, headers))
        if data.get("errors"):
            raise LinkError("TIDAL: %s" % (data["errors"][0].get("detail") or data["errors"][0].get("title") or "refused"))
        ids += [item["id"] for item in data.get("data") or [] if item.get("type") == "tracks" and item.get("id")]
        following = (data.get("links") or {}).get("next")
        if not following:
            break
        url = following if following.startswith("http") else TIDAL_API.rstrip("/") + "/" + following.lstrip("/").replace("v2/", "", 1)
    out = []
    for start in range(0, len(ids), 20):
        chunk = ids[start:start + 20]
        data = _json(fetch(TIDAL_API + "tracks?countryCode=%s&include=artists&filter%%5Bid%%5D=%s"
                           % (country, ",".join(chunk)), headers))
        artists = dict((x["id"], (x.get("attributes") or {}).get("name", "")) for x in data.get("included") or []
                       if x.get("type") == "artists")
        tracks = dict((x["id"], x) for x in data.get("data") or [])
        for track_id in chunk:
            track = tracks.get(track_id)
            if not track:
                continue
            links = ((track.get("relationships") or {}).get("artists") or {}).get("data") or []
            names = [artists.get(link.get("id"), "") for link in links]
            out.append(_entry(", ".join(n for n in names if n), (track.get("attributes") or {}).get("title")))
    return out


YOUTUBE_ITEMS = "https://www.googleapis.com/youtube/v3/playlistItems?"
_VIDEO_WORDS = re.compile(r"(?i)\s*[\(\[](?:official[^\)\]]*|lyrics?(?: video)?|audio|visuali[sz]er|hd|hq|4k)[\)\]]")


def youtube_playlist(fetch, playlist_id, api_key):
    """[entry] from a public YouTube Music or YouTube playlist, through the YouTube Data API with the person's
    own key. Only the names are read; nothing is played or downloaded from YouTube."""
    from urllib.parse import urlencode
    out, page = [], ""
    for _ in range(MOST_PAGES):
        query = {"part": "snippet", "maxResults": 50, "playlistId": playlist_id, "key": api_key}
        if page:
            query["pageToken"] = page
        data = _json(fetch(YOUTUBE_ITEMS + urlencode(query), {}))
        if data.get("error"):
            raise LinkError("YouTube: %s" % (data["error"].get("message") or "refused"))
        for item in data.get("items") or []:
            snippet = item.get("snippet") or {}
            title, owner = snippet.get("title") or "", snippet.get("videoOwnerChannelTitle") or ""
            if title in ("Deleted video", "Private video"):
                continue
            if owner.endswith(" - Topic"):  # YouTube Music's own uploads: the channel is the artist
                out.append(_entry(owner[:-len(" - Topic")], title))
            else:
                artist, named = _split_line(_VIDEO_WORDS.sub("", title))
                out.append(_entry(artist or owner, named))
        page = data.get("nextPageToken")
        if not page:
            break
    return out


def _title_key(title):
    return key(clean_title(title))


def _artist_keys(credit):
    return set(key(name) for name in _SEPARATORS.split(credit or "") if key(name))


def match(entries, library):
    """Returns (found, missing): found is [(entry, track)] in playlist order, missing is [entry].
    A track matches on its file name, or on title plus any one shared artist."""
    by_title, by_name = {}, {}
    for track in library:
        by_title.setdefault(_title_key(track.get("title")), []).append(track)
        by_name.setdefault(os.path.basename(track.get("path") or "").lower(), track)
    found, missing = [], []
    for entry in entries:
        track = by_name.get(re.split(r"[\\/]", entry.get("path") or "")[-1].lower()) if entry.get("path") else None
        if not track:
            wanted = (_artist_keys(entry["artist"]) | set([key(main_artist(entry["artist"]))])) - set([""])
            same = by_title.get(_title_key(entry["title"])) or []
            track = next((t for t in same if not wanted or wanted & _artist_keys(t.get("artist"))), None)
        if track:
            found.append((entry, track))
        else:
            missing.append(entry)
    return found, missing


def write_m3u(name, tracks):
    lines = ["#EXTM3U", "#PLAYLIST:" + (name or "Playlist")]
    for track in tracks:
        lines.append("#EXTINF:-1,%s - %s" % (track.get("artist") or "", track.get("title") or ""))
        lines.append(track.get("path") or "")
    return "\n".join(lines) + "\n"


def file_url(base, path):
    """rekordbox's file address for a track, from the music folder on the computer that runs rekordbox:
    base "D:/Music" or "/Users/me/Music" plus the track's path inside it."""
    full = (base.rstrip("/\\") + "/" + path.lstrip("/\\")).replace("\\", "/") if base else path.replace("\\", "/")
    return "file://localhost/" + quote(full.lstrip("/"), safe="/:")


def write_rekordbox(name, tracks, base=""):
    """A rekordbox XML holding one playlist. The key goes in Tonality, as Mixed In Key's Camelot code
    turned into the usual name (rekordbox shows it in its own notation). A track with "grid" (first beat in
    seconds, BPM) gets a beat grid, and with "cues" ([{"time", "label"}]) memory cues, the first eight also as
    hot cues A to H, so the cue points come into rekordbox with the playlist."""
    out = ['<?xml version="1.0" encoding="UTF-8"?>', '<DJ_PLAYLISTS Version="1.0.0">',
           '  <PRODUCT Name="Sortovia" Version="1" Company="Sortovia"/>',
           '  <COLLECTION Entries="%d">' % len(tracks)]
    for number, track in enumerate(tracks, 1):
        attrs = [("TrackID", str(number)), ("Name", track.get("title") or ""), ("Artist", track.get("artist") or ""),
                 ("Location", file_url(base, track.get("path") or ""))]
        if track.get("bpm"):
            attrs.append(("AverageBpm", "%.2f" % float(track["bpm"])))
        if track.get("camelot"):
            attrs.append(("Tonality", djkeys.key_name(track["camelot"])))
        if track.get("genre"):
            attrs.append(("Genre", track["genre"]))
        marks = []
        grid = track.get("grid")
        if grid and grid[1]:
            marks.append('<TEMPO Inizio="%.3f" Bpm="%.2f" Metro="4/4" Battito="1"/>' % (float(grid[0]), float(grid[1])))
        cues = sorted(({"time": c, "label": "Cue"} if isinstance(c, (int, float)) else c for c in track.get("cues") or []),
                      key=lambda c: c["time"])  # plain seconds from Serato or rekordbox tags, or named cues
        for number, cue in enumerate(cues):
            label = quoteattr(cue.get("label", "").split(",")[0])
            marks.append('<POSITION_MARK Name=%s Type="0" Start="%.3f" Num="-1"/>' % (label, float(cue["time"])))
            if number < 8:
                marks.append('<POSITION_MARK Name=%s Type="0" Start="%.3f" Num="%d"/>' % (label, float(cue["time"]), number))
        head = "    <TRACK %s" % " ".join("%s=%s" % (k, quoteattr(v)) for k, v in attrs)
        if marks:
            out.append(head + ">")
            out += ["      " + m for m in marks]
            out.append("    </TRACK>")
        else:
            out.append(head + "/>")
    out += ["  </COLLECTION>", "  <PLAYLISTS>", '    <NODE Type="0" Name="ROOT" Count="1">',
            '      <NODE Name=%s Type="1" KeyType="0" Entries="%d">' % (quoteattr(name or "Playlist"), len(tracks))]
    out += ['        <TRACK Key="%d"/>' % number for number in range(1, len(tracks) + 1)]
    out += ["      </NODE>", "    </NODE>", "  </PLAYLISTS>", "</DJ_PLAYLISTS>"]
    return "\n".join(out) + "\n"
