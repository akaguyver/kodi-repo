"""Hold down a song in Kodi's music library: songs that mix well after it."""
import sys

import xbmc

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

if __name__ == "__main__":
    path = xbmc.getInfoLabel("ListItem.FileNameAndPath") or sys.listitem.getPath()
    xbmc.executebuiltin("RunPlugin(plugin://script.kodisorter/?action=dj_next&path=%s)" % quote(path.encode("utf-8")))
