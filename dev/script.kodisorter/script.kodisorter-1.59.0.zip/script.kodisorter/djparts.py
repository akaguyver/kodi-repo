"""The parts of a track a DJ listens for beyond its energy: where the vocals are, which vocal parts repeat (a chorus
or hook) and which don't (a verse), how loud the track is where it's loudest, and whether it fades out.

Every finding is per bar of the beat grid djcues found, so it lines up with the phrases.

Vocals: dance music is built from loops, so each instrument sounds the same in every bar of a phrase. A voice
doesn't: syllables land in different places from bar to bar. Each bar's loudness in the mids (200 Hz to 2.5 kHz,
where a voice sits) is taken at STEPS points; the phrase's usual shape at each point (the median over the 8 bars
around it) is taken away, and what's left, once slow sweeps are smoothed out, is what doesn't loop. A phrase of
loops leaves almost nothing; a voice leaves a lot. (rekordbox's vocal detection is a trained network; this is a
cheap stand-in that needs no download, and it hears a lead line that changes every bar as a voice too.)

Choruses: a chorus repeats its words, a verse doesn't. The part of the mids that doesn't loop is the rhythm of the
words, so two bars of the same hook have the same leftover shape even over the same beat, where two verses don't.
4-bar blocks are compared by that shape and by their notes (the chroma line); vocal blocks that come back are a
chorus, the others verses (the idea of Goto's RefraiD chorus finder: repeated stretches in a self-similarity
matrix, here on whole blocks of bars, as a DJ counts them).

Pure Python, like djcues, so it runs on the phone and in tests.
"""
import math

STEPS = 48  # points across each bar for the mids' shape
TREND = 8  # points smoothed away as slow change (a filter sweep), about a sixth of a bar
USUAL_AT = 0.5  # the loop's shape: the median of the bars around (a lower share was tried: noisier on real tracks)
WINDOW = 8  # bars around each bar whose usual shape is taken away
QUIET = 0.08  # a bar quieter than this share of the loudest bar has nothing to say
VOCAL_LEAST, VOCAL_MOST = 0.17, 0.26  # the leftover (in log loudness) a voice needs, whatever the track
VOCAL_OVER = 2.0  # and how many times the track's own usual leftover (a growling bass leaves some too)
VOCAL_SURE = 0.1  # over the line by this much, one bar alone counts
BLOCK = 4  # bars in a block compared for repeats
HOOK_REPEAT, HOOK_LOUD = 0.6, 0.7  # a block with no voice found this alike to another, this loud, is a hook
REPEAT = 0.42  # two blocks this alike (correlation of their word rhythm, with their notes) are the same part
HIPHOP_SHARE = 0.55  # with a voice in this share of bars, the loud hooks are choruses even in a track with drops
SONG_SHARE = 0.4  # a track with a voice in this share of its bars is a song: verses and choruses, not drops
LOUD_SHARE = 0.3  # loudness is taken over the loudest 30% of bars, as a DJ sets the gain at the loudest part
FADE_BARS = 6  # at least this many bars, each quieter than the one before, make a fade-out
FADE_DOWN = 0.45  # ending below this share of the track's loudest bars


def _mean(values, a, b):
    part = values[max(0, a):max(0, b)]
    return sum(part) / len(part) if part else 0.0


def _shape(curve, start, length):
    """A bar's loudness at STEPS points, in log terms so a loud and a quiet bar compare alike."""
    out = []
    for s in range(STEPS):
        a = int(start + length * s / STEPS)
        b = max(a + 1, int(start + length * (s + 1) / STEPS))
        out.append(math.log(_mean(curve, a, b) + 1e-5))
    return out


def _detrend(values):
    """What changes faster than TREND points: a moving average taken away."""
    n, half = len(values), TREND // 2
    out = []
    for i in range(n):
        a, b = max(0, i - half), min(n, i + half + 1)
        out.append(values[i] - sum(values[a:b]) / (b - a))
    return out


def leftovers(mid, bars, bar_len):
    """For each bar: the part of its mids' shape that doesn't loop (detrended, the bar's usual shape taken away)."""
    shapes = [_shape(mid, b, bar_len) for b in bars]
    out = []
    for k, shape in enumerate(shapes):
        a, b = max(0, k - WINDOW // 2), min(len(shapes), k + WINDOW // 2)
        if b - a < 3:
            a, b = max(0, b - 3), min(len(shapes), a + 3)
        others = [shapes[j] for j in range(a, b) if j != k] or [shape]
        usual = []
        for s in range(STEPS):
            column = sorted(o[s] for o in others)
            usual.append(column[int(len(column) * USUAL_AT)])
        diff = [x - u for x, u in zip(shape, usual)]
        level = sum(diff) / STEPS
        out.append(_detrend([d - level for d in diff]))
    return out


def vocal_scores(energy, mid, bars, bar_len):
    """How much of each bar doesn't loop (0 for a quiet bar), smoothed over three bars."""
    rest = leftovers(mid, bars, bar_len)
    loud = [_mean(energy, int(b), int(b + bar_len)) for b in bars]
    top = max(loud) if loud else 0.0
    # a voice only adds sound: what's over the loop counts, not what's under it (a bar after a verse, against a
    # usual shape that still has the words in it, is under it where the words were)
    raw = [0.0 if top <= 0 or e < QUIET * top else math.sqrt(sum(max(0.0, v) ** 2 for v in r) * 2 / STEPS) for r, e in zip(rest, loud)]
    out = []
    for k in range(len(raw)):
        near = sorted(raw[max(0, k - 1):k + 2])
        out.append(near[len(near) // 2])
    return out, rest


def vocal_line(scores):
    """The leftover a bar needs to count as voiced: VOCAL_OVER times the usual one (the 30th percentile of the
    bars with sound), kept between VOCAL_LEAST and VOCAL_MOST."""
    heard = sorted(s for s in scores if s > 0)
    usual = heard[int(len(heard) * 0.3)] if heard else 0.0
    return min(VOCAL_MOST, max(VOCAL_LEAST, VOCAL_OVER * usual))


def vocal_spans(scores, line=None):
    """Runs of bars with a voice, as [(first bar, end bar, strength 0..1)]: bars over the line, gaps of one bar
    bridged, runs of one bar dropped unless the voice is clear."""
    line = vocal_line(scores) if line is None else line
    on = [s >= line for s in scores]
    for k in range(1, len(on) - 1):
        if not on[k] and on[k - 1] and on[k + 1]:
            on[k] = True
    spans, k = [], 0
    while k < len(on):
        if not on[k]:
            k += 1
            continue
        j = k
        while j < len(on) and on[j]:
            j += 1
        peak = max(scores[k:j])
        if j - k >= 2 or peak >= line + VOCAL_SURE:
            strength = min(1.0, 0.5 + 0.5 * (sum(scores[k:j]) / (j - k) - line) / VOCAL_SURE)
            spans.append((k, j, round(max(0.1, strength), 2)))
        k = j
    return spans


def _bar_notes(note_line, bars, bar_len, rate):
    """Each bar's 12 note shares from the notes over time ({"rate": blocks a second, "notes": [12 a block]})."""
    if not note_line or not note_line.get("notes"):
        return None
    notes, per = note_line["notes"], float(note_line.get("rate") or 0)
    blocks = len(notes) // 12
    if per <= 0 or blocks == 0:
        return None
    out = []
    for b in bars:
        a, z = int(b / rate * per), int((b + bar_len) / rate * per) + 1
        v = [0.0] * 12
        for i in range(max(0, a), min(blocks, z)):
            for c in range(12):
                v[c] += notes[12 * i + c]
        total = sum(v)
        out.append([x / total for x in v] if total > 0 else v)
    return out


def _correlation(a, b):
    n = len(a)
    if n == 0:
        return 0.0
    ma, mb = sum(a) / n, sum(b) / n
    sa = math.sqrt(sum((x - ma) ** 2 for x in a))
    sb = math.sqrt(sum((x - mb) ** 2 for x in b))
    if sa <= 1e-9 or sb <= 1e-9:
        return 0.0
    return sum((x - ma) * (y - mb) for x, y in zip(a, b)) / (sa * sb)


def block_repeats(rest, notes, first, count):
    """For each 4-bar block from bar `first`: how alike it is to its best match elsewhere in the track (not the
    block next to it), by the rhythm of what doesn't loop and, when there are notes, the notes too."""
    blocks = []
    for i in range(count):
        a = first + i * BLOCK
        rhythm = [v for k in range(a, a + BLOCK) if k < len(rest) for v in rest[k]]
        tones = [v for k in range(a, a + BLOCK) if notes and k < len(notes) for v in notes[k]]
        blocks.append((rhythm, tones))
    best = []
    for i, (r, t) in enumerate(blocks):
        score = 0.0
        for j, (r2, t2) in enumerate(blocks):
            if abs(i - j) < 2 or len(r) != len(r2) or not r:
                continue
            s = _correlation(r, r2)
            if t and len(t) == len(t2):
                s = 0.75 * s + 0.25 * _correlation(t, t2)
            score = max(score, s)
        best.append(round(score, 3))
    return best


def loudness(energy, bars, bar_len):
    """(loudness in dB, peak in dB) of the whole sound: the RMS over the loudest LOUD_SHARE of bars, and the loudest
    10 ms. 0 dB is full scale."""
    loud = sorted((_mean([v * v for v in energy[int(b):int(b + bar_len)]], 0, 10 ** 9) for b in bars), reverse=True)
    keep = loud[:max(1, int(len(loud) * LOUD_SHARE))]
    power = sum(keep) / len(keep) if keep else 0.0
    peak = max(energy) if energy else 0.0
    def db(x):
        return round(10 * math.log10(x), 1) if x > 1e-12 else -99.0
    return db(power), db(peak * peak)


def fade_start(energy, bars, bar_len):
    """The bar a fade-out starts at (the last FADE_BARS or more bars each quieter than the one before, ending well
    below the loud parts), or None for a track that ends on its own."""
    loud = [_mean(energy, int(b), int(b + bar_len)) for b in bars]
    if len(loud) < FADE_BARS + 4:
        return None
    end = len(loud) - 1
    while end > 0 and loud[end] < 0.02 * max(loud):  # trailing silence
        end -= 1
    k = end
    while k > 0 and loud[k - 1] >= loud[k] * 1.01:
        k -= 1
    top = sorted(loud, reverse=True)[max(0, len(loud) // 5)]
    if end - k + 1 >= FADE_BARS and loud[end] < FADE_DOWN * top and loud[k] > 0.7 * top:
        return k + 1  # the first bar quieter than the one before
    return None


def song_parts(spans, repeats, first, n_bars, loud=None, drops=False, dance=None):
    """Verse and chorus names for a song (a voice in SONG_SHARE of its bars or more), per 4-bar block: vocal
    blocks that come back are a Chorus, vocal blocks that don't a Verse. A hook sung on every bar loops like an
    instrument, so the voice can hide in it: a loud block with no voice found that comes back clearly is a Chorus
    too (or a Drop, for a track with drops and fewer vocals: dubstep with a rapper). Other blocks with no voice are
    the Intro at the start, the Outro at the end, otherwise Inst, or the name djcues gave that bar (dance(bar):
    Drop, Breakdown, Buildup) when there is one. loud: each bar's loudness. Returns
    [{"bar", "end", "name"}]."""
    voiced = [False] * n_bars
    for a, b, _ in spans:
        for k in range(a, min(b, n_bars)):
            voiced[k] = True
    names = []
    for i in range(len(repeats)):
        a = first + i * BLOCK
        share = sum(1 for k in range(a, min(a + BLOCK, n_bars)) if voiced[k]) / BLOCK
        level = sum(loud[a:a + BLOCK]) / BLOCK if loud else 0.0
        if share < 0.5 and loud and repeats[i] >= HOOK_REPEAT and level >= HOOK_LOUD * max(loud):
            names.append("Drop" if drops else "Chorus")
        elif share < 0.5:
            names.append(None)
        else:
            names.append("Chorus" if repeats[i] >= REPEAT else "Verse")
    # a block alone between two of the other kind takes theirs (one line of a verse can echo the hook)
    for i in range(1, len(names) - 1):
        if names[i] and names[i - 1] and names[i - 1] == names[i + 1] != names[i]:
            names[i] = names[i - 1]
    parts = []
    lead = first
    if first > 0:
        parts.append({"bar": 0, "end": first, "name": "Intro"})
    for i, name in enumerate(names):
        a = first + i * BLOCK
        b = min(n_bars, a + BLOCK)
        if name is None:
            any_voice_after = any(x for x in names[i + 1:])
            any_voice_before = any(x for x in names[:i])
            name = "Intro" if not any_voice_before else "Outro" if not any_voice_after else "Inst"
            if dance and name == "Inst":
                name = dance(a) or name
        if parts and parts[-1]["name"] == name:
            parts[-1]["end"] = b
        else:
            parts.append({"bar": a, "end": b, "name": name})
        lead = b
    if lead < n_bars:
        if parts and parts[-1]["name"] in ("Outro", "Inst"):
            parts[-1]["end"] = n_bars
            if parts[-1]["name"] == "Inst":
                parts[-1]["name"] = "Outro"
        else:
            parts.append({"bar": lead, "end": n_bars, "name": "Outro"})
    # a chorus is at least 8 bars as DJs count it: a lone 4-bar "chorus" inside verses is a verse line
    for j, p in enumerate(parts):
        if p["name"] == "Chorus" and p["end"] - p["bar"] < 8 and 0 < j < len(parts) - 1 \
                and parts[j - 1]["name"] == "Verse" and parts[j + 1]["name"] == "Verse":
            p["name"] = "Verse"
    merged = []
    for p in parts:
        if merged and merged[-1]["name"] == p["name"]:
            merged[-1]["end"] = p["end"]
        else:
            merged.append(dict(p))
    # the part after the last chorus that has a voice and doesn't repeat, late in the song, is a bridge only when
    # a chorus follows it
    for j in range(1, len(merged) - 1):
        if merged[j]["name"] == "Verse" and merged[j - 1]["name"] == "Chorus" and merged[j + 1]["name"] == "Chorus" \
                and merged[j]["end"] - merged[j]["bar"] <= 8 and j >= 3:
            merged[j]["name"] = "Bridge"
    return merged


STRUCTURE_VERSION = 1


def voiced_bars(spans, n_bars):
    voiced = [0.0] * n_bars
    for a, b, strength in spans:
        for k in range(a, min(b, n_bars)):
            voiced[k] = strength
    return voiced


def from_model(voices, bars, bar_len, rate):
    """Vocal runs from the sound plugin's voice model: voices [[start second, voice probability], ...] for patches
    about 2 seconds long. A bar is voiced when the patches over it say so more than not."""
    spans_on = []
    for b in bars:
        t0, t1 = b / rate, (b + bar_len) / rate
        near = [p for t, p in voices if t < t1 and t + 2.0 > t0]
        spans_on.append(sum(near) / len(near) if near else None)
    out, k = [], 0
    while k < len(spans_on):
        if spans_on[k] is None or spans_on[k] < 0.5:
            k += 1
            continue
        j = k
        while j < len(spans_on) and (spans_on[j] is None or spans_on[j] >= 0.5):
            j += 1
        if j - k >= 2:
            known = [x for x in spans_on[k:j] if x is not None]
            out.append((k, j, round(sum(known) / len(known), 2)))
        k = j
    return out


def find(energy, mid, found, rate, note_line=None, voices=None):
    """Everything above for one analysis (found: djcues.analyse's result, in seconds, on the file's own time).
    Returns the fields to add: "vocals" [[start, end, strength]], "vocal_share", "vocal_from" ("sound" for this
    detector, "model" for the voice model), "song" (verses and choruses rather than drops), "song_parts"
    [{"time", "name", "bars"}] for a song, "loudness_db", "peak_db", "fade_at" (seconds) and "structure_v"."""
    bars = [b * rate for b in found.get("bars") or []]
    beat = found.get("beat") or 0
    out = {"structure_v": STRUCTURE_VERSION}
    if len(bars) < 8 or beat <= 0 or not mid:
        return out
    bar_len = beat * 4 * rate
    scores, rest = vocal_scores(energy, mid, bars, bar_len)
    if voices:
        spans, out["vocal_from"] = from_model(voices, bars, bar_len, rate), "model"
    else:
        spans, out["vocal_from"] = vocal_spans(scores), "sound"
    n = len(bars)
    out["vocals"] = [[round(bars[a] / rate, 2), round(min(len(energy), bars[b - 1] + bar_len) / rate, 2), s] for a, b, s in spans]
    voiced = voiced_bars(spans, n)
    share = sum(1 for v in voiced if v > 0) / n
    out["vocal_share"] = round(share, 2)
    out["loudness_db"], out["peak_db"] = loudness(energy, bars, bar_len)
    fade = fade_start(energy, bars, bar_len)
    if fade is not None:
        out["fade_at"] = round(bars[fade] / rate, 2)
    notes = _bar_notes(note_line, bars, bar_len, rate)
    # blocks of 4 bars counted from the first phrase line (the downbeat djcues brought the track in on)
    down = found.get("mix_in", bars[0] / rate) * rate
    first = min(range(n), key=lambda k: abs(bars[k] - down))
    first %= BLOCK
    count = (n - first) // BLOCK
    repeats = block_repeats(rest, notes, first, count)
    out["song"] = share >= SONG_SHARE
    if out["song"]:
        loud = [sum(energy[int(b):int(b + bar_len)]) / max(1, len(energy[int(b):int(b + bar_len)])) for b in bars]
        drops = any(x.get("name") == "Drop" for x in found.get("sections") or []) and share < HIPHOP_SHARE
        named = sorted(((x["time"] * rate, x["name"]) for x in found.get("sections") or []), key=lambda x: x[0])

        def dance(k):
            name = None
            for at, nm in named:
                if at <= bars[k] + 1:
                    name = nm
            return name if name in ("Drop", "Breakdown", "Buildup", "Main") else None
        parts = song_parts(spans, repeats, first, n, loud, drops, dance)
        out["song_parts"] = [{"time": round(bars[p["bar"]] / rate, 3), "name": p["name"], "bars": p["end"] - p["bar"]}
                             for p in parts if p["end"] > p["bar"]]
    out["repeats"] = repeats
    out["block_from"] = round(bars[first] / rate, 3)
    return out
