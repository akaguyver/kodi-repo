"""Musical keys for DJs: read the key, BPM and energy that Mixed In Key (or rekordbox, Serato, Traktor)
wrote into a track's tags, put every key on the Camelot wheel, and suggest tracks that mix well.

Camelot: 1-12 plus A (minor) or B (major). Neighbours on the wheel mix cleanly.
"""
import math
import re

NOTES = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
NAMES = ("C", "Db", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")
BPM_RANGE = 0.06  # a tempo within 6% can be matched with the pitch fader

_CAMELOT = re.compile(r"(?i)^0?(1[0-2]|[1-9])\s*([AB])$")
_OPEN_KEY = re.compile(r"(?i)^0?(1[0-2]|[1-9])\s*([MD])$")
_TRADITIONAL = re.compile(r"^([A-Ga-g])\s*([#b♯♭]?)\s*(m|min|minor|Min|Minor|maj|major|Maj|Major|M)?$")
_COMMENT_KEY = re.compile(r"(?i)^\s*0?(1[0-2]|[1-9])([AB])\b")
_ENERGY = re.compile(r"(?i)\benergy\s*(?:level)?\s*[:=-]?\s*(\d{1,2})\b")


def camelot(text):
    """"8A", "08A", "1m" (Open Key), "Am", "A minor", "F#", "Bbm" -> "8A"; anything else -> ""."""
    text = (text or "").strip()
    text = re.sub(r"(?i)\s*-?\s*flat\b", "b", re.sub(r"(?i)\s*-?\s*sharp\b", "#", text))  # "A flat minor", as Audius writes
    found = _CAMELOT.match(text)
    if found:
        return found.group(1) + found.group(2).upper()
    found = _OPEN_KEY.match(text)
    if found:
        number = (int(found.group(1)) - 5) % 12 or 12
        return "%d%s" % (number, "A" if found.group(2).lower() == "m" else "B")
    found = _TRADITIONAL.match(text)
    if not found:
        return ""
    pitch = NOTES[found.group(1).upper()] + {"#": 1, "♯": 1, "b": -1, "♭": -1}.get(found.group(2), 0)
    quality = found.group(3) or ""
    minor = quality == "m" or quality.lower() in ("min", "minor")  # "M" and "maj" mean major
    if minor:
        pitch += 3  # the major key with the same notes
    return "%d%s" % ((7 * pitch % 12 + 7) % 12 + 1, "A" if minor else "B")


def key_name(code):
    """"8A" -> "Am", "8B" -> "C": the usual name, for software that wants one."""
    found = _CAMELOT.match(code or "")
    if not found:
        return ""
    number, letter = int(found.group(1)), found.group(2).upper()
    major = (7 * (number - 8)) % 12  # each step round the wheel is a fifth
    return NAMES[(major - 3) % 12] + "m" if letter == "A" else NAMES[major]


def open_key(code):
    """"8A" -> "1m": the same key in Traktor's Open Key notation."""
    found = _CAMELOT.match(code or "")
    if not found:
        return ""
    return "%d%s" % ((int(found.group(1)) + 4) % 12 + 1, "m" if found.group(2).upper() == "A" else "d")


def bpm(text):
    """"124", "124.00", "124 BPM" -> 124.0; nothing usable -> 0.0."""
    found = re.search(r"\d+(?:[.,]\d+)?", str(text or ""))
    value = float(found.group(0).replace(",", ".")) if found else 0.0
    return value if 40 <= value <= 250 else 0.0


def dj_info(tags):
    """{camelot, bpm, energy} from a track's tags (musictags.read_tags). Mixed In Key can put the key and
    energy at the start of the comment ("8A - Energy 6") instead of, or as well as, the key tag."""
    comment = tags.get("comment") or ""
    code = camelot(tags.get("key"))
    if not code:
        found = _COMMENT_KEY.match(comment)
        code = found.group(1) + found.group(2).upper() if found else ""
    energy = 0
    for text in (tags.get("energy"), comment):
        found = re.match(r"^\s*(\d{1,2})\s*$", str(text or "")) or _ENERGY.search(str(text or ""))
        if found and 1 <= int(found.group(1)) <= 10:
            energy = int(found.group(1))
            break
    return {"camelot": code, "bpm": bpm(tags.get("bpm")), "energy": energy}


def _split(code):
    found = _CAMELOT.match(code or "")
    return (int(found.group(1)), found.group(2).upper()) if found else (0, "")


def _step(number, by):
    return (number - 1 + by) % 12 + 1


def mix_reason(a, b):
    """Why key b follows key a well, or "" if it doesn't. Best matches first in MIX_ORDER."""
    (n, letter), (m, other) = _split(a), _split(b)
    if not n or not m:
        return ""
    if (n, letter) == (m, other):
        return "Same key"
    if letter == other and m in (_step(n, 1), _step(n, -1)):
        return "One step " + ("up" if m == _step(n, 1) else "down")
    if n == m:
        return "Relative " + ("major" if other == "B" else "minor")
    if letter == other and m == _step(n, 2):
        return "Energy boost"
    return ""


MIX_ORDER = ("Same key", "One step up", "One step down", "Relative major", "Relative minor", "Energy boost")


def tempo_gap(a, b):
    """How far apart two tempos are as a share, counting half and double time; 1.0 if one is unknown."""
    if not a or not b:
        return 1.0
    return min(abs(b * f - a) / a for f in (0.5, 1.0, 2.0))


def fits(current, track, bpm_range=BPM_RANGE):
    """True when track can be mixed after current: a key that mixes and, unless bpm_range is None (tempos aren't
    matched), a tempo within bpm_range (half and double time count). An unknown key or tempo doesn't fit."""
    if not mix_reason(current.get("camelot"), track.get("camelot")):
        return False
    return bpm_range is None or bool(current.get("bpm") and track.get("bpm")
                                     and tempo_gap(current.get("bpm"), track.get("bpm")) <= bpm_range)


def _rank(reason):
    """Where a key match sits in MIX_ORDER: the best first, no match last."""
    return MIX_ORDER.index(reason) if reason else len(MIX_ORDER)


def closest(current, track):
    """How near track comes to mixing after current, for when none fits: the key match first, then the tempo."""
    reason = mix_reason(current.get("camelot"), track.get("camelot"))
    return (_rank(reason), min(tempo_gap(current.get("bpm"), track.get("bpm")), 1.0))


def suggest(current, tracks, limit=20, bpm_range=BPM_RANGE, strict=False):
    """Tracks that mix well after current. Each track is a dict with at least camelot, bpm and energy
    (from dj_info). Returns [(track, reason)], best first: by key match, then tempo, then energy. A track with no
    tempo is let through, unless strict (then only tracks that fit, see fits)."""
    picks = []
    for track in tracks:
        if track is current:
            continue
        reason = mix_reason(current.get("camelot"), track.get("camelot"))
        gap = tempo_gap(current.get("bpm"), track.get("bpm"))
        if strict and not fits(current, track, bpm_range):
            continue
        if not reason or (bpm_range is not None and current.get("bpm") and track.get("bpm") and gap > bpm_range):
            continue
        energy = abs((current.get("energy") or 0) - (track.get("energy") or 0))
        picks.append((MIX_ORDER.index(reason), gap, energy, len(picks), track, reason))
    picks.sort(key=lambda p: p[:4])
    return [(p[4], p[5]) for p in picks[:limit]]


def wheel_order(tracks):
    """Tracks sorted round the Camelot wheel (1A, 1B, 2A ...), then by tempo; unknown keys last."""
    def place(track):
        number, letter = _split(track.get("camelot"))
        return (not number, number, letter, track.get("bpm") or 0)
    return sorted(tracks, key=place)


ORDERS = ("saved", "keys", "harder", "softer", "live", "waves", "warmup", "closing")
WARMUP_TOP = 0.65  # a warm-up set never goes above this much of the energy range: the headliner's job is the peak
WAVE_TRACKS = 8  # about one peak every 8 tracks in a "waves" set
PEAK_AT = 0.75  # a live set peaks about three quarters of the way through, then cools down


def same_octave(a, b):
    """b at half, the same or double time, whichever is nearest a: 75 next to 150 is 150."""
    if not a or not b:
        return b
    return min((b * f for f in (0.5, 1.0, 2.0)), key=lambda x: abs(x - a))


def _too_far(current, track, bpm_range=BPM_RANGE):
    """True when the tempos can't be beat-matched (more than bpm_range apart, or one is unknown). Never when
    bpm_range is None (tempos aren't matched)."""
    return bpm_range is not None and tempo_gap(current.get("bpm"), track.get("bpm")) > bpm_range


def _pick(current, left, rank, bpm_range, strict):
    """The best of left to follow current by rank(track). Strict: only from the tracks that fit while any are
    left, and if none does, the closest by key then tempo."""
    if strict:
        fitting = [t for t in left if fits(current, t, bpm_range)]
        if not fitting:
            return min(left, key=lambda t: closest(current, t))
        left = fitting
    return min(left, key=rank)


def _against(current, track, mode):
    """1 for each way a track goes against the wanted direction: lower energy or tempo when building up,
    higher when winding down."""
    e0, e1 = current.get("energy") or 0, track.get("energy") or 0
    b0 = current.get("bpm") or 0
    b1 = same_octave(b0, track.get("bpm") or 0)
    if mode == "harder":
        return int(bool(e0 and e1 and e1 < e0)) + int(bool(b0 and b1 and b1 < b0 * 0.99))
    if mode == "softer":
        return int(bool(e0 and e1 and e1 > e0)) + int(bool(b0 and b1 and b1 > b0 * 1.01))
    return 0


def voice_clash(current, track):
    """1 when the playing track's outro and the next one's intro both have vocals (vocal_out and vocal_in, the
    shares of their mix-out and mix-in phrases with a voice): two voices at once clash worse than two keys."""
    return int((current.get("vocal_out") or 0) > 0.4 and (track.get("vocal_in") or 0) > 0.4)


def _fit(current, track, mode, bpm_range=BPM_RANGE):
    reason = mix_reason(current.get("camelot"), track.get("camelot"))
    rank = _rank(reason)
    if mode == "harder" and reason == "Energy boost":
        rank = 1  # building up, the boost is wanted
    energy = abs((current.get("energy") or 0) - (track.get("energy") or 0))
    # A tempo that can be matched comes first, then the key: a good key at a tempo too far away can't be mixed.
    return (_too_far(current, track, bpm_range), rank, _against(current, track, mode), voice_clash(current, track),
            min(tempo_gap(current.get("bpm"), track.get("bpm")), 1.0), energy)


def set_shape(at):
    """How far up the energy range a live set should be at `at` (0 = first track, 1 = last): it warms up, peaks
    at PEAK_AT, and cools down to a little over half way."""
    if at <= PEAK_AT:
        return at / PEAK_AT
    return 1.0 - 0.45 * (at - PEAK_AT) / (1.0 - PEAK_AT)


def wave_shape(at, waves):
    """Peaks and valleys: `waves` rises and falls through the set, from a valley, never quite to the bottom."""
    return 0.15 + 0.85 * (0.5 - 0.5 * math.cos(2 * math.pi * waves * at))


def _live(tracks, shape=set_shape, start=None, bpm_range=BPM_RANGE, strict=False):
    """A live set: from the calmest track, each next one in a key that mixes, as near as can be to the energy
    the set's shape wants at that point (shape(0..1) -> 0..1), then the nearest tempo. bpm_range and strict as
    in reorder."""
    left = list(tracks)
    known = [t.get("energy") or 0 for t in left if t.get("energy")]
    low, high = (min(known), max(known)) if known else (0, 0)
    current = start if start is not None else min(left, key=lambda t: ((t.get("energy") or 0) or 99, t.get("bpm") or 0))
    out = [current]
    left.remove(current)
    total = len(tracks)
    while left:
        wanted = low + (high - low) * shape(len(out) / max(total - 1, 1.0))

        def fit(track, current=current, wanted=wanted):
            reason = mix_reason(current.get("camelot"), track.get("camelot"))
            rank = _rank(reason)
            miss = abs((track.get("energy") or wanted) - wanted)
            return (_too_far(current, track, bpm_range), not reason, round(miss), voice_clash(current, track),
                    min(tempo_gap(current.get("bpm"), track.get("bpm")), 1.0), rank)
        current = _pick(current, left, fit, bpm_range, strict)
        out.append(current)
        left.remove(current)
    return out


def reorder(tracks, mode, start=None, bpm_range=BPM_RANGE, strict=False):
    """A new order where each track mixes well into the next: "keys" keeps the first track first, "harder"
    starts low and builds energy and tempo, "softer" starts high and winds down, "live" warms up, peaks and
    cools down like a club set, "waves" rises and falls again and again. "saved" changes nothing. Each step takes
    a track within BPM_RANGE of the tempo (half and double time count), then the best key match left, then the
    right direction, then the nearest tempo. start: a live or waves set begins with this track (one of tracks),
    such as the one playing now; with strict, every order does. bpm_range: how far apart tempos can be matched, or
    None when they aren't (the key alone counts). strict: only a track that fits (see fits) follows while one is
    left; when none does, the closest by key then tempo."""
    left = list(tracks)
    if mode not in ("keys", "harder", "softer", "live", "waves", "warmup", "closing") or not left:
        return left
    if mode == "warmup":  # rises slowly and stops short of the top
        return _live(left, lambda at: WARMUP_TOP * at, start, bpm_range, strict)
    if mode == "closing":  # from the peak, winding down to the last track
        return _live(left, lambda at: 1.0 - 0.7 * at, start, bpm_range, strict)
    if mode == "live":
        return _live(left, start=start, bpm_range=bpm_range, strict=strict)
    if mode == "waves":
        waves = max(2, int(round(len(left) / float(WAVE_TRACKS))))
        return _live(left, lambda at: wave_shape(at, waves), start, bpm_range, strict)
    if strict and start is not None:
        current = start
    elif mode == "keys":
        current = left[0]
    else:
        pick = min if mode == "harder" else max
        current = pick(left, key=lambda t: ((t.get("energy") or 0), (t.get("bpm") or 0)))
    out = [current]
    left.remove(current)
    while left:
        current = _pick(current, left, lambda t, current=current: _fit(current, t, mode, bpm_range), bpm_range, strict)
        out.append(current)
        left.remove(current)
    return out
