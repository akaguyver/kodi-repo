"""Music the phone can stream from other places: Kodi on another device (such as the Xbox), the person's own music
server (Subsonic-style, such as Navidrome, or Jellyfin), and Audius.

Each source turns into tracks with a url to play (and headers, for Kodi's password) plus what's known about them.
fetch(url, headers) and post(url, body, headers) return the reply's bytes, so tests stand in for the network.
"""
import base64
import hashlib
import json
import os
import random
import re

try:
    from urllib.parse import quote, urlencode
except ImportError:
    from urllib import quote, urlencode

import djkeys
import musictags

AUDIUS_HOSTS = "https://api.audius.co"
APP_NAME = "Sortovia"
KODI_PAGE = 500


class SourceError(Exception):
    """A source can't be reached or refused the password."""


def _json(raw):
    return json.loads(raw.decode("utf-8", "replace"))


def _track(artist, title, url, headers=None, bpm=0, key="", genre="", source=""):
    out = {"artist": " ".join((artist or "").split()), "title": " ".join((title or "").split()), "url": url,
           "headers": headers or {}, "genre": genre or "", "path": "", "cues": [], "source": source}
    out.update(djkeys.dj_info({"bpm": bpm, "key": key}))
    return out


# ---------- Kodi (the Xbox) ----------

def kodi_base(host, port):
    host = (host or "").strip().rstrip("/")
    if not host.startswith("http"):
        host = "http://" + host
    if port and not re.search(r":\d+$", host):
        host += ":%s" % port
    return host


def kodi_headers(user, password):
    token = base64.b64encode(("%s:%s" % (user or "kodi", password or "")).encode()).decode()
    return {"Authorization": "Basic " + token}


def _kodi_call(post, base, headers, method, params):
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
    wanted = dict(headers, **{"Content-Type": "application/json"})
    raw = post(base + "/jsonrpc", body, wanted)
    try:
        reply = _json(raw)
    except ValueError:
        raise SourceError("Kodi refused the user name or password, or this isn't Kodi's web server.")
    if "error" in reply:
        raise SourceError("Kodi: %s" % (reply["error"].get("message") or "error"))
    return reply.get("result") or {}


def kodi_songs(post, host, port, user, password):
    """Every song in Kodi's music library, each playable over Kodi's web server."""
    base, headers = kodi_base(host, port), kodi_headers(user, password)
    properties = ["title", "artist", "file", "genre", "bpm"]
    out, start = [], 0
    while True:
        params = {"properties": properties, "limits": {"start": start, "end": start + KODI_PAGE}}
        try:
            result = _kodi_call(post, base, headers, "AudioLibrary.GetSongs", params)
        except SourceError:
            if "bpm" not in properties:
                raise
            properties.remove("bpm")  # Kodi before 19 has no BPM field
            continue
        songs = result.get("songs") or []
        for song in songs:
            artist = song.get("artist")
            artist = ", ".join(artist) if isinstance(artist, list) else artist
            genre = song.get("genre")
            out.append(_track(artist, song.get("title"), base + "/vfs/" + quote(song.get("file") or "", safe=""),
                              headers, song.get("bpm") or 0, "", ", ".join(genre) if isinstance(genre, list) else genre,
                              "kodi"))
            out[-1]["path"] = re.split(r"[\\/]", song.get("file") or "")[-1]
        total = (result.get("limits") or {}).get("total", 0)
        start += KODI_PAGE
        if not songs or start >= total:
            return out


# ---------- the person's own server ----------

def subsonic_query(user, password, **more):
    """Subsonic's sign-in for each request: a salted hash of the password, never the password itself."""
    salt = "%08x" % random.getrandbits(32)
    query = {"u": user, "t": hashlib.md5((password + salt).encode()).hexdigest(), "s": salt, "v": "1.16.1",
             "c": APP_NAME, "f": "json"}
    query.update(more)
    return urlencode(query)


def subsonic_search(fetch, url, user, password, artist, title):
    base = url.rstrip("/")
    data = _json(fetch(base + "/rest/search3?" + subsonic_query(user, password, query="%s %s" % (artist, title),
                                                                 songCount=20, albumCount=0, artistCount=0), {}))
    reply = data.get("subsonic-response") or {}
    if reply.get("status") != "ok":
        raise SourceError("Music server: %s" % ((reply.get("error") or {}).get("message") or "refused"))
    out = []
    for song in (reply.get("searchResult3") or {}).get("song") or []:
        stream = base + "/rest/stream?" + subsonic_query(user, password, id=song.get("id"), format="raw")
        out.append(_track(song.get("artist"), song.get("title"), stream, {}, song.get("bpm") or 0, "",
                          song.get("genre"), "server"))
        out[-1]["path"] = os.path.basename(song.get("path") or "")
    return out


def jellyfin_login(post, url, user, password):
    """(token, user id) for a Jellyfin server."""
    header = 'MediaBrowser Client="%s", Device="Android", DeviceId="sortovia-phone", Version="1"' % APP_NAME
    raw = post(url.rstrip("/") + "/Users/AuthenticateByName", json.dumps({"Username": user, "Pw": password}),
               {"Content-Type": "application/json", "X-Emby-Authorization": header})
    try:
        data = _json(raw)
    except ValueError:
        raise SourceError("Jellyfin refused the user name or password.")
    if not data.get("AccessToken"):
        raise SourceError("Jellyfin refused the user name or password.")
    return data["AccessToken"], (data.get("User") or {}).get("Id", "")


def jellyfin_search(fetch, url, token, user_id, artist, title):
    base = url.rstrip("/")
    query = urlencode({"searchTerm": title, "IncludeItemTypes": "Audio", "Recursive": "true", "Limit": 30,
                       "Fields": "Path,Genres"})
    data = _json(fetch(base + "/Users/%s/Items?%s" % (user_id, query), {"X-Emby-Token": token}))
    out = []
    for item in data.get("Items") or []:
        stream = base + "/Audio/%s/stream?static=true&api_key=%s" % (item.get("Id"), token)
        out.append(_track(", ".join(item.get("Artists") or []) or item.get("AlbumArtist"), item.get("Name"), stream,
                          {}, 0, "", ", ".join(item.get("Genres") or []), "server"))
        out[-1]["path"] = os.path.basename(item.get("Path") or "")
    return out


# ---------- Audius ----------

def audius_host(fetch):
    """One of Audius's servers. They're listed at a fixed address, as they can change."""
    hosts = _json(fetch(AUDIUS_HOSTS, {})).get("data") or []
    if not hosts:
        raise SourceError("Audius listed no servers")
    return hosts[0].rstrip("/")


AUDIUS_GENRES = ("Electronic", "Dubstep", "Drum & Bass", "House", "Deep House", "Tech House", "Techno", "Trance",
                 "Trap", "Future Bass", "Moombahton", "Downtempo", "Lo-Fi", "Hip-Hop/Rap", "R&B/Soul", "Funk",
                 "Experimental", "Ambient", "Pop", "Rock")


def audius_search(fetch, host, artist, title):
    data = _json(fetch(host + "/v1/tracks/search?" + urlencode({"query": ("%s %s" % (artist, title)).strip(), "app_name": APP_NAME}), {}))
    return _audius_tracks(host, data)


def audius_trending(fetch, host, genre=""):
    """What's being played most on Audius this week, in one genre (AUDIUS_GENRES) or all."""
    query = {"app_name": APP_NAME}
    if genre:
        query["genre"] = genre
    return _audius_tracks(host, _json(fetch(host + "/v1/tracks/trending?" + urlencode(query), {})))


def _audius_tracks(host, data):
    out = []
    for item in data.get("data") or []:
        if item.get("is_streamable") is False:
            continue
        named, by = item.get("title") or "", (item.get("user") or {}).get("name") or ""
        head, _, tail = named.partition(" - ")
        artists = by
        if tail:  # "GRiZ x The Sponges - Volume": the artists named in the title count as well as the uploader
            names = [by] + re.split(r"(?i)\s+x\s+|,\s*", head)
            named, artists = tail, ", ".join(n for i, n in enumerate(names) if n and n.lower() not in
                                             [m.lower() for m in names[:i]])
        url = host + "/v1/tracks/%s/stream?app_name=%s" % (item.get("id"), APP_NAME)
        found = _track(artists, named, url, {}, item.get("bpm") or 0, item.get("musical_key") or "",
                       item.get("genre"), "audius")
        found["tags"] = [t for t in [item.get("genre"), item.get("mood")] + re.split(r"[,#]", item.get("tags") or "") if t and t.strip()]
        out.append(found)
    return out


# ---------- tags read over the network ----------

def remote_tags(fetch_range, url, headers, block=64 * 1024, most_reads=12):
    """A file's tags (musictags.read_tags) read over HTTP with range requests, for the key, BPM and cue points.
    fetch_range(url, headers, start, end) returns (bytes, total size or 0)."""
    blocks, size = {}, [0]

    def read_at(offset, count):
        out = b""
        while count > 0:
            number = offset // block
            if number not in blocks:
                if len(blocks) >= most_reads:
                    break
                data, total = fetch_range(url, headers, number * block, number * block + block - 1)
                blocks[number] = data
                size[0] = size[0] or total
            part = blocks[number][offset - number * block:offset - number * block + count]
            if not part:
                break
            out += part
            offset += len(part)
            count -= len(part)
        return out
    read_at(0, 1)
    return musictags.read_tags(read_at, size[0] or block)
