"""Tools for developing and testing Sortovia. A regular user wouldn't use these, so this file and
youtube_test.py aren't in public builds. Having this file also keeps a device on the dev update
channel. bind() gives these functions everything in default.py, so they can use its helpers."""


OWN = ("bind", "OWN", "menu_items", "actions", "youtube_test", "music_library_files", "send_music_library",
       "_remove_duplicate_songs")


def bind(names):
    globals().update((k, v) for k, v in names.items() if not k.startswith("__") and k not in OWN)


def youtube_test(dlg):
    """Could this device download from YouTube without a phone? See youtube_test.py."""
    import realdebrid
    import youtube_test as yt
    if not dlg.yesno(ADDON, "This test checks whether this device could download from YouTube by itself, without a phone.\n\n"
                     "It downloads the official yt-dlp tool from GitHub (about 3 MB), checks it against its published "
                     "checksum, and asks YouTube about one test video. No video is downloaded, and no sign-in or cookies "
                     "are used. The tool is deleted afterwards.\n\nIt can take up to 3 minutes.",
                     nolabel="Cancel", yeslabel="Run the test"):
        return
    prog = xbmcgui.DialogProgress()
    prog.create(ADDON, "Starting...")
    try:
        folder = xbmcvfs.translatePath("special://temp/")  # for Python's own file functions, not Kodi's
        works, lines = yt.run(lambda url: realdebrid._http(url, timeout=120), folder, lambda m: prog.update(0, m))
    finally:
        _close(prog)
    for line in lines:
        log("youtube test: %s" % line)
    dlg.textviewer("%s - YouTube test" % ADDON, "\n".join(lines) + "\n\nThese results are also in Kodi's log. To share them, "
                   "use Help & settings > Send a problem report.")


def music_library_files():
    """[(file name, bytes)]: Kodi's music database now, and the newest saved copies, to compare when troubleshooting."""
    name = backup.newest_db(backup.MUSIC_DB)
    files = [("music-now.db", name[1])] if name[0] and name[1] else []
    copies = [r for r in letter_backups() if backup.MUSIC_DB in (r[2].get("db") or "")][:4]
    for folder, stamp, info in copies:
        kept = [n for n in info["db"].split(", ") if n.startswith(backup.MUSIC_DB)][0]
        files.append(("music-%s-%s.db" % (info.get("drive", "x"), stamp.replace(" ", "-")), backup._read(folder + stamp + "/" + kept)))
    return files


def send_music_library(dlg):
    if not (load_cache(data_file("phone.json")).get("dav") or {}).get("pass"):
        dlg.ok(ADDON, "Connect your phone first: start sharing on it, then send Kodi's log from Help & settings once.")
        return False
    try:
        files = music_library_files()
        status = send_logs("music library", dlg, files=files) if files else "there's no music library yet"
    except Exception as e:
        log("send music library: %s" % e)
        status = str(e)
    log("send music library: %s" % status)
    dlg.ok(ADDON, "Music library copies: %s." % status)
    return True


def _remove_duplicate_songs(dlg):
    """Repair: remove songs listed more than once for one file, then clean the library."""
    import missing
    name = backup.newest_db(backup.MUSIC_DB)[0]
    if not name:
        dlg.ok(ADDON, "Kodi doesn't have a music library yet.")
        return 0
    prog, stage = _stages("Removing duplicate songs...")
    try:
        stage(0, 20, "Saving a copy of your music library...")(0, 1, "")
        if not _save_music_copy():
            _close(prog)
            dlg.ok(ADDON, "Couldn't save a copy of your music library first, so nothing was changed.")
            return 0
        before = _song_count()
        stage(20, 50, "Removing duplicates...")(0, 1, "")
        removed = _remove_duplicate_songs_now()
        stage(50, 100, "Cleaning the library...")(0, 1, "")
        _run_music_job(lambda: missing._rpc("AudioLibrary.Clean", {"showdialogs": False}), limit=180, is_scan=False)
    except Exception as e:
        log("remove duplicates: %s" % e)
        _close(prog)
        dlg.ok(ADDON, "Couldn't remove duplicates: %s\nYour music files weren't touched." % e)
        return 0
    _close(prog)
    log("remove duplicates: %d removed, %d songs before, %d now" % (removed, before, _song_count()))
    dlg.ok(ADDON, "Removed %d duplicate songs. Your library now has %d songs. No music files were touched." % (removed, _song_count()))
    return removed


def menu_items():
    return [
        _item("Test YouTube without a phone", "Checks whether this device could download from YouTube by itself. "
              "Downloads no videos.", "DefaultAddonVideo.png", action="youtube_test"),
        _item("Send Kodi's log to my phone now", "The phone must be sharing.", "DefaultIconInfo.png", action="logs"),
        _item("Send the music library to my phone", "Kodi's music database and its saved copies, to compare them.",
              "DefaultIconInfo.png", action="music_send"),
        _item("Remove duplicate songs", "Keeps the newest entry for each file and adds up its play counts. Saves a "
              "copy first.", "DefaultMusicAlbums.png", action="music_dedupe")]


def actions():
    return {"youtube_test": lambda dlg, spath: youtube_test(dlg),
            "logs": lambda dlg, spath: dlg.ok(ADDON, "Log: %s." % send_logs("manual", dlg)),
            "music_send": lambda dlg, spath: send_music_library(dlg),
            "music_dedupe": lambda dlg, spath: one_at_a_time(_remove_duplicate_songs)(dlg)}
