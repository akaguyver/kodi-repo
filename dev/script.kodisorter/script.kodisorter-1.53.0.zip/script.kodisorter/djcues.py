"""Where a DJ would mix: a track's beat grid, its phrases, and the points to bring it in and take it out.

Two ways in. Cue points already saved by Mixed In Key or Serato (the "Serato Markers2" tag) or rekordbox (its
collection XML), and an analysis of the audio itself. The analysis gets two loudness curves, frames per second
apart: the whole sound and the bass (the app's Java side decodes the audio and makes them). From those it finds
the tempo and the beats, which beat starts each bar, and where the energy changes at phrase starts (every 8 bars),
as a DJ hears it: the intro, the drop, the breakdown, the outro.

Pure Python, so it runs on the phone through Chaquopy and in tests without either.
"""
import base64
import math
import re
import struct
from xml.etree import ElementTree

RATE = 100  # loudness frames per second
BEATS_PER_BAR = 4
PHRASE_BARS = 8
LOWEST_BPM, HIGHEST_BPM = 70.0, 180.0
LIFT, DROP = 1.3, 0.75  # how much louder or quieter the next phrase must be to count as a change


# ---------- cue points saved by other software ----------

def _b64(text):
    text = re.sub(r"\s+", "", text or "").rstrip("=")
    if len(text) % 4 == 1:
        text = text[:-1]  # Serato pads its base64 oddly
    return base64.b64decode(text + "=" * (-len(text) % 4))


def serato_cues(encoded):
    """[seconds] from a "Serato Markers2" tag (as base64 text, which is how musictags passes it on), in order.
    Mixed In Key writes its cue points here when it's set to save cues for Serato."""
    try:
        data = _b64(encoded)
        at = data.find(b"Serato Markers2\x00")
        if at >= 0:  # FLAC and MP4 keep the ID3 frame's header, and its body is base64 once more
            data = data[at + len(b"Serato Markers2\x00"):]
            data = _b64(data[2:].decode("ascii", "ignore")) if data[:2] == b"\x01\x01" else data
    except (ValueError, TypeError):
        return []
    cues, pos = [], 2 if data[:2] == b"\x01\x01" else 0  # the entries follow a version number
    try:
        while pos < len(data):
            end = data.find(b"\x00", pos)
            if end <= pos:
                break
            kind = data[pos:end].decode("ascii", "replace")
            size = struct.unpack(">I", data[end + 1:end + 5])[0]
            body = data[end + 5:end + 5 + size]
            pos = end + 5 + size
            if kind == "CUE" and len(body) >= 6:
                cues.append(struct.unpack(">I", body[2:6])[0] / 1000.0)
    except (struct.error, IndexError):
        pass
    return sorted(cues)


def rekordbox_cues(xml_text):
    """{file name in lower case: [seconds]} from a rekordbox collection XML (File > Export Collection in xml
    format). Hot cues and memory cues both count."""
    out = {}
    try:
        root = ElementTree.fromstring(xml_text)
    except ElementTree.ParseError:
        return out
    for track in root.iter("TRACK"):
        location = track.get("Location") or ""
        marks = [m.get("Start") for m in track.findall("POSITION_MARK")]
        times = sorted(set(float(m) for m in marks if m and re.match(r"^\d+(\.\d+)?$", m)))
        if location and times:
            from urllib.parse import unquote
            out[unquote(location.replace("\\", "/")).rsplit("/", 1)[-1].lower()] = times
    return out


# ---------- analysis ----------

def _onsets(values):
    """How sharply the loudness rises at each frame: where drums hit."""
    logs = [math.log(v + 1e-6) for v in values]
    return [0.0] + [max(0.0, logs[i] - logs[i - 1]) for i in range(1, len(logs))]


def _comb(onset, period, offset):
    """The onset strength on a grid of beats `period` frames apart, starting at `offset`."""
    total, at, n = 0.0, offset, len(onset)
    while at < n - 1:
        i = int(at)
        frac = at - i
        total += onset[i] * (1 - frac) + onset[i + 1] * frac
        at += period
    return total


def _best_phase(onset, period):
    steps = max(1, int(period))
    return max((_comb(onset, period, float(p)), p) for p in range(steps))[1]


def tempo(onset, rate=RATE, hint=0.0):
    """The tempo in BPM. A hint (such as the BPM tag) narrows the search to near it, or half or double."""
    lags = range(int(60.0 * rate / HIGHEST_BPM), int(60.0 * rate / LOWEST_BPM) + 1)
    if hint:
        while hint > HIGHEST_BPM:
            hint /= 2
        while hint < LOWEST_BPM:
            hint *= 2
        lags = [lag for lag in lags if abs(60.0 * rate / lag - hint) / hint < 0.06] or list(lags)
    n = len(onset)
    mean = sum(onset) / max(n, 1)
    centred = [v - mean for v in onset]
    best = max(lags, key=lambda lag: sum(centred[i] * centred[i + lag] for i in range(0, n - lag, 2)))
    coarse = 60.0 * rate / best
    candidates = [coarse * (1 + k / 1000.0) for k in range(-20, 21)]  # refine to about 0.1%
    if hint and abs(hint - round(hint)) > 0.001:
        candidates.append(hint)
    def strength(bpm, step=2):
        return max(_comb(onset, 60.0 * rate / bpm, float(p)) for p in range(0, int(60.0 * rate / bpm), step))
    best = max(candidates, key=strength)
    best = max([best * (1 + k / 10000.0) for k in range(-10, 11)], key=lambda bpm: strength(bpm, 1))
    # Without a hint, a track can read at half its tempo (drum & bass as 87). Its bars and phrases still fall on
    # the right beats, and tempo matching counts half and double time, so the mix points stay right.
    return best


def _mean(values, a, b):
    part = values[max(0, a):max(0, b)]
    return sum(part) / len(part) if part else 0.0


# ---------- key, energy and the waveform ----------

# Krumhansl and Kessler's key profiles: how strongly each note of the scale belongs to a major or minor key.
MAJOR_PROFILE = (6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
MINOR_PROFILE = (6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)
WAVE_POINTS = 400


def _correlation(a, b):
    ma, mb = sum(a) / len(a), sum(b) / len(b)
    top = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    under = math.sqrt(sum((x - ma) ** 2 for x in a) * sum((y - mb) ** 2 for y in b))
    return top / under if under else 0.0


def detect_key(chroma):
    """(Camelot code, strength 0-1) from how much of each note (C first) the track holds; ("", 0) if unclear.
    Analyzer.java adds the notes up over the whole track. Mixed In Key's own key, when tagged, is better."""
    import djkeys
    if not chroma or len(chroma) != 12 or sum(chroma) <= 0:
        return "", 0.0
    best = max((_correlation(chroma, [profile[(note - tonic) % 12] for note in range(12)]), tonic, minor)
               for tonic in range(12) for minor, profile in ((False, MAJOR_PROFILE), (True, MINOR_PROFILE)))
    strength, tonic, minor = best
    if strength < 0.3:
        return "", round(max(strength, 0.0), 2)
    return djkeys.camelot(djkeys.NAMES[tonic] + ("m" if minor else "")), round(strength, 2)


def estimate_energy(energy, bass, bpm):
    """A rough 1-10 energy from how loud the loud parts are, how much of that is bass, and the tempo. Mixed In
    Key's energy, when tagged, is better: this is only for tracks without one."""
    if not energy:
        return 0
    loud = sorted(energy)[int(len(energy) * 0.8)]
    db = 20 * math.log10(max(loud, 1e-6))
    loudness = min(1.0, max(0.0, (db + 24) / 16.0))  # -24 dB quiet, -8 dB a loud club master
    top = [i for i, v in enumerate(energy) if v >= loud * 0.7] or range(len(energy))
    share = sum(bass[i] for i in top) / max(sum(energy[i] for i in top), 1e-9)
    bassy = min(1.0, max(0.0, (share - 0.2) / 0.5))
    tempo = bpm * 2 if bpm and bpm < 95 else bpm  # 87 for drum & bass is really 174
    fast = min(1.0, max(0.0, ((tempo or 120) - 85) / 80.0))
    return int(max(1, min(10, round(1 + 9 * (0.55 * loudness + 0.25 * bassy + 0.2 * fast)))))


def waveform(energy, bass, points=WAVE_POINTS):
    """([height 0-1], [bass share 0-1]) at `points` places along the track, for drawing it."""
    n = len(energy)
    if not n:
        return [], []
    peak = max(energy) or 1.0
    heights, shares = [], []
    for i in range(points):
        a = int(i * n / points)
        b = max(a + 1, int((i + 1) * n / points))
        part = energy[a:b]
        heights.append(round(max(part) / peak, 3))
        shares.append(round(min(1.0, sum(bass[a:b]) / max(sum(part), 1e-9)), 2))
    return heights, shares


# ---------- where a DJ would mix ----------

def analyse(energy, bass, rate=RATE, bpm_hint=0.0, saved_cues=(), chroma=None):
    """The DJ details of one track, from its loudness curves. Times are in seconds.

    {"bpm", "first_beat", "beat" (seconds per beat), "bars": [start of each bar], "mix_in", "mix_out",
     "intro_end", "cues": [{"time", "label"}], "from_file": bool}

    mix_in: where to start this track when bringing it in (its first downbeat, or the first saved cue).
    mix_out: where to start bringing the next one in (the outro's first phrase, or a saved cue late on).
    """
    n = len(energy)
    if n < rate * 10:
        raise ValueError("too short to analyse")
    onset = [a + b for a, b in zip(_onsets(energy), _onsets(bass))]
    bpm = tempo(onset, rate, bpm_hint)
    period = 60.0 * rate / bpm
    phase = _best_phase(onset, period)
    loud = sorted(energy)[n // 2] * 0.1
    first = phase
    while first < n and _mean(energy, int(first), int(first + period)) < loud:
        first += period
    bar = period * BEATS_PER_BAR

    def bar_energy(start):
        return _mean(energy, int(start), int(start + bar))

    # The downbeat is the beat where the energy changes happen: sections start on the first beat of a bar.
    # One beat either side of each bar line, so a change shows sharply at the right beat.
    def change_score(offset):
        score, at = 0.0, first + offset * period + bar
        while at + period < n:
            score += abs(_mean(energy, int(at), int(at + period)) - _mean(energy, int(at - period), int(at)))
            at += bar
        return score
    downbeat = first + max(range(BEATS_PER_BAR), key=change_score) * period
    bars = []
    at = downbeat
    while at < n:
        bars.append(at)
        at += bar
    peak = max(bar_energy(b) for b in bars) or 1.0

    phrases = bars[::PHRASE_BARS]
    changes = []
    for i in range(1, len(phrases)):
        if phrases[i] + PHRASE_BARS * bar > n:
            break  # the track ends inside this phrase
        before = _mean(energy, int(phrases[i - 1]), int(phrases[i]))
        after = _mean(energy, int(phrases[i]), int(phrases[i] + PHRASE_BARS * bar))
        if before and after / before >= LIFT:
            changes.append((phrases[i], "lift"))
        elif before and after / before <= DROP:
            changes.append((phrases[i], "drop"))
    intro_end = next((t for t, kind in changes if kind == "lift"), phrases[min(2, len(phrases) - 1)])
    last_beat = n - period
    late = [t for t, kind in changes if kind == "drop" and t > n * 0.6 and last_beat - t >= 8 * bar]
    mix_out = late[-1] if late else max(downbeat, last_beat - 32 * bar)
    mix_in = downbeat

    from_file = False
    saved = sorted(t * rate for t in saved_cues if 0 <= t * rate < n)
    if saved:
        from_file = True
        snap = lambda t: min(bars, key=lambda b: abs(b - t))  # noqa: E731
        mix_in = snap(saved[0])
        late_saved = [t for t in saved if t > n * 0.6 and last_beat - t >= 8 * bar]
        if late_saved:
            mix_out = snap(late_saved[-1])

    def level(t):
        return max(1, min(10, int(round(10 * _mean(energy, int(t), int(t + PHRASE_BARS * bar)) / peak))))

    def rising(start):
        """A build-up: the phrase's last two bars much louder than its first two (a riser, a snare roll)."""
        early = _mean(energy, int(start), int(start + 2 * bar))
        late = _mean(energy, int(start + (PHRASE_BARS - 2) * bar), int(start + PHRASE_BARS * bar))
        return early > 0 and late / early >= 1.25

    marks = {}  # frame -> name, so two names never land on one spot
    after_break = False
    lifts = set(t for t, kind in changes if kind == "lift")
    for t, kind in changes:
        if kind == "lift" and rising(t) and any(abs(u - (t + PHRASE_BARS * bar)) < 1 for u in lifts):
            marks[t] = "Buildup"  # it climbs into the next phrase, which is the drop
        elif kind == "lift":
            marks[t] = "Intro ends" if t == intro_end and not after_break else "Drop" if after_break or level(t) >= 9 else "Lift"
            after_break = False
        else:
            marks[t] = "Outro" if t == mix_out else "Breakdown"
            after_break = True
    for i in range(1, len(phrases)):
        if phrases[i] in marks and marks[phrases[i]] in ("Drop", "Lift") and phrases[i - 1] not in marks and rising(phrases[i - 1]):
            marks[phrases[i - 1]] = "Buildup"
    if intro_end not in marks and intro_end > mix_in:
        marks[intro_end] = "Intro ends"
    cues = [{"time": round(mix_in / rate, 3), "label": "Mix in"}]
    cues += [{"time": round(t / rate, 3), "label": "%s, energy %d" % (name, level(t))} for t, name in marks.items() if t != mix_in]
    if mix_out not in marks:
        cues.append({"time": round(mix_out / rate, 3), "label": "Mix out"})
    heights, shares = waveform(energy, bass)
    camelot, strength = detect_key(chroma)
    return {"bpm": round(bpm, 2), "first_beat": round(first / rate, 3), "beat": round(period / rate, 5),
            "bars": [round(b / rate, 3) for b in bars], "mix_in": round(mix_in / rate, 3),
            "mix_out": round(mix_out / rate, 3), "intro_end": round(intro_end / rate, 3),
            "cues": sorted(cues, key=lambda c: c["time"]), "from_file": from_file,
            "duration": round(n / rate, 2), "waveform": heights, "bass_share": shares,
            "key": camelot, "key_strength": strength, "energy_estimate": estimate_energy(energy, bass, bpm)}


def mix_bars(outgoing, incoming, most=32, least=8):
    """How many bars the two tracks play together: what's left of the outgoing track after its mix-out point,
    up to the incoming track's intro, in whole phrases of 8 (at least 8, at most 32)."""
    out_left = (outgoing["bars"][-1] - outgoing["mix_out"]) / (outgoing["beat"] * BEATS_PER_BAR) if outgoing["bars"] else most
    intro = (incoming["intro_end"] - incoming["mix_in"]) / (incoming["beat"] * BEATS_PER_BAR)
    room = min(out_left, intro if intro >= least else most)
    return int(max(least, min(most, room // PHRASE_BARS * PHRASE_BARS)))
