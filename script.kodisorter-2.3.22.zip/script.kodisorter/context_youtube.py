"""Hold down a video in Tutorials or Music and DJing: its YouTube channel, upload date, more from the channel,
the rest of its series."""
import sys

import xbmc

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

if __name__ == "__main__":
    path = sys.listitem.getPath() or xbmc.getInfoLabel("ListItem.FileNameAndPath")
    # 2.3.19: how Kodi spells this folder and what it shows, to match watched marks to the listing
    xbmc.log("[Sortovia] details: folder %r, item %r, playcount %r, overlay %r, resume %r" % (
        xbmc.getInfoLabel("Container.FolderPath"), path, xbmc.getInfoLabel("ListItem.PlayCount"),
        xbmc.getInfoLabel("ListItem.Overlay"), xbmc.getInfoLabel("ListItem.PercentPlayed")), xbmc.LOGINFO)
    xbmc.executebuiltin("RunPlugin(plugin://script.kodisorter/?action=yt_video&path=%s)" % quote(path.encode("utf-8"), ""))
